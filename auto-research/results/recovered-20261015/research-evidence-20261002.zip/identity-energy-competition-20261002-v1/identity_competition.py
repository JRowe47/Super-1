"""Identity-safe energy competition graft; usefulness and novelty unproven.

Two scalar mixing coefficients, one per rotation bank. The local learned
transport remains exact at zero. Centered and global-only modes are matched.
"""
import torch
from torch import nn
import pair_energy_phase_candidate as source


class IdentityCompetitionLM(source.PairEnergyPhaseLM):
    def __init__(self,width,dynamic=True,mode='centered'):
        if mode not in ('centered','global_only'):
            raise ValueError('Unregistered competition mode')
        super().__init__(width,dynamic)
        self.competition_mix=nn.Parameter(torch.zeros(2))
        self.competition_mode=mode

    def angle_for(self,state,drive,angle,gain,offset):
        local=super().angle_for(state,drive,angle,gain,offset)
        if gain is None:
            return local
        pair=torch.roll(state,shifts=offset,dims=-1).reshape(len(state),-1,2)
        target=torch.roll(drive,shifts=offset,dims=-1).reshape(len(state),-1,2)
        se=pair.square().sum(-1); de=target.square().sum(-1)
        delta=torch.log(se+1e-6)-torch.log(de+1e-6)
        mean=delta.mean(-1,keepdim=True)
        contrast=(delta-mean).tanh() if self.competition_mode=='centered' else mean.tanh().expand_as(delta)
        cross=pair[...,0]*target[...,1]-pair[...,1]*target[...,0]
        denominator=torch.sqrt(se*de+1e-6)
        weight=self.energy_gain if offset==0 else self.second_energy_gain
        competitive=angle+gain*(cross/denominator+weight*contrast).tanh()
        bank=0 if offset==0 else 1
        return local+self.competition_mix[bank]*(competitive-local)
