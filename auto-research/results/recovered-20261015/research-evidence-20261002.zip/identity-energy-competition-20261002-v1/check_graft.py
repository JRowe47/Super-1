"""Trained-checkpoint graft feasibility, using synthetic inputs only."""
import argparse
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import torch
import torch.nn.functional as F


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(ok,message):
    if not ok:raise RuntimeError(message)


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def main(args):
    root=Path(__file__).resolve().parent
    require(Path('/Volumes/SP AI 01_16').is_mount()
            and Path('/Volumes/SP AI 01_16/CodexWorkspaces') in root.parents,'SSD required')
    source=Path(args.source).resolve(strict=True)
    archive=Path(args.archive).resolve(strict=True)
    require(sha(archive)==args.archive_sha256,'Archive seal mismatch')
    files=json.loads(archive.read_text())['manifest']['files']
    names=('pair_energy_phase_candidate.py','noncommuting_phase_candidate.py','phase_transition_language.py',
           'capacity_sweep.py','direct_distance.py','run.py')
    pins={n:files['code/'+n]['sha256'] for n in names}
    for n,h in pins.items():require(sha(source/n)==h,'Source seal mismatch')
    require(sha(args.checkpoint)==args.checkpoint_sha256,'Checkpoint seal mismatch')
    save(root/'PROTOCOL.json',{'source_pins':pins,'archive_sha256':args.archive_sha256,
         'checkpoint':args.checkpoint,'checkpoint_sha256':args.checkpoint_sha256,
         'driver_sha256':sha(__file__),'module_sha256':sha(root/'identity_competition.py'),
         'seed':47103411,'dtype':'FP32','width':256,'batch':2,'context':32,
         'added_parameters':2,'modes':['centered','global_only'],
         'scope':'Synthetic trained-checkpoint graft compatibility, not language accuracy or novelty',
         'task_text_reads':0,'official_test_reads':0})
    sys.path.insert(0,str(source)); energy=importlib.import_module('pair_energy_phase_candidate')
    from identity_competition import IdentityCompetitionLM
    for n in names:require(Path(sys.modules[Path(n).stem].__file__).resolve()==source/n,'Imported closure differs')
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    torch.manual_seed(47103411)
    state=torch.load(args.checkpoint,map_location='cpu',weights_only=True)
    base=energy.PairEnergyPhaseLM(256);base.load_state_dict(state,strict=True)
    require(all(v.dtype==torch.float32 and torch.isfinite(v).all() for v in state.values()),'Invalid checkpoint state')
    tokens=torch.randint(256,(2,32)); targets=torch.randint(256,(2,32))
    probe=torch.randn(2,32,256)
    expected=base(tokens); (expected*probe).sum().backward()
    results=[]
    for mode in ('centered','global_only'):
        model=IdentityCompetitionLM(256,mode=mode)
        loaded=model.load_state_dict(state,strict=False)
        require(loaded.missing_keys==['competition_mix'] and not loaded.unexpected_keys,'Graft keys differ')
        actual=model(tokens);require(torch.equal(actual,expected),'Identity forward not exact')
        (actual*probe).sum().backward()
        require(all(torch.equal(p.grad,dict(model.named_parameters())[n].grad) for n,p in base.named_parameters()),'Inherited native gradient differs')
        require(torch.isfinite(model.competition_mix.grad).all() and (model.competition_mix.grad!=0).all(),'Both mixing gradients must activate')
        gradients=model.competition_mix.grad.tolist()
        for n,p in model.named_parameters():p.requires_grad_(n=='competition_mix');p.grad=None
        inherited={n:v.clone() for n,v in model.state_dict().items() if n!='competition_mix'}
        optimizer=torch.optim.AdamW([model.competition_mix],lr=.001,foreach=False,fused=False)
        for _ in range(2):
            optimizer.zero_grad(set_to_none=True)
            F.cross_entropy(model(tokens).reshape(-1,256),targets.flatten()).backward()
            require(torch.isfinite(model.competition_mix.grad).all(),'Nonfinite mixing update')
            optimizer.step()
        require(all(torch.equal(v,model.state_dict()[n]) for n,v in inherited.items()),'Frozen inherited weights changed')
        changed=tokens.clone();changed[:,16:]=torch.randint(256,(2,16))
        require(torch.equal(model(tokens)[:,:16],model(changed)[:,:16]),'Causal prefix differs')
        results.append({'mode':mode,'identity_logits_exact':True,'inherited_native_gradients_exact':True,
                        'both_mix_gradients':gradients,'mix_only_finite_updates':2,
                        'inherited_weights_unchanged':True,'causal_prefix_exact':True})
    for n,h in pins.items():require(sha(source/n)==h,'Source changed during canary')
    require(sha(args.checkpoint)==args.checkpoint_sha256,'Checkpoint changed during canary')
    save(root/'REPORT.json',{'checks':results,'added_parameters':2,'added_FP32_weight_bytes':8,
                           'task_text_reads':0,'task_accuracy_untested':True,'novelty_unproven':True})
    print(json.dumps({'modes_passed':len(results),'task_text_reads':0}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ('source','archive','archive-sha256','checkpoint','checkpoint-sha256'):p.add_argument('--'+n,required=True)
    main(p.parse_args())
