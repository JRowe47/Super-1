"""Bounded identity-safe recurrent competition pilot; no resume or test reads."""
import argparse
import copy
import hashlib
import importlib
import json
import math
from pathlib import Path
import random
import sys
import traceback
import torch
import torch.nn.functional as F


def require(ok,message):
    if not ok:raise RuntimeError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def score(model,data,start,windows,context,batch):
    require(start>=0 and start+windows*context+1<=len(data),'Score bounds')
    model.eval(); losses=[]; fingerprint=hashlib.sha256()
    with torch.inference_mode():
        for i in range(0,windows,batch):
            starts=[start+j*context for j in range(i,min(i+batch,windows))]
            x=torch.stack([data[j:j+context] for j in starts]);y=torch.stack([data[j+1:j+context+1] for j in starts])
            logits=model(x)
            require(logits.dtype==torch.float32 and torch.isfinite(logits).all(),'Invalid logits')
            value=F.cross_entropy(logits.reshape(-1,256),y.flatten(),reduction='sum').item()
            require(math.isfinite(value),'Nonfinite score');losses.append(value)
            fingerprint.update(logits.contiguous().numpy().tobytes())
    return {'ce':math.fsum(losses)/(windows*context),'targets':windows*context,
            'batch_loss_sums':losses,'logits_sha256':fingerprint.hexdigest()}


def register(root,args):
    old=Path(args.previous_protocol).resolve(strict=True)
    require(sha(old)==args.previous_protocol_sha256,'Previous protocol changed')
    old_c=json.loads(old.read_text())
    canary=json.loads((root/'PROTOCOL.json').read_text())
    report=json.loads((root/'REPORT.json').read_text())
    require(len(report['checks'])==2 and all(r['identity_logits_exact'] and r['inherited_native_gradients_exact'] for r in report['checks']),'Graft canary not passed')
    for row in old_c['backbones']:require(sha(row['checkpoint'])==row['sha256'],'Frozen backbone changed')
    c={'hypothesis':'Pairwise relative-to-other-pairs energy competition improves frozen recurrent transport beyond a matched global-only energy signal.',
       'backbones':old_c['backbones'],'source':args.source,'source_pins':canary['source_pins'],
       'driver_sha256':sha(__file__),'module_sha256':sha(root/'identity_competition.py'),
       'canary_report_sha256':sha(root/'REPORT.json'),'previous_protocol_sha256':sha(old),
       'arms':['unchanged','centered','global_only'],'lrs':[.001,.003],
       'steps':200,'selection_interval':50,'batch':4,'context':128,'width':256,'threads':1,
       'confirmation':{'start':800000,'windows':256,'passes':2},
       'optimizer':{'lr_schedule':'constant','betas':[.9,.999],'eps':1e-8,'weight_decay':.01,'clip':1.,'foreach':False,'fused':False},
       'train_data':old_c['train_data'],'valid_data':old_c['valid_data'],
       'trainable_parameters':['competition_mix'],'added_parameters_per_adapted_arm':2,
       'target_exposures_per_trial':102400,'window_rng':'random.Random(source_seed+10000),same per arm/LR',
       'selection':'All12 trials complete; per seed/mode select by CE, step, LR; freeze six plus three unchanged controls before confirmation.',
       'advance_gate':'All9 exact duplicate FP32 metrics/logit hashes, centered strictly below global_only and unchanged in every seed.',
       'scope':'Frozen-backbone local byte pilot, not original hierarchy, full from-scratch training, word perplexity, matched FLOPs, globally pristine validation, novelty or SOTA.',
       'holdout_caveat':'Confirmation target bytes 800001..832768 are disjoint from this selection prefix and documented head/mechanism bands; the valid file was historically read.',
       'official_test_reads':0,'cloud_resources':0}
    # Keep the numeric selection region separate from the prose contract.
    c['selection_region']={'start':0,'windows':128}
    save(root/'LANGUAGE_PROTOCOL.json',c)
    print(json.dumps({'registered':True,'protocol_sha256':sha(root/'LANGUAGE_PROTOCOL.json'),'task_text_reads':0}))


def run(root,args):
    protocol=root/'LANGUAGE_PROTOCOL.json'
    require(sha(protocol)==args.protocol_sha256,'Protocol changed')
    c=json.loads(protocol.read_text())
    source=Path(c['source']).resolve(strict=True)
    def seals():
        require(sha(protocol)==args.protocol_sha256 and sha(__file__)==c['driver_sha256']
                and sha(root/'identity_competition.py')==c['module_sha256'],'Experiment source changed')
        require(sha(root/'REPORT.json')==c['canary_report_sha256'],'Canary report changed')
        for name,expected in c['source_pins'].items():require(sha(source/name)==expected,'Backbone source changed')
        for row in c['backbones']:require(sha(row['checkpoint'])==row['sha256'],'Backbone checkpoint changed')
    seals();require(args.authorize_training,'Training authorization missing')
    output=root/'language-run';output.mkdir(exist_ok=False)
    save(output/'EXECUTION.json',{'protocol_sha256':args.protocol_sha256,'driver_sha256':c['driver_sha256'],
         'runtime':{'python':sys.version,'torch':torch.__version__,'dtype':'FP32','device':'cpu'},
         'storage_policy':'All generated files/runtime outputs on mounted SSD; no iCloud fallback.',
         'official_test_reads':0})
    try:
        sys.path.insert(0,str(source)); energy=importlib.import_module('pair_energy_phase_candidate')
        from identity_competition import IdentityCompetitionLM
        for name in c['source_pins']:
            require(Path(sys.modules[Path(name).stem].__file__).resolve()==source/name,'Imported closure changed')
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
        def make(row,mode):
            model=IdentityCompetitionLM(c['width'],mode=mode if mode!='unchanged' else 'centered')
            state=torch.load(row['checkpoint'],map_location='cpu',weights_only=True)
            require(set(state)==set(model.state_dict())-{'competition_mix'},'Source state keys')
            require(all(v.device.type=='cpu' and v.dtype==torch.float32 and torch.isfinite(v).all()
                        and v.shape==model.state_dict()[n].shape for n,v in state.items()),'Invalid source tensor')
            loaded=model.load_state_dict(state,strict=False)
            require(loaded.missing_keys==['competition_mix'] and not loaded.unexpected_keys,'Invalid graft keys')
            for n,p in model.named_parameters():p.requires_grad_(n=='competition_mix' and mode!='unchanged')
            return model
        torch.manual_seed(47103411)
        synthetic=torch.randint(256,(2,32))
        for backbone in c['backbones']:
            reference=energy.PairEnergyPhaseLM(c['width'])
            reference.load_state_dict(torch.load(backbone['checkpoint'],map_location='cpu',weights_only=True),strict=True)
            with torch.no_grad():
                expected=reference(synthetic)
                for mode in ('centered','global_only'):
                    graft=make(backbone,mode)
                    require(torch.equal(expected,graft(synthetic)),'Trained checkpoint identity parity failed')
                    require(sum(p.numel() for p in graft.parameters() if p.requires_grad)==2,'Trainable count mismatch')
        save(output/'INITIALIZATION.json',{'all3_checkpoint_identity_logits_exact':True,
              'trainable_parameters_per_adapted_arm':2,'task_text_reads_before_check':0})
        data={}
        for split in ('train','valid'):
            spec=c[split+'_data'];raw=Path(spec['path']).read_bytes()
            require(hashlib.sha256(raw).hexdigest()==spec['sha256'],'Task data changed')
            data[split]=torch.tensor(list(raw),dtype=torch.long);del raw
        save(output/'DATA_RECEIPTS.json',{split:c[split+'_data'] for split in data})
        rows=[];frozen=[]
        region=c['selection_region']
        for backbone in c['backbones']:
            seed=backbone['seed'];rng=random.Random(seed+10000)
            starts=[[rng.randrange(len(data['train'])-c['context']) for _ in range(c['batch'])] for _ in range(c['steps'])]
            window_sha=hashlib.sha256(json.dumps(starts).encode()).hexdigest()
            baseline=make(backbone,'unchanged')
            base_score=score(baseline,data['valid'],region['start'],region['windows'],c['context'],c['batch'])
            path=output/('%s-unchanged.pt'%seed);torch.save(baseline.state_dict(),path)
            frozen.append({'seed':seed,'arm':'unchanged','lr':None,'step':0,'checkpoint':str(path),'sha256':sha(path),'selection':base_score})
            for mode in ('centered','global_only'):
                options=[]
                for lr in c['lrs']:
                    model=make(backbone,mode);o=c['optimizer']
                    optimizer=torch.optim.AdamW([model.competition_mix],lr=lr,betas=tuple(o['betas']),eps=o['eps'],
                                                weight_decay=o['weight_decay'],foreach=False,fused=False)
                    best=None
                    for step,indices in enumerate(starts,1):
                        x=torch.stack([data['train'][i:i+c['context']] for i in indices]);y=torch.stack([data['train'][i+1:i+c['context']+1] for i in indices])
                        optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model(x).reshape(-1,256),y.flatten());loss.backward()
                        require(torch.isfinite(loss) and torch.isfinite(model.competition_mix.grad).all(),'Nonfinite training')
                        torch.nn.utils.clip_grad_norm_([model.competition_mix],o['clip'],foreach=False);optimizer.step()
                        if step%c['selection_interval']==0:
                            selected=score(model,data['valid'],region['start'],region['windows'],c['context'],c['batch'])
                            if best is None or (selected['ce'],step)<(best['selection']['ce'],best['step']):
                                best={'seed':seed,'arm':mode,'lr':lr,'step':step,'selection':selected,'state':copy.deepcopy(model.state_dict()),
                                      'window_sha256':window_sha,'completed_steps':c['steps']}
                    require(all(torch.equal(v,model.state_dict()[n]) for n,v in baseline.state_dict().items() if n!='competition_mix'),'Frozen weights changed')
                    path=output/('%s-%s-%s.pt'%(seed,mode,lr));torch.save(best.pop('state'),path)
                    best.update(checkpoint=str(path),sha256=sha(path));rows.append(best);options.append(best)
                    print(json.dumps({'trial_complete':len(rows),'total':12,'seed':seed,'arm':mode,'lr':lr}),flush=True)
                frozen.append(min(options,key=lambda r:(r['selection']['ce'],r['step'],r['lr'])))
        require(len(rows)==12 and len(frozen)==9,'Incomplete trials')
        save(output/'CANDIDATES.json',rows);save(output/'FREEZE.json',frozen)
        def selected_model(row):
            model=make(next(b for b in c['backbones'] if b['seed']==row['seed']),row['arm'])
            require(sha(row['checkpoint'])==row['sha256'],'Selected checkpoint changed')
            state=torch.load(row['checkpoint'],map_location='cpu',weights_only=True)
            require(set(state)==set(model.state_dict()) and all(v.shape==model.state_dict()[n].shape and v.dtype==torch.float32 and v.device.type=='cpu' and torch.isfinite(v).all() for n,v in state.items()),'Selected state invalid')
            model.load_state_dict(state,strict=True);return model
        for row in frozen:
            require(score(selected_model(row),data['valid'],region['start'],region['windows'],c['context'],c['batch'])==row['selection'],'Selected replay drift')
        seals();save(output/'SELECTED_VERIFICATION.json',{'all9_exact_before_confirmation':True,'freeze_sha256':sha(output/'FREEZE.json')})
        scores=[];region=c['confirmation']
        for row in frozen:
            model=selected_model(row)
            first=score(model,data['valid'],region['start'],region['windows'],c['context'],c['batch'])
            second=score(model,data['valid'],region['start'],region['windows'],c['context'],c['batch'])
            require(first==second,'Duplicate confirmation drift')
            scores.append({'seed':row['seed'],'arm':row['arm'],'checkpoint_sha256':row['sha256'],'first':first,'second':second,'duplicate_drift':0})
        paired=[]
        for backbone in c['backbones']:
            ce={r['arm']:r['first']['ce'] for r in scores if r['seed']==backbone['seed']}
            paired.append({'seed':backbone['seed'],'ce':ce,'passed':ce['centered']<min(ce['global_only'],ce['unchanged'])})
        seals();save(output/'CONFIRMATION.json',scores)
        save(output/'COMPLETION.json',{'all9_duplicate_exact':True,'paired':paired,'advance_gate_passed':all(r['passed'] for r in paired),
             'freeze_sha256':sha(output/'FREEZE.json'),'confirmation_sha256':sha(output/'CONFIRMATION.json'),
             'scope':c['scope'],'official_test_reads':0})
    except BaseException:
        save(output/'FAILURE.json',{'traceback':traceback.format_exc(),'no_automatic_resume':True});raise


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['register','run'],required=True)
    for n in ('source','previous-protocol','previous-protocol-sha256','protocol-sha256'):p.add_argument('--'+n)
    p.add_argument('--authorize-training',action='store_true');a=p.parse_args()
    root=Path(__file__).resolve().parent
    require(Path('/Volumes/SP AI 01_16').is_mount() and Path('/Volumes/SP AI 01_16/CodexWorkspaces') in root.parents,'SSD required')
    register(root,a) if a.mode=='register' else run(root,a)
