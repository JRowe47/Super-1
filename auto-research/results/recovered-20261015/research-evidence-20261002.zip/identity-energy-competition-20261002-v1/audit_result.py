"""Independent native-state/artifact audit, without any model evaluation."""
import hashlib
import json
import math
from pathlib import Path
import torch


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):return json.loads(path.read_text())


def require(ok,message):
    if not ok:raise RuntimeError(message)


def audit(root):
    output=root/'language-run'; terminal=output/'COMPLETION.json'
    if not terminal.exists():
        return {'terminal':False,'failure_preserved':(output/'FAILURE.json').exists()}
    protocol=root/'LANGUAGE_PROTOCOL.json'
    require(sha(protocol)=='47386f0e44a51a701ece8ebea1b49eca3d503739c4f69e5f900c6d569cf4c73d','Protocol changed')
    c=read(protocol);end=read(terminal);execution=read(output/'EXECUTION.json')
    require(execution['protocol_sha256']==sha(protocol) and execution['driver_sha256']==c['driver_sha256'], 'Execution binding changed')
    require(sha(root/'language_test.py')==c['driver_sha256'] and sha(root/'identity_competition.py')==c['module_sha256'],'Driver/module seal changed')
    for name,expected in c['source_pins'].items():
        require(sha(Path(c['source'])/name)==expected,'Frozen source changed')
    baseline={}
    for row in c['backbones']:
        require(sha(row['checkpoint'])==row['sha256'],'Original checkpoint changed')
        baseline[row['seed']]=torch.load(row['checkpoint'],map_location='cpu',weights_only=True)
    candidates=read(output/'CANDIDATES.json'); frozen=read(output/'FREEZE.json'); scores=read(output/'CONFIRMATION.json')
    require(sha(output/'FREEZE.json')==end['freeze_sha256'] and sha(output/'CONFIRMATION.json')==end['confirmation_sha256'],'Terminal seal mismatch')
    seeds=set(baseline);adapted={'centered','global_only'}
    slots={(r['seed'],r['arm'],r['lr']) for r in candidates}
    require(len(candidates)==12 and slots=={(s,a,l) for s in seeds for a in adapted for l in c['lrs']},'Missing/duplicate trial')
    require(all(r['completed_steps']==c['steps'] and r['step'] in range(c['selection_interval'],c['steps']+1,c['selection_interval']) for r in candidates),'Wrong budget/selected step')
    require(len(frozen)==9 and {(r['seed'],r['arm']) for r in frozen}=={(s,a) for s in seeds for a in c['arms']},'Wrong frozen slots')
    for seed in seeds:
        require(len({r['window_sha256'] for r in candidates if r['seed']==seed})==1,'Exposure stream mismatch')
    for row in frozen:
        if row['arm'] in adapted:
            options=[r for r in candidates if r['seed']==row['seed'] and r['arm']==row['arm']]
            require(row==min(options,key=lambda r:(r['selection']['ce'],r['step'],r['lr'])),'Noncanonical winner')
    state_receipts=[]
    for row in candidates+frozen:
        path=Path(row['checkpoint']).resolve(strict=True)
        require(path.parent==output and sha(path)==row['sha256'],'Saved checkpoint changed/outside output')
        state=torch.load(path,map_location='cpu',weights_only=True);original=baseline[row['seed']]
        require(set(state)==set(original)|{'competition_mix'},'Unexpected state key')
        require(all(isinstance(v,torch.Tensor) and v.dtype==torch.float32 and v.device.type=='cpu'
                    and torch.isfinite(v).all() for v in state.values()),'Invalid tensor dtype/device/value')
        require(state['competition_mix'].shape==(2,),'Mix parameter shape')
        require(all(torch.equal(state[n],v) for n,v in original.items()),'Inherited frozen weights changed')
        if row['arm']=='unchanged': require(torch.count_nonzero(state['competition_mix'])==0,'Baseline was adapted')
        require(row['selection']['targets']==16384 and math.isfinite(row['selection']['ce']),'Selection score invalid')
        state_receipts.append({'seed':row['seed'],'arm':row['arm'],'checkpoint_sha256':row['sha256'],
                               'original_weights_exact':True,'mix':state['competition_mix'].tolist()})
    require(len(scores)==9 and {(r['seed'],r['arm']) for r in scores}=={(s,a) for s in seeds for a in c['arms']},'Duplicate slots incomplete')
    for row in scores:
        chosen=next(r for r in frozen if r['seed']==row['seed'] and r['arm']==row['arm'])
        require(row['checkpoint_sha256']==chosen['sha256'],'Confirmed checkpoint mismatch')
        require(row['first']==row['second'] and row['duplicate_drift']==0
                and row['first']['targets']==32768 and math.isfinite(row['first']['ce']),'Duplicate drift/score scope')
    verified=read(output/'SELECTED_VERIFICATION.json')
    require(verified['all9_exact_before_confirmation'] is True and verified['freeze_sha256']==sha(output/'FREEZE.json'),'Replay receipt binding failed')
    paired=[]
    for seed in sorted(seeds):
        ce={r['arm']:r['first']['ce'] for r in scores if r['seed']==seed}
        paired.append({'seed':seed,'ce':ce,'centered_minus_global':ce['centered']-ce['global_only'],
                       'centered_minus_unchanged':ce['centered']-ce['unchanged'],
                       'passed':ce['centered']<min(ce['global_only'],ce['unchanged'])})
    passed=all(r['passed'] for r in paired)
    require(passed==end['advance_gate_passed'] and end['all9_duplicate_exact'] is True,'Reported outcome mismatch')
    return {'terminal':True,'all12_trials_completed':True,'all9_duplicate_exact':True,
            'all_saved_inherited_weights_exact':True,'state_receipts':state_receipts,
            'paired':paired,'advance_gate_passed':passed,'terminal_sha256':sha(terminal),
            'new_model_evaluations':0,'task_text_reads':0,'limitations':c['scope']}


if __name__=='__main__':
    root=Path(__file__).resolve().parent
    result=audit(root)
    if result['terminal']:
        with (root/'INDEPENDENT_AUDIT.json').open('x') as stream:
            json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(result,sort_keys=True))
