"""One contrast-law ablation of the pinned PairEnergy generated-angle model.

No new parameters, stored state, regularizer, inverse, or contraction promise.
Generic cross-channel competition is established prior art. Task usefulness and
the originality of this exact conditional angle combination are unproven.
"""
import torch
import pair_energy_phase_candidate as source


class CenteredEnergyPhaseLM(source.PairEnergyPhaseLM):
    MODES = ("local", "centered", "global_only")

    def __init__(self, width, dynamic=True, contrast_mode="centered"):
        if contrast_mode not in self.MODES:
            raise ValueError("Unknown registered contrast mode")
        super().__init__(width, dynamic)
        # Non-tensor selector: the inherited parameter/state layout is exact.
        self.contrast_mode = contrast_mode

    def contrast_from_energies(self, state_energy, drive_energy):
        delta = torch.log(state_energy + 1e-6) - torch.log(drive_energy + 1e-6)
        if self.contrast_mode == "local":
            return delta.tanh()
        # Last axis is pairs in ONE current sample and ONE current bank.
        # Neither batch examples nor timesteps participate in this reduction.
        mean = delta.mean(dim=-1, keepdim=True)
        if self.contrast_mode == "centered":
            return (delta - mean).tanh()
        return mean.tanh().expand_as(delta)

    def angle_for(self, state, drive, angle, gain, offset):
        if self.contrast_mode == "local":
            # Exact pinned reference graph, including operation order/gradients.
            return super().angle_for(state, drive, angle, gain, offset)
        if gain is None:
            return angle
        pair = torch.roll(state, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        target = torch.roll(drive, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        state_energy = pair.square().sum(-1)
        drive_energy = target.square().sum(-1)
        cross = pair[..., 0] * target[..., 1] - pair[..., 1] * target[..., 0]
        denominator = torch.sqrt(state_energy * drive_energy + 1e-6)
        contrast = self.contrast_from_energies(state_energy, drive_energy)
        weight = self.energy_gain if offset == 0 else self.second_energy_gain
        return angle + gain * (cross / denominator + weight * contrast).tanh()
