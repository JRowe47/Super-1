"""Bounded synthetic structural/native-autograd canary; review before execution.

No task-data/checkpoint loader, benchmark launcher, cloud API, process-control
API, or email integration. Existing source dependencies are read-only.
"""
import argparse
import copy
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
BASE = Path("/Volumes/SP AI 01_16/CodexWorkspaces/trin-research-evidence-20261002/centered-energy-competition-canary-20261002-v1")
SSD = Path("/Volumes/SP AI 01_16")
SOURCE = Path("/Volumes/SP AI 01_16/trin/experiments/disparity_constraints")
EXPECTED = {
    "phase_transition_language": "9e79bff53701581864118b18a5fc35156af41afaeb44b2fc6e25916a8c41f9b4",
    "capacity_sweep": "a8d6d092c9b21ae0b38cdb972a4054fb58d5bf11fcd9775c2f9e1e0850c4f97e",
    "direct_distance": "c0b3bd153d213f9deffd8677b364ba5c2351f99bdec6fe94721672e5c7e9d25c",
    "run": "6efab2fd890a1757ba9925084b84f89120ff94cd2e48b54802493c780d2a96d2",
    "noncommuting_phase_candidate": "063584bd9d4746ade54669e4cb1a9b70f8cdb38fff586ce68db37564552d14b5",
    "pair_energy_phase_candidate": "61b8d710a0c647c8c45cbe8e5a4e06eea440fa37975d9f387e9402b5ea2efa9a",
}
MODES = ("local", "centered", "global_only")
REGISTERED = {
    "structural_width": 16, "native_width": 32, "deployment_width": 256,
    "batch": 2, "context": 9, "threads": 1,
    "fixture_labels": ["fixture-0", "fixture-1", "fixture-2"],
    "native_updates_per_mode_fixture": 5,
    "deployment_updates_per_mode": 1,
    "lr": 0.003, "weight_decay": 0.01,
    "adam_betas": [0.9, 0.999], "adam_eps": 1e-8, "clip_norm": 1.0,
    "gradient_atol_FP64": 1e-12, "gradient_rtol_FP64": 1e-12,
    "expected_deployment_parameters": 198656,
    "equations": {
        "local": "delta_j=log(Es_j+eps)-log(Eu_j+eps); c_j=tanh(delta_j)",
        "centered": "mu=mean_pairs(delta) within sample/token/bank; c_j=tanh(delta_j-mu)",
        "global_only": "mu=mean_pairs(delta) within sample/token/bank; c_j=tanh(mu)",
        "shared_angle": "theta_j=a_j+g_j*tanh(q_j+e_j*c_j); inherited q/eps/rotation/write/retention",
    },
    "scope": "Synthetic structural/trainability canary, not task CE, benchmark utility, SOTA, novelty, extra independent information, inversion, contraction, stable gradients, latency or total-memory advantage.",
    "real_task_data_or_checkpoint_reads_permitted": False,
    "official_test_read_permitted": False,
    "cloud_email_or_existing_job_actions_permitted": False,
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def storage_guard():
    if not SSD.is_mount() or SSD.resolve() != SSD:
        raise RuntimeError("Authoritative SSD is not actually mounted/resolved")
    mounts = subprocess.check_output(["/sbin/mount"], text=True)
    if " on " + str(SSD) + " (" not in mounts:
        raise RuntimeError("SSD absent from operating-system mount table")
    if BASE.resolve() != BASE or not BASE.is_dir() or not os.access(BASE, os.W_OK):
        raise RuntimeError("Project is not resolved and writable on the SSD")
    BASE.relative_to(SSD / "CodexWorkspaces")
    if any(part in str(BASE) for part in ("/Documents/", "/Desktop/", "/Mobile Documents/", "iCloud")):
        raise RuntimeError("Forbidden iCloud output destination")


def write_once(path, value):
    storage_guard()
    if path.parent != BASE or path.resolve().parent != BASE:
        raise RuntimeError("Artifact escaped registered project")
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def source_receipts():
    return {name: sha(SOURCE / (name + ".py")) for name in EXPECTED}


def seed(label):
    digest = hashlib.sha256(("centered-energy-canary-v1:" + label).encode("ascii")).digest()
    return int.from_bytes(digest[:8], "big") & ((1 << 63) - 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--module-sha256", required=True)
    parser.add_argument("--driver-sha256", required=True)
    args = parser.parse_args()
    storage_guard()
    if Path(args.output) != BASE or Path(__file__).resolve() != BASE / "run_canary.py":
        raise RuntimeError("Wrong registered driver/output")
    module_path = BASE / "centered_energy.py"
    if sha(__file__) != args.driver_sha256 or sha(module_path) != args.module_sha256:
        raise RuntimeError("Reviewed source hash mismatch")
    if any((BASE / name).exists() for name in ("PROTOCOL.json", "REPORT.json", "FAILURE.json")):
        raise RuntimeError("Canary already attempted; no implicit rerun")
    before = source_receipts()
    if before != EXPECTED:
        raise RuntimeError("Pinned dependency source mismatch")
    for variable, folder in (("TMPDIR", "tmp"), ("XDG_CACHE_HOME", "xdg-cache"), ("TORCH_HOME", "torch-home")):
        path = BASE / folder
        if path.resolve() != path:
            raise RuntimeError("Temp/cache escaped the SSD")
        path.mkdir(exist_ok=True)
        os.environ[variable] = str(path)
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    blocked_opens = []

    def forbid_task_data(event, arguments):
        if event != "open" or not arguments or not isinstance(arguments[0], (str, bytes, os.PathLike)):
            return
        name = os.fsdecode(arguments[0])
        if Path(name).name in {"train.txt", "valid.txt", "test.txt", "best.pt"} or "/wikitext-2/" in name:
            blocked_opens.append(name)
            raise RuntimeError("Real task corpus/checkpoint access forbidden")

    sys.addaudithook(forbid_task_data)
    write_once(BASE / "PROTOCOL.json", {
        "registered": REGISTERED,
        "module_sha256": args.module_sha256, "driver_sha256": args.driver_sha256,
        "dependency_sha256": before, "stage": "pre-import, pre-numerical-work",
        "fixture_seed_rule": "SHA256 first8bytes of centered-energy-canary-v1:label masked to63bits; fixed labels, no seed rejection or metric tuning",
        "real_task_data_reads": 0,
    })
    receipts, failures, result = [], [], {}
    try:
        sys.path.insert(0, str(SOURCE))
        imported = {name: importlib.import_module(name) for name in EXPECTED}
        for name, module in imported.items():
            if Path(module.__file__).resolve() != SOURCE / (name + ".py") or sha(module.__file__) != EXPECTED[name]:
                raise RuntimeError("Imported dependency differs from immutable pin")
        sys.path.insert(0, str(BASE))
        candidate = importlib.import_module("centered_energy")
        if Path(candidate.__file__).resolve() != module_path or sha(candidate.__file__) != args.module_sha256:
            raise RuntimeError("Imported candidate is not reviewed module")
        import torch
        from torch import nn
        from torch.nn import functional as F
        torch.set_num_threads(REGISTERED["threads"])
        torch.set_num_interop_threads(1)
        torch.use_deterministic_algorithms(True)
        if torch.__version__ != "2.8.0" or torch.get_num_threads() != 1:
            raise RuntimeError("Registered native CPU runtime mismatch")
        energy = imported["pair_energy_phase_candidate"]
        geometry = imported["noncommuting_phase_candidate"]
        Model = candidate.CenteredEnergyPhaseLM

        def gate(label, condition, detail=None):
            if not bool(condition):
                failures.append({"check": label, "detail": detail})

        def tensor(label, shape, dtype=torch.float64, byte=False):
            rng = torch.Generator().manual_seed(seed(label))
            value = torch.randint(256, shape, generator=rng) if byte else torch.randn(shape, generator=rng, dtype=dtype)
            receipts.append({"label": label, "seed": str(seed(label)), "shape": list(shape), "dtype": str(value.dtype), "sha256": hashlib.sha256(value.contiguous().numpy().tobytes()).hexdigest(), "encoding": "row-major native-endian tensor bytes"})
            return value

        def fresh(label, width, mode, dtype=torch.float64):
            torch.manual_seed(seed(label))
            receipts.append({"label": label, "seed": str(seed(label)), "kind": "fresh model initialization"})
            return Model(width, True, contrast_mode=mode).to(dtype=dtype)

        def metric(a, b):
            difference = a.detach().double() - b.detach().double()
            finite = bool(torch.isfinite(a).all() and torch.isfinite(b).all() and torch.isfinite(difference).all())
            return {"finite": finite, "exact": bool(torch.equal(a, b)), "max_abs": difference.abs().max().item(), "allclose_FP64_1e-12": finite and bool(torch.allclose(a, b, atol=REGISTERED["gradient_atol_FP64"], rtol=REGISTERED["gradient_rtol_FP64"]))}

        def stats(value):
            value = value.detach()
            return {"finite": bool(torch.isfinite(value).all()), "nonzero": int(torch.count_nonzero(value)), "elements": value.numel(), "L1": value.double().abs().sum().item(), "max_abs": value.double().abs().max().item()}

        def fill_transport(model, label):
            for name in ("angle", "gain", "second_angle", "second_gain", "energy_gain", "second_energy_gain"):
                values = tensor(label + ":" + name, tuple(getattr(model, name).shape))
                with torch.no_grad():
                    getattr(model, name).copy_(values * 0.35)

        def fingerprint(model):
            digest = hashlib.sha256()
            for name, value in sorted(model.state_dict().items()):
                digest.update(name.encode("utf-8"))
                digest.update(str(value.dtype).encode("ascii"))
                digest.update(json.dumps(list(value.shape)).encode("ascii"))
                digest.update(value.detach().cpu().contiguous().numpy().tobytes())
            return digest.hexdigest()

        counts = {}
        for width in (REGISTERED["structural_width"], REGISTERED["native_width"], REGISTERED["deployment_width"]):
            models = {mode: fresh("count:" + str(width), width, mode, torch.float32) for mode in MODES}
            values = {mode: {"parameters": sum(p.numel() for p in model.parameters()), "state_scalars": sum(v.numel() for v in model.state_dict().values()), "state_bytes": sum(v.numel() * v.element_size() for v in model.state_dict().values()), "state_keys": list(model.state_dict())} for mode, model in models.items()}
            gate("equal_counts_layout_width" + str(width), all(v == values["local"] for v in values.values()), values)
            if width == REGISTERED["deployment_width"]:
                gate("deployment_count198656", values["local"]["parameters"] == REGISTERED["expected_deployment_parameters"], values)
            counts[str(width)] = values
        result["counts"] = counts

        # Nonzero local mode must reproduce outputs and ALL native gradients of
        # the pinned PairEnergy graph exactly in FP64 and FP32.
        comparisons = []
        for dtype in (torch.float64, torch.float32):
            label = "local-reference:" + str(dtype)
            model = fresh(label, REGISTERED["structural_width"], "local", dtype)
            fill_transport(model, label)
            reference = energy.PairEnergyPhaseLM(REGISTERED["structural_width"], True).to(dtype=dtype)
            reference.load_state_dict(copy.deepcopy(model.state_dict()), strict=True)
            tokens = tensor(label + ":tokens", (REGISTERED["batch"], REGISTERED["context"]), byte=True)
            targets = tensor(label + ":targets", tuple(tokens.shape), byte=True)
            expected, actual = reference(tokens), model(tokens)
            forward = metric(expected, actual)
            F.cross_entropy(expected.flatten(0, 1), targets.flatten()).backward()
            F.cross_entropy(actual.flatten(0, 1), targets.flatten()).backward()
            gradients = {name: metric(parameter.grad, dict(model.named_parameters())[name].grad) for name, parameter in reference.named_parameters()}
            gate(label + ":forward_exact", forward["finite"] and forward["exact"], forward)
            gate(label + ":all_gradients_exact", all(v["finite"] and v["exact"] for v in gradients.values()), gradients)
            comparisons.append({"dtype": str(dtype), "forward": forward, "gradients": gradients})
        result["nonzero_local_reference_equality"] = comparisons

        # Zero energy coefficients recover common oriented-query geometry even
        # with nonzero angles/gains. No claim about a trained energy checkpoint.
        shared = fresh("zero-energy:shared", REGISTERED["structural_width"], "local")
        fill_transport(shared, "zero-energy:transport")
        with torch.no_grad():
            shared.energy_gain.zero_()
            shared.second_energy_gain.zero_()
        base = geometry.OverlappingPhaseLM(REGISTERED["structural_width"], True).double()
        base.load_state_dict({name: value for name, value in shared.state_dict().items() if name not in ("energy_gain", "second_energy_gain")}, strict=True)
        tokens = tensor("zero-energy:tokens", (REGISTERED["batch"], REGISTERED["context"]), byte=True)
        expected = base(tokens)
        comparisons = []
        for mode in MODES:
            model = fresh("zero-energy:" + mode, REGISTERED["structural_width"], mode)
            model.load_state_dict(copy.deepcopy(shared.state_dict()), strict=True)
            comparison = metric(expected, model(tokens))
            gate("zero_energy_common_geometry_exact:" + mode, comparison["finite"] and comparison["exact"], comparison)
            comparisons.append({"mode": mode, "forward": comparison})
        result["zero_energy_common_baseline"] = comparisons

        # Each fixture is in that bank's rolled pair coordinates. Only remote
        # pair2 changes energy; target pair0 and its drive/query stay exact.
        distant = []
        for offset in (0, 1):
            pair = torch.tensor([[[0.8, 0.3], [-0.4, 0.7], [0.6, -0.2], [0.2, 0.5]]], dtype=torch.float64)
            target = torch.tensor([[[0.3, -0.6], [0.4, 0.2], [-0.5, 0.7], [0.6, -0.3]]], dtype=torch.float64)
            changed = pair.clone()
            changed[:, 2] *= 1.8
            state = torch.roll(pair.flatten(1), shifts=-offset, dims=-1)
            perturbed = torch.roll(changed.flatten(1), shifts=-offset, dims=-1)
            drive = torch.roll(target.flatten(1), shifts=-offset, dims=-1)
            for mode in MODES:
                model = fresh("distant:" + str(offset), 8, mode)
                with torch.no_grad():
                    for name in ("angle", "second_angle"):
                        getattr(model, name).fill_(0.2)
                    for name in ("gain", "second_gain"):
                        getattr(model, name).fill_(0.4)
                    for name in ("energy_gain", "second_energy_gain"):
                        getattr(model, name).fill_(0.3)
                angle, gain = (model.angle, model.gain) if offset == 0 else (model.second_angle, model.second_gain)
                before_angle = model.angle_for(state, drive, angle, gain, offset)
                after_angle = model.angle_for(perturbed, drive, angle, gain, offset)
                comparison = metric(before_angle[:, 0], after_angle[:, 0])
                expect_same = mode == "local"
                gate("distant_dependency:bank" + str(offset) + ":" + mode, comparison["finite"] and comparison["exact"] == expect_same, comparison)
                distant.append({"bank": offset, "mode": mode, "target_pair": 0, "changed_pair": 2, "before_angle": before_angle[0, 0].item(), "after_angle": after_angle[0, 0].item(), "comparison": comparison, "expected_exactly_unchanged": expect_same})
        result["distant_pair_dependency"] = distant

        # Keep batch size identical: no cross-kernel/batch-shape bitwise claim.
        tokens = tensor("isolation:tokens", (2, REGISTERED["context"]), byte=True)
        changed_other = tokens.clone()
        changed_other[1] = (changed_other[1] + 31) % 256
        changed_future = tokens.clone()
        changed_future[:, 4:] = (changed_future[:, 4:] + 73) % 256
        state = tensor("isolation:state", (2, REGISTERED["structural_width"]))
        drive = tensor("isolation:drive", tuple(state.shape))
        state_other, drive_other = state.clone(), drive.clone()
        state_other[1] *= 2.0
        drive_other[1] *= 0.25
        isolation = []
        for mode in MODES:
            model = fresh("isolation:model", REGISTERED["structural_width"], mode)
            fill_transport(model, "isolation:transport")
            output = model(tokens)
            batch = metric(output[0], model(changed_other)[0])
            causal = metric(output[:, :4], model(changed_future)[:, :4])
            angles = {}
            for offset in (0, 1):
                angle, gain = (model.angle, model.gain) if offset == 0 else (model.second_angle, model.second_gain)
                first = model.angle_for(state, drive, angle, gain, offset)
                second = model.angle_for(state_other, drive_other, angle, gain, offset)
                comparison = metric(first[0], second[0])
                gate("angle_batch_isolation:bank" + str(offset) + ":" + mode, comparison["finite"] and comparison["exact"], comparison)
                angles[str(offset)] = comparison
            gate("LM_batch_isolation:" + mode, batch["finite"] and batch["exact"], batch)
            gate("LM_causal_prefix:" + mode, causal["finite"] and causal["exact"], causal)
            isolation.append({"mode": mode, "angle_cross_example": angles, "LM_cross_example": batch, "causal_prefix": causal})
        result["sample_token_bank_isolation"] = isolation

        # Cartesian zero/epsilon-scale derivative checks; no nonzero-learning
        # claim at a zero transported hidden state.
        edges = []
        for mode in MODES:
            for label, state_scale, drive_scale in (("zero-both", 0.0, 0.0), ("zero-state", 0.0, 1.0), ("zero-drive", 1.0, 0.0), ("epsilon-scale", 1e-3, 1e-3)):
                model = fresh("edge:model", 8, mode)
                fill_transport(model, "edge:transport")
                state = (tensor("edge:" + label + ":state", (2, 8)) * state_scale).requires_grad_(True)
                drive = (tensor("edge:" + label + ":drive", (2, 8)) * drive_scale).requires_grad_(True)
                theta = model.angle_for(state, drive, model.angle, model.gain, 0)
                theta.square().sum().backward()
                values = {"theta": stats(theta), "state_gradient": stats(state.grad), "drive_gradient": stats(drive.grad), "gain_gradient": stats(model.gain.grad), "energy_gradient": stats(model.energy_gain.grad)}
                gate("edge_finite:" + mode + ":" + label, all(v["finite"] for v in values.values()), values)
                edges.append({"mode": mode, "fixture": label, "statistics": values})
        result["finite_edge_fixtures"] = edges

        def updates(model, tokens, targets, count, label):
            optimizer = torch.optim.AdamW(model.parameters(), lr=REGISTERED["lr"], betas=tuple(REGISTERED["adam_betas"]), eps=REGISTERED["adam_eps"], weight_decay=REGISTERED["weight_decay"], foreach=False, fused=False, amsgrad=False, maximize=False, capturable=False, differentiable=False)
            rows = []
            for update in range(1, count + 1):
                optimizer.zero_grad(set_to_none=True)
                logits = model(tokens)
                loss = F.cross_entropy(logits.flatten(0, 1), targets.flatten())
                gate(label + ":finite_logits_loss:" + str(update), bool(torch.isfinite(logits).all() and torch.isfinite(loss)))
                if not bool(torch.isfinite(loss)):
                    raise RuntimeError("Nonfinite synthetic native loss")
                loss.backward()
                gradients = {name: stats(p.grad) if p.grad is not None else {"finite": False, "missing": True} for name, p in model.named_parameters()}
                gate(label + ":all_gradients_finite:" + str(update), all(v["finite"] for v in gradients.values()), gradients)
                gains = {name: gradients[name] for name in ("gain", "second_gain")}
                coefficients = {name: gradients[name] for name in ("energy_gain", "second_energy_gain")}
                if update == 1:
                    gate(label + ":first_gains_all_active", all(v["nonzero"] == v["elements"] for v in gains.values()), gains)
                    gate(label + ":first_coefficients_dormant", all(v["nonzero"] == 0 for v in coefficients.values()), coefficients)
                if update == 2:
                    gate(label + ":second_coefficients_all_active", all(v["nonzero"] == v["elements"] for v in coefficients.values()), coefficients)
                norm = nn.utils.clip_grad_norm_(model.parameters(), REGISTERED["clip_norm"], norm_type=2.0, error_if_nonfinite=True, foreach=False)
                optimizer.step()
                parameters_finite = all(bool(torch.isfinite(p).all()) for p in model.parameters())
                optimizer_finite = all(bool(torch.isfinite(v).all()) for slot in optimizer.state.values() for v in slot.values() if torch.is_tensor(v))
                gate(label + ":parameters_optimizer_finite:" + str(update), parameters_finite and optimizer_finite)
                rows.append({"update": update, "synthetic_training_loss_not_task_CE": loss.item(), "preclip_gradient_norm": norm.item(), "all_gradients_finite": all(v["finite"] for v in gradients.values()), "gain_gradients": gains, "energy_gradients": coefficients, "parameters_finite": parameters_finite, "optimizer_tensors_finite": optimizer_finite, "state_sha256": fingerprint(model)})
            return rows

        native = []
        for fixture in REGISTERED["fixture_labels"]:
            label = "native:" + fixture
            tokens = tensor(label + ":tokens", (REGISTERED["batch"], REGISTERED["context"]), byte=True)
            targets = tensor(label + ":targets", tuple(tokens.shape), byte=True)
            common = fresh(label + ":model", REGISTERED["native_width"], "local", torch.float32)
            common_state, initial_hash = copy.deepcopy(common.state_dict()), fingerprint(common)
            for mode in MODES:
                model = fresh(label + ":model", REGISTERED["native_width"], mode, torch.float32)
                model.load_state_dict(copy.deepcopy(common_state), strict=True)
                gate(label + ":same_initial_state:" + mode, fingerprint(model) == initial_hash)
                rows = updates(model, tokens, targets, REGISTERED["native_updates_per_mode_fixture"], label + ":" + mode)
                native.append({"fixture": fixture, "mode": mode, "initial_state_sha256": initial_hash, "updates": rows})
        result["native_FP32_staged_activation"] = native

        deployment = []
        tokens = tensor("deployment:tokens", (REGISTERED["batch"], REGISTERED["context"]), byte=True)
        targets = tensor("deployment:targets", tuple(tokens.shape), byte=True)
        common = fresh("deployment:model", REGISTERED["deployment_width"], "local", torch.float32)
        common_state, initial_hash = copy.deepcopy(common.state_dict()), fingerprint(common)
        for mode in MODES:
            model = fresh("deployment:model", REGISTERED["deployment_width"], mode, torch.float32)
            model.load_state_dict(copy.deepcopy(common_state), strict=True)
            gate("deployment:same_initial_state:" + mode, fingerprint(model) == initial_hash)
            rows = updates(model, tokens, targets, REGISTERED["deployment_updates_per_mode"], "deployment:" + mode)
            deployment.append({"mode": mode, "initial_state_sha256": initial_hash, "updates": rows})
        result["deployment_width_native_FP32_finite"] = deployment
        after = source_receipts()
        gate("dependency_sources_unchanged", after == before == EXPECTED, after)
        gate("candidate_driver_unchanged", sha(module_path) == args.module_sha256 and sha(__file__) == args.driver_sha256)
        gate("forbidden_task_opens_zero", not blocked_opens, blocked_opens)
        runtime = {"python": sys.version, "executable": str(Path(sys.executable).resolve()), "torch": torch.__version__, "torch_source": str(Path(torch.__file__).resolve()), "device": "cpu", "precision": "nativeFP32 plus independent FP64 structural probes", "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(), "deterministic": torch.are_deterministic_algorithms_enabled(), "custom_backward": False, "compile": False}
        report = {"status": "passed" if not failures else "failed", "failures": failures, "registered": REGISTERED, "module_sha256": args.module_sha256, "driver_sha256": args.driver_sha256, "dependency_sha256_before": before, "dependency_sha256_after": after, "runtime": runtime, "fixtures": receipts, "results": result, "real_task_data_or_checkpoint_reads": 0, "blocked_task_open_attempts": blocked_opens, "task_region_scored": False, "official_test_read": False, "cloud_resources_created": 0, "email_sent": False, "existing_live_job_mutation": False, "numerical_canary_executions": 1, "claim_scope": REGISTERED["scope"], "limitations": ["Cross-channel competition is established; exact recurrent combination originality unproven.", "Centering discards mean relative amplitude, which may be useful.", "q remains directional; no analytic inverse, full-volume preservation or contraction asserted.", "No task utility, latency, FLOP, total-memory or persistent-state savings measured.", "Synthetic optimization losses are not real-task validation CE."]}
        write_once(BASE / "REPORT.json", report)
        print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
        return 0 if not failures else 1
    except Exception as exc:
        failure = {"status": "failed_exception", "exception_type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc(), "module_sha256": args.module_sha256, "driver_sha256": args.driver_sha256, "registered": REGISTERED, "fixtures": receipts, "completed_results": result, "failures_so_far": failures, "blocked_task_open_attempts": blocked_opens, "task_region_scored": False, "scope": REGISTERED["scope"]}
        write_once(BASE / "FAILURE.json", failure)
        print(json.dumps(failure, sort_keys=True, allow_nan=False), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
