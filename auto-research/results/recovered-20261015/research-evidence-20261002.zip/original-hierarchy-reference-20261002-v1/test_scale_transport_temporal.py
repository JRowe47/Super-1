"""Test delayed effect through the exact original recurrent transition."""
import json
from pathlib import Path
import torch
import regularized_rotation as reference
from scale_transport import ScaleTransport

ROOT = Path(__file__).resolve().parent
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.manual_seed(92117)
base_class = reference.reference.reference.reference.PersistentMultiScaleLM
base = base_class(256, 32, 4)
transport = ScaleTransport(4, 32)
tokens = torch.randint(256, (2, 2))
state = base.advance_state(tokens[:, :1], base.initial_state(2))
embedded = base.core.embedding(tokens[:, 0])

def readout(h):
    return base.output(base.core.norm(h.mean(1)))

shifted = transport(state, embedded)
assert torch.equal(state, shifted)
future = base.advance_state(tokens[:, 1:], shifted)
loss = torch.nn.functional.cross_entropy(readout(future), tokens[:, 0])
loss.backward()
initial_gain_gradient = float(transport.gain.grad.detach().norm())
assert initial_gain_gradient > 0 and torch.isfinite(transport.gain.grad).all()
with torch.no_grad():
    transport.gain.fill_(.3)
transport.zero_grad(set_to_none=True)
shifted = transport(state.detach(), embedded.detach())
immediate_drift = float((readout(shifted)-readout(state.detach())).detach().abs().max())
plain_future = base.advance_state(tokens[:, 1:], state.detach())
moved_future = base.advance_state(tokens[:, 1:], shifted)
future_drift = float((readout(moved_future)-readout(plain_future)).detach().abs().max())
assert immediate_drift < 3e-6 and future_drift > immediate_drift
future_loss = torch.nn.functional.cross_entropy(readout(moved_future), tokens[:, 0])
future_loss.backward()
query_gradient = float(transport.query.weight.grad.detach().norm())
assert query_gradient > 0 and torch.isfinite(transport.query.weight.grad).all()
report = dict(immediate_logit_max_roundoff=immediate_drift, next_transition_logit_max_difference=future_drift,
              gain_gradient_norm_at_identity_from_future=initial_gain_gradient,
              query_gradient_norm_at_nonzero_gain_from_future=query_gradient,
              task_data_reads=0, official_test_reads=0,
              scope='Two synthetic tokens through the original gated transition. Demonstrates delayed influence and gradient path, not language accuracy, long-horizon stability or novelty.')
with (ROOT/'SCALE_TRANSPORT_TEMPORAL_CANARY.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
print(json.dumps(report, indent=2))
