"""Synthetic optimizer/carry parity, separate from all sealed training runs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('training_parity_candidate', ROOT / 'scripted_regularized_rotation.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
base_class = module.reference.reference.reference.reference.PersistentMultiScaleLM
protocol = json.loads((ROOT / 'regularized-language-run/PROTOCOL.json').read_text())
pins = dict(protocol['source_hashes'])
pins[str(ROOT / 'scripted_regularized_rotation.py')] = hashlib.sha256((ROOT / 'scripted_regularized_rotation.py').read_bytes()).hexdigest()

def seals():
    for path, pin in pins.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == pin

seals()
rows = []
for cross in (False, True):
    for nonzero_gain in (False, True):
        torch.manual_seed(48117)
        eager = module.reference.RegularizedRotation(base_class(256, 32, 4), cross)
        scripted = module.ScriptedRegularizedRotation(base_class(256, 32, 4), cross)
        if nonzero_gain:
            with torch.no_grad():
                eager.rotation_gain.copy_(torch.tensor([.2, -.1, .3, -.2]))
        scripted.load_state_dict(eager.state_dict(), strict=True)
        optimizers = [torch.optim.AdamW(m.parameters(), lr=.003, weight_decay=.01, foreach=False)
                      for m in (eager, scripted)]
        states = [None, None]
        steps = []
        for step in range(5):
            sequence = torch.randint(256, (2, 129))
            losses, logits_list = [], []
            for index, (model, optimizer) in enumerate(zip((eager, scripted), optimizers)):
                optimizer.zero_grad(set_to_none=True)
                logits, state = model(sequence[:, :-1], state=states[index], return_state=True)
                loss = torch.nn.functional.cross_entropy(logits.reshape(-1, 256), sequence[:, 1:].reshape(-1))
                assert torch.isfinite(loss)
                loss.backward()
                assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step()
                states[index] = state.detach()
                losses.append(float(loss.detach()))
                logits_list.append(logits.detach())
            parameter_drift = max(float((a-b).abs().max()) for a,b in zip(eager.parameters(), scripted.parameters()))
            state_drift = float((states[0]-states[1]).abs().max())
            logit_drift = float((logits_list[0]-logits_list[1]).abs().max())
            assert max(parameter_drift, state_drift, logit_drift) < 1e-4
            steps.append(dict(step=step+1, losses=losses, parameter_max_drift=parameter_drift,
                              carried_state_max_drift=state_drift, logit_max_drift=logit_drift))
        rows.append(dict(cross_scale=cross, initial_nonzero_gain=nonzero_gain, steps=steps))
seals()
report = dict(results=rows, source_hashes=pins, source_seals_intact=True,
              task_data_reads=0, official_test_reads=0,
              scope='Five synthetic AdamW updates with detached carried state. Tolerance parity, not bitwise training equivalence, accuracy, speed or SOTA proof. No active trainer modified.')
with (ROOT / 'SCRIPTED_TRAINING_PARITY.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
print(json.dumps(report, indent=2))
