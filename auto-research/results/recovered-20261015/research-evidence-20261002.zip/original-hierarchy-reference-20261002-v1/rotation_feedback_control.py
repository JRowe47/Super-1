"""Mechanism control only; no training or benchmark claims."""
import torch
from torch.nn import functional as F
from regularized_rotation import RegularizedRotation


class StoppedGeometryRotation(RegularizedRotation):
    """Same cross-scale forward rotation, without angle-path state gradients.

    Gain and radius remain trainable. Direct gradients through rotated state
    remain present; only the geometric query's dependence on state is stopped.
    """

    def rotate(self, state):
        pairs = state.reshape(*state.shape[:-1], -1, 2)
        geometry = pairs.detach()
        other = geometry.roll(1, dims=1)
        numerator = geometry[..., 0]*other[..., 1]-geometry[..., 1]*other[..., 0]
        radius = F.softplus(self.log_radius)[None, :, None]
        query = numerator/(radius+geometry.square().sum(-1)+other.square().sum(-1))
        angle = torch.tanh(self.rotation_gain)[None, :, None]*query
        cosine, sine = torch.cos(angle), torch.sin(angle)
        return torch.stack([cosine*pairs[..., 0]-sine*pairs[..., 1],
                            sine*pairs[..., 0]+cosine*pairs[..., 1]], -1).flatten(-2)
