"""Separate original-hierarchy word comparison. No official test access."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import torch
import regularized_rotation as rotation
from input_rotation_control import InputGeometryRotation
from rotation_feedback_control import StoppedGeometryRotation

ROOT = Path(__file__).resolve().parent
PLAN = ROOT / 'WORD_ROTATION_COMPARISON_PLAN.json'
BASE_CONFIG = ROOT.parent / 'word-energy-native-20261002-v1/FULL_RUN_CONFIG.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def verify_seals(seals):
    for path, expected in seals.items():
        if sha(Path(path)) != expected:
            raise RuntimeError('Sealed artifact changed: '+str(path))

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def verify_update(model, optimizer, state):
    if not torch.isfinite(state).all():
        raise FloatingPointError('Nonfinite carried recurrent state')
    for name, parameter in model.named_parameters():
        if parameter.dtype != torch.float32 or not torch.isfinite(parameter).all():
            raise FloatingPointError('Invalid FP32 parameter: '+name)
        for key, value in optimizer.state.get(parameter, {}).items():
            if torch.is_tensor(value) and not torch.isfinite(value).all():
                raise FloatingPointError('Nonfinite optimizer state: '+name+'/'+key)

def validate_prior_receipts(completion, confirmation, verification):
    def require(condition, message):
        if not condition:
            raise AssertionError(message)
    require((completion['trials_completed'], completion['frozen'], completion['duplicates']) == (18,9,18),
            'Prior sweep is incomplete')
    require(completion['official_test_read'] is False, 'Prior official test access is not sealed')
    require(len(confirmation) == len(verification) == 9, 'Missing prior confirmation or replay')
    expected = {(str(seed),arm) for seed in (647713113,1852934521,230862299)
                for arm in ('pair_energy','odd_query_shape','transformer')}
    require({(str(r['seed']),r['arm']) for r in confirmation} == expected, 'Wrong confirmation coverage')
    require({(str(r['seed']),r['arm']) for r in verification} == expected, 'Wrong replay coverage')
    require(all(r['duplicate_exact'] is True and r['first'] == r['second'] and
                math.isfinite(r['first']['ce']) for r in confirmation), 'Nonfinite or drifting confirmation')
    require(all(r['strict_state_verified'] is True and r['selection_replay_exact'] is True for r in verification),
            'Prior checkpoint replay failed')

def construct(cfg, arm, initial=None):
    model = rotation.reference.reference.reference.PersistentMultiScaleLM(33278, cfg['width'], cfg['state_scales'])
    if initial is not None:
        model.load_state_dict(initial, strict=True)
    if arm == 'original':
        return model
    if arm == 'input':
        return InputGeometryRotation(model, True)
    if arm == 'stopped_cross':
        return StoppedGeometryRotation(model, True)
    if arm in ('local', 'cross'):
        return rotation.RegularizedRotation(model, arm == 'cross')
    raise ValueError('Unknown comparison arm: '+str(arm))

def batch(data, starts, step, context):
    windows = torch.stack([data[s+step*context:s+(step+1)*context+1] for s in starts])
    assert windows.shape == (len(starts), context+1)
    return windows[:, :-1], windows[:, 1:]

def training_lanes(token_count, cfg):
    """Disjoint target lanes; reset memory before repeating each full traversal."""
    lane_targets = ((token_count-1)//cfg['batch']//cfg['context'])*cfg['context']
    if lane_targets < cfg['context']:
        raise ValueError('Corpus is too short for contiguous training lanes')
    starts = [i*lane_targets for i in range(cfg['batch'])]
    return starts, lane_targets//cfg['context']

def score(model, data, region, cfg):
    count, context, size = region['targets'], cfg['context'], cfg['batch']
    assert count % (context*size) == 0
    steps = count // (context*size)
    starts = [region['start']+i*steps*context for i in range(size)]
    state, losses, digest = None, [], hashlib.sha256()
    model.eval()
    with torch.no_grad():
        for step in range(steps):
            x, y = batch(data, starts, step, context)
            logits, state = model(x, state, return_state=True)
            assert torch.isfinite(logits).all() and torch.isfinite(state).all()
            losses.append(float(torch.nn.functional.cross_entropy(logits.flatten(0,1), y.flatten(), reduction='sum')))
            digest.update(logits.contiguous().numpy().tobytes())
    model.train()
    return {'ce': math.fsum(losses)/count, 'targets': count, 'logit_sha256': digest.hexdigest(),
            'target_interval': [region['start']+1, region['start']+count]}

def read_data(source):
    assert sha(BASE_CONFIG) == '419045f33d2d2013dd8adc2b00086fffd7799ee8f3129e6b742a77641f886a49'
    vocab_pin = source['vocabulary']
    path = Path(vocab_pin['path'])
    assert sha(path) == vocab_pin['sha256']
    payload = torch.load(path, map_location='cpu', weights_only=True)
    assert set(payload) == {'vocabulary', 'source_checkpoint_sha256'}
    vocab = payload['vocabulary']
    assert len(vocab) == 33278 and set(vocab.values()) == set(range(33278))
    assert {k:vocab[k] for k in vocab_pin['special_ids']} == vocab_pin['special_ids']
    receipts = json.loads((BASE_CONFIG.parent/'run/DATA_RECEIPTS.json').read_text())
    data = {}
    for kind in ('train', 'valid'):
        pin = source['data'][kind]
        path = Path(pin['path'])
        assert path.resolve(strict=True) == path and path.name == kind+'.txt'
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin['sha256']
        values = [vocab.get(word, vocab['<unk>']) for line in raw.decode('utf-8').splitlines()
                  for word in line.split()+['<eos>']]
        data[kind] = torch.tensor(values, dtype=torch.int64)
        assert len(values) == receipts[kind]['word_tokens_with_per_line_eos']
        assert hashlib.sha256(data[kind].numpy().tobytes()).hexdigest() == receipts[kind]['token_int64_sha256']
    return data, receipts

def comparison_data_receipts(receipts, cfg):
    """Preserve verified data identity, but derive this experiment's budget."""
    result = {kind: receipts[kind] for kind in ('train', 'valid', 'vocabulary')}
    targets = cfg['updates'] * cfg['context'] * cfg['batch']
    assert targets == cfg['word_target_exposures_per_trial']
    count = receipts['train']['word_tokens_with_per_line_eos']
    starts, traversal_steps = training_lanes(count, cfg)
    traversal_targets = traversal_steps*cfg['context']*cfg['batch']
    result['exposure'] = {
        'train_word_tokens': count,
        'word_target_exposures_per_trial': targets,
        'exposure_over_train_token_count': targets / count,
        'not_same_epochs_across_byte_and_word_units': True,
        'sampling': 'disjoint_contiguous_target_lanes_reset_at_traversal_boundary',
        'lane_starts': starts,
        'updates_per_full_lane_traversal': traversal_steps,
        'unique_target_positions_per_traversal': traversal_targets,
        'unique_target_positions_seen_per_trial': min(cfg['updates'], traversal_steps)*cfg['context']*cfg['batch'],
        'omitted_tail_targets_per_traversal': count-1-traversal_targets,
        'completed_full_lane_traversals': cfg['updates']//traversal_steps,
        'partial_final_traversal_updates': cfg['updates']%traversal_steps,
        'ratio_is_not_completed_epochs': True,
    }
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--prior-trainer-pid', type=int)
    args = parser.parse_args()
    cfg, source = json.loads(PLAN.read_text()), json.loads(BASE_CONFIG.read_text())
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    require(cfg['word_target_exposures_per_trial'] == cfg['updates']*cfg['context']*cfg['batch'], 'Exposure budget mismatch')
    require(cfg['selection']['start']+cfg['selection']['targets'] < cfg['confirmation']['start'], 'Evaluation regions overlap')
    require(cfg['confirmation']['start']+cfg['confirmation']['targets'] < 217646, 'Confirmation outside validation region')
    require(ROOT.is_relative_to(Path('/Volumes/SP AI 01_16/CodexWorkspaces')), 'Workspace is outside SSD boundary')
    require(os.path.ismount('/Volumes/SP AI 01_16') and os.access(ROOT, os.W_OK), 'SSD unavailable or not writable')
    if not args.run:
        print(json.dumps({'status': 'configuration_preflight_passed', 'task_data_reads': 0,
                          'official_test_reads': 0, 'launch': False}))
        return
    require(args.prior_trainer_pid is not None and args.prior_trainer_pid > 0, 'Explicit positive previous trainer identity required')
    try:
        os.kill(args.prior_trainer_pid, 0)
    except ProcessLookupError:
        pass
    else:
        raise RuntimeError('Previous trainer PID still exists: refusing competing launch')
    # Absence alone is insufficient: the previous comparison must have a terminal receipt.
    prior = BASE_CONFIG.parent/'run'
    completion = json.loads((prior/'COMPLETION.json').read_text())
    confirmation = json.loads((prior/'CONFIRMATION.json').read_text())
    verification = json.loads((prior/'SELECTED_VERIFICATION.json').read_text())
    validate_prior_receipts(completion,confirmation,verification)
    require(all(sha(Path(p)) == pin for p,pin in completion['boundary_seals'].items()), 'Prior boundary seals changed')
    out = ROOT/'word-rotation-run'
    out.mkdir(exist_ok=False)
    files = [Path(__file__).resolve(), PLAN, BASE_CONFIG, ROOT/'regularized_rotation.py',
             ROOT/'input_rotation_control.py', ROOT/'rotation_feedback_control.py',
             ROOT/'packed_rotation.py', ROOT/'cross_scale_rotation_canary.py']+list((ROOT/'experiments').rglob('*.py'))
    seals = {str(p): sha(p) for p in files}
    receipt_seals = {}
    def check():
        verify_seals(seals)
        verify_seals(receipt_seals)
        for pin in [source['vocabulary'], *source['data'].values()]:
            assert sha(Path(pin['path'])) == pin['sha256']
    write(out/'PROTOCOL.json', {'config': cfg, 'source_hashes': seals, 'official_test_reads': 0})
    receipt_seals[str(out/'PROTOCOL.json')] = sha(out/'PROTOCOL.json')
    try:
        data, receipts = read_data(source)
        write(out/'DATA_RECEIPTS.json', comparison_data_receipts(receipts, cfg))
        receipt_seals[str(out/'DATA_RECEIPTS.json')] = sha(out/'DATA_RECEIPTS.json')
        trials, selected, streams = [], [], {}
        for seed in cfg['seeds']:
            torch.manual_seed(seed)
            initial = construct(cfg, 'original').state_dict()
            starts, traversal_steps = training_lanes(len(data['train']), cfg)
            streams[str(seed)] = starts
            for arm in cfg['arms']:
                arm_trials = []
                for lr in cfg['learning_rates']:
                    check()
                    model = construct(cfg, arm, initial)
                    assert sum(p.numel() for p in model.parameters()) == cfg['expected_parameters'][arm]
                    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, betas=(.9,.999),
                                                   eps=1e-8, weight_decay=.01, foreach=False,
                                                   amsgrad=False, maximize=False)
                    state, best = None, None
                    for step in range(cfg['updates']):
                        lane_step = step % traversal_steps
                        if lane_step == 0:
                            state = None
                        x,y = batch(data['train'], starts, lane_step, cfg['context'])
                        optimizer.zero_grad()
                        logits,state = model(x,state,return_state=True)
                        loss = torch.nn.functional.cross_entropy(logits.flatten(0,1),y.flatten())
                        loss.backward()
                        assert torch.isfinite(loss) and all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
                        torch.nn.utils.clip_grad_norm_(model.parameters(),1, norm_type=2, foreach=False)
                        optimizer.step()
                        verify_update(model, optimizer, state)
                        state = state.detach()
                        if (step+1) % cfg['selection']['every_updates'] == 0:
                            metric = score(model,data['valid'],cfg['selection'],cfg)
                            progress = {'seed':seed,'arm':arm,'lr':lr,'step':step+1,
                                        'word_target_exposures':(step+1)*cfg['context']*cfg['batch'],
                                        'selection':metric}
                            encoded = json.dumps(progress, allow_nan=False)
                            with (out/'progress.jsonl').open('a') as stream:
                                stream.write(encoded+'\n')
                                stream.flush()
                                os.fsync(stream.fileno())
                            print(encoded,flush=True)
                            if best is None or metric['ce'] < best['selection']['ce']:
                                checkpoint = out/f'{seed}-{arm}-{lr}-{step+1}.pt'
                                torch.save(model.state_dict(),checkpoint)
                                best = {'seed':seed,'arm':arm,'lr':lr,'step':step+1,'selection':metric,
                                        'checkpoint':str(checkpoint),'checkpoint_sha256':sha(checkpoint)}
                    best['completed_updates'] = cfg['updates']
                    best['word_target_exposures'] = cfg['word_target_exposures_per_trial']
                    trials.append(best)
                    arm_trials.append(best)
                selected.append(min(arm_trials,key=lambda r:(r['selection']['ce'],r['lr'],r['step'],r['checkpoint_sha256'])))
        write(out/'CANDIDATES.json',{'trials':trials,'streams':streams})
        write(out/'FREEZE.json',{'selected':selected})
        for name in ('CANDIDATES.json', 'FREEZE.json'):
            receipt_seals[str(out/name)] = sha(out/name)
        def load_selected(row):
            check()
            path = Path(row['checkpoint'])
            assert sha(path) == row['checkpoint_sha256']
            model = construct(cfg,row['arm'])
            saved = torch.load(path,map_location='cpu',weights_only=True)
            assert all(v.dtype == torch.float32 and torch.isfinite(v).all() for v in saved.values())
            model.load_state_dict(saved,strict=True)
            return model
        verified = []
        for row in selected:
            model = load_selected(row)
            assert score(model,data['valid'],cfg['selection'],cfg) == row['selection']
            verified.append({'seed':row['seed'],'arm':row['arm'],'checkpoint_sha256':row['checkpoint_sha256'], 'selection_replay_exact':True})
        write(out/'SELECTED_VERIFICATION.json',verified)
        receipt_seals[str(out/'SELECTED_VERIFICATION.json')] = sha(out/'SELECTED_VERIFICATION.json')
        results = []
        for row in selected:
            model = load_selected(row)
            first = score(model,data['valid'],cfg['confirmation'],cfg)
            check()
            assert sha(Path(row['checkpoint'])) == row['checkpoint_sha256']
            second = score(model,data['valid'],cfg['confirmation'],cfg)
            assert first == second
            results.append({'candidate':row,'first':first,'second':second,'duplicate_exact':True})
        paired = []
        for seed in cfg['seeds']:
            ce = {r['candidate']['arm']:r['first']['ce'] for r in results if r['candidate']['seed']==seed}
            paired.append({'seed':seed,'ce':ce,'passed':all(ce['cross'] < value for arm,value in ce.items() if arm != 'cross')})
        check()
        write(out/'COMPLETION.json',{'results':results,'paired':paired,'advance_gate_passed':all(r['passed'] for r in paired),'official_test_reads':0,
                                    'source_seals':seals,'receipt_seals':receipt_seals})
    except BaseException as error:
        write(out/'FAILURE.json',{'type':type(error).__name__,'message':str(error)})
        raise

if __name__ == '__main__':
    main()
