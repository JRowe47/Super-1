"""Untrained scale-readout ablation; no novelty or performance claim."""
import torch
from torch import nn


class LearnedScaleReadout(nn.Module):
    """Uniform at initialization; learned convex weights over memory scales.

    Express the readout as mean plus weighted disagreement so the zero-logit
    initialization retains the original mean exactly for power-of-two scales.
    This changes only readout, not the hierarchy's recurrent transition.
    """

    def __init__(self, scales):
        super().__init__()
        if scales < 2:
            raise ValueError('At least two memory scales required')
        self.scale_logits = nn.Parameter(torch.zeros(scales))

    def forward(self, state):
        if state.ndim != 3 or state.shape[1] != self.scale_logits.numel():
            raise ValueError('Expected batch, scale, channel state')
        mean = state.mean(1)
        weights = self.scale_logits.softmax(0)
        residual_weights = weights - torch.ones_like(weights)/weights.numel()
        return mean + (state*residual_weights[None, :, None]).sum(1)
