"""Identity-centered input-conditioned transport in a zero-mean scale plane."""
import math
import torch
from torch import nn


class ScaleTransport(nn.Module):
    def __init__(self, scales, width):
        super().__init__()
        if scales < 3 or width < 1:
            raise ValueError('At least three scales and positive width required')
        # Helmert plane: geometric coordinates, not learned task constants.
        basis = torch.zeros(scales, 2)
        basis[0, 0], basis[1, 0] = 1 / math.sqrt(2), -1 / math.sqrt(2)
        basis[0, 1], basis[1, 1], basis[2, 1] = 1 / math.sqrt(6), 1 / math.sqrt(6), -2 / math.sqrt(6)
        self.register_buffer('basis', basis)
        self.query = nn.Linear(width, width)
        self.gain = nn.Parameter(torch.zeros(width))

    def forward(self, state, token_embedding):
        if state.ndim != 3 or token_embedding.shape != (state.shape[0], state.shape[2]):
            raise ValueError('Expected [batch,scale,width] and [batch,width]')
        if state.shape[1] != self.basis.shape[0]:
            raise ValueError('Scale count differs')
        a = (state * self.basis[:, 0][None, :, None]).sum(1)
        b = (state * self.basis[:, 1][None, :, None]).sum(1)
        angle = self.gain.tanh()[None, :] * self.query(token_embedding).tanh()
        c, s = angle.cos(), angle.sin()
        da = (c - 1) * a - s * b
        db = s * a + (c - 1) * b
        return state + self.basis[:, 0][None, :, None] * da[:, None, :] + self.basis[:, 1][None, :, None] * db[:, None, :]
