"""Synthetic fidelity only: no dataset, checkpoint, or training-run access."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
PINS = {
    'function_weight_wt2_original_multiscale_decisive/models.py': '3dbe4fa50a4e7e0a9f1d1dec72b8e209e66ae842cb164e00d93cb4fe56d854a8',
    'function_weight_wikitext2_benchmark/model_core.py': '0e43040605679d73f2654c4d30afc1e29bbfadb46dbafc12cb4ff4f5bc24f61a',
    'function_weight_wt2_original_transformer_port/model.py': '3180772c6614b31d2152782d36aba4c3c6545f216fcca21df870975133393145',
}
def seals():
    for relative, expected in PINS.items():
        path = ROOT / 'experiments' / relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
        assert path.stat().st_mode & 0o222 == 0
seals()
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
spec = importlib.util.spec_from_file_location('preserved_hierarchy', ROOT / 'experiments' / next(iter(PINS)))
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
results = []
for dtype, tolerance in [(torch.float64, 1e-12), (torch.float32, 2e-5)]:
    # Original scan creates zeros with the global default dtype. Match it to
    # the model for this synthetic precision test without editing its source.
    torch.set_default_dtype(dtype)
    torch.manual_seed(20261002)
    legacy = module.AUTHORITATIVE_MULTISCALE_MODULE.MultiScaleLM(37, 16, {'state_scales': 4}).to(dtype)
    packed = module.PersistentMultiScaleLM(37, 16, 4).to(dtype)
    packed.load_state_dict(legacy.state_dict(), strict=True)
    tokens = torch.randint(37, (2, 70))
    a, b = legacy(tokens), packed(tokens)
    drift = (a - b).abs().max().item()
    a.square().mean().backward()
    b.square().mean().backward()
    gradients = {name: (param.grad - dict(packed.named_parameters())[name].grad).abs().max().item() for name, param in legacy.named_parameters()}
    assert drift < tolerance and max(gradients.values()) < tolerance
    with torch.no_grad():
        whole, final = packed(tokens, return_state=True)
        first, state = packed(tokens[:, :23], return_state=True)
        last, carried = packed(tokens[:, 23:], state, return_state=True)
        chunk_drift = (whole - torch.cat([first, last], 1)).abs().max().item()
        state_drift = (final - carried).abs().max().item()
        advance_drift = (final - packed.advance_state(tokens, packed.initial_state(2))).abs().max().item()
        prefix_drift = (whole[:, :23] - packed(tokens[:, :23])).abs().max().item()
        assert max(chunk_drift, state_drift, advance_drift, prefix_drift) < tolerance
    optimizer = torch.optim.AdamW(packed.parameters(), lr=0.001, foreach=False)
    for _ in range(2):
        optimizer.zero_grad()
        loss = packed(tokens).square().mean()
        loss.backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in packed.parameters())
        optimizer.step()
        assert all(torch.isfinite(p).all() for p in packed.parameters())
    results.append(dict(dtype=str(dtype), tolerance=tolerance, logits_max_drift=drift, gradient_max_drifts=gradients, chunk_logits_max_drift=chunk_drift, carried_state_max_drift=state_drift, advance_state_max_drift=advance_drift, causal_prefix_max_drift=prefix_drift, synthetic_optimizer_updates=2))
seals()
report = dict(scope='Synthetic original-hierarchy fidelity; no language accuracy, novelty or SOTA claim', results=results, source_pins=PINS, task_data_reads=0, trained_checkpoint_reads=0, official_test_reads=0)
with (ROOT / 'FIDELITY_REPORT.json').open('x') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps(report, indent=2))
