"""Operator invariants only; no language data, checkpoint or active-run edits."""
import hashlib
import json
from pathlib import Path
import torch
from scale_transport import ScaleTransport

ROOT = Path(__file__).resolve().parent
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
rows = []
for dtype in (torch.float32, torch.float64):
    torch.manual_seed(23811)
    model = ScaleTransport(4, 32).to(dtype=dtype)
    state = torch.randn(2, 4, 32, dtype=dtype, requires_grad=True)
    token = torch.randn(2, 32, dtype=dtype, requires_grad=True)
    identity = model(state, token)
    assert torch.equal(identity, state)
    (identity * torch.randn_like(identity)).sum().backward()
    assert model.gain.grad is not None and torch.isfinite(model.gain.grad).all()
    assert torch.count_nonzero(model.gain.grad) == model.gain.numel()
    # The query is intentionally masked at identity; it becomes trainable once
    # gain moves. Do not claim all new parameters receive gradients initially.
    with torch.no_grad():
        model.gain.fill_(.3)
    model.zero_grad(set_to_none=True)
    output = model(state, token)
    mean_drift = float((output.mean(1)-state.mean(1)).detach().abs().max())
    energy_drift = float((output.square().sum(1)-state.square().sum(1)).detach().abs().max())
    tolerance = 3e-6 if dtype == torch.float32 else 2e-6
    # Basis originates in FP32, so casting alone is not FP64 exact geometry.
    assert mean_drift < tolerance and energy_drift < tolerance
    (output * torch.randn_like(output)).sum().backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    assert torch.count_nonzero(model.query.weight.grad) > 0
    assert torch.isfinite(state.grad).all() and torch.isfinite(token.grad).all()
    rows.append(dict(dtype=str(dtype), identity_bit_exact=True,
                     mean_max_roundoff=mean_drift, scale_energy_max_roundoff=energy_drift,
                     gain_gradient_nonzero_at_identity=True,
                     query_gradient_nonzero_at_nonzero_gain=True))
report = dict(results=rows, source_sha256=hashlib.sha256((ROOT/'scale_transport.py').read_bytes()).hexdigest(),
              scope='Operator invariants and gradients only. FP64 cast retains FP32 basis rounding. No language accuracy, global stability, novelty or SOTA claim.',
              task_data_reads=0, official_test_reads=0)
with (ROOT/'SCALE_TRANSPORT_OPERATOR_CANARY.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
print(json.dumps(report, indent=2))
