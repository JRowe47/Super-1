"""Input-only angle ablation, not an implementation of Mamba-3."""
import torch
from torch.nn import functional as F
from regularized_rotation import RegularizedRotation


class InputGeometryRotation(RegularizedRotation):
    def rotate_input(self, state, embedded):
        pairs = state.reshape(*state.shape[:-1], -1, 2)
        inputs = embedded.reshape(embedded.shape[0], -1, 2)
        radius = F.softplus(self.log_radius)[None, :, None]
        numerator = (inputs[..., 0]*inputs[..., 1])[:, None]
        energy = inputs.square().sum(-1)[:, None]
        angle = torch.tanh(self.rotation_gain)[None, :, None]*numerator/(radius+energy)
        cosine, sine = torch.cos(angle), torch.sin(angle)
        return torch.stack([cosine*pairs[..., 0]-sine*pairs[..., 1],
                            sine*pairs[..., 0]+cosine*pairs[..., 1]], -1).flatten(-2)

    def forward(self, tokens, state=None, return_state=False):
        core = self.base.core
        embedded = core.embedding(tokens)
        if state is None:
            state = self.base.initial_state(tokens.shape[0])
        self.base._validate_state(state, embedded)
        terms = F.linear(embedded, torch.cat([core.input_update.weight, core.input_gate.weight]),
                         torch.cat([core.input_update.bias, core.input_gate.bias]))
        inputs_update, inputs_gate = terms.split(self.base.width, -1)
        recurrent = torch.cat([core.state_update.weight, core.state_gate.weight])
        scale, means = core.scale[None], []
        for index in range(tokens.shape[1]):
            ru, rg = F.linear(state, recurrent).split(self.base.width, -1)
            coupled = core.coupling(state.mean(1, keepdim=True))
            update = torch.tanh(inputs_update[:, index, None]+ru+coupled+scale)
            gate = torch.sigmoid(inputs_gate[:, index, None]+rg-scale)
            state = self.rotate_input(gate*state+(1-gate)*update, embedded[:, index])
            means.append(state.mean(1))
        logits = self.base.output(core.norm(torch.stack(means, 1)))
        return (logits, state) if return_state else logits
