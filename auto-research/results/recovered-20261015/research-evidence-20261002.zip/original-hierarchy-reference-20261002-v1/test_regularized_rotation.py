"""Synthetic original-base identity, norm, gradient and carry checks."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('regularized_candidate',ROOT/'regularized_rotation.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
base_class=module.reference.reference.reference.PersistentMultiScaleLM
rows=[]
for seed in [10313,31817]:
    torch.manual_seed(seed)
    original=base_class(256,32,4)
    tokens=torch.randint(256,(2,512))
    initial=original.state_dict()
    for cross in [False,True]:
        base=base_class(256,32,4)
        base.load_state_dict(initial)
        model=module.RegularizedRotation(base,cross)
        with torch.no_grad():
            identity_drift=float((original(tokens)-model(tokens)).abs().max())
        assert identity_drift == 0
        optimizer=torch.optim.AdamW(model.parameters(),lr=.001,foreach=False)
        gradients=[]
        for step in range(3):
            optimizer.zero_grad()
            logits=model(tokens)
            loss=logits.square().mean()
            loss.backward()
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
            assert model.rotation_gain.grad.abs().sum()>0
            gradients.append(max(float(p.grad.abs().max()) for p in model.parameters()))
            optimizer.step()
        with torch.no_grad():
            logits,state=model(tokens,return_state=True)
            a,s=model(tokens[:,:173],return_state=True)
            b,end=model(tokens[:,173:],s,return_state=True)
            assert torch.equal(logits,torch.cat([a,b],1)) and torch.equal(state,end)
            assert torch.equal(a,model(tokens[:,:173]))
            probe=torch.randn(2,4,32)
            norm_drift=float((probe.reshape(2,4,16,2).square().sum(-1)-model.rotate(probe).reshape(2,4,16,2).square().sum(-1)).abs().max())
            assert norm_drift < 2e-6
            model.rotation_gain.fill_(10)
        model.zero_grad()
        model(tokens).square().mean().backward()
        strong_grad=max(float(p.grad.abs().max()) for p in model.parameters())
        assert all(torch.isfinite(p.grad).all() for p in model.parameters())
        rows.append(dict(seed=seed,cross_scale=cross,identity_logits_exact=True,context=512,joint_updates=3,update_max_gradients=gradients,strong_bounded_gain_max_gradient=strong_grad,pair_squared_norm_max_drift=norm_drift,chunk_state_exact=True,added_parameters=8))
report=dict(results=rows,module_sha256=hashlib.sha256((ROOT/'regularized_rotation.py').read_bytes()).hexdigest(),scope='Synthetic canary only; no language accuracy, no novelty or global stability proof',task_data_reads=0,official_test_reads=0)
with (ROOT/'REGULARIZED_ROTATION_CANARY.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
