"""Synthetic native execution parity; no trained checkpoint or data reads."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import torch

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('scripted_test_candidate',ROOT/'scripted_regularized_rotation.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
rows=[]
base_class=module.reference.reference.reference.reference.PersistentMultiScaleLM
for cross in [False,True]:
    for length in [128,512]:
        torch.manual_seed(9611)
        eager=module.reference.RegularizedRotation(base_class(256,32,4),cross)
        compiled=module.ScriptedRegularizedRotation(base_class(256,32,4),cross)
        with torch.no_grad():
            eager.rotation_gain.copy_(torch.tensor([.2,-.1,.3,-.2]))
        compiled.load_state_dict(eager.state_dict())
        tokens=torch.randint(256,(2,length))
        durations={}
        outputs=[]
        states=[]
        for name,model in [('eager',eager),('scripted',compiled)]:
            times=[]
            for _ in range(3):
                model.zero_grad()
                start=time.perf_counter()
                logits,state=model(tokens,return_state=True)
                logits.square().mean().backward()
                times.append(time.perf_counter()-start)
            durations[name]=times
            outputs.append(logits.detach())
            states.append(state.detach())
        logit_drift=float((outputs[0]-outputs[1]).abs().max())
        state_drift=float((states[0]-states[1]).abs().max())
        gradient_drift=max(float((p.grad-dict(compiled.named_parameters())[name].grad).abs().max()) for name,p in eager.named_parameters())
        assert max(logit_drift,state_drift,gradient_drift)<2e-6
        rows.append(dict(cross_scale=cross,context=length,logit_max_drift=logit_drift,state_max_drift=state_drift,gradient_max_drift=gradient_drift,forward_backward_seconds=durations))
report=dict(results=rows,scope='Native synthetic parity only. TorchScript sequential loop, not fused/block parallel. Concurrent CPU timings, no language accuracy claim.',task_data_reads=0,official_test_reads=0)
with (ROOT/'SCRIPTED_REGULARIZED_VERIFICATION.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
