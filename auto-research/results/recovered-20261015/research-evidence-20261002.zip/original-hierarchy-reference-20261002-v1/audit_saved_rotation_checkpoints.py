"""Read-only saved tensor preservation audit; no predictions or data reads."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT=Path(__file__).resolve().parent
RUN=ROOT/'regularized-language-run'
protocol=json.loads((RUN/'PROTOCOL.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(Path(path))==pin for path,pin in protocol['source_hashes'].items())
spec=importlib.util.spec_from_file_location('preservation_rotation',ROOT/'regularized_rotation.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)
base_class=module.reference.reference.reference.PersistentMultiScaleLM
expected={}
for arm in protocol['config']['arms']:
    base=base_class(256,64,4)
    model=base if arm=='original' else module.RegularizedRotation(base,arm=='cross')
    expected[arm]={name:tuple(value.shape) for name,value in model.state_dict().items()}
rows=[]
for path in sorted(RUN.glob('*.pt')):
    arm=path.name.split('-')[1]
    assert arm in expected
    before=sha(path)
    try:
        state=torch.load(path,map_location='cpu',weights_only=True)
    except (EOFError,RuntimeError) as error:
        rows.append(dict(file=path.name,status='unreadable_at_snapshot',exception=type(error).__name__))
        continue
    after=sha(path)
    if before!=after:
        rows.append(dict(file=path.name,status='changed_during_snapshot'))
        continue
    assert set(state)==set(expected[arm]),path.name
    assert all(tuple(v.shape)==expected[arm][name] and v.dtype==torch.float32 and torch.isfinite(v).all() for name,v in state.items()),path.name
    digest=hashlib.sha256()
    for name in sorted(state):
        digest.update(name.encode())
        digest.update(state[name].contiguous().numpy().tobytes())
    rows.append(dict(file=path.name,status='stable_tensor_audit_passed',file_sha256=before,state_sha256=digest.hexdigest(),parameters=sum(v.numel() for v in state.values()),serialized_bytes=path.stat().st_size))
assert all(sha(Path(path))==pin for path,pin in protocol['source_hashes'].items())
print(json.dumps(dict(checkpoints=rows,task_data_reads=0,official_test_reads=0,scope='Tensor preservation only, not checkpoint ranking, evaluation or training provenance'),indent=2))
