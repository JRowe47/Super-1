"""Synthetic readout/transport checks, not language benchmark evidence."""
import json
import torch
from all_scale_transport import AllScaleTransport
from learned_scale_readout import LearnedScaleReadout


def main():
    torch.set_num_threads(1)
    rows = []
    for seed in (73, 191, 307):
        for dtype in (torch.float32, torch.float64):
            torch.manual_seed(seed)
            readout = LearnedScaleReadout(4).to(dtype=dtype)
            transport = AllScaleTransport(4, 16).to(dtype=dtype)
            with torch.no_grad():
                transport.gain.fill_(0.3)
            state = torch.randn(2, 4, 16, dtype=dtype)
            source = torch.randn(2, 16, dtype=dtype)
            probe = torch.randn(2, 16, dtype=dtype)
            moved = transport(state, source)
            if not torch.equal(readout(moved), moved.mean(1)):
                raise AssertionError('Uniform initialization changed mean')
            (readout(moved)*probe).sum().backward()
            gradient = readout.scale_logits.grad
            if not torch.isfinite(gradient).all() or gradient.norm() <= 1e-6:
                raise AssertionError('Scale readout did not receive gradient')
            with torch.no_grad():
                readout.scale_logits.add_(-0.01*gradient)
            weights = readout.scale_logits.softmax(0)
            direct = (moved*weights[None, :, None]).sum(1)
            tolerance = 1e-6 if dtype == torch.float32 else 1e-12
            torch.testing.assert_close(readout(moved), direct, atol=tolerance, rtol=tolerance)
            transport.zero_grad()
            (readout(transport(state, source))*probe).sum().backward()
            norm = transport.gain.grad.norm().item()
            if not torch.isfinite(transport.gain.grad).all() or norm <= 1e-6:
                raise AssertionError('Learned readout did not expose transport gradient')
            rows.append({'seed': seed, 'dtype': str(dtype),
                         'transport_gradient_after_readout_update': norm})
    print(json.dumps({'passed': True, 'cases': rows, 'data_reads': 0,
                      'scope': 'Synthetic algebra and gradients only; no performance or novelty claim'}))


if __name__ == '__main__':
    main()
