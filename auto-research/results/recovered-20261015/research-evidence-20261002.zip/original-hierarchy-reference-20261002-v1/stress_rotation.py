"""Long-context synthetic stress; no language corpus access."""
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('stress_packed',ROOT/'packed_rotation.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.manual_seed(10313)
rows=[]
for cross in [False,True]:
    for magnitude in [0.0,0.1,1.0]:
        base=module.reference.reference.PersistentMultiScaleLM(256,32,4)
        model=module.PackedRotation(base,cross)
        with torch.no_grad():
            model.rotation_gain.copy_(torch.tensor([magnitude,-magnitude,magnitude,-magnitude]))
        tokens=torch.randint(256,(2,512))
        logits,state=model(tokens,return_state=True)
        loss=logits.square().mean()
        loss.backward()
        assert torch.isfinite(logits).all() and torch.isfinite(state).all()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
        rows.append(dict(cross_scale=cross,gain_magnitude=magnitude,context=512,loss=float(loss.detach()),state_norm=float(state.detach().norm()),max_parameter_gradient=max(float(p.grad.abs().max()) for p in model.parameters())))
report=dict(results=rows,task_data_reads=0,official_test_reads=0,scope='Finite-gradient synthetic stress only, not long-context retrieval or language accuracy; no global stability proof')
with (ROOT/'ROTATION_LONG_CONTEXT_STRESS.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
