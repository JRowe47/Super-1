"""Untrained all-scale transport candidate, not a novelty or SOTA claim.

Rotate adjacent Helmert coordinates of scale disagreement. Each rotation
preserves the mean scale readout and total state energy in exact arithmetic.
The original hierarchy and earlier transport prototype are unchanged.
"""
import math
import torch
from torch import nn


class AllScaleTransport(nn.Module):
    def __init__(self, scales, width):
        super().__init__()
        if scales < 3 or width < 1:
            raise ValueError('At least three scales and positive width required')
        basis = torch.zeros(scales, scales-1)
        for j in range(scales-1):
            denominator = math.sqrt((j+1)*(j+2))
            basis[:j+1, j] = 1/denominator
            basis[j+1, j] = -(j+1)/denominator
        self.register_buffer('basis', basis)
        self.width = width
        self.query = nn.Linear(width, (scales-2)*width)
        self.gain = nn.Parameter(torch.zeros(scales-2, width))

    def angles(self, token_embedding):
        if token_embedding.shape[-1] != self.width:
            raise ValueError('Unexpected embedding width')
        angles = self.query(token_embedding).reshape(*token_embedding.shape[:-1], -1, self.width).tanh()
        return angles*self.gain.tanh()

    def apply_angles(self, state, angles):
        if state.ndim != 3 or state.shape[1:] != (self.basis.shape[0], self.width):
            raise ValueError('Unexpected hierarchy state shape')
        if angles.shape != (state.shape[0], self.basis.shape[1]-1, self.width):
            raise ValueError('Unexpected transport angle shape')
        result = state
        for j in range(self.basis.shape[1]-1):
            u, v = self.basis[:, j][None, :, None], self.basis[:, j+1][None, :, None]
            a, b = (result*u).sum(1), (result*v).sum(1)
            cosine, sine = angles[:, j].cos(), angles[:, j].sin()
            da = (cosine-1)*a-sine*b
            db = sine*a+(cosine-1)*b
            result = result+u*da[:, None]+v*db[:, None]
        return result

    def forward(self, state, token_embedding):
        if token_embedding.shape != (state.shape[0], self.width):
            raise ValueError('Unexpected token embedding shape')
        return self.apply_angles(state, self.angles(token_embedding))
