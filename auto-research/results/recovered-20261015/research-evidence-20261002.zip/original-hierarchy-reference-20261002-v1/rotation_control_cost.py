"""Synthetic controls and cost; never reads language data."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import torch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rotation_candidate', ROOT / 'cross_scale_rotation_canary.py')
candidate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = candidate
spec.loader.exec_module(candidate)

def main():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    rows = []
    for seed in [73, 191, 307]:
        torch.manual_seed(seed)
        initial = candidate.reference.PersistentMultiScaleLM(256, 64, 4)
        tokens = torch.randint(256, (2, 70))
        targets = torch.randint(256, (2, 70))
        for arm in ['unchanged', 'local_only', 'cross_scale']:
            base = candidate.reference.PersistentMultiScaleLM(256, 64, 4)
            base.load_state_dict(initial.state_dict())
            model = base if arm == 'unchanged' else candidate.CrossScaleRotation(base, cross_scale=arm == 'cross_scale')
            optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, foreach=False)
            timings = []
            gains = []
            for step in range(5):
                start = time.perf_counter()
                optimizer.zero_grad()
                output = model(tokens)
                loss = torch.nn.functional.cross_entropy(output.flatten(0, 1), targets.flatten())
                loss.backward()
                assert torch.isfinite(loss) and all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
                if arm != 'unchanged':
                    gains.append(model.rotation_gain.grad.detach().tolist())
                optimizer.step()
                timings.append(time.perf_counter() - start)
            assert arm == 'unchanged' or any(abs(x) > 0 for x in gains[0])
            rows.append(dict(seed=seed, arm=arm, parameters=sum(p.numel() for p in model.parameters()), synthetic_updates=5, measured_seconds=timings, initial_gain_gradient=gains[0] if gains else None, final_synthetic_ce=loss.item()))
    report = dict(rows=rows, context=70, batch=2, width=64, seeds=[73,191,307], scope='Synthetic uniform random tokens; CE is a plumbing check, not language-model performance. CPU concurrent workloads make timing noisy; not matched FLOPs.', task_data_reads=0, official_test_reads=0)
    with (ROOT / 'ROTATION_CONTROL_COST.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
