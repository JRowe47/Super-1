"""Matched-initialization recurrent stress and isolated angle derivatives."""
import importlib.util
import json
from pathlib import Path
import sys
import torch

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnostic_rotation',ROOT/'packed_rotation.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
torch.manual_seed(10313)
base_class=module.reference.reference.PersistentMultiScaleLM
initial=base_class(256,32,4).state_dict()
tokens=torch.randint(256,(2,512))
rows=[]
for cross in [False,True]:
    for magnitude in [0.0,0.1,1.0]:
        base=base_class(256,32,4)
        base.load_state_dict(initial)
        model=module.PackedRotation(base,cross)
        with torch.no_grad():
            model.rotation_gain.copy_(torch.tensor([magnitude,-magnitude,magnitude,-magnitude]))
        output,state=model(tokens,return_state=True)
        loss=output.square().mean()
        loss.backward()
        gradients={name:float(param.grad.abs().max()) for name,param in model.named_parameters()}
        assert all(torch.isfinite(param.grad).all() for param in model.parameters())
        rows.append(dict(cross_scale=cross,magnitude=magnitude,loss=float(loss.detach()),state_norm=float(state.detach().norm()),gradients=gradients))
derivatives=[]
for scale in [1.0,0.1,0.001,0.00001,0.0]:
    a=torch.tensor([scale,0.0],dtype=torch.float64,requires_grad=True)
    b=torch.tensor([0.0,scale],dtype=torch.float64,requires_grad=True)
    cross=a[0]*b[1]-a[1]*b[0]
    normalized=cross/torch.sqrt(a.square().sum()*b.square().sum()+1e-12)
    regularized=cross/(1+a.square().sum()+b.square().sum())
    for name,query in [('product_normalized',normalized),('energy_sum_regularized',regularized)]:
        grad=torch.autograd.grad(torch.tanh(query),[a,b],retain_graph=True)
        derivatives.append(dict(scale=scale,query=name,value=float(query.detach()),maximum_derivative=max(float(g.abs().max()) for g in grad)))
report=dict(matched_recurrence=rows,isolated_query_derivatives=derivatives,context=512,scope='Synthetic diagnosis using identical original weights and tokens, not language accuracy or global stability. Energy-sum query is only an isolated mathematical alternative, not a trained architecture.',task_data_reads=0,official_test_reads=0)
with (ROOT/'ROTATION_GRADIENT_DIAGNOSIS.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(dict(matched=[dict(cross_scale=r['cross_scale'],gain=r['magnitude'],max_gradient=max(r['gradients'].values())) for r in rows],derivatives=derivatives),indent=2))
