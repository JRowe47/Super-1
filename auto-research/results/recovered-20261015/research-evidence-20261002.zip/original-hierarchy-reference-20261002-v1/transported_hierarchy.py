"""Untrained identity-centered all-scale transport on the original hierarchy."""
import torch
from torch import nn
from torch.nn import functional as F
from all_scale_transport import AllScaleTransport


class TransportedHierarchy(nn.Module):
    def __init__(self, base, readout=None):
        super().__init__()
        self.base = base
        self.transport = AllScaleTransport(base.state_scales, base.width)
        self.readout = readout

    def forward(self, tokens, state=None, return_state=False):
        core = self.base.core
        embedded = core.embedding(tokens)
        angles = self.transport.angles(embedded)
        if state is None:
            state = self.base.initial_state(tokens.shape[0])
        self.base._validate_state(state, embedded)
        inputs = F.linear(embedded, torch.cat([core.input_update.weight, core.input_gate.weight]),
                          torch.cat([core.input_update.bias, core.input_gate.bias]))
        iu, ig = inputs.split(self.base.width, -1)
        recurrent = torch.cat([core.state_update.weight, core.state_gate.weight])
        scale, means = core.scale[None], []
        for index in range(tokens.shape[1]):
            ru, rg = F.linear(state, recurrent).split(self.base.width, -1)
            coupled = core.coupling(state.mean(1, keepdim=True))
            update = torch.tanh(iu[:, index, None]+ru+coupled+scale)
            gate = torch.sigmoid(ig[:, index, None]+rg-scale)
            state = self.transport.apply_angles(gate*state+(1-gate)*update, angles[:, index])
            means.append(state.mean(1) if self.readout is None else self.readout(state))
        logits = self.base.output(core.norm(torch.stack(means, 1)))
        return (logits, state) if return_state else logits
