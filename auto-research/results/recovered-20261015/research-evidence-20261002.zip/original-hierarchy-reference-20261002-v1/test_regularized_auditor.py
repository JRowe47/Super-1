"""Synthetic receipt fault injection; no task data or trained checkpoints."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('receipt_auditor',BASE/'audit_regularized_terminal.py')
auditor=importlib.util.module_from_spec(spec)
spec.loader.exec_module(auditor)
fixtures=Path(tempfile.mkdtemp(prefix='regularized-audit-fixtures-',dir=BASE))

def fixture(name):
    root=fixtures/name
    root.mkdir()
    config=dict(seeds=[73,191,307],arms=['original','local','cross'],learning_rates=[.001,.003],updates=6000,context=128,batch=4,selection_every=1000,selection_targets=16384,confirmation_start=900000,confirmation_targets=32768)
    candidates=[]
    for seed in config['seeds']:
        for arm in config['arms']:
            for lr in config['learning_rates']:
                path=root/f'{seed}-{arm}-{lr}.pt'
                path.write_bytes(b'synthetic-receipt-fixture-not-torch')
                candidates.append(dict(seed=seed,arm=arm,lr=lr,step=1000,completed_updates=6000,train_target_exposures=3072000,selection=dict(ce=2+lr,targets=16384),checkpoint=str(path),checkpoint_sha256=auditor.digest(path)))
    freeze=[r for r in candidates if r['lr']==.001]
    results=[]
    for row in freeze:
        metric=dict(ce={'original':2.0,'local':1.9,'cross':2.1}[row['arm']],targets=32768,target_interval=[900001,932768],logit_sha256='a'*64)
        results.append(dict(candidate=row,first=metric,second=copy.deepcopy(metric),duplicate_exact=True))
    paired=[dict(seed=seed,ce={'original':2.0,'local':1.9,'cross':2.1},passed=False) for seed in config['seeds']]
    payloads={'PROTOCOL.json':dict(config=config,source_hashes={}), 'CANDIDATES.json':dict(trials=candidates,streams={str(s):[0,1,2,3] for s in config['seeds']}),'FREEZE.json':dict(selected=freeze),'COMPLETION.json':dict(results=results,paired=paired,advance_gate_passed=False,official_test_reads=0,source_hashes={})}
    return root,payloads

def execute(name,mutate,expect_rejection):
    root,payloads=fixture(name)
    mutate(payloads,root)
    for file,value in payloads.items():
        (root/file).write_text(json.dumps(value))
    auditor.ROOT=root
    rejected=False
    try:
        result=auditor.audit()
        assert result['advance_gate_passed'] is False
    except (AssertionError,KeyError,FileNotFoundError):
        rejected=True
    assert rejected==expect_rejection,name
    return dict(case=name,rejected=rejected,passed=True)

rows=[]
rows.append(execute('valid_negative',lambda p,r:None,False))
rows.append(execute('missing_trial',lambda p,r:p['CANDIDATES.json']['trials'].pop(),True))
rows.append(execute('short_budget',lambda p,r:p['CANDIDATES.json']['trials'][0].update(completed_updates=5999),True))
rows.append(execute('duplicate_drift',lambda p,r:p['COMPLETION.json']['results'][0]['second'].update(ce=9),True))
rows.append(execute('false_gate',lambda p,r:p['COMPLETION.json'].update(advance_gate_passed=True),True))
rows.append(execute('wrong_region',lambda p,r:p['COMPLETION.json']['results'][0]['first'].update(target_interval=[1,32768]),True))
rows.append(execute('changed_checkpoint',lambda p,r:Path(p['CANDIDATES.json']['trials'][0]['checkpoint']).write_bytes(b'changed'),True))
report=dict(cases=rows,fixture_directory=str(fixtures),task_data_reads=0,trained_checkpoint_reads=0,scope='Synthetic receipt audit fault coverage only; not native model replay')
with (BASE/'REGULARIZED_AUDITOR_FAULT_TESTS.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
