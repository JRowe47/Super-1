"""Synthetic paired sensitivity probe; never a language benchmark.

Uses preserved original byte-model checkpoints, not the live word trainer.
No corpus reads, training, checkpoint writes, or official-test access.
"""
import hashlib
import json
from pathlib import Path
import torch
import regularized_rotation as reference
from all_scale_transport import AllScaleTransport


def main():
    root = Path(__file__).resolve().parent
    frozen = json.loads((root/'regularized-language-run/FREEZE.json').read_text())
    torch.set_num_threads(1)
    results = []
    for row in frozen['selected']:
        if row['arm'] != 'original':
            continue
        path = Path(row['checkpoint'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['checkpoint_sha256']:
            raise RuntimeError('Preserved checkpoint hash mismatch')
        torch.manual_seed(row['seed'])
        constructor = reference.reference.reference.reference.PersistentMultiScaleLM
        untrained, trained = constructor(256, 64, 4), constructor(256, 64, 4)
        trained.load_state_dict(torch.load(path, map_location='cpu', weights_only=True), strict=True)
        transport = AllScaleTransport(4, 64).double()
        tokens = torch.randint(256, (2, 130))
        probe = torch.randn(2, 64, dtype=torch.float64)
        for label, model in [('untrained', untrained), ('trained', trained)]:
            model = model.double().requires_grad_(False)
            state = model.advance_state(tokens[:, :1], model.initial_state(2))
            embedded = model.core.embedding(tokens[:, 0])
            sensitivities = []
            for horizon in (1, 32, 64, 128):
                transport.zero_grad(set_to_none=True)
                future = model.advance_state(tokens[:, 1:1+horizon], transport(state, embedded))
                (future.mean(1)*probe).sum().backward()
                sensitivity = float(transport.gain.grad.norm())
                if not torch.isfinite(transport.gain.grad).all():
                    raise FloatingPointError('Nonfinite probe gradient')
                sensitivities.append({'future_tokens': horizon, 'gradient_norm': sensitivity})
            results.append({'seed': row['seed'], 'model': label,
                            'checkpoint_sha256': row['checkpoint_sha256'] if label == 'trained' else None,
                            'sensitivities': sensitivities,
                            'retained_fraction_128_vs_1': sensitivities[-1]['gradient_norm']/sensitivities[0]['gradient_norm']})
    print(json.dumps({'results': results, 'task_data_reads': 0, 'official_test_reads': 0,
                      'scope': 'Synthetic random-input sensitivity, not recall accuracy, CE improvement, stability proof, novelty or SOTA.'}, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
