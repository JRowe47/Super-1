"""Full static validation metric for the hierarchy; no file or test loader.

Call only with verified validation tokens under a separately frozen protocol.
This evaluator does not establish official-test eligibility by itself.
"""
import hashlib
import math
import torch
from torch.nn import functional as F


def evaluate_full_validation(model, validation_tokens, batch_size, bptt):
    if validation_tokens.device.type != 'cpu' or validation_tokens.dtype != torch.int64:
        raise ValueError('Expected verified CPU int64 validation tokens')
    if validation_tokens.ndim != 1:
        raise ValueError('Expected a flat validation token stream')
    if batch_size < 1 or bptt < 1:
        raise ValueError('Positive batch size and context required')
    if any(p.device.type != 'cpu' or p.dtype != torch.float32 or
           not torch.isfinite(p).all() for p in model.parameters()):
        raise ValueError('Expected a finite CPU FP32 model')
    length = validation_tokens.numel()//batch_size
    if length < 2:
        raise ValueError('Insufficient validation targets')
    usable = length*batch_size
    lanes = validation_tokens[:usable].reshape(batch_size, length)
    losses, count, state = [], 0, None
    digest = hashlib.sha256()
    was_training = model.training
    model.eval()
    try:
        with torch.no_grad():
            for start in range(0, length-1, bptt):
                stop = min(start+bptt, length-1)
                x, y = lanes[:, start:stop], lanes[:, start+1:stop+1]
                logits, state = model(x, state, return_state=True)
                if logits.dtype != torch.float32 or logits.shape[:2] != y.shape:
                    raise ValueError('Invalid FP32 output shape')
                if not torch.isfinite(logits).all() or not torch.isfinite(state).all():
                    raise FloatingPointError('Nonfinite validation output or state')
                losses.append(float(F.cross_entropy(logits.flatten(0, 1),
                                                   y.flatten(), reduction='sum')))
                count += y.numel()
                digest.update(logits.contiguous().numpy().tobytes())
                state = state.detach()
    finally:
        model.train(was_training)
    expected = batch_size*(length-1)
    if count != expected:
        raise RuntimeError('Validation target count mismatch')
    nll_sum = math.fsum(losses)
    ce = nll_sum/count
    return {
        'ce': ce, 'perplexity': math.exp(ce), 'nll_sum': nll_sum,
        'predicted_targets': count, 'input_tokens': validation_tokens.numel(),
        'batch_size': batch_size, 'bptt': bptt,
        'batchified_length': length, 'discarded_tail_tokens': validation_tokens.numel()-usable,
        'unpredicted_lane_initial_tokens': batch_size,
        'logit_sha256': digest.hexdigest(),
        'normalization': 'sum_nll_over_actual_predicted_targets',
        'legacy_salesforce_sequence_denominator_ce': nll_sum/usable,
        'legacy_normalization_is_not_promotion_authority': True,
        'scope': 'Full static validation only; no official-test loader or eligibility decision',
    }
