"""Synthetic five-arm interface verification; no corpus or checkpoint access."""
import torch
import regularized_rotation as reference
from input_rotation_control import InputGeometryRotation
from rotation_feedback_control import StoppedGeometryRotation


def main():
    torch.set_num_threads(1)
    torch.manual_seed(49184)
    base_type = reference.reference.reference.reference.PersistentMultiScaleLM
    initial = base_type(33278, 64, 4).state_dict()
    tokens = torch.randint(33278, (1, 129))
    identity = None
    for arm in ('original', 'local', 'input', 'stopped_cross', 'cross'):
        base = base_type(33278, 64, 4)
        base.load_state_dict(initial)
        model = {'original': lambda: base,
                 'local': lambda: reference.RegularizedRotation(base, False),
                 'input': lambda: InputGeometryRotation(base, True),
                 'stopped_cross': lambda: StoppedGeometryRotation(base, True),
                 'cross': lambda: reference.RegularizedRotation(base, True)}[arm]()
        logits, state = model(tokens[:, :-1], return_state=True)
        if identity is None:
            identity = logits.detach(), state.detach()
        assert torch.equal(logits, identity[0]) and torch.equal(state, identity[1])
        if arm != 'original':
            with torch.no_grad():
                model.rotation_gain.fill_(.3)
        logits, state = model(tokens[:, :-1], return_state=True)
        left, carried = model(tokens[:, :64], return_state=True)
        right, final = model(tokens[:, 64:-1], carried, return_state=True)
        assert torch.equal(state, final)
        assert torch.allclose(logits, torch.cat([left, right], 1), atol=1e-6, rtol=1e-6)
        optimizer = torch.optim.AdamW(model.parameters(), lr=.001, foreach=False)
        loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), tokens[:, 1:].flatten())
        loss.backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
        optimizer.step()
        assert all(torch.isfinite(p).all() for p in model.parameters())
        assert all(torch.isfinite(v).all() for s in optimizer.state.values()
                   for v in s.values() if isinstance(v, torch.Tensor))
        print(arm, 'identity/carry/gradient/optimizer PASS', flush=True)
    print('Synthetic checks only; task-data reads 0; official-test reads 0.')


if __name__ == '__main__':
    main()
