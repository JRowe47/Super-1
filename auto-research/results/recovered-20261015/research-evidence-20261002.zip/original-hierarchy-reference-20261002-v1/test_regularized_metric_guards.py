"""Additional malformed metric tests without importing training code."""
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('metric_guard_audit',ROOT/'audit_regularized_terminal.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
# Copy prior synthetic fixtures through normal JSON serialization. These are
# not trained checkpoints and never run task evaluation.
old=json.loads((ROOT/'REGULARIZED_AUDITOR_FAULT_TESTS.json').read_text())
source=Path(old['fixture_directory'])/'valid_negative'
cases=[]
for name,value in [('nan',float('nan')),('infinite',float('inf')),('negative',-1.0),('zero',0.0)]:
    root=source.parent/f'metric-{name}'
    root.mkdir()
    for filename in ['PROTOCOL.json','CANDIDATES.json','FREEZE.json','COMPLETION.json']:
        payload=json.loads((source/filename).read_text())
        if filename=='COMPLETION.json':
            payload['results'][0]['first']['ce']=value
            payload['results'][0]['second']['ce']=value
        (root/filename).write_text(json.dumps(payload))
    # Candidate paths must remain inside this receipt root, so relocate only
    # synthetic fixture bytes and their JSON references before the audit.
    for filename in ['CANDIDATES.json','FREEZE.json','COMPLETION.json']:
        text=(root/filename).read_text().replace(str(source),str(root))
        (root/filename).write_text(text)
    for checkpoint in source.glob('*.pt'):
        (root/checkpoint.name).write_bytes(checkpoint.read_bytes())
    module.ROOT=root
    rejected=False
    try:
        module.audit()
    except AssertionError:
        rejected=True
    assert rejected,name
    cases.append(dict(case=name,rejected=True))
report=dict(cases=cases,task_data_reads=0,trained_checkpoint_reads=0,scope='Malformed metric receipt rejection only')
with (ROOT/'REGULARIZED_METRIC_GUARD_TESTS.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
