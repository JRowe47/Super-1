"""Receipt guard fixtures only; no data or checkpoint evaluation."""
import copy
import hashlib
import json
from pathlib import Path
from word_rotation_runner import validate_prior_receipts

root = Path(__file__).resolve().parent
completion = {'trials_completed':18,'frozen':9,'duplicates':18,'official_test_read':False}
confirmation, verification = [], []
for seed in (647713113,1852934521,230862299):
    for arm in ('pair_energy','odd_query_shape','transformer'):
        metric = {'ce':5.,'logit_sha256':'fixture'}
        confirmation.append({'seed':str(seed),'arm':arm,'duplicate_exact':True,'first':metric,'second':dict(metric)})
        verification.append({'seed':str(seed),'arm':arm,'strict_state_verified':True,'selection_replay_exact':True})
validate_prior_receipts(completion,confirmation,verification)
rows = [{'case':'valid_fixture','passed':True}]
cases = [
    ('incomplete_training', lambda c,r,v: c.update(trials_completed=17)),
    ('official_test_access', lambda c,r,v: c.update(official_test_read=True)),
    ('missing_checkpoint', lambda c,r,v: r.pop()),
    ('wrong_seed', lambda c,r,v: r[0].update(seed='other')),
    ('duplicate_arm', lambda c,r,v: r[0].update(arm=r[1]['arm'])),
    ('duplicate_drift', lambda c,r,v: r[0]['second'].update(ce=5.1)),
    ('nonfinite_metric', lambda c,r,v: (r[0]['first'].update(ce=float('inf')),r[0]['second'].update(ce=float('inf')))),
    ('failed_native_replay', lambda c,r,v: v[0].update(selection_replay_exact=False)),
]
for field in ('duplicate_exact', 'strict_state_verified', 'selection_replay_exact'):
    for malformed in ('false', 'true', 1, False, None):
        def invalidate(c, r, v, field=field, malformed=malformed):
            target = r if field == 'duplicate_exact' else v
            target[0][field] = malformed
        cases.append(('non_boolean_'+field+'_'+repr(malformed), invalidate))
for name,mutate in cases:
    c,r,v = copy.deepcopy((completion,confirmation,verification))
    mutate(c,r,v)
    try:
        validate_prior_receipts(c,r,v)
    except (AssertionError,KeyError):
        rows.append({'case':name,'rejected':True})
    else:
        raise AssertionError('Guard accepted '+name)
report = {'cases':rows,'runner_sha256':hashlib.sha256((root/'word_rotation_runner.py').read_bytes()).hexdigest(),
          'task_data_reads':0,'official_test_reads':0,
          'scope':'Receipt validator fixtures, not full-run or independent checkpoint verification.'}
with (root/'WORD_ROTATION_GUARD_FIXTURES.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
