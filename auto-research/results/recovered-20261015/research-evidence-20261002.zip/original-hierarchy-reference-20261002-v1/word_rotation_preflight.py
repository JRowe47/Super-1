"""Word-sized synthetic implementation canary; no corpus/checkpoint reads."""
import hashlib
import json
from pathlib import Path
import time
import torch
import regularized_rotation as rotation

root = Path(__file__).resolve().parent
config_path = root.parent / 'word-energy-native-20261002-v1/FULL_RUN_CONFIG.json'
config = json.loads(config_path.read_text())
vocabulary = config['vocabulary']['size']
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
base_type = rotation.reference.reference.reference.PersistentMultiScaleLM
torch.manual_seed(49183)
initial = base_type(vocabulary, 64, 4).state_dict()
tokens = torch.randint(vocabulary, (1, 129))
models = {}
rows = []
for arm in ('original', 'local', 'cross'):
    base = base_type(vocabulary, 64, 4)
    base.load_state_dict(initial)
    model = base if arm == 'original' else rotation.RegularizedRotation(base, arm == 'cross')
    assert base.output.weight.data_ptr() != base.core.embedding.weight.data_ptr()
    assert base.output.bias is not None
    start = time.perf_counter()
    logits, state = model(tokens[:, :-1], return_state=True)
    split_logits, split_state = model(tokens[:, :64], return_state=True)
    rest_logits, rest_state = model(tokens[:, 64:-1], split_state, return_state=True)
    assert torch.allclose(logits, torch.cat((split_logits, rest_logits), 1), atol=1e-6, rtol=1e-6)
    assert torch.equal(state, rest_state)
    models[arm] = (logits.detach(), state.detach())
    optimizer = torch.optim.AdamW(model.parameters(), lr=.001, foreach=False)
    optimizer.zero_grad()
    loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), tokens[:, 1:].flatten())
    loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
    optimizer.step()
    rows.append({'arm': arm, 'parameters': sum(p.numel() for p in model.parameters()),
                 'synthetic_update_seconds': time.perf_counter()-start,
                 'untied_biased_head': True, 'carry_state_exact': True, 'finite_gradients': True})
for arm in ('local', 'cross'):
    assert torch.equal(models['original'][0], models[arm][0])
    assert torch.equal(models['original'][1], models[arm][1])
report = {'vocabulary_size': vocabulary, 'width': 64, 'scales': 4, 'context': 128,
          'rows': rows, 'zero_gain_identity_exact': True, 'task_data_reads': 0,
          'official_test_reads': 0, 'config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
          'scope': 'Synthetic interface canary only. No accuracy, throughput benchmark, novelty, or SOTA evidence. Active trainer unchanged.'}
with (root / 'WORD_ROTATION_PREFLIGHT.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
print(json.dumps(report, indent=2))
