"""Native synthetic equivalence and noisy local CPU timing."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import torch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('packed_candidate', ROOT/'packed_rotation.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
rows = []
for dtype, tolerance in [(torch.float64, 1e-12), (torch.float32, 2e-6)]:
    for cross_scale in [False, True]:
        torch.manual_seed(9183)
        base_class = module.reference.reference.PersistentMultiScaleLM
        slow = module.reference.CrossScaleRotation(base_class(256, 64, 4), cross_scale).to(dtype)
        fast = module.PackedRotation(base_class(256, 64, 4), cross_scale).to(dtype)
        with torch.no_grad():
            slow.rotation_gain.copy_(torch.tensor([.12, -.09, .04, -.03], dtype=dtype))
        fast.load_state_dict(slow.state_dict())
        tokens = torch.randint(256, (2,70))
        timings = {}
        outputs = []
        for name, model in [('token_wise', slow), ('packed', fast)]:
            times = []
            for _ in range(4):
                model.zero_grad()
                start = time.perf_counter()
                output = model(tokens)
                output.square().mean().backward()
                times.append(time.perf_counter()-start)
            timings[name] = times
            outputs.append(output.detach())
        drift = (outputs[0]-outputs[1]).abs().max().item()
        gradients = {name:(param.grad-dict(fast.named_parameters())[name].grad).abs().max().item() for name,param in slow.named_parameters()}
        assert drift < tolerance and max(gradients.values()) < tolerance
        with torch.no_grad():
            whole, state = fast(tokens, return_state=True)
            a, intermediate = fast(tokens[:,:19], return_state=True)
            b, carried = fast(tokens[:,19:], intermediate, return_state=True)
            chunk_drift = (whole-torch.cat([a,b],1)).abs().max().item()
            state_drift = (state-carried).abs().max().item()
            assert max(chunk_drift,state_drift) < tolerance
        rows.append(dict(dtype=str(dtype), cross_scale=cross_scale, nonzero_rotation=True, logits_max_drift=drift, gradient_max_drift=max(gradients.values()), chunk_logits_max_drift=chunk_drift, state_max_drift=state_drift, seconds=timings))
report = dict(results=rows, file_hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['packed_rotation.py','cross_scale_rotation_canary.py','verify_packed_rotation.py']}, task_data_reads=0, official_test_reads=0, scope='Synthetic equivalence only, no accuracy, SOTA or novelty claim; local CPU timings under concurrent workloads, not fused or parallel scan')
with (ROOT/'PACKED_ROTATION_VERIFICATION.json').open('x') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps(report,indent=2))
