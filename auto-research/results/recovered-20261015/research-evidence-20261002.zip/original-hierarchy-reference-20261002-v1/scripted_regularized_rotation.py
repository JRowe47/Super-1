"""TorchScript loop: no Python token dispatch, not a fused GPU kernel."""
import importlib.util
from pathlib import Path
import sys
from typing import List, Tuple
import torch
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('scripted_regularized_reference',ROOT/'regularized_rotation.py')
reference=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=reference
spec.loader.exec_module(reference)

@torch.jit.script
def scan(inputs_update:torch.Tensor, inputs_gate:torch.Tensor,state:torch.Tensor,recurrent_weight:torch.Tensor,coupling_weight:torch.Tensor,scale:torch.Tensor,gain:torch.Tensor,log_radius:torch.Tensor,cross_scale:bool)->Tuple[torch.Tensor,torch.Tensor]:
    width=state.size(-1)
    means=torch.jit.annotate(List[torch.Tensor],[])
    radius=F.softplus(log_radius).unsqueeze(0).unsqueeze(-1)
    bounded_gain=torch.tanh(gain).unsqueeze(0).unsqueeze(-1)
    for index in range(inputs_update.size(1)):
        recurrent=F.linear(state,recurrent_weight)
        ru=recurrent[:,:,:width]
        rg=recurrent[:,:,width:]
        coupled=F.linear(state.mean(1,keepdim=True),coupling_weight)
        update=torch.tanh(inputs_update[:,index,:].unsqueeze(1)+ru+coupled+scale)
        gate=torch.sigmoid(inputs_gate[:,index,:].unsqueeze(1)+rg-scale)
        state=gate*state+(1-gate)*update
        pairs=state.reshape(state.size(0),state.size(1),width//2,2)
        other=torch.roll(pairs,1,1) if cross_scale else pairs
        numerator=pairs[:,:,:,0]*other[:,:,:,1]-pairs[:,:,:,1]*other[:,:,:,0] if cross_scale else (pairs*other).sum(-1)
        query=numerator/(radius+pairs.square().sum(-1)+other.square().sum(-1))
        angle=bounded_gain*query
        c,s=torch.cos(angle),torch.sin(angle)
        state=torch.stack([c*pairs[:,:,:,0]-s*pairs[:,:,:,1],s*pairs[:,:,:,0]+c*pairs[:,:,:,1]],-1).flatten(-2)
        means.append(state.mean(1))
    return torch.stack(means,1),state

class ScriptedRegularizedRotation(reference.RegularizedRotation):
    def forward(self,tokens,state=None,return_state=False):
        core=self.base.core
        embedded=core.embedding(tokens)
        if state is None:
            state=self.base.initial_state(tokens.shape[0])
        self.base._validate_state(state,embedded)
        inputs=F.linear(embedded,torch.cat([core.input_update.weight,core.input_gate.weight]),torch.cat([core.input_update.bias,core.input_gate.bias]))
        update,gate=inputs.split(self.base.width,-1)
        hidden,state=scan(update,gate,state,torch.cat([core.state_update.weight,core.state_gate.weight]),core.coupling.weight,core.scale[None],self.rotation_gain,self.log_radius,self.cross_scale)
        logits=self.base.output(core.norm(hidden))
        return (logits,state) if return_state else logits
