"""Render a confirmed local comparison from frozen artifacts; no evaluation."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--confirmation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    volume = Path("/Volumes/SP AI 01_16")
    workspace = volume / "CodexWorkspaces"
    parent = args.output.parent.resolve()
    assert os.path.ismount(str(volume)) and os.access(str(parent), os.W_OK)
    assert str(parent).startswith(str(workspace.resolve()) + "/")
    assert not args.output.exists()
    os.environ["MPLCONFIGDIR"] = str(parent / "matplotlib-cache")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    source = args.source.resolve()
    output = args.confirmation.resolve()
    protocol = json.loads((source / "PROTOCOL.json").read_text())
    freeze = json.loads((source / "FREEZE.json").read_text())
    result = json.loads((output / "RESULT.json").read_text())
    receipt = json.loads((output / "PROTOCOL.json").read_text())
    summary = json.loads((output / "SUMMARY.json").read_text())
    completion = json.loads((output / "COMPLETION.json").read_text())
    config = protocol["config"]
    arms, seeds = config["arms"], config["seeds"]
    hypothesis = summary["candidate_arm"]
    controls = [arm for arm in arms if arm != hypothesis]
    expected = {(seed, arm) for seed in seeds for arm in arms}
    assert len(result) == len(expected) == len(freeze) == completion["checkpoints"]
    assert {(row["seed"], row["arm"]) for row in result} == expected
    assert completion["duplicate_drift"] == 0
    assert completion["official_test_read"] is False
    assert completion["cloud_resources_created"] == 0
    assert receipt["source_protocol_sha256"] == sha(source / "PROTOCOL.json")
    assert receipt["freeze_sha256"] == sha(source / "FREEZE.json")
    assert receipt["confirmation_plan_sha256"] == sha(source / "CONFIRMATION_PLAN.json")
    assert receipt["precision"] == "FP32" and receipt["duplicate_evaluations"] == 2
    assert receipt["scored_bytes"] == config["context"] * config["reserved_confirmation_windows"]
    frozen = {(row["seed"], row["arm"]): row for row in freeze}
    scores = {}
    for row in result:
        f = frozen[row["seed"], row["arm"]]
        assert row["sha256"] == f["sha256"] == sha(source / Path(f["checkpoint"]).name)
        assert row["duplicate_drift"] == 0 and math.isfinite(row["validation"]["ce"])
        assert row["validation"]["scored_bytes"] == receipt["scored_bytes"]
        scores[row["seed"], row["arm"]] = row["validation"]["ce"]
    means = {arm: statistics.mean(scores[seed, arm] for seed in seeds) for arm in arms}
    assert all(group["ce"] == means[group["arm"]] for group in summary["groups"])
    assert all(scores[seed, hypothesis] < scores[seed, control] for seed in seeds for control in controls)
    assert summary["candidate_beats_all_controls_all_seeds"]

    labels = {"pair_energy": "Relative energy", "geometric_overlapping": "Geometry",
              "relative_phase_key": "Phase keys", "transformer": "Local Transformer"}
    colors = {"pair_energy": "#16826b", "geometric_overlapping": "#3278ae",
              "relative_phase_key": "#8b63aa", "transformer": "#657384"}
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 13,
                         "axes.spines.top": False, "axes.spines.right": False})
    fig = plt.figure(figsize=(16, 10), facecolor="white")
    grid = fig.add_gridspec(3, 2, height_ratios=[3.2, 1.3, 1.6],
                           left=.075, right=.965, bottom=.025, top=.82,
                           hspace=.42, wspace=.27)
    ax, bx = fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])
    fig.suptitle("Relative pair energy improves generated-weight transport",
                 x=.075, y=.965, ha="left", fontsize=24, weight="bold")
    fig.text(.075, .921, "Confirmed local byte-level WikiText-2 pilot | Not SOTA or established novelty",
             fontsize=16, color="#3d4e60")
    fig.text(.075, .878,
             f"{len(seeds)} seeds | {len(freeze)} frozen checkpoints | "
             f"{receipt['scored_bytes']:,} reserved targets scored twice in FP32 | Zero duplicate drift",
             fontsize=13)
    offsets = [(i - (len(seeds)-1)/2) * .10 for i in range(len(seeds))]
    markers = ["o", "s", "^"]
    for si, seed in enumerate(seeds):
        xs = [i + offsets[si] for i in range(len(arms))]
        ys = [scores[seed, arm] for arm in arms]
        ax.plot(xs, ys, color="#c7cdd4", lw=.8, alpha=.8, zorder=1)
        for i, arm in enumerate(arms):
            ax.scatter(xs[i], ys[i], c=colors[arm], marker=markers[si],
                       s=72, zorder=3, edgecolors="white", linewidth=.6)
    for i, arm in enumerate(arms):
        ax.plot([i-.22, i+.22], [means[arm]]*2, color=colors[arm], lw=3.5)
        ax.text(i, max(scores[seed, arm] for seed in seeds)+.009,
                f"{means[arm]:.5f}", ha="center", color=colors[arm], fontsize=12, weight="bold")
    ax.set_xticks(range(len(arms)), [labels[arm].replace("Local ", "Local\n") for arm in arms])
    all_scores = list(scores.values())
    spread = max(all_scores)-min(all_scores)
    ax.set_ylim(min(all_scores)-spread*.17, max(all_scores)+spread*.26)
    ax.set_ylabel("Byte cross-entropy (nats / target); lower is better")
    ax.set_title("All seed scores and group means\nCE axis cropped; not a zero-based bar chart", fontsize=14)
    ax.grid(axis="y", alpha=.18)
    ax.legend(handles=[Line2D([0],[0], marker=markers[i], color="none", markerfacecolor="#526373",
                             label=str(seed), markersize=7) for i, seed in enumerate(seeds)]
                     + [Line2D([0],[0], color="#526373", lw=3, label="Mean")],
              ncol=len(seeds)+1, loc="lower right", frameon=False, fontsize=10)

    for i, control in enumerate(controls):
        gain = 100*(1-means[hypothesis]/means[control])
        bx.barh(i, gain, color=colors[control], alpha=.28, height=.54)
        for si, seed in enumerate(seeds):
            point = 100*(1-scores[seed,hypothesis]/scores[seed,control])
            bx.scatter(point, i+offsets[si], c=colors[control], marker=markers[si], s=70, zorder=3)
        bx.text(gain+.15, i-.20, f"{gain:.2f}%", color=colors[control], weight="bold", fontsize=12)
    bx.set_yticks(range(len(controls)), [labels[arm] for arm in controls])
    bx.set_xlim(0, max(100*(1-scores[s,hypothesis]/scores[s,c]) for s in seeds for c in controls)*1.18)
    bx.set_xlabel("Relative CE reduction of energy candidate (%)")
    bx.set_title("Energy wins against each control in every seed", fontsize=14)
    bx.grid(axis="x", alpha=.18)
    bx.invert_yaxis()

    tx = fig.add_subplot(grid[1,:]); tx.axis("off")
    cells = [[str(seed)]+[f"{scores[seed,arm]:.6f}" for arm in arms] for seed in seeds]
    cells.append(["Mean"]+[f"{means[arm]:.6f}" for arm in arms])
    table = tx.table(cellText=cells, colLabels=["Seed"]+[labels[a] for a in arms],
                     cellLoc="center", colLoc="center", loc="center", bbox=[0,0,1,1])
    table.auto_set_font_size(False); table.set_fontsize(12)
    for (r,c),cell in table.get_celld().items():
        cell.set_edgecolor("#e0e5eb")
        if r==0:cell.set_facecolor("#eef3f7");cell.get_text().set_weight("bold")
        if r==len(cells):cell.set_facecolor("#f4f8f7");cell.get_text().set_weight("bold")

    notes = fig.add_subplot(grid[2,:]); notes.axis("off")
    steps = sorted({row["best_step"] for row in freeze})
    params = "; ".join(f"{labels[a]} {protocol['parameters'][a]:,}" for a in arms)
    runtime_ratios = [frozen[s,hypothesis]["training_seconds"]/frozen[s,"transformer"]["training_seconds"] for s in seeds]
    exposures = config["steps"]*config["batch"]*config["context"]
    text = [
        f"Parameters: {params}.",
        f"Equal training budget: {config['steps']:,} updates, {exposures:,} target-byte exposures per trial, "
        f"{len(config['lrs'])} LR trials per arm/seed; every frozen best step is {steps[0]:,}.",
        f"Context: {config['context']} bytes, reset state each window. Parameters/tokens/LR counts matched; FLOPs and walltime NOT matched.",
        f"Recorded selected-trial walltime (includes validation): energy / Transformer {min(runtime_ratios):.1f}–{max(runtime_ratios):.1f}x on unisolated CPU. Not inference latency.",
        "Registered reserved region is held out for this comparison, not globally unseen across all research. No official test accessed.",
        "No total-memory, generalization-across-tasks, information-capacity, original-hierarchy, or published-SOTA claim."
    ]
    notes.text(0,1,"\n".join(text), va="top", fontsize=11.5, color="#415268", linespacing=1.55)
    fig.savefig(args.output, dpi=170, facecolor="white")
    print(json.dumps({"chart":str(args.output),"sha256":sha(args.output),
                      "bytes":args.output.stat().st_size,"plot_source_sha256":sha(Path(__file__)),
                      "result_sha256":sha(output/"RESULT.json"),"no_new_evaluation":True}))


if __name__ == "__main__":
    main()

