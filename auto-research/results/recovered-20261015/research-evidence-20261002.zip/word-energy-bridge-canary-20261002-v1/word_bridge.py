"""Native synthetic preflight for a stateful word-vocabulary energy model.

No corpus constructor, dataset scoring, cloud action, or official-test access.
The transport remains the pinned PairEnergy law, not the original hierarchy.
"""
import argparse
import gc
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import resource
import sys
import time


SSD = Path('/Volumes/SP AI 01_16/CodexWorkspaces')


def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(part)
    return checksum.hexdigest()


def require_ssd(path):
    resolved = Path(path).resolve()
    if not os.path.ismount(SSD.parent) or not os.access(SSD, os.W_OK):
        raise RuntimeError('Real writable external SSD is required')
    if resolved == SSD or SSD not in resolved.parents:
        raise RuntimeError('New outputs must resolve inside SSD CodexWorkspaces')
    return resolved


def load_sources(config_path, config_hash):
    if digest(config_path) != config_hash:
        raise RuntimeError('Source registration hash changed')
    registration = json.loads(Path(config_path).read_text())
    pins = registration['source_pins']
    for pin in pins.values():
        if digest(pin['path']) != pin['sha256']:
            raise RuntimeError('Pinned import source changed')
    parent = Path(pins['pair_energy_phase_candidate']['path']).parent
    sys.path.insert(0, str(parent))
    energy = importlib.import_module('pair_energy_phase_candidate')
    for name, pin in pins.items():
        module = sys.modules.get(name)
        if module is None or Path(module.__file__).resolve() != Path(pin['path']).resolve():
            raise RuntimeError('Unexpected module resolution: ' + name)
        if digest(pin['path']) != pin['sha256']:
            raise RuntimeError('Import source drift')
    return energy, pins


def build_types(energy, torch):
    nn = torch.nn

    class WordEnergyLM(energy.PairEnergyPhaseLM):
        def __init__(self, vocabulary_size, width):
            super().__init__(width, True)
            if vocabulary_size != self.embedding.num_embeddings:
                self.embedding = nn.Embedding(vocabulary_size, width)
                nn.init.normal_(self.embedding.weight, std=.02)

        def forward(self, tokens, state=None, return_state=False):
            embedded = self.embedding(tokens)
            drive = torch.tanh(self.drive(embedded))
            retention = torch.sigmoid(self.write(embedded) + self.retention)
            if state is None:
                state = embedded.new_zeros((len(tokens), self.d))
            if state.shape != (len(tokens), self.d):
                raise ValueError('Invalid recurrent-state shape')
            if state.dtype != embedded.dtype or state.device != embedded.device:
                raise ValueError('Invalid recurrent-state dtype or device')
            history = []
            for step in range(tokens.shape[1]):
                theta = self.angle_for(state, drive[:, step], self.angle, self.gain, 0)
                transported = energy.source.rotate(state, theta, 0)
                theta2 = self.angle_for(transported, drive[:, step], self.second_angle,
                                        self.second_gain, 1)
                transported = energy.source.rotate(transported, theta2, 1)
                state = retention[:, step] * transported + (1 - retention[:, step]) * drive[:, step]
                history.append(state)
            logits = self.norm(torch.stack(history, 1)) @ self.embedding.weight.T
            return (logits, state) if return_state else logits

    class WordTransformer(nn.Module):
        def __init__(self, vocabulary_size, width, feedforward_width, context):
            super().__init__()
            self.embedding = nn.Embedding(vocabulary_size, width)
            nn.init.normal_(self.embedding.weight, std=.02)
            self.position = nn.Parameter(torch.randn(context, width) * .02)
            self.block = nn.TransformerEncoderLayer(
                width, 2, feedforward_width, dropout=0., batch_first=True, norm_first=True)
            self.norm = nn.LayerNorm(width)

        def forward(self, tokens):
            hidden = self.embedding(tokens) + self.position[:tokens.shape[1]]
            mask = torch.ones(tokens.shape[1], tokens.shape[1], device=tokens.device,
                              dtype=torch.bool).triu(1)
            return self.norm(self.block(hidden, src_mask=mask)) @ self.embedding.weight.T

    return WordEnergyLM, WordTransformer


def count(model):
    return sum(parameter.numel() for parameter in model.parameters())


def finite_training_state(model, optimizer, torch):
    for name, parameter in model.named_parameters():
        if parameter.grad is None or not torch.isfinite(parameter.grad).all():
            raise RuntimeError('Missing or nonfinite gradient: ' + name)
        if not torch.isfinite(parameter).all():
            raise RuntimeError('Nonfinite parameter: ' + name)
    for state in optimizer.state.values():
        for value in state.values():
            if torch.is_tensor(value) and not torch.isfinite(value).all():
                raise RuntimeError('Nonfinite optimizer tensor')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-config', type=Path, required=True)
    parser.add_argument('--source-config-sha256', required=True)
    parser.add_argument('--vocabulary-checkpoint', type=Path, required=True)
    parser.add_argument('--vocabulary-checkpoint-sha256', required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--context', type=int, required=True)
    parser.add_argument('--batch', type=int, required=True)
    parser.add_argument('--updates', type=int, required=True)
    parser.add_argument('--lr', type=float, required=True)
    parser.add_argument('--seed', type=int, required=True)
    args = parser.parse_args()
    report_path = require_ssd(args.report)
    if report_path.exists() or args.width <= 0 or args.width % 2 or min(args.context, args.batch, args.updates) <= 0:
        raise RuntimeError('Refuse overwrite or invalid dimensions')
    runtime = report_path.parent / 'runtime'
    for name in ('tmp', 'cache', 'torch'):
        require_ssd(runtime / name).mkdir(parents=True, exist_ok=True)
    os.environ['TMPDIR'] = str(runtime / 'tmp')
    os.environ['XDG_CACHE_HOME'] = str(runtime / 'cache')
    os.environ['TORCH_HOME'] = str(runtime / 'torch')
    sys.dont_write_bytecode = True
    import torch
    import torch.nn.functional as F
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    energy, pins = load_sources(args.source_config, args.source_config_sha256)
    WordEnergyLM, WordTransformer = build_types(energy, torch)
    if digest(args.vocabulary_checkpoint) != args.vocabulary_checkpoint_sha256:
        raise RuntimeError('Vocabulary-only checkpoint hash changed')
    payload = torch.load(args.vocabulary_checkpoint, map_location='cpu', weights_only=True)
    if not isinstance(payload, dict) or set(payload) != {'vocabulary', 'source_checkpoint_sha256'}:
        raise RuntimeError('Input is not the approved vocabulary-only payload')
    vocabulary = payload['vocabulary']
    if not isinstance(vocabulary, dict) or not vocabulary or any(not isinstance(word, str) for word in vocabulary):
        raise RuntimeError('Invalid frozen vocabulary')
    if any(type(value) is not int for value in vocabulary.values()) or set(vocabulary.values()) != set(range(len(vocabulary))):
        raise RuntimeError('Vocabulary ids must be unique, dense integers')
    vocabulary_size = len(vocabulary)
    torch.manual_seed(args.seed)
    base = energy.PairEnergyPhaseLM(32, True)
    with torch.no_grad():
        base.gain.fill_(.35)
        base.second_gain.fill_(.2)
        base.energy_gain.fill_(.3)
        base.second_energy_gain.fill_(-.25)
    bridge = WordEnergyLM(256, 32)
    bridge.load_state_dict(base.state_dict(), strict=True)
    byte_ids = torch.randint(256, (2, 18))
    base_logits, bridge_logits = base(byte_ids), bridge(byte_ids)
    if not torch.equal(base_logits, bridge_logits):
        raise RuntimeError('Byte forward parity is not exact')
    base_logits.square().mean().backward()
    bridge_logits.square().mean().backward()
    for name, parameter in base.named_parameters():
        if not torch.equal(parameter.grad, dict(bridge.named_parameters())[name].grad):
            raise RuntimeError('Byte native-gradient parity failed: ' + name)
    with torch.no_grad():
        full, terminal = bridge(byte_ids, return_state=True)
        prefix, carried = bridge(byte_ids[:, :7], return_state=True)
        suffix, streamed_terminal = bridge(byte_ids[:, 7:], carried, True)
        chunked = torch.cat((prefix, suffix), 1)
        seam_logit_error = (full - chunked).abs().max().item()
        seam_state_error = (terminal - streamed_terminal).abs().max().item()
        if not torch.allclose(full, chunked, atol=1e-6, rtol=1e-5) or not torch.allclose(terminal, streamed_terminal, atol=1e-6, rtol=1e-5):
            raise RuntimeError('State-carry seam exceeds preregistered FP32 tolerance')
        changed = byte_ids.clone()
        changed[:, 9:] = torch.randint(256, changed[:, 9:].shape)
        if not torch.equal(full[:, :9], bridge(changed)[:, :9]):
            raise RuntimeError('Causal prefix changed')
    del base, bridge, base_logits, bridge_logits, full, prefix, suffix, chunked, terminal, streamed_terminal, carried
    gc.collect()
    target_parameters = 2 * args.width ** 2 + (vocabulary_size + 8) * args.width
    # Preserve the prior pilot's two-stage architecture matching convention:
    # pick nominal FF=2d width, then adjust FF within [d,4d]. No metric tuning.
    tf_width = min(range(2, 2 * args.width + 1, 2), key=lambda width:
                   (abs((vocabulary_size + args.context + 13) * width + 8 * width ** 2 - target_parameters), width))
    intercept = vocabulary_size * tf_width + args.context * tf_width + 4 * tf_width ** 2 + 11 * tf_width
    tf_feedforward = min(range(tf_width, 4 * tf_width + 1), key=lambda feedforward:
                         (abs(intercept + (2 * tf_width + 1) * feedforward - target_parameters), feedforward))
    analytic_tf_parameters = intercept + (2 * tf_width + 1) * tf_feedforward
    timings = []
    for arm in ('pair_energy_word', 'transformer_word'):
        torch.manual_seed(args.seed)
        if arm == 'pair_energy_word':
            model = WordEnergyLM(vocabulary_size, args.width)
            expected_parameters = target_parameters
        else:
            model = WordTransformer(vocabulary_size, tf_width, tf_feedforward, args.context)
            expected_parameters = analytic_tf_parameters
        if count(model) != expected_parameters:
            raise RuntimeError('Actual parameter count disagrees with matching formula')
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=(.9, .999),
                                      eps=1e-8, weight_decay=.01, foreach=False, fused=False)
        generator = torch.Generator().manual_seed(args.seed + 10000)
        update_seconds = []
        all_update_losses_finite = True
        for step in range(args.updates):
            ids = torch.randint(vocabulary_size, (args.batch, args.context), generator=generator)
            targets = torch.randint(vocabulary_size, ids.shape, generator=generator)
            started = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            logits = model(ids)
            if not torch.isfinite(logits).all():
                raise RuntimeError('Nonfinite native word logits')
            loss = F.cross_entropy(logits.reshape(-1, vocabulary_size), targets.flatten())
            all_update_losses_finite = all_update_losses_finite and bool(torch.isfinite(loss))
            if not all_update_losses_finite:
                raise RuntimeError('Nonfinite synthetic loss')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1, foreach=False)
            optimizer.step()
            finite_training_state(model, optimizer, torch)
            update_seconds.append(time.perf_counter() - started)
        if len(optimizer.state) != len(list(model.parameters())):
            raise RuntimeError('Missing native optimizer state')
        timings.append({'arm': arm, 'parameters': count(model), 'synthetic_updates': args.updates,
                        'update_seconds': update_seconds, 'all_loss_gradient_parameter_optimizer_tensors_finite': True,
                        'logit_elements': args.batch * args.context * vocabulary_size,
                        'model_grad_two_Adam_moments_FP32_bytes': 16 * count(model)})
        del model, optimizer, logits, loss, ids, targets
        gc.collect()
    for pin in pins.values():
        if digest(pin['path']) != pin['sha256']:
            raise RuntimeError('Pinned source changed during preflight')
    if digest(args.source_config) != args.source_config_sha256 or digest(args.vocabulary_checkpoint) != args.vocabulary_checkpoint_sha256:
        raise RuntimeError('External input seal changed')
    peak_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    report = {'kind': 'synthetic_native_word_bridge_preflight', 'script_sha256': digest(__file__),
              'command': sys.argv, 'python': sys.executable, 'torch_version': torch.__version__,
              'source_pins': pins, 'source_config_sha256': args.source_config_sha256,
              'vocabulary_checkpoint_sha256': args.vocabulary_checkpoint_sha256,
              'vocabulary_size': vocabulary_size, 'width': args.width, 'batch': args.batch,
              'context': args.context, 'threads': torch.get_num_threads(), 'interop_threads': torch.get_num_interop_threads(),
              'byte_forward_exact': True, 'byte_native_gradients_exact': True, 'causal_prefix_exact': True,
              'streaming_seam_FP32': {'max_logit_abs_error': seam_logit_error, 'max_state_abs_error': seam_state_error,
                                     'preregistered_atol': 1e-6, 'preregistered_rtol': 1e-5, 'bitwise_exact_not_required': True},
              'transformer': {'width': tf_width, 'feedforward_width': tf_feedforward,
                              'absolute_parameter_gap': abs(analytic_tf_parameters - target_parameters),
                              'relative_parameter_gap': abs(analytic_tf_parameters - target_parameters) / target_parameters},
              'native_training_canaries': timings,
              'process_peak_RSS_bytes': peak_rss if sys.platform == 'darwin' else peak_rss * 1024,
              'dataset_content_reads': 0, 'official_test_read': False, 'cloud_resources_created': 0,
              'task_prediction_improvement_established': False, 'novelty_established': False,
              'scope': 'Word-vocabulary API/runtime preflight only. Random ids and targets are not benchmark CE. Counts match, not FLOPs. Timing/RSS unisolated while a separate sealed CPU experiment is live. No training corpus read or scoring. Existing model source unchanged; not original hierarchy. No full word experiment launched.'}
    with report_path.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
