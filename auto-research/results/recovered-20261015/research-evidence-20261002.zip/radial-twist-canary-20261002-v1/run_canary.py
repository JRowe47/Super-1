"""One bounded native structural/trainability canary; no task-data or checkpoint reads."""
import argparse
import copy
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

sys.dont_write_bytecode=True
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Volumes/SP AI 01_16/trin/experiments/disparity_constraints')
BASE=Path('/Volumes/SP AI 01_16/CodexWorkspaces/trin-research-evidence-20261002/radial-twist-canary-20261002-v1')
EXPECTED={"/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/pair_energy_phase_candidate.py":"61b8d710a0c647c8c45cbe8e5a4e06eea440fa37975d9f387e9402b5ea2efa9a","/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/noncommuting_phase_candidate.py":"063584bd9d4746ade54669e4cb1a9b70f8cdb38fff586ce68db37564552d14b5","/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/phase_transition_language.py":"9e79bff53701581864118b18a5fc35156af41afaeb44b2fc6e25916a8c41f9b4","/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/capacity_sweep.py":"a8d6d092c9b21ae0b38cdb972a4054fb58d5bf11fcd9775c2f9e1e0850c4f97e","/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/direct_distance.py":"c0b3bd153d213f9deffd8677b364ba5c2351f99bdec6fe94721672e5c7e9d25c","/Volumes/SP AI 01_16/trin/experiments/disparity_constraints/run.py":"6efab2fd890a1757ba9925084b84f89120ff94cd2e48b54802493c780d2a96d2","/Volumes/SP AI 01_16/CodexWorkspaces/trin-research-evidence-20261002/energy-vs-odd-query-20261002-v1/run_energy_shape.py":"580e0c82bae307d7e2952a75eeda5c6a0a8364a9b525b365ef44f3dffa50805a","/Volumes/SP AI 01_16/CodexWorkspaces/trin-research-evidence-20261002/energy-vs-odd-query-20261002-v1/CONFIG.json":"6167346e88c00af538b5ecb823642321c8d1a0316da9c827351da5161feac483"}
MODULES=('phase_transition_language','capacity_sweep','direct_distance','run','noncommuting_phase_candidate','pair_energy_phase_candidate')
parser=argparse.ArgumentParser()
parser.add_argument('--output',required=True)
parser.add_argument('--module-sha256',required=True)
parser.add_argument('--driver-sha256',required=True)
args=parser.parse_args()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def guard():
 assert Path('/Volumes/SP AI 01_16').is_mount()
 assert '/dev/disk10s1 on /Volumes/SP AI 01_16 ' in subprocess.check_output(['/sbin/mount'],text=True)
 assert BASE.resolve()==BASE and BASE.is_dir() and os.access(BASE,os.W_OK)
 assert not any(t in str(BASE) for t in ['/Documents/','/Desktop/','/Mobile Documents/','iCloud'])
guard()
assert Path(args.output)==BASE
assert Path(__file__).resolve().parent==BASE
assert sha(__file__)==args.driver_sha256
module_path=BASE/'radial_twist.py'
assert sha(module_path)==args.module_sha256
report_path=BASE/'REPORT.json'
assert not report_path.exists()
before={path:sha(path) for path in EXPECTED}
assert before==EXPECTED
for key,folder in [('TMPDIR','tmp'),('XDG_CACHE_HOME','xdg-cache'),('TORCH_HOME','torch-home')]:
 path=BASE/folder
 assert path.resolve()==path and path.is_dir() and os.access(path,os.W_OK)
 os.environ[key]=str(path)
os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
sys.path.insert(0,str(ROOT))
imported={name:importlib.import_module(name) for name in MODULES}
for name,module in imported.items():
 assert Path(module.__file__).resolve()==ROOT/(name+'.py')
 assert sha(module.__file__)==EXPECTED[str(ROOT/(name+'.py'))]
import torch
from torch import nn
from torch.nn import functional as F
from radial_twist import RadialTwistLM
import radial_twist
assert Path(radial_twist.__file__).resolve()==module_path
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
source=imported['noncommuting_phase_candidate'];energy=imported['pair_energy_phase_candidate']
FP64_ATOL=1e-12;FP64_RTOL=1e-12;DET_ATOL=1e-10;DET_RTOL=1e-10
failures=[];receipts=[]
def gate(name,condition,details=None):
 if not bool(condition):failures.append({'check':name,'details':details})
 return bool(condition)
def seed(label):return int.from_bytes(hashlib.sha256(label.encode('ascii')).digest()[:8],'big')&((1<<63)-1)
def note_seed(label,kind):
 r={'label':label,'seed':str(seed(label)),'kind':kind};receipts.append(r);return r
def tensor(label,shape,dtype=torch.float64,kind='normal'):
 rng=torch.Generator().manual_seed(seed(label))
 t=torch.randn(shape,dtype=dtype,generator=rng) if kind=='normal' else torch.randint(256,shape,generator=rng)
 r={'label':label,'seed':str(seed(label)),'shape':list(shape),'dtype':str(t.dtype),'sha256':hashlib.sha256(bytes(t.flatten().tolist()) if kind=='byte' else t.contiguous().numpy().tobytes()).hexdigest(),'hash_encoding':'row-major uint8 bytes' if kind=='byte' else 'row-major native-endian IEEE754'}
 receipts.append(r);return t,r
def metric(a,b):
 d=a.detach().double()-b.detach().double()
 finite=bool(torch.isfinite(a).all() and torch.isfinite(b).all() and torch.isfinite(d).all())
 return {'max_abs':d.abs().max().item(),'rms':d.square().mean().sqrt().item(),'exact':torch.equal(a,b),'finite':finite,'allclose_FP64_1e-12':finite and torch.allclose(a,b,atol=FP64_ATOL,rtol=FP64_RTOL)}
def stats(t):
 t=t.detach().double()
 return {'finite':bool(torch.isfinite(t).all()),'L1':t.abs().sum().item(),'L2':t.square().sum().sqrt().item(),'max_abs':t.abs().max().item(),'nonzero_elements':int(torch.count_nonzero(t)),'elements':t.numel(),'exact_zero':bool(torch.count_nonzero(t)==0)}
def initialized(label,width,dtype):
 torch.manual_seed(seed(label));note_seed(label,'fresh model initialization')
 return RadialTwistLM(width,True).to(dtype=dtype)
def determinant_case(model,state,drive,retention=None):
 fn=(lambda x:model.transport(x.unsqueeze(0),drive)[0]) if retention is None else (lambda x:model.hidden_step(x.unsqueeze(0),drive,retention)[0])
 jac=torch.autograd.functional.jacobian(fn,state[0],strict=True)
 actual=torch.linalg.det(jac)
 target=state.new_tensor(1.) if retention is None else retention[0].prod()
 m=metric(actual,target)
 return {'actual':actual.item(),'expected':target.item(),'abs_error':abs(actual.item()-target.item()),'finite_jacobian':bool(torch.isfinite(jac).all()),'determinant_finite':bool(torch.isfinite(actual)),'within_declared_det_tolerance':bool(torch.isfinite(actual) and torch.allclose(actual,target,atol=DET_ATOL,rtol=DET_RTOL)),'jacobian_sha256':hashlib.sha256(jac.detach().contiguous().numpy().tobytes()).hexdigest()}
result={}
try:
 # Fresh fixed-angle baseline only: this does not reproduce a trained q/energy model.
 torch.manual_seed(seed('radial-twist-20261002-v1-fresh-fixed-baseline'))
 note_seed('radial-twist-20261002-v1-fresh-fixed-baseline','fresh fixed-angle baseline initialization')
 fixed=source.OverlappingPhaseLM(16,False).double()
 fresh=initialized('radial-twist-20261002-v1-fresh-radial-baseline',16,torch.float64)
 loaded=fresh.load_state_dict(fixed.state_dict(),strict=False)
 gate('fresh_fixed_baseline_missing_only_g_and_radial',set(loaded.missing_keys)=={'gain','second_gain','radial_shape','second_radial_shape'} and not loaded.unexpected_keys)
 baseline_tokens,baseline_receipt=tensor('radial-twist-20261002-v1-fixed-baseline-tokens',(2,9),kind='byte')
 f=fixed(baseline_tokens);r=fresh(baseline_tokens)
 baseline=metric(f,r)
 gate('fresh_g_e_zero_fixed_angle_forward_exact',baseline['exact'] and baseline['finite'],baseline)
 f.square().mean().backward();r.square().mean().backward()
 shared={name:metric(p.grad,dict(fresh.named_parameters())[name].grad) for name,p in fixed.named_parameters()}
 gate('fresh_fixed_shared_gradients_finite_close',all(m['finite'] and m['allclose_FP64_1e-12'] for m in shared.values()),shared)
 probe=initialized('radial-twist-20261002-v1-fp64-probe-init',8,torch.float64)
 for name in ['angle','gain','radial_shape','second_angle','second_gain','second_radial_shape']:
  values,_=tensor('radial-twist-20261002-v1-probe-'+name,(4,))
  with torch.no_grad():getattr(probe,name).copy_(values*.4)
 structural=[]
 for index in range(3):
  x,_=tensor(f'radial-twist-20261002-v1-fp64-state-{index}',(1,8))
  u,_=tensor(f'radial-twist-20261002-v1-fp64-drive-{index}',(1,8))
  rr,_=tensor(f'radial-twist-20261002-v1-fp64-retention-{index}',(1,8))
  retention=.2+.6*rr.sigmoid()
  banks={}
  for offset in [0,1]:
   output=probe.bank(x,u,offset)
   inverse=probe.inverse_bank(output,u,offset)
   jac=torch.autograd.functional.jacobian(lambda v:probe.bank(v.unsqueeze(0),u,offset)[0],x[0],strict=True)
   det=torch.linalg.det(jac)
   roundtrip=metric(x,inverse);norm=metric(x.square().sum(-1),output.square().sum(-1))
   detok=bool(torch.isfinite(jac).all() and torch.isfinite(det) and torch.allclose(det,det.new_tensor(1.),atol=DET_ATOL,rtol=DET_RTOL))
   banks[str(offset)]={'determinant':det.item(),'abs_det_minus1':abs(det.item()-1),'finite_jacobian':bool(torch.isfinite(jac).all()),'determinant_gate':detok,'roundtrip':roundtrip,'squared_norm':norm}
   gate(f'fp64_fixture{index}_bank{offset}_det1',detok,banks[str(offset)])
   gate(f'fp64_fixture{index}_bank{offset}_inverse_roundtrip',roundtrip['finite'] and roundtrip['allclose_FP64_1e-12'],roundtrip)
   gate(f'fp64_fixture{index}_bank{offset}_norm',norm['finite'] and norm['allclose_FP64_1e-12'],norm)
  output=probe.transport(x,u)
  inverse=probe.inverse_transport(output,u)
  transport_det=determinant_case(probe,x,u)
  transport_roundtrip=metric(x,inverse)
  gate(f'fp64_fixture{index}_two_bank_det1',transport_det['finite_jacobian'] and transport_det['within_declared_det_tolerance'],transport_det)
  gate(f'fp64_fixture{index}_two_bank_roundtrip',transport_roundtrip['finite'] and transport_roundtrip['allclose_FP64_1e-12'],transport_roundtrip)
  transport_norm=metric(x.square().sum(-1),output.square().sum(-1))
  gate(f'fp64_fixture{index}_two_bank_norm',transport_norm['finite'] and transport_norm['allclose_FP64_1e-12'],transport_norm)
  full=probe.hidden_step(x,u,retention)
  recovered=probe.inverse_hidden_step(full,u,retention)
  full_det=determinant_case(probe,x,u,retention)
  full_roundtrip=metric(x,recovered)
  gate(f'fp64_fixture{index}_full_step_det_product_retention',full_det['finite_jacobian'] and full_det['within_declared_det_tolerance'],full_det)
  gate(f'fp64_fixture{index}_full_step_roundtrip_known_positive_retention',full_roundtrip['finite'] and full_roundtrip['allclose_FP64_1e-12'],full_roundtrip)
  structural.append({'fixture':index,'banks':banks,'two_bank_determinant':transport_det,'two_bank_roundtrip':transport_roundtrip,'two_bank_squared_norm':metric(x.square().sum(-1),output.square().sum(-1)),'full_step_determinant':full_det,'full_step_roundtrip':full_roundtrip,'retention_min':retention.min().item(),'retention_max':retention.max().item()})
 # Single-bank equivariance, not arbitrary common rotation through both overlapping banks.
 common,_=tensor('radial-twist-20261002-v1-common-pair-rotation',(4,))
 equivariance={}
 for offset in [0,1]:
  lhs=probe.bank(source.rotate(x,common,offset),source.rotate(u,common,offset),offset)
  rhs=source.rotate(probe.bank(x,u,offset),common,offset)
  m=metric(lhs,rhs);equivariance[str(offset)]=m
  gate(f'bank{offset}_common_pair_rotation_equivariance',m['finite'] and m['allclose_FP64_1e-12'],m)
 order_ab=probe.bank(probe.bank(x,u,0),u,1)
 order_ba=probe.bank(probe.bank(x,u,1),u,0)
 noncommutation=metric(order_ab,order_ba)
 gate('sampled_overlapping_banks_noncommute',noncommutation['finite'] and noncommutation['max_abs']>1e-8,noncommutation)
 edges=[]
 for offset in [0,1]:
  for edge,s0,u0 in [('both_zero',torch.zeros_like(x),torch.zeros_like(u)),('zero_state',torch.zeros_like(x),u.detach()),('zero_drive',x.detach(),torch.zeros_like(u))]:
   s=s0.clone().requires_grad_();d=u0.clone().requires_grad_()
   output=probe.bank(s,d,offset)
   angle,gain,coefficient=(probe.angle,probe.gain,probe.radial_shape) if offset==0 else (probe.second_angle,probe.second_gain,probe.second_radial_shape)
   grads=torch.autograd.grad(output.sum(),[s,d,angle,gain,coefficient])
   edge_grads={name:stats(value) for name,value in zip(['state','drive','angle','gain','radial_shape'],grads)}
   inv=metric(s,probe.inverse_bank(output,d,offset))
   entry={'bank':offset,'edge':edge,'output_finite':bool(torch.isfinite(output).all()),'gradient_stats':edge_grads,'roundtrip':inv}
   edges.append(entry)
   gate(f'bank{offset}_{edge}_finite_output_derivatives',entry['output_finite'] and all(v['finite'] for v in edge_grads.values()),entry)
   gate(f'bank{offset}_{edge}_roundtrip',inv['finite'] and inv['allclose_FP64_1e-12'],inv)
 zero_guard={'rejected':False}
 try:probe.inverse_hidden_step(x,u,torch.zeros_like(x))
 except ValueError as error:zero_guard={'rejected':True,'exception':str(error)}
 gate('retention_zero_inverse_refused_before_division',zero_guard['rejected'],zero_guard)
 # Record FP32 errors; no bit-exactness or general numerical-conditioning claim.
 probe32=copy.deepcopy(probe).float();x32=x.float();u32=u.float();r32=retention.float()
 fp32={}
 for offset in [0,1]:
  y=probe32.bank(x32,u32,offset)
  jac=torch.autograd.functional.jacobian(lambda v:probe32.bank(v.unsqueeze(0),u32,offset)[0],x32[0],strict=True)
  fp32['bank'+str(offset)]={'determinant':torch.linalg.det(jac).item(),'abs_det_minus1':abs(torch.linalg.det(jac).item()-1),'roundtrip':metric(x32,probe32.inverse_bank(y,u32,offset)),'squared_norm':metric(x32.square().sum(-1),y.square().sum(-1)),'finite_jacobian':bool(torch.isfinite(jac).all())}
 fp32['two_bank']={'determinant':determinant_case(probe32,x32,u32),'roundtrip':metric(x32,probe32.inverse_transport(probe32.transport(x32,u32),u32))}
 fp32['full_step']={'determinant':determinant_case(probe32,x32,u32,r32),'roundtrip':metric(x32,probe32.inverse_hidden_step(probe32.hidden_step(x32,u32,r32),u32,r32))}
 gate('fp32_all_errors_finite',all(fp32['bank'+str(offset)]['finite_jacobian'] and math.isfinite(fp32['bank'+str(offset)]['determinant']) and fp32['bank'+str(offset)]['roundtrip']['finite'] and fp32['bank'+str(offset)]['squared_norm']['finite'] for offset in [0,1]) and all(fp32[key]['determinant']['finite_jacobian'] and fp32[key]['determinant']['determinant_finite'] and fp32[key]['roundtrip']['finite'] for key in ['two_bank','full_step']),fp32)
 def training(label,width,steps):
  m=initialized(label,width,torch.float32)
  opt=torch.optim.AdamW(m.parameters(),lr=.003,betas=(.9,.999),eps=1e-8,weight_decay=.01,foreach=False)
  rows=[]
  for step in range(1,steps+1):
   inputs,im=tensor(label+f'-step{step}-input',(2,16),kind='byte')
   targets,tm=tensor(label+f'-step{step}-target',(2,16),kind='byte')
   opt.zero_grad(set_to_none=True)
   logits=m(inputs);loss=F.cross_entropy(logits.reshape(-1,256),targets.flatten(),reduction='mean')
   forward_finite=bool(logits.dtype==torch.float32 and torch.isfinite(logits).all() and torch.isfinite(loss))
   gate(label+f'-step{step}-native_fp32_logits_loss_finite',forward_finite)
   if not forward_finite:raise RuntimeError('Nonfinite synthetic objective; no backward/update')
   loss.backward()
   allgrads={name:stats(p.grad) for name,p in m.named_parameters()}
   gradients_finite=all(v['finite'] for v in allgrads.values())
   gate(label+f'-step{step}-all14gradients_finite',gradients_finite)
   if not gradients_finite:raise RuntimeError('Nonfinite native gradient; no optimizer update')
   bankgrads={name:allgrads[name] for name in ['gain','second_gain','radial_shape','second_radial_shape']}
   if step==1:
    gate(label+'-first_backward_gains_active',all(bankgrads[name]['L1']>0 for name in ['gain','second_gain']),bankgrads)
    gate(label+'-first_backward_radial_shape_dormant',all(bankgrads[name]['exact_zero'] for name in ['radial_shape','second_radial_shape']),bankgrads)
   if step==2:
    gate(label+'-second_backward_radial_shape_activated',all(bankgrads[name]['L1']>0 for name in ['radial_shape','second_radial_shape']),bankgrads)
   norm=nn.utils.clip_grad_norm_(m.parameters(),1.,norm_type=2.,foreach=False)
   if not bool(torch.isfinite(norm)):raise RuntimeError('Nonfinite clipping norm; no optimizer update')
   opt.step()
   parameter_finite=all(bool(torch.isfinite(p).all()) for p in m.parameters())
   optimizer_finite=all(not isinstance(v,torch.Tensor) or bool(torch.isfinite(v).all()) for st in opt.state.values() for v in st.values())
   gate(label+f'-step{step}-parameters_optimizer_finite',parameter_finite and optimizer_finite)
   rows.append({'step':step,'input':im,'target':tm,'synthetic_mean_CE_not_task_score':loss.item(),'forward_finite':forward_finite,'all14_gradient_finite_mask':''.join('1' if allgrads[name]['finite'] else '0' for name,_ in m.named_parameters()),'bank_preclip_gradient_stats':bankgrads,'preclip_norm':norm.item(),'clip_multiplier':(1./(norm+1e-6)).clamp(max=1.).item(),'all_parameters_optimizer_finite':parameter_finite and optimizer_finite,'banks_after_update':{name:stats(getattr(m,name)) for name in ['gain','second_gain','radial_shape','second_radial_shape']}})
  return {'initialization_label':label,'initialization_seed':str(seed(label)),'width':width,'batch':2,'context':16,'updates':steps,'parameters':sum(p.numel() for p in m.parameters()),'rows':rows}
 trainability=[training(f'radial-twist-20261002-v1-sequence-seed-{i}',32,5) for i in range(3)]
 fullwidth=training('radial-twist-20261002-v1-width256-one-update',256,1)
 pair_count=sum(p.numel() for p in energy.PairEnergyPhaseLM(256).parameters())
 gate('width256_equal_pair_energy198656_count',fullwidth['parameters']==pair_count==198656,{'radial':fullwidth['parameters'],'energy':pair_count})
 after={path:sha(path) for path in EXPECTED}
 gate('six_source_and_active_driver_config_hashes_unchanged',before==after)
 gate('own_module_and_driver_hashes_unchanged',sha(module_path)==args.module_sha256 and sha(__file__)==args.driver_sha256)
 result={'status':'bounded_radial_structural_and_trainability_checks_passed' if not failures else 'bounded_radial_canary_failures_preserved','failures':failures,'method':{'python':sys.version.split()[0],'python_executable':str(Path(sys.executable).resolve()),'torch':torch.__version__,'torch_file':str(Path(torch.__file__).resolve()),'CPU_threads':1,'interop_threads':1,'deterministic_algorithms':True,'native_eager_autograd_only':True,'FP64_roundtrip_norm_atol':FP64_ATOL,'FP64_roundtrip_norm_rtol':FP64_RTOL,'FP64_determinant_atol':DET_ATOL,'FP64_determinant_rtol':DET_RTOL,'FP32_gate':'Finite; errors recorded, not exact and not accepted under FP64 tolerance','jacobian_scope':'State Jacobian only, fixed known drive/retention/parameters, three random8D FP64 fixtures','sequence_training':{'seeds':3,'width':32,'batch':2,'context':16,'updates_each':5,'lr':.003,'AdamW_betas':[.9,.999],'AdamW_eps':1e-8,'weight_decay':.01,'foreach':False,'clip_norm':1.,'clip_norm_type':2.,'clip_foreach':False,'loss':'native mean cross_entropy with independent synthetic random byte targets'},'width256_updates':1,'total_in_memory_updates':16,'seed_derivation':"int.from_bytes(hashlib.sha256(label.encode('ascii')).digest()[:8],'big')&((1<<63)-1)",'seed_serialization':'All large seeds converted to strings before JSON','dataset_reads':0,'official_test_reads':0,'checkpoint_reads':0,'existing_source_edits':0,'existing_process_changes':0,'cloud_calls':0},'equation':'theta=a+g*tanh(c+e*c^3); c=tanh(log(Es+1e-6)-log(Edrive+1e-6))','inverse_scope':'Each bank recomputes theta from output pair radius and fixed known drive. Two-bank inverse reverses bank order. Full hidden step unmixes/divides by known strictly positive finite r before inverse transport. No inverse for unknown input/drive/retention claimed.','fresh_fixed_baseline':{'forward':baseline,'shared_gradients':shared,'missing_keys':loaded.missing_keys,'scope':'Common fresh fixed-angle baseline when g=e=0 only; no reduction to a trained q/energy winner claimed'},'FP64_random8D_fixtures':structural,'single_bank_common_pair_rotation_equivariance':equivariance,'overlapping_noncommutation_witness':noncommutation,'zero_edges':edges,'retention_zero_guard':zero_guard,'FP32_error_records':fp32,'native_sequence_trainability':trainability,'width256_count_and_one_update':fullwidth,'pair_energy_width256_parameter_count':pair_count,'all_seed_hash_receipts':receipts,'source_and_live_run_sha256_before':before,'source_and_live_run_sha256_after':after,'all_eight_external_hashes_unchanged':before==after,'canary_module':{'path':str(module_path),'sha256':args.module_sha256},'exact_driver':{'path':str(Path(__file__).resolve()),'sha256':args.driver_sha256},'limitations':'Generic radial/invertible twist prior art, not novelty. Raw transport is volume1 in exact arithmetic; complete hidden step volume is prod(r), not1 and not a contraction guarantee. Small sampled Jacobians/roundtrips do not prove general numerical stability. Near-zero r can make inversion ill-conditioned; zero r is rejected. Common rotation equivariance is bank-local, not arbitrary equivariance of the overlapping composition. Nonzero second-step e gradients are conditional on g/c/downstream adjoints and observed only in these synthetic fixtures. Fresh fixed-angle identity does not match trained q/energy winners. No task-data CE, official test, performance selection, full benchmark, prediction utility, original-hierarchy, SOTA, throughput or peak-memory claim. Active benchmark concurrent; no edits or process lifecycle actions.'}
except BaseException as error:
 result={'status':'bounded_radial_canary_execution_failed_preserved','error':str(error),'traceback':traceback.format_exc(),'failures':failures,'completed_partial_result':result,'all_seed_hash_receipts':receipts,'source_and_live_run_sha256_before':before,'source_and_live_run_sha256_after':{path:sha(path) for path in EXPECTED},'canary_module_sha256':args.module_sha256,'driver_sha256':args.driver_sha256,'no_rerun':True}
guard()
with report_path.open('x',encoding='utf8') as handle:json.dump(result,handle,indent=2,sort_keys=True,allow_nan=False);handle.write('\n');handle.flush();os.fsync(handle.fileno())
print(json.dumps(result,separators=(',',':'),allow_nan=False),flush=True)
if result['status']!='bounded_radial_structural_and_trainability_checks_passed':sys.exit(1)
