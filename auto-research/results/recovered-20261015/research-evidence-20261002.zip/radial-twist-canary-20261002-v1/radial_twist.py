"""Bounded radial-twist mechanism candidate; generic invertible-twist prior art applies."""
import torch
from torch import nn
import noncommuting_phase_candidate as source


class RadialTwistLM(source.OverlappingPhaseLM):
    def __init__(self, width, dynamic=True):
        super().__init__(width, dynamic)
        self.radial_shape = nn.Parameter(torch.zeros(width // 2))
        self.second_radial_shape = nn.Parameter(torch.zeros(width // 2))

    def angle_for(self, state, drive, angle, gain, offset):
        if gain is None:
            return angle
        pair = torch.roll(state, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        target = torch.roll(drive, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        state_energy = pair.square().sum(-1)
        drive_energy = target.square().sum(-1)
        contrast = (torch.log(state_energy + 1e-6) - torch.log(drive_energy + 1e-6)).tanh()
        coefficient = self.radial_shape if offset == 0 else self.second_radial_shape
        return angle + gain * (contrast + coefficient * contrast.pow(3)).tanh()

    def bank(self, state, drive, offset):
        angle, gain = (self.angle, self.gain) if offset == 0 else (self.second_angle, self.second_gain)
        return source.rotate(state, self.angle_for(state, drive, angle, gain, offset), offset)

    def inverse_bank(self, output, drive, offset):
        angle, gain = (self.angle, self.gain) if offset == 0 else (self.second_angle, self.second_gain)
        theta = self.angle_for(output, drive, angle, gain, offset)
        return source.rotate(output, -theta, offset)

    def transport(self, state, drive):
        return self.bank(self.bank(state, drive, 0), drive, 1)

    def inverse_transport(self, output, drive):
        return self.inverse_bank(self.inverse_bank(output, drive, 1), drive, 0)

    def hidden_step(self, state, drive, retention):
        return retention * self.transport(state, drive) + (1 - retention) * drive

    def inverse_hidden_step(self, output, drive, retention):
        if not torch.isfinite(retention).all() or not (retention > 0).all():
            raise ValueError("Known retention must be finite and strictly positive")
        unmixed = (output - (1 - retention) * drive) / retention
        return self.inverse_transport(unmixed, drive)
