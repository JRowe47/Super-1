"""Read-only receipt gate; never imports Torch, reads task text, or scores.

Passing this gate is NOT permission to score: native checkpoint/state checks,
selection replay and transfer-window reconstruction remain evaluator duties.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def verify(preregistration, expected_sha):
    require(sha(preregistration) == expected_sha, "Preregistration seal changed")
    spec = read(preregistration)["source_experiment"]
    source = Path(spec["path"]).resolve(strict=True)
    require(sha(source / "CONFIG.json") == spec["config_sha256"], "Config seal changed")
    require(sha(source / "run_energy_shape.py") == spec["driver_sha256"], "Driver seal changed")
    output = source / "run"
    require(not (output / "FAILURE.json").exists(), "Source failure preserved; scoring forbidden")
    terminal = output / "CONFIRMATION_COMPLETION.json"
    require(terminal.is_file(), "Source confirmation is not terminal; scoring forbidden")
    end = read(terminal)
    names = {"PROTOCOL.json", "DATA_RECEIPTS.json", "CANDIDATES.json", "FREEZE.json",
             "TRAINING_COMPLETION.json", "SELECTED_VERIFICATION.json", "CONFIRMATION.json"}
    seals = end["critical_receipt_expected_sha256"]
    require(set(seals) == names, "Incomplete terminal receipt closure")
    for name in names:
        require(sha(output / name) == seals[name], "Receipt changed: " + name)
    require(end["config_sha256"] == spec["config_sha256"], "Terminal config mismatch")
    require(end["completed_checkpoints"] == 12 and end["fp32_evaluations"] == 24
            and end["all_duplicate_drift_exact_zero"] is True
            and end["official_test_read"] is False, "Invalid terminal scope")
    config = read(source / "CONFIG.json")
    rows = read(output / "CANDIDATES.json")
    expected = {(seed, arm, lr) for seed in spec["seeds"]
                for arm in spec["arms"] for lr in config["lrs"]}
    actual = [(r["seed"], r["arm"], r["lr"]) for r in rows]
    require(len(rows) == len(expected) == 24 and len(set(actual)) == 24
            and set(actual) == expected, "Incomplete candidate slots")
    require(all(r["completed_steps"] == config["steps"] for r in rows), "Incomplete training")
    for seed in spec["seeds"]:
        require(len({r["train_window_indices_sha256"] for r in rows
                     if r["seed"] == seed}) == 1, "Exposure stream mismatch")
    frozen = read(output / "FREEZE.json")
    canonical = [min([r for r in rows if r["seed"] == seed and r["arm"] == arm],
                     key=lambda r: (r["selection"]["ce"], r["lr"], r["best_step"], r["checkpoint_sha256"]))
                 for seed in sorted(spec["seeds"], key=int) for arm in sorted(spec["arms"])]
    require(frozen == canonical and len(frozen) == 12, "Noncanonical freeze")
    verified = read(output / "SELECTED_VERIFICATION.json")
    require(verified["all12_verified_before_any_confirmation"] is True
            and len(verified["checkpoints"]) == 12
            and all(r["selection_replay_exact"] is True and r["strict_keys_shapes_finite"] is True
                    and r["dtype"] == "FP32" for r in verified["checkpoints"]), "Source replay incomplete")
    confirmation = read(output / "CONFIRMATION.json")
    require(len(confirmation) == 12, "Incomplete duplicates")
    require([(r["seed"], r["arm"], r["checkpoint_sha256"]) for r in confirmation]
            == [(r["seed"], r["arm"], r["checkpoint_sha256"]) for r in frozen], "Confirmation slots mismatch")
    for row in confirmation:
        require(row["first"] == row["second"] and row["duplicate_ce_abs_drift"] == 0
                and row["all_metrics_and_logits_fingerprint_exact"] is True
                and math.isfinite(row["first"]["ce"]), "Duplicate drift/nonfinite score")
    for row in frozen:
        checkpoint = Path(row["checkpoint"]).resolve(strict=True)
        require(checkpoint.parent == (output / "checkpoints").resolve()
                and sha(checkpoint) == row["checkpoint_sha256"], "Checkpoint changed/outside source")
    return {"receipt_gate_passed": True, "source_terminal_sha256": sha(terminal),
            "source_primary_gate_passed": end["primary_gate_passed"],
            "source_overall_gate_passed": end["overall_local_advance_gate_passed"],
            "negative_source_results_do_not_exclude_checkpoints": True,
            "transfer_predictions": 0, "task_content_reads": 0,
            "remaining_before_scoring": ["Native state/provenance/runtime verification",
                                          "All12 exact native selection replays",
                                          "Transfer corpus and sample reconstruction"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--preregistration", required=True)
    parser.add_argument("--preregistration-sha256", required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(verify(args.preregistration, args.preregistration_sha256), sort_keys=True))
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"receipt_gate_passed": False, "reason": str(error),
                          "transfer_predictions": 0, "task_content_reads": 0}, sort_keys=True))
        raise SystemExit(2)
