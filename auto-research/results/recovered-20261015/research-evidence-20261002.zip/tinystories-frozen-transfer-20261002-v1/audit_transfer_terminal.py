"""Read-only audit of frozen transfer receipts; no model or task-text reads."""
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root):
    output = root / 'transfer-run'
    execution = json.loads((output / 'EXECUTION.json').read_text())
    registration = json.loads((root / 'PREREGISTRATION.json').read_text())
    assert digest(root / 'PREREGISTRATION.json') == execution['preregistration_sha256']
    assert digest(root / 'evaluate_frozen_transfer.py') == execution['driver_sha256']
    source = Path(registration['source_experiment']['path']) / 'run'
    assert digest(source / 'CONFIRMATION_COMPLETION.json') == execution['source_terminal_sha256']
    assert digest(source / 'FREEZE.json') == execution['source_freeze_sha256']
    assert execution['all12_native_selection_replays_exact'] is True
    assert execution['all_windows_reconstructed_exact'] is True
    assert execution['training_updates'] == execution['official_test_reads'] == 0
    if (output / 'FAILURE.json').exists():
        return {'status': 'failure', 'failure': json.loads((output / 'FAILURE.json').read_text())}
    if not (output / 'COMPLETION.json').exists():
        return {'status': 'pending', 'saved_pairs': len(list(output.glob('checkpoint-*.json'))),
                'scope': 'Receipt status only; process liveness must be checked separately'}
    terminal = json.loads((output / 'COMPLETION.json').read_text())
    assert digest(output / 'RESULT.json') == terminal['result_sha256']
    assert digest(output / 'EXECUTION.json') == terminal['execution_sha256']
    rows = json.loads((output / 'RESULT.json').read_text())
    frozen = json.loads((source / 'FREEZE.json').read_text())
    assert len(rows) == len(frozen) == 12
    assert terminal['all12_duplicate_exact'] is True
    manifest = json.loads((root / 'WINDOWS.json').read_text())
    expected_targets = manifest['target_bytes']
    for index, (row, candidate) in enumerate(zip(rows, frozen), 1):
        assert row == json.loads((output / ('checkpoint-%02d.json' % index)).read_text())
        assert row['seed'] == candidate['seed'] and row['arm'] == candidate['arm']
        assert row['checkpoint_sha256'] == candidate['checkpoint_sha256']
        assert digest(Path(candidate['checkpoint'])) == row['checkpoint_sha256']
        assert row['first'] == row['second'] and row['duplicate_drift'] == 0
        score = row['first']
        assert math.isfinite(score['ce']) and score['ce'] > 0
        assert score['scored_targets'] == expected_targets
        assert len(score['window_loss_sums']) == manifest['window_count']
        assert all(math.isfinite(value) and value >= 0 for value in score['window_loss_sums'])
        assert score['ce'] == math.fsum(score['batch_loss_sums']) / expected_targets
        assert len(score['logits_sha256']) == 64
        assert all(c in '0123456789abcdef' for c in score['logits_sha256'])
        assert sum(d['targets'] for d in score['documents'].values()) == expected_targets
    paired = []
    for seed in registration['source_experiment']['seeds']:
        selected = [r for r in rows if r['seed'] == seed]
        ce = {r['arm']: r['first']['ce'] for r in selected}
        assert len(selected) == len(ce) == 4
        docs = {r['arm']: r['first']['documents'] for r in selected}
        differences = {}
        for document, energy in docs['pair_energy'].items():
            differences[document] = {'targets': energy['targets'], 'energy_minus_control_ce': {}}
            for arm, values in docs.items():
                assert set(values) == set(docs['pair_energy'])
                assert values[document]['targets'] == energy['targets']
                if arm != 'pair_energy':
                    differences[document]['energy_minus_control_ce'][arm] = (
                        energy['loss_sum'] - values[document]['loss_sum']) / energy['targets']
        paired.append({'seed': seed, 'ce': ce, 'document_paired_differences': differences,
                       'passed': all(ce['pair_energy'] < ce[a] for a in ce if a != 'pair_energy')})
    assert terminal['paired'] == paired
    assert terminal['advance_gate_passed'] == all(r['passed'] for r in paired)
    assert terminal['official_test_reads'] == 0
    return {'status': 'terminal_receipt_audit_passed',
            'advance_gate_passed': terminal['advance_gate_passed'],
            'completion_sha256': digest(output / 'COMPLETION.json'),
            'scope': 'Receipt/checkpoint integrity and paired arithmetic only; no independent native replay or SOTA proof'}


if __name__ == '__main__':
    print(json.dumps(audit(Path(__file__).resolve().parent), indent=2))
