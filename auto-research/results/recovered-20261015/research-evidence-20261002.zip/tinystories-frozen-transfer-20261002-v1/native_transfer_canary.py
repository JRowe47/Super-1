"""All-architecture transfer-scoring integration, synthetic bytes only."""
import copy
import importlib
import importlib.util
import json
from pathlib import Path
import random
import sys
import tempfile
import torch
from evaluate_frozen_transfer import require,save,sha,score_transfer,exact_duplicate


def main():
    root=Path(__file__).resolve().parent
    require(Path('/Volumes/SP AI 01_16').is_mount(),'SSD not mounted')
    require(sha(root/'PREREGISTRATION.json')=='c2e0732798a6f6417ae5fa8ef888b94492ad6535ccf613bcf1d9b8eca66488f9','Registration changed')
    registration=json.loads((root/'PREREGISTRATION.json').read_text())
    source=Path(registration['source_experiment']['path'])
    require(sha(source/'CONFIG.json')==registration['source_experiment']['config_sha256']
            and sha(source/'run_energy_shape.py')==registration['source_experiment']['driver_sha256'],'Source experiment changed')
    config=json.loads((source/'CONFIG.json').read_text())
    for pin in config['source_pins'].values():require(sha(pin['path'])==pin['sha256'],'Source dependency changed')
    roots={Path(pin['path']).parent for pin in config['source_pins'].values()};require(len(roots)==1,'Source roots')
    sys.path.insert(0,str(next(iter(roots))))
    imported={name:importlib.import_module(name) for name in config['source_pins']}
    for name,module in imported.items():require(Path(module.__file__).resolve()==Path(config['source_pins'][name]['path']).resolve(),'Wrong imported source')
    spec=importlib.util.spec_from_file_location('synthetic_transfer_source',source/'run_energy_shape.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    runner.CONFIG=config;runner.CONFIG_PATH=source/'CONFIG.json';runner.CONFIG_SHA=registration['source_experiment']['config_sha256'];runner.DRIVER_PATH=source/'run_energy_shape.py'
    runner.torch=torch;runner.nn=torch.nn;runner.F=torch.nn.functional
    runner.pilot=imported['phase_transition_language'];runner.source=imported['noncommuting_phase_candidate'];runner.energy=imported['pair_energy_phase_candidate']
    runner.pilot.C['context']=config['context'];exec(runner.SHAPE_QUERY_SOURCE,runner.__dict__)
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    runner.seal_check();info=runner.architecture()
    output=Path(tempfile.mkdtemp(prefix='native-transfer-fixtures-',dir=str(root)))
    save(output/'PROTOCOL.json',{'evaluator_sha256':sha(root/'evaluate_frozen_transfer.py'),
         'driver_sha256':sha(__file__),'source_config_sha256':runner.CONFIG_SHA,
         'source_driver_sha256':registration['source_experiment']['driver_sha256'],
         'seeds':config['seeds'],'arms':config['arms'],'synthetic_windows':5,'context':128,
         'scope':'Fresh random model weights, synthetic bytes, serialization and scorer integration; not trained-checkpoint verification or task usefulness.'})
    rng=random.Random(673095)
    raw=bytes(rng.randrange(256) for _ in range(641))
    entries=[{'input_start_absolute_byte':i*128,'document':0 if i<3 else 1} for i in range(5)]
    receipts=[]
    for seed in config['seeds']:
        for arm in config['arms']:
            model,initial=runner.make_model(arm,seed,info)
            first=score_transfer(model,raw,entries,128,4,torch)
            second=score_transfer(model,raw,entries,128,4,torch);exact_duplicate(first,second)
            require(first['scored_targets']==640 and len(first['window_loss_sums'])==5
                    and first['documents']['0']['targets']==384 and first['documents']['1']['targets']==256,'Accounting mismatch')
            path=output/('%s-%s.pt'%(seed,arm));torch.save(model.state_dict(),path)
            restored,_=runner.make_model(arm,seed,info)
            state=torch.load(path,map_location='cpu',weights_only=True);runner.validate_state(restored,state,arm)
            require(runner.state_hash(state)==runner.state_hash(model.state_dict()),'Serialized state changed')
            third=score_transfer(restored,raw,entries,128,4,torch);exact_duplicate(first,third)
            bad=copy.deepcopy(state);key=next(iter(bad));bad[key]=bad[key].double()
            try:runner.validate_state(restored,bad,arm)
            except RuntimeError:pass
            else:raise RuntimeError('Non-FP32 checkpoint accepted')
            receipts.append({'seed':seed,'arm':arm,'parameters':runner.count(model),
                             'three_scores_exact':True,'window_document_accounting_exact':True,
                             'native_checkpoint_roundtrip_exact':True,'nonfp32_state_rejected':True,
                             'synthetic_checkpoint_sha256':sha(path)})
    try:score_transfer(model,raw,[{'document':0,'input_start_absolute_byte':640}],128,4,torch)
    except RuntimeError:bounds=True
    else:raise RuntimeError('Out-of-bounds window accepted')
    runner.seal_check()
    report={'models_checked':len(receipts),'receipts':receipts,'bounds_rejected':bounds,
            'fixture_path':str(output),'evaluator_sha256':sha(root/'evaluate_frozen_transfer.py'),
            'real_task_text_reads':0,'trained_checkpoint_reads':0,'training_updates':0,
            'transfer_corpus_predictions':0,'scope':'Synthetic integration only; actual source terminal remains required.'}
    save(root/'NATIVE_TRANSFER_CANARY_REPORT.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='receipts'}))


if __name__=='__main__':main()
