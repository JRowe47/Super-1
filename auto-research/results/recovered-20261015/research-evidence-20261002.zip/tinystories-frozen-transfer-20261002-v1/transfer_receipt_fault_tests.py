"""Synthetic receipt faults only; all fixtures retained on SSD.

These tests do not establish native checkpoint validity or benchmark success.
"""
import copy
import json
from pathlib import Path
import tempfile
import check_source_ready as gate


def write(path,value):
    path.write_text(json.dumps(value,sort_keys=True,allow_nan=False)+'\n')


def fixture(root):
    source=root/'source'; source.mkdir(); output=source/'run'; output.mkdir()
    checkpoints=output/'checkpoints'; checkpoints.mkdir()
    seeds=['1','2','3']; arms=['pair_energy','odd_query_shape','geometric_overlapping','transformer']
    write(source/'CONFIG.json',{'lrs':[.001,.003],'steps':6000})
    # This inert JSON file occupies the driver path; it is never imported.
    write(source/'run_energy_shape.py',{'synthetic':True})
    config_sha=gate.sha(source/'CONFIG.json')
    prereg=root/'registration.json'
    write(prereg,{'source_experiment':{'path':str(source),'config_sha256':config_sha,
          'driver_sha256':gate.sha(source/'run_energy_shape.py'),'seeds':seeds,'arms':arms}})
    rows=[]
    for seed in seeds:
        for arm in arms:
            for lr in (.001,.003):
                path=checkpoints/('%s-%s-%s.json'%(seed,arm,lr))
                write(path,{'synthetic_not_a_model':True,'seed':seed,'arm':arm,'lr':lr})
                rows.append({'seed':seed,'arm':arm,'lr':lr,'completed_steps':6000,
                             'train_window_indices_sha256':seed,'selection':{'ce':1+lr},
                             'best_step':6000,'checkpoint':str(path),'checkpoint_sha256':gate.sha(path)})
    frozen=[min([r for r in rows if r['seed']==s and r['arm']==a],
                key=lambda r:(r['selection']['ce'],r['lr'],r['best_step'],r['checkpoint_sha256']))
            for s in seeds for a in sorted(arms)]
    confirmation=[{'seed':r['seed'],'arm':r['arm'],'checkpoint_sha256':r['checkpoint_sha256'],
                   'first':{'ce':1.2,'logits_sha256':'same'},'second':{'ce':1.2,'logits_sha256':'same'},
                   'duplicate_ce_abs_drift':0,'all_metrics_and_logits_fingerprint_exact':True} for r in frozen]
    receipts={'PROTOCOL.json':{'synthetic':True},'DATA_RECEIPTS.json':{'synthetic':True},
              'CANDIDATES.json':rows,'FREEZE.json':frozen,'TRAINING_COMPLETION.json':{'synthetic':True},
              'SELECTED_VERIFICATION.json':{'all12_verified_before_any_confirmation':True,
                  'checkpoints':[{'selection_replay_exact':True,'strict_keys_shapes_finite':True,'dtype':'FP32'} for _ in frozen]},
              'CONFIRMATION.json':confirmation}
    for name,value in receipts.items(): write(output/name,value)
    end={'config_sha256':config_sha,'completed_checkpoints':12,'fp32_evaluations':24,
         'all_duplicate_drift_exact_zero':True,'official_test_read':False,
         'critical_receipt_expected_sha256':{n:gate.sha(output/n) for n in receipts},
         'primary_gate_passed':False,'overall_local_advance_gate_passed':False}
    write(output/'CONFIRMATION_COMPLETION.json',end)
    return prereg,output,receipts,end


def main():
    root=Path(__file__).resolve().parent
    assert Path('/Volumes/SP AI 01_16').is_mount()
    fixture_root=Path(tempfile.mkdtemp(prefix='receipt-faults-',dir=str(root)))
    cases=['valid_negative_source','missing_terminal','missing_trial','incomplete_update_budget',
           'exposure_mismatch','noncanonical_freeze','missing_duplicate','duplicate_logit_drift',
           'checkpoint_changed','selected_replay_missing','receipt_seal_changed']
    passed=[]
    for case in cases:
        folder=fixture_root/case; folder.mkdir()
        prereg,out,receipts,end=fixture(folder)
        if case=='missing_terminal':
            # Recoverable rename, not deletion, of this synthetic fixture only.
            (out/'CONFIRMATION_COMPLETION.json').rename(out/'terminal-withheld.json')
        elif case=='missing_trial': receipts['CANDIDATES.json'].pop()
        elif case=='incomplete_update_budget': receipts['CANDIDATES.json'][0]['completed_steps']=5999
        elif case=='exposure_mismatch': receipts['CANDIDATES.json'][0]['train_window_indices_sha256']='different'
        elif case=='noncanonical_freeze': receipts['FREEZE.json'][0]=copy.deepcopy(receipts['CANDIDATES.json'][1])
        elif case=='missing_duplicate': receipts['CONFIRMATION.json'].pop()
        elif case=='duplicate_logit_drift': receipts['CONFIRMATION.json'][0]['second']['logits_sha256']='different'
        elif case=='checkpoint_changed': write(Path(receipts['FREEZE.json'][0]['checkpoint']),{'changed':True})
        elif case=='selected_replay_missing': receipts['SELECTED_VERIFICATION.json']['checkpoints'][0]['selection_replay_exact']=False
        elif case=='receipt_seal_changed': write(out/'PROTOCOL.json',{'unsealed_mutation':True})
        if case not in ('missing_terminal','checkpoint_changed','receipt_seal_changed'):
            for name,value in receipts.items(): write(out/name,value)
            end['critical_receipt_expected_sha256']={n:gate.sha(out/n) for n in receipts}
            write(out/'CONFIRMATION_COMPLETION.json',end)
        try:
            result=gate.verify(prereg,gate.sha(prereg))
        except (ValueError,KeyError,OSError) as error:
            assert case!='valid_negative_source'
            passed.append({'case':case,'rejected':True,'reason':str(error)})
        else:
            assert case=='valid_negative_source' and result['receipt_gate_passed'] is True
            assert result['source_primary_gate_passed'] is False
            passed.append({'case':case,'accepted_with_negative_result_preserved':True})
    report={'passed':passed,'fixture_path':str(fixture_root),'checker_sha256':gate.sha(root/'check_source_ready.py'),
            'task_text_reads':0,'native_model_evaluations':0,'training_updates':0,
            'scope':'Receipt gate faults only. Synthetic checkpoint JSON is not native state evidence.'}
    with (root/'TRANSFER_RECEIPT_FAULT_REPORT.json').open('x') as stream:
        json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps({'passed':len(passed),'task_text_reads':0,'native_model_evaluations':0}))


if __name__=='__main__': main()
