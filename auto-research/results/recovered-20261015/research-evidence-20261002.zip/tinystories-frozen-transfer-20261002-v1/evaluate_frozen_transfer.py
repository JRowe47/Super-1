"""Frozen zero-shot transfer. Never trains or invokes the source launcher."""
import argparse
import hashlib
import importlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys
import traceback


def require(ok,message):
    if not ok: raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False); stream.write('\n')


def reconstruct(raw,manifest,registration):
    context=registration['selection']['context_bytes']
    delimiter=bytes.fromhex(registration['selection']['document_delimiter_hex'])
    population=[]; cursor=0
    for document,story in enumerate(raw.split(delimiter)):
        for local in range(0,max(0,len(story)-context),context):
            start=cursor+local
            population.append({'document':document,'eligible_population_window':len(population),
                               'input_start_absolute_byte':start,'target_start_absolute_byte':start+1,
                               'target_end_inclusive_absolute_byte':start+context})
        cursor+=len(story)+len(delimiter)
    seed=int(registration['selection']['selection_rng_seed'])
    sampled=sorted(random.Random(seed).sample(range(len(population)),registration['selection']['windows']))
    entries=[dict(population[index],window=i) for i,index in enumerate(sampled)]
    require(entries==manifest['entries'] and len(population)==manifest['eligible_population_windows'], 'Window reconstruction mismatch')
    require(manifest['source_sha256']==hashlib.sha256(raw).hexdigest()
            and manifest['selection_rng_seed']==str(seed)
            and manifest['context']==context and manifest['window_count']==len(entries)
            and manifest['target_bytes']==len(entries)*context,'Window scope mismatch')
    return entries


def exact_duplicate(first,second):
    require(first==second and math.isfinite(first['ce']),'Duplicate transfer drift/nonfinite score')


def score_transfer(model,raw,entries,context,microbatch,torch):
    require(len(entries)>0 and context>0 and microbatch>0,'Empty/invalid scoring request')
    require(all(0<=e['input_start_absolute_byte'] and e['input_start_absolute_byte']+context+1<=len(raw)
                for e in entries),'Transfer window exceeds bytes')
    model.eval();losses=[];batch_sums=[];fingerprint=hashlib.sha256();documents={}
    with torch.inference_mode():
        for i in range(0,len(entries),microbatch):
            batch=entries[i:i+microbatch]
            slices=[torch.tensor(list(raw[e['input_start_absolute_byte']:e['input_start_absolute_byte']+context+1]),dtype=torch.long) for e in batch]
            x=torch.stack([s[:-1] for s in slices]);y=torch.stack([s[1:] for s in slices])
            logits=model(x)
            require(logits.dtype==torch.float32 and torch.isfinite(logits).all(),'Invalid logits')
            per=torch.nn.functional.cross_entropy(logits.reshape(-1,256),y.flatten(),reduction='none').reshape(len(batch),context).sum(1)
            total=torch.nn.functional.cross_entropy(logits.reshape(-1,256),y.flatten(),reduction='sum').item()
            require(math.isfinite(total),'Nonfinite batch loss');batch_sums.append(total)
            fingerprint.update(logits.contiguous().numpy().tobytes())
            for entry,value in zip(batch,per.tolist()):
                require(math.isfinite(value),'Nonfinite window loss')
                losses.append(value);documents.setdefault(str(entry['document']),[]).append(value)
    ce=math.fsum(batch_sums)/(len(entries)*context)
    return {'ce':ce,'bpc':ce/math.log(2),'scored_targets':len(entries)*context,
            'window_loss_sums':losses,'batch_loss_sums':batch_sums,'logits_sha256':fingerprint.hexdigest(),
            'documents':{d:{'loss_sum':math.fsum(v),'targets':len(v)*context} for d,v in documents.items()}}


def run(args):
    root=Path(__file__).resolve().parent
    workspace=Path('/Volumes/SP AI 01_16/CodexWorkspaces').resolve(strict=True)
    require(Path('/Volumes/SP AI 01_16').is_mount() and workspace in root.parents,'Mounted SSD required')
    require(sha(__file__)==args.driver_sha256 and sha(root/'check_source_ready.py')==args.checker_sha256,'Evaluator source changed')
    prereg=root/'PREREGISTRATION.json'
    require(sha(prereg)==args.preregistration_sha256,'Transfer registration changed')
    import check_source_ready
    readiness=check_source_ready.verify(prereg,args.preregistration_sha256)
    c=json.loads(prereg.read_text()); source=Path(c['source_experiment']['path']); output_source=source/'run'
    terminal=output_source/'CONFIRMATION_COMPLETION.json'
    require(sha(terminal)==args.source_terminal_sha256,'Externally pinned terminal changed')
    for name,expected in [('WINDOWS.json',args.windows_sha256),('DATA_COMPLETION.json',args.data_completion_sha256)]:
        require(sha(root/name)==expected,'Transfer data receipt changed')
    if args.verify_only:
        print(json.dumps({'source_receipt_gate':readiness,'transfer_predictions':0,
                          'remaining':'Native state/runtime/replay/sample checks precede scoring in full mode'}))
        return
    require(args.authorize_transfer,'Transfer authorization required')
    config_path=source/'CONFIG.json'; config=json.loads(config_path.read_text())
    protocol=json.loads((output_source/'PROTOCOL.json').read_text())
    for pin in config['source_pins'].values():
        require(sha(pin['path'])==pin['sha256'],'Source dependency changed')
    import torch
    require(torch.__version__==protocol['runtime']['torch_version'] and sys.version==protocol['runtime']['python_version']
            and str(Path(sys.executable).resolve())==protocol['runtime']['python_executable'],'Recorded runtime identity mismatch')
    torch.set_num_threads(1); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True)
    roots={Path(pin['path']).parent for pin in config['source_pins'].values()}
    require(len(roots)==1,'Dependency roots mismatch')
    sys.path.insert(0,str(next(iter(roots))))
    imported={name:importlib.import_module(name) for name in config['source_pins']}
    for name,module in imported.items():
        require(Path(module.__file__).resolve()==Path(config['source_pins'][name]['path']).resolve(),'Imported dependency mismatch')
    spec=importlib.util.spec_from_file_location('sealed_transfer_source',source/'run_energy_shape.py')
    runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    runner.CONFIG=config; runner.CONFIG_PATH=config_path; runner.CONFIG_SHA=c['source_experiment']['config_sha256']; runner.DRIVER_PATH=source/'run_energy_shape.py'
    runner.torch=torch; runner.nn=torch.nn; runner.F=torch.nn.functional
    runner.pilot=imported['phase_transition_language']; runner.source=imported['noncommuting_phase_candidate']; runner.energy=imported['pair_energy_phase_candidate']
    runner.pilot.C['context']=config['context']
    exec(runner.SHAPE_QUERY_SOURCE,runner.__dict__)
    runner.seal_check()
    info=protocol['architecture']; frozen=json.loads((output_source/'FREEZE.json').read_text())
    # All state and provenance checks precede the first transfer prediction.
    models=[]
    for row in frozen:
        require(row['provenance']==runner.provenance(),'Checkpoint provenance changed')
        require(sha(row['checkpoint'])==row['checkpoint_sha256'],'Checkpoint file changed')
        model,_=runner.make_model(row['arm'],row['seed'],info)
        state=torch.load(row['checkpoint'],map_location='cpu',weights_only=True)
        runner.validate_state(model,state,row['arm'])
        require(runner.state_hash(state)==row['checkpoint_state_sha256'],'Checkpoint state changed')
        models.append((row,model))
    for split in ('train','valid'):
        require(sha(config['data'][split]['path'])==config['data'][split]['sha256'],'Source corpus changed')
    valid_raw=Path(config['data']['valid']['path']).read_bytes()
    valid=torch.tensor(list(valid_raw),dtype=torch.long); del valid_raw
    for row,model in models:
        require(runner.evaluate(model,valid,config['selection_start'],config['selection_windows'])==row['selection'], 'Native selection replay drift')
    del valid
    corpus=root/'TinyStories-valid.txt'; raw=corpus.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==c['source']['expected_LFS_sha256'] and len(raw)==c['source']['expected_bytes'],'Transfer corpus changed')
    windows=json.loads((root/'WINDOWS.json').read_text()); entries=reconstruct(raw,windows,c)
    completion=json.loads((root/'DATA_COMPLETION.json').read_text())
    require(completion['windows_sha256']==args.windows_sha256
            and completion['registration_sha256']==args.preregistration_sha256
            and completion['corpus_sha256']==hashlib.sha256(raw).hexdigest(),'Acquisition bindings differ')
    output=root/'transfer-run'; output.mkdir(exist_ok=False)
    frozen_sha=sha(output_source/'FREEZE.json')
    execution={'source_terminal_sha256':args.source_terminal_sha256,'source_readiness':readiness,
               'driver_sha256':args.driver_sha256,'all12_native_selection_replays_exact':True,
               'all_windows_reconstructed_exact':True,'corpus_sha256':hashlib.sha256(raw).hexdigest(),
               'preregistration_sha256':args.preregistration_sha256,'source_freeze_sha256':frozen_sha,
               'official_test_reads':0,'training_updates':0}
    save(output/'EXECUTION.json',execution)
    def seals():
        require(sha(terminal)==args.source_terminal_sha256 and sha(output_source/'FREEZE.json')==frozen_sha,'Source terminal changed')
        require(sha(__file__)==args.driver_sha256 and sha(prereg)==args.preregistration_sha256
                and sha(root/'WINDOWS.json')==args.windows_sha256,'Transfer closure changed')
        runner.seal_check()
    def score(model):
        return score_transfer(model,raw,entries,c['selection']['context_bytes'],c['selection']['microbatch'],torch)
    results=[]
    try:
        for row,model in models:
            seals(); require(sha(row['checkpoint'])==row['checkpoint_sha256'],'Frozen checkpoint changed')
            first=score(model); seals(); second=score(model); exact_duplicate(first,second)
            item={'seed':row['seed'],'arm':row['arm'],'checkpoint_sha256':row['checkpoint_sha256'],
                  'first':first,'second':second,'duplicate_drift':0}
            results.append(item)
            save(output/('checkpoint-%02d.json'%len(results)),item)
            print(json.dumps({'completed':len(results),'total':12,'seed':row['seed'],'arm':row['arm']}),flush=True)
        paired=[]
        for seed in c['source_experiment']['seeds']:
            ce={r['arm']:r['first']['ce'] for r in results if r['seed']==seed}
            by_arm={r['arm']:r['first']['documents'] for r in results if r['seed']==seed}
            documents={}
            for document,energy in by_arm['pair_energy'].items():
                documents[document]={'targets':energy['targets'],'energy_minus_control_ce':{}}
                for arm,values in by_arm.items():
                    require(values[document]['targets']==energy['targets'],'Document target mismatch')
                    if arm!='pair_energy':
                        documents[document]['energy_minus_control_ce'][arm]=(energy['loss_sum']-values[document]['loss_sum'])/energy['targets']
            paired.append({'seed':seed,'ce':ce,'document_paired_differences':documents,
                           'passed':all(ce['pair_energy']<ce[a] for a in ce if a!='pair_energy')})
        seals(); require(sha(corpus)==execution['corpus_sha256'],'Transfer corpus changed during evaluation')
        save(output/'RESULT.json',results)
        save(output/'COMPLETION.json',{'all12_duplicate_exact':True,'paired':paired,
             'advance_gate_passed':all(r['passed'] for r in paired),'source_primary_gate_passed':readiness['source_primary_gate_passed'],
             'result_sha256':sha(output/'RESULT.json'),'execution_sha256':sha(output/'EXECUTION.json'),
             'official_test_reads':0,'limitations':c['scope']})
    except BaseException:
        save(output/'FAILURE.json',{'traceback':traceback.format_exc(),'no_automatic_retry':True}); raise


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('driver-sha256','checker-sha256','preregistration-sha256','windows-sha256','data-completion-sha256','source-terminal-sha256'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--verify-only',action='store_true'); p.add_argument('--authorize-transfer',action='store_true')
    run(p.parse_args())
