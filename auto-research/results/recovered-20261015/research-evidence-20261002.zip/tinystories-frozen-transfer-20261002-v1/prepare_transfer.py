"""Seal independently sourced transfer bytes without reading/scoring a model.

This prepares a future frozen-checkpoint test, not a new training experiment.
"""
import hashlib
import json
import os
from pathlib import Path
import random
import secrets
import urllib.request


ROOT = Path(__file__).resolve().parent
SSD = Path('/Volumes/SP AI 01_16/CodexWorkspaces')
REVISION = 'f54c09fd23315a6f9c86f9dc80f725de7d8f9c64'
SOURCE_URL = 'https://huggingface.co/datasets/roneneldan/TinyStories/resolve/' + REVISION + '/TinyStories-valid.txt'
EXPECTED_SHA = '94e431816c4cce81ff71e4408ff8d3bda9a42e8d2663986697c3954288cb38b4'
EXPECTED_BYTES = 19447282
SOURCE_RUN = SSD / 'trin-research-evidence-20261002/energy-vs-odd-query-20261002-v1'
SOURCE_CONFIG_SHA = '6167346e88c00af538b5ecb823642321c8d1a0316da9c827351da5161feac483'
SOURCE_DRIVER_SHA = '580e0c82bae307d7e2952a75eeda5c6a0a8364a9b525b365ef44f3dffa50805a'
WINDOWS = 2048
CONTEXT = 128
DELIMITER = b'<|endoftext|>'


def sha(path):
    checksum = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(part)
    return checksum.hexdigest()


def canonical_bytes(payload):
    return (json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + '\n').encode('utf-8')


def save(path, payload):
    encoded = canonical_bytes(payload)
    expected = hashlib.sha256(encoded).hexdigest()
    with Path(path).open('xb') as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    if sha(path) != expected:
        raise RuntimeError('Canonical payload seal changed during write')
    return expected


def require_hash(path, expected):
    if sha(path) != expected:
        raise RuntimeError('A registered artifact changed: ' + Path(path).name)


def main():
    if not os.path.ismount(SSD.parent) or not os.access(SSD, os.W_OK):
        raise RuntimeError('Require actual mounted writable SSD')
    if ROOT != ROOT.resolve() or SSD not in ROOT.parents:
        raise RuntimeError('All new artifacts must resolve inside SSD CodexWorkspaces')
    for file in ('PREREGISTRATION.json', 'CORPUS_RECEIPT.json', 'WINDOWS.json', 'DATA_COMPLETION.json', 'TinyStories-valid.txt', 'TinyStories-valid.txt.partial'):
        if (ROOT / file).exists():
            raise RuntimeError('Refuse an existing acquisition or registration')
    if sha(SOURCE_RUN / 'CONFIG.json') != SOURCE_CONFIG_SHA or sha(SOURCE_RUN / 'run_energy_shape.py') != SOURCE_DRIVER_SHA:
        raise RuntimeError('Sealed source experiment drift')
    source_config = json.loads((SOURCE_RUN / 'CONFIG.json').read_text())
    selection_seed = str(secrets.randbits(64))
    registration = {
        'kind': 'preregistered_future_frozen_zero_shot_transfer',
        'preparation_script_sha256': sha(__file__),
        'source': {'dataset': 'roneneldan/TinyStories', 'revision': REVISION,
                   'download_url': SOURCE_URL, 'expected_LFS_sha256': EXPECTED_SHA,
                   'expected_bytes': EXPECTED_BYTES, 'license': 'cdla-sharing-1.0',
                   'primary_card': 'https://huggingface.co/datasets/roneneldan/TinyStories'},
        'selection': {'document_delimiter_hex': DELIMITER.hex(),
                      'preserve_document_bytes_no_stripping_or_unicode_normalization': True,
                      'rule': 'Enumerate every nonoverlapping 128-target window entirely inside each story in file/document order, requiring 129 bytes. Uniformly sample 2048 distinct eligible windows without replacement with Python random.Random(selection_rng_seed), then restore file order. Each window starts fresh state; delimiter bytes never scored.',
                      'selection_rng_seed': selection_seed,
                      'selection_rng_seed_source': 'OS randomness drawn once and recorded before corpus acquisition',
                      'windows': WINDOWS, 'context_bytes': CONTEXT,
                      'target_bytes': WINDOWS * CONTEXT, 'microbatch': source_config['batch'],
                      'metric_used_for_corpus_or_window_selection': False},
        'source_experiment': {'path': str(SOURCE_RUN), 'config_sha256': SOURCE_CONFIG_SHA,
                              'driver_sha256': SOURCE_DRIVER_SHA, 'seeds': source_config['seeds'],
                              'arms': source_config['arms'], 'expected_frozen_checkpoints': 12,
                              'selection_only_freeze_path': str(SOURCE_RUN / 'run/FREEZE.json')},
        'execution_gate': 'Do not score before all24 source trials finish, all12 selection-only checkpoints are frozen and strictly hash/source/config/data verified, original duplicate FP32 confirmation is terminal, and transfer corpus/window seals have been verified. Never select or retrain on transfer scores.',
        'evaluation': {'device': 'cpu', 'dtype': 'FP32', 'threads': 1,
                       'native_eager_autograd_model_inference': True, 'duplicate_passes': 2,
                       'duplicate_drift_required': 0, 'fresh_state_per_128_byte_window': True,
                       'score_every_frozen_checkpoint': True, 'preserve_all_seed_scores': True,
                       'preserve_document_paired_differences': True, 'drop_delimiter_targets': True,
                       'checkpoint_reselection_or_refit': False},
        'advance_gate': 'After all twelve checkpoints duplicate-confirm exactly, Energy must have strictly lower byte CE than OddQuery, geometry and Transformer in every source seed. A favorable mean alone fails.',
        'scope': 'Different independently sourced synthetic-story corpus, frozen zero-shot transfer from a WikiText-trained local byte model. Uniform eligible-window sampling is not uniform-document or whole-corpus scoring. Not globally pristine text, a calibrated statistical significance claim, original hierarchy, word-level perplexity, long-context memory, novelty or SOTA. Corpus preparation performs no prediction scoring.',
        'official_WikiText_test_access': False, 'cloud_resources_provisioned': 0,
        'current_source_run_mutated': False,
    }
    registration_sha = save(ROOT / 'PREREGISTRATION.json', registration)
    partial = ROOT / 'TinyStories-valid.txt.partial'
    checksum = hashlib.sha256()
    received = 0
    request = urllib.request.Request(SOURCE_URL, headers={'User-Agent': 'research-evidence-preparation'})
    with urllib.request.urlopen(request) as response, partial.open('xb') as stream:
        for part in iter(lambda: response.read(1024 * 1024), b''):
            stream.write(part)
            checksum.update(part)
            received += len(part)
        stream.flush()
        os.fsync(stream.fileno())
    if received != EXPECTED_BYTES or checksum.hexdigest() != EXPECTED_SHA:
        raise RuntimeError('Downloaded byte count or primary LFS hash differs; partial evidence preserved')
    corpus = ROOT / 'TinyStories-valid.txt'
    os.link(partial, corpus)  # Fails atomically if another writer created the destination.
    partial.unlink()  # Remove only the redundant temporary hard link; corpus remains intact.
    raw = corpus.read_bytes()
    if len(raw) != EXPECTED_BYTES or hashlib.sha256(raw).hexdigest() != EXPECTED_SHA:
        raise RuntimeError('Corpus changed between acquisition and window construction')
    if DELIMITER not in raw:
        raise RuntimeError('Expected document delimiter absent; do not reinterpret the registered selection')
    population = []
    cursor = 0
    document = 0
    while cursor < len(raw):
        marker = raw.find(DELIMITER, cursor)
        end = marker if marker >= 0 else len(raw)
        local_start = 0
        while cursor + local_start + CONTEXT < end:
            start = cursor + local_start
            population.append({'eligible_population_window': len(population), 'document': document,
                            'input_start_absolute_byte': start,
                            'target_start_absolute_byte': start + 1,
                            'target_end_inclusive_absolute_byte': start + CONTEXT})
            local_start += CONTEXT
        if marker < 0:
            break
        cursor = marker + len(DELIMITER)
        document += 1
    if len(population) < WINDOWS:
        raise RuntimeError('Not enough complete document-local windows')
    selected = sorted(random.Random(int(selection_seed)).sample(range(len(population)), WINDOWS))
    entries = [dict(population[index], window=order) for order, index in enumerate(selected)]
    windows = {'source_sha256': EXPECTED_SHA, 'context': CONTEXT, 'target_bytes': WINDOWS * CONTEXT,
               'window_count': WINDOWS, 'included_document_count': len({row['document'] for row in entries}),
               'eligible_population_windows': len(population), 'selection_rng_seed': selection_seed,
               'entries': entries}
    windows_sha = save(ROOT / 'WINDOWS.json', windows)
    require_hash(corpus, EXPECTED_SHA)
    receipt_sha = save(ROOT / 'CORPUS_RECEIPT.json', {'path': str(corpus), 'bytes': received, 'sha256': EXPECTED_SHA,
                                      'primary_LFS_hash_matches': True, 'source_revision': REVISION,
                                      'raw_document_content_used_only_for_window_construction': True,
                                      'model_checkpoint_reads': 0, 'prediction_scoring_calls': 0})
    if sha(SOURCE_RUN / 'CONFIG.json') != SOURCE_CONFIG_SHA or sha(SOURCE_RUN / 'run_energy_shape.py') != SOURCE_DRIVER_SHA:
        raise RuntimeError('Source experiment seal changed during acquisition')
    require_hash(corpus, EXPECTED_SHA)
    require_hash(ROOT / 'PREREGISTRATION.json', registration_sha)
    require_hash(ROOT / 'WINDOWS.json', windows_sha)
    require_hash(ROOT / 'CORPUS_RECEIPT.json', receipt_sha)
    completion = {'status': 'independent_corpus_and_future_protocol_sealed_not_evaluated',
                  'corpus_sha256': EXPECTED_SHA, 'registration_sha256': registration_sha,
                  'windows_sha256': windows_sha, 'receipt_sha256': receipt_sha,
                  'context': CONTEXT, 'windows': WINDOWS, 'scored_targets_if_executed': WINDOWS * CONTEXT,
                  'included_document_count': windows['included_document_count'],
                  'model_checkpoint_reads': 0, 'prediction_scoring_calls': 0,
                  'training_launches': 0, 'official_WikiText_test_access': False, 'cloud_resources_provisioned': 0}
    completion_sha = save(ROOT / 'DATA_COMPLETION.json', completion)
    print(json.dumps({'completion': completion, 'completion_sha256': completion_sha}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
