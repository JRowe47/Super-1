"""Registered native-FP32 energy-versus-odd-query comparison; no automatic resume."""
import argparse
import copy
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import traceback

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
SSD = Path("/Volumes/SP AI 01_16")
WORK = SSD / "CodexWorkspaces"
ARMS = ("pair_energy", "odd_query_shape", "geometric_overlapping", "transformer")
MODULES = ("phase_transition_language", "capacity_sweep", "direct_distance",
           "run", "noncommuting_phase_candidate", "pair_energy_phase_candidate")
SHAPE_QUERY_SOURCE = """class ShapeQueryLM(source.OverlappingPhaseLM):
    def __init__(self, width, dynamic=True):
        super().__init__(width, dynamic)
        self.shape_gain = nn.Parameter(torch.zeros(width // 2))
        self.second_shape_gain = nn.Parameter(torch.zeros(width // 2))

    def angle_for(self, state, drive, angle, gain, offset):
        if gain is None:
            return angle
        pair = torch.roll(state, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        target = torch.roll(drive, shifts=offset, dims=-1).reshape(len(state), -1, 2)
        cross = pair[..., 0] * target[..., 1] - pair[..., 1] * target[..., 0]
        denominator = torch.sqrt(pair.square().sum(-1) * target.square().sum(-1) + 1e-6)
        query = cross / denominator
        coefficient = self.shape_gain if offset == 0 else self.second_shape_gain
        return angle + gain * (query + coefficient * query.pow(3)).tanh()
"""


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def finite(value, name):
    require(math.isfinite(float(value)), name + " is nonfinite")
    return float(value)


def mounted():
    lines = subprocess.check_output(["/sbin/mount"], text=True).splitlines()
    matches = [line for line in lines if " on " + str(SSD) + " (" in line]
    require(SSD.is_mount() and len(matches) == 1 and matches[0].startswith("/dev/"),
            "Actual external SSD mount unavailable")
    require(os.access(WORK, os.W_OK) and WORK.resolve() == WORK,
            "SSD workspace is not resolved/writable")
    return matches[0]


def guarded_path(value, *, workspace=True, exists=None, directory=False):
    mounted()
    path = Path(value)
    require(path.is_absolute() and path.resolve() == path, "Path must be absolute/resolved: " + str(path))
    base = WORK if workspace else SSD
    require(path != base and base in path.parents, "Path is outside authorized SSD: " + str(path))
    require(not any(part in ("Documents", "Desktop", "Mobile Documents") for part in path.parts),
            "iCloud-synced destination prohibited")
    require(not path.is_symlink(), "Symlink target prohibited: " + str(path))
    if exists is True:
        require(path.exists(), "Required path absent: " + str(path))
    elif exists is False:
        require(not path.exists(), "Existing path refused: " + str(path))
    if directory and exists is True:
        require(path.is_dir(), "Directory required: " + str(path))
    return path


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate config/receipt key: " + key)
        result[key] = value
    return result


def read_json(raw):
    return json.loads(raw, object_pairs_hook=no_duplicate_keys,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON: " + value)))


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf8")


def atomic_bytes(path, raw, *, exclusive=False):
    path = guarded_path(str(path))
    require(path.parent.is_dir() and os.access(path.parent, os.W_OK), "Output parent unavailable")
    fd, pending = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".pending", dir=str(path.parent))
    with os.fdopen(fd, "wb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    if exclusive:
        os.link(pending, path)
        os.unlink(pending)
    else:
        os.replace(pending, path)


def write_json(path, value, *, exclusive=False):
    raw = json_bytes(value)
    atomic_bytes(path, raw, exclusive=exclusive)
    expected = digest(raw)
    require(sha(path) == expected, "Written JSON differs from canonical payload: " + str(path))
    return expected


def check_boundary_seals(output, seals):
    for name, expected in seals.items():
        path = guarded_path(str(output / name), exists=True)
        require(sha(path) == expected, "Critical receipt changed after finalized write: " + name)


def checkpoint_write(path, state):
    path = guarded_path(str(path), exists=False)
    fd, pending = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".pending", dir=str(path.parent))
    with os.fdopen(fd, "wb") as handle:
        torch.save(state, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.link(pending, path)
    os.unlink(pending)
    return sha(path)


def emit(value):
    print(json.dumps(value, sort_keys=True, allow_nan=False, separators=(",", ":")), flush=True)


def positive_int(config, key, *, zero=False):
    value = config[key]
    require(type(value) is int and value >= (0 if zero else 1), "Invalid integer: " + key)
    return value


def validate_config(config):
    required = {"experiment_id", "seeds", "lrs", "arms", "steps", "batch", "context", "width",
                "validation_interval", "progress_interval", "selection_windows", "selection_start",
                "confirmation_windows", "confirmation_start", "threads", "adamw", "gradient_clip",
                "clip_norm_type", "clip_foreach", "cosine_floor", "window_seed_offset",
                "expected_parameters", "parameter_relative_tolerance", "data", "source_pins",
                "driver_sha256", "candidate_source_sha256", "candidate_source_utf8_bytes",
                "runtime_outputs", "runtime", "canary_steps"}
    require(required <= set(config), "Missing config keys: " + repr(sorted(required - set(config))))
    require(isinstance(config["experiment_id"], str) and config["experiment_id"], "Experiment ID required")
    require(isinstance(config["seeds"], list) and len(config["seeds"]) == 3, "Exactly three registered seeds required")
    require(all(isinstance(seed, str) and seed.isdecimal() and str(int(seed)) == seed for seed in config["seeds"]),
            "Seeds must be canonical decimal strings")
    require(len(set(config["seeds"])) == 3 and all(0 <= int(seed) < 2**63 for seed in config["seeds"]),
            "Invalid/duplicate seeds")
    require(isinstance(config["lrs"], list) and len(config["lrs"]) == 2 and len(set(config["lrs"])) == 2,
            "Exactly two distinct registered LRs required")
    require(all(finite(lr, "LR") > 0 for lr in config["lrs"]), "Positive LRs required")
    require(len(config["arms"]) == 4 and set(config["arms"]) == set(ARMS), "Exactly four registered arms required")
    for key in ("steps", "batch", "context", "width", "validation_interval", "progress_interval",
                "selection_windows", "confirmation_windows", "threads", "canary_steps"):
        positive_int(config, key)
    for key in ("selection_start", "confirmation_start", "window_seed_offset"):
        positive_int(config, key, zero=True)
    require(config["threads"] == 1 and config["width"] % 2 == 0, "CPU1/even width required")
    require(config["selection_start"] == 0, "Selection must remain the registered validation prefix")
    require(config["confirmation_start"] >= config["selection_windows"] * config["context"] + 1,
            "Selection and confirmation input/target spans overlap")
    require(0 <= finite(config["cosine_floor"], "Cosine floor") <= 1, "Invalid cosine floor")
    require(finite(config["gradient_clip"], "Gradient clip") > 0, "Invalid clip")
    require(finite(config["clip_norm_type"], "Clip norm type") > 0, "Invalid clip norm type")
    require(config["clip_foreach"] is False, "Explicit native clip foreach=False required")
    require(0 <= finite(config["parameter_relative_tolerance"], "Parameter tolerance") < 1, "Invalid count tolerance")
    require(set(config["expected_parameters"]) == set(ARMS), "All four expected parameter counts required")
    require(all(type(v) is int and v > 0 for v in config["expected_parameters"].values()), "Invalid parameter counts")
    require(set(config["source_pins"]) == set(MODULES), "Exactly six dependency source pins required")
    require(set(config["data"]) == {"train", "valid"}, "Only train/valid data paths permitted")
    optimizer = config["adamw"]
    require(set(optimizer) == {"betas", "eps", "weight_decay", "foreach", "amsgrad", "maximize",
                              "capturable", "differentiable", "fused"}, "Explicit AdamW options required")
    require(len(optimizer["betas"]) == 2 and all(0 <= finite(v, "Beta") < 1 for v in optimizer["betas"]), "Invalid betas")
    require(finite(optimizer["eps"], "AdamW epsilon") > 0 and finite(optimizer["weight_decay"], "Weight decay") >= 0,
            "Invalid AdamW options")
    require(all(optimizer[key] is False for key in ("foreach", "amsgrad", "maximize", "capturable", "differentiable", "fused")),
            "Only ordinary native non-fused AdamW supported")
    require(set(config["runtime_outputs"]) >= {"output_dir", "lock_path", "pid_path", "tmp_dir", "xdg_cache_home", "torch_home"},
            "Runtime output/cache paths required")
    require(set(config["runtime"]) >= {"python_executable", "torch_version"}, "Pinned runtime required")
    require(all(0 <= int(seed) + config["window_seed_offset"] < 2**63 for seed in config["seeds"]),
            "Window RNG seed exceeds supported range")


def seal_check():
    require(sha(CONFIG_PATH) == CONFIG_SHA, "Config changed after registration")
    require(sha(DRIVER_PATH) == CONFIG["driver_sha256"], "Driver changed after registration")
    current = {}
    for name in MODULES:
        pin = CONFIG["source_pins"][name]
        path = guarded_path(pin["path"], workspace=False, exists=True)
        require(path.name == name + ".py" and sha(path) == pin["sha256"], "Source seal changed: " + name)
        if name in sys.modules:
            require(Path(sys.modules[name].__file__).resolve() == path, "Imported source location changed: " + name)
        current[name] = {"path": str(path), "sha256": pin["sha256"]}
    for key in ("structural_canary", "prior_training_protocol"):
        if key in CONFIG:
            pin = CONFIG[key]
            path = guarded_path(pin["path"], workspace=False, exists=True)
            require(path.is_file() and sha(path) == pin["sha256"], "Reference artifact seal changed: " + key)
            current[key] = {"path": str(path), "sha256": pin["sha256"]}
    return current


def preflight(args):
    global CONFIG, CONFIG_PATH, CONFIG_SHA, DRIVER_PATH
    mounted()
    DRIVER_PATH = guarded_path(str(Path(__file__).resolve()), exists=True)
    CONFIG_PATH = guarded_path(args.config, exists=True)
    raw = CONFIG_PATH.read_bytes()
    CONFIG_SHA = digest(raw)
    require(CONFIG_SHA == args.config_sha256, "External config SHA256 pin mismatch")
    CONFIG = read_json(raw)
    validate_config(CONFIG)
    require(sha(DRIVER_PATH) == CONFIG["driver_sha256"], "Driver SHA256 pin mismatch")
    require(digest(SHAPE_QUERY_SOURCE.encode()) == CONFIG["candidate_source_sha256"]
            and len(SHAPE_QUERY_SOURCE.encode()) == CONFIG["candidate_source_utf8_bytes"],
            "Exact ShapeQuery source pin mismatch")
    output = guarded_path(args.output)
    require(str(output) == CONFIG["runtime_outputs"]["output_dir"], "CLI output differs from sealed config")
    require(output.parent.is_dir() and os.access(output.parent, os.W_OK), "Output parent unavailable")
    for name in ("tmp_dir", "xdg_cache_home", "torch_home"):
        path = guarded_path(CONFIG["runtime_outputs"][name], exists=True, directory=True)
        require(os.access(path, os.W_OK) and output not in path.parents and path != output, "Invalid runtime cache path")
    for name in ("lock_path", "pid_path"):
        path = guarded_path(CONFIG["runtime_outputs"][name])
        require(path.parent == output.parent and path != output and path not in (CONFIG_PATH, DRIVER_PATH),
                "Lock/PID must be distinct adjacent runtime paths")
    require(CONFIG["runtime_outputs"]["lock_path"] != CONFIG["runtime_outputs"]["pid_path"], "Lock/PID collision")
    if "stdout_log" in CONFIG["runtime_outputs"]:
        guarded_path(CONFIG["runtime_outputs"]["stdout_log"])
    for split in ("train", "valid"):
        record = CONFIG["data"][split]
        path = guarded_path(record["path"], workspace=False, exists=True)
        require(path.is_file() and path.name == split + ".txt", "Only named train.txt/valid.txt permitted")
        require(isinstance(record["sha256"], str) and len(record["sha256"]) == 64, "Data digest missing")
    require(Path(sys.executable).resolve() == Path(CONFIG["runtime"]["python_executable"]).resolve(),
            "Python runtime pin mismatch")
    os.environ["TMPDIR"] = CONFIG["runtime_outputs"]["tmp_dir"]
    os.environ["XDG_CACHE_HOME"] = CONFIG["runtime_outputs"]["xdg_cache_home"]
    os.environ["TORCH_HOME"] = CONFIG["runtime_outputs"]["torch_home"]
    os.environ["OMP_NUM_THREADS"] = str(CONFIG["threads"])
    os.environ["MKL_NUM_THREADS"] = str(CONFIG["threads"])
    sealed = seal_check()
    roots = {Path(pin["path"]).parent for pin in CONFIG["source_pins"].values()}
    require(len(roots) == 1, "Dependency closure must share one pinned authoritative SSD directory")
    source_root = next(iter(roots))
    require(not any(name in sys.modules for name in MODULES), "Preloaded dependency refused")
    sys.path.insert(0, str(source_root))
    imported = {name: importlib.import_module(name) for name in MODULES}
    global torch, nn, F, pilot, source, energy
    torch = importlib.import_module("torch")
    nn = torch.nn
    F = torch.nn.functional
    require(torch.__version__ == CONFIG["runtime"]["torch_version"], "Torch runtime pin mismatch")
    torch.set_num_threads(CONFIG["threads"])
    torch.set_num_interop_threads(CONFIG["threads"])
    torch.use_deterministic_algorithms(True)
    torch.set_default_dtype(torch.float32)
    for name, module in list(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if filename and Path(filename).resolve().parent == source_root:
            require(name in MODULES and Path(filename).resolve() == Path(CONFIG["source_pins"][name]["path"]),
                    "Unpinned imported source closure: " + name)
    seal_check()
    pilot = imported["phase_transition_language"]
    source = imported["noncommuting_phase_candidate"]
    energy = imported["pair_energy_phase_candidate"]
    pilot.C["context"] = CONFIG["context"]
    exec(SHAPE_QUERY_SOURCE, globals())
    return output, {"source_pins_before_import": sealed, "source_pins_after_import": seal_check(),
                    "python_executable": str(Path(sys.executable).resolve()), "python_version": sys.version,
                    "torch_version": torch.__version__, "torch_file": str(Path(torch.__file__).resolve()),
                    "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
                    "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
                    "mount": mounted()}


def count(model):
    return sum(p.numel() for p in model.parameters())


def state_hash(state):
    checksum = hashlib.sha256()
    for name, tensor in sorted(state.items()):
        checksum.update(name.encode())
        checksum.update(str(tensor.dtype).encode())
        checksum.update(str(tuple(tensor.shape)).encode())
        checksum.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return checksum.hexdigest()


def architecture():
    width = CONFIG["width"]
    primary = count(energy.PairEnergyPhaseLM(width))
    require(primary == count(ShapeQueryLM(width)), "Primary parameter budgets differ")
    upper = 2
    while count(pilot.TinyTransformer(upper)) < primary:
        upper *= 2
    transformer_width = min(range(2, upper + 1, 2),
                            key=lambda d: abs(count(pilot.TinyTransformer(d)) - primary))
    transformer_ff = min(range(transformer_width, 4 * transformer_width + 1),
                         key=lambda ff: abs(count(pilot.TinyTransformer(transformer_width, ff)) - primary))
    counts = {"pair_energy": primary, "odd_query_shape": count(ShapeQueryLM(width)),
              "geometric_overlapping": count(source.OverlappingPhaseLM(width, True)),
              "transformer": count(pilot.TinyTransformer(transformer_width, transformer_ff))}
    require(counts == CONFIG["expected_parameters"], "Registered parameter counts do not match models")
    require(max(counts.values()) / min(counts.values()) - 1 <= CONFIG["parameter_relative_tolerance"],
            "Registered parameter matching tolerance failed")
    return {"parameters": counts, "transformer_width": transformer_width, "transformer_ff": transformer_ff,
            "matching": "Same even-width doubling and nearest FF search as prior energy runner; parameters, not FLOPs"}


def make_model(arm, seed, info):
    torch.manual_seed(int(seed))
    if arm == "transformer":
        model = pilot.TinyTransformer(info["transformer_width"], info["transformer_ff"]).float()
        receipt = {"seed": str(seed), "arm": arm, "initial_state_sha256": state_hash(model.state_dict())}
    else:
        base = source.OverlappingPhaseLM(CONFIG["width"], True).float()
        common = base.state_dict()
        if arm == "geometric_overlapping":
            model = base
            missing = []
        else:
            model = energy.PairEnergyPhaseLM(CONFIG["width"]) if arm == "pair_energy" else ShapeQueryLM(CONFIG["width"])
            result = model.load_state_dict(common, strict=False)
            expected = {"energy_gain", "second_energy_gain"} if arm == "pair_energy" else {"shape_gain", "second_shape_gain"}
            require(set(result.missing_keys) == expected and not result.unexpected_keys, "Common-init key mismatch")
            missing = result.missing_keys
            model = model.float()
            require(all(torch.equal(value, model.state_dict()[name]) for name, value in common.items()),
                    "Shared initial parameters are not exact")
            require(all(common[name].data_ptr() != model.state_dict()[name].data_ptr() for name in common),
                    "Candidate shares base storage")
            require(all(torch.count_nonzero(model.state_dict()[name]).item() == 0 for name in expected),
                    "Added banks must start zero")
        require(torch.count_nonzero(model.gain).item() == 0 and torch.count_nonzero(model.second_gain).item() == 0,
                "Existing gains must retain native zero initialization")
        receipt = {"seed": str(seed), "arm": arm, "common_state_sha256": state_hash(common),
                   "added_zero_keys": sorted(missing), "initial_state_sha256": state_hash(model.state_dict())}
    require(count(model) == info["parameters"][arm], "Runtime parameter count mismatch")
    require(all(p.device.type == "cpu" and p.dtype == torch.float32 for p in model.parameters()), "CPU FP32 required")
    return model, receipt


def optimizer(model, lr):
    options = dict(CONFIG["adamw"])
    options["betas"] = tuple(options["betas"])
    return torch.optim.AdamW(model.parameters(), lr=lr, **options)


def update(model, opt, inputs, targets):
    opt.zero_grad(set_to_none=True)
    model.train()
    logits = model(inputs)
    require(logits.dtype == torch.float32 and bool(torch.isfinite(logits).all()), "Nonfinite/non-FP32 training logits")
    loss = F.cross_entropy(logits.reshape(-1, 256), targets.flatten(), reduction="mean")
    finite(loss.item(), "Training loss")
    loss.backward()
    require(all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for p in model.parameters()), "Nonfinite/missing gradient")
    norm = nn.utils.clip_grad_norm_(model.parameters(), CONFIG["gradient_clip"],
                                   norm_type=CONFIG["clip_norm_type"], foreach=CONFIG["clip_foreach"])
    finite(norm.item(), "Preclip norm")
    opt.step()
    require(all(bool(torch.isfinite(p).all()) for p in model.parameters()), "Nonfinite updated parameter")
    require(all(not isinstance(value, torch.Tensor) or bool(torch.isfinite(value).all())
                for state in opt.state.values() for value in state.values()), "Nonfinite optimizer state")
    return {"loss": loss.item(), "preclip_norm": norm.item()}


def learned_feature_diagnostics(model, arm):
    names = ("energy_gain", "second_energy_gain") if arm == "pair_energy" else (
        ("shape_gain", "second_shape_gain") if arm == "odd_query_shape" else ())
    result = {}
    for name in names:
        parameter = getattr(model, name)
        value = parameter.detach().double()
        gradient = parameter.grad.detach().double()
        result[name] = {"coefficient_max_abs": value.abs().max().item(),
                        "coefficient_rms": value.square().mean().sqrt().item(),
                        "current_gradient_nonzero_elements": int(torch.count_nonzero(gradient)),
                        "current_gradient_l2": gradient.square().sum().sqrt().item(),
                        "current_gradient_max_abs": gradient.abs().max().item(),
                        "gradient_stage": "Postclip gradient used by completed AdamW update",
                        "informational_only_no_activation_acceptance_gate": True}
    return result


def evaluate(model, valid, start, windows):
    require(start >= 0 and start + windows * CONFIG["context"] + 1 <= len(valid), "Scoring region exceeds valid bytes")
    model.eval()
    sums = []
    fingerprint = hashlib.sha256()
    with torch.inference_mode():
        for first in range(0, windows, CONFIG["batch"]):
            ids = torch.arange(first, min(first + CONFIG["batch"], windows)) * CONFIG["context"] + start
            inputs = torch.stack([valid[int(i):int(i) + CONFIG["context"]] for i in ids])
            targets = torch.stack([valid[int(i) + 1:int(i) + CONFIG["context"] + 1] for i in ids])
            logits = model(inputs)
            require(logits.dtype == torch.float32 and bool(torch.isfinite(logits).all()), "Nonfinite/non-FP32 scoring logits")
            value = F.cross_entropy(logits.reshape(-1, 256), targets.flatten(), reduction="sum").item()
            sums.append(finite(value, "Scoring loss"))
            fingerprint.update(logits.contiguous().numpy().tobytes())
    scored = windows * CONFIG["context"]
    ce = finite(math.fsum(sums) / scored, "Scoring CE")
    return {"ce": ce, "bpc": ce / math.log(2), "windows": windows, "scored_bytes": scored,
            "start": start, "target_span_half_open": [start + 1, start + scored + 1],
            "batch_loss_sums": sums, "logits_sha256": fingerprint.hexdigest(),
            "policy": "Every window is a fresh state; position starts at zero; no earlier-region prefix"}


def validate_state(model, state, arm):
    require(isinstance(state, dict) and set(state) == set(model.state_dict()), "Checkpoint key mismatch")
    for name, expected in model.state_dict().items():
        actual = state[name]
        require(isinstance(actual, torch.Tensor) and actual.device.type == "cpu"
                and actual.dtype == torch.float32 and actual.shape == expected.shape
                and bool(torch.isfinite(actual).all()), "Checkpoint dtype/shape/finite failure: " + name)
    model.load_state_dict(state, strict=True)
    require(count(model) == CONFIG["expected_parameters"][arm], "Strict checkpoint parameter count mismatch")


def pid_status(path):
    try:
        record = read_json(path.read_bytes())
        pid = record.get("pid")
        if type(pid) is int and pid > 0:
            try:
                os.kill(pid, 0)
                return {"pid": pid, "possibly_alive": True}
            except ProcessLookupError:
                return {"pid": pid, "possibly_alive": False}
            except PermissionError:
                return {"pid": pid, "possibly_alive": "permission_unknown"}
    except Exception:
        pass
    return {"existing_receipt": "unparseable; refused"}


def acquire(output):
    require(not output.exists(), "Existing output refused; no resume or restart")
    lock = guarded_path(CONFIG["runtime_outputs"]["lock_path"])
    pid = guarded_path(CONFIG["runtime_outputs"]["pid_path"])
    for path in (lock, pid):
        require(not path.exists(), "Existing concurrency/PID guard refused: " + str(path)
                + (" " + repr(pid_status(path)) if path.exists() else ""))
    record = {"pid": os.getpid(), "state": "running", "experiment_id": CONFIG["experiment_id"],
              "config_sha256": CONFIG_SHA, "driver_sha256": CONFIG["driver_sha256"],
              "output": str(output), "started_unix_seconds": time.time()}
    write_json(lock, record, exclusive=True)
    write_json(pid, record, exclusive=True)
    output.mkdir(exist_ok=False)
    (output / "checkpoints").mkdir(exist_ok=False)
    return record


def trial_key(row):
    return (int(row["seed"]), row["arm"], row["selection"]["ce"], row["lr"], row["best_step"], row["checkpoint_sha256"])


def candidate_slots(rows):
    expected = {(seed, arm, lr) for seed in CONFIG["seeds"] for arm in ARMS for lr in CONFIG["lrs"]}
    actual = [(row["seed"], row["arm"], row["lr"]) for row in rows]
    require(len(rows) == 24 and len(set(actual)) == 24 and set(actual) == expected, "Missing/duplicate trial slots")
    require(all(row["completed_steps"] == CONFIG["steps"] for row in rows), "Incomplete trial")
    for seed in CONFIG["seeds"]:
        hashes = {row["train_window_indices_sha256"] for row in rows if row["seed"] == seed}
        require(len(hashes) == 1, "Training windows differed across arms/LRs")


def data_receipts():
    return {split: {"path": record["path"], "sha256": sha(record["path"])}
            for split, record in CONFIG["data"].items()}


def provenance():
    return {"config_sha256": CONFIG_SHA, "driver_sha256": CONFIG["driver_sha256"],
            "source_pins": {name: dict(CONFIG["source_pins"][name]) for name in MODULES},
            "data": {name: dict(CONFIG["data"][name]) for name in ("train", "valid")},
            "reference_artifacts": {name: dict(CONFIG[name]) for name in ("structural_canary", "prior_training_protocol")
                                    if name in CONFIG}}


def train_trial(seed, arm, lr, info, train, valid, output):
    model, initialization = make_model(arm, seed, info)
    opt = optimizer(model, lr)
    generator = torch.Generator().manual_seed(int(seed) + CONFIG["window_seed_offset"])
    window_hash = hashlib.sha256()
    history = []
    best_state = None
    best_record = None
    started = time.perf_counter()
    for step in range(1, CONFIG["steps"] + 1):
        ids = torch.randint(len(train) - CONFIG["context"] - 1, (CONFIG["batch"],), generator=generator)
        window_hash.update(ids.numpy().tobytes())
        inputs = torch.stack([train[int(i):int(i) + CONFIG["context"]] for i in ids])
        targets = torch.stack([train[int(i) + 1:int(i) + CONFIG["context"] + 1] for i in ids])
        actual_lr = lr * (CONFIG["cosine_floor"] + (1 - CONFIG["cosine_floor"])
                          * .5 * (1 + math.cos(math.pi * step / CONFIG["steps"])))
        for group in opt.param_groups:
            group["lr"] = actual_lr
        stats = update(model, opt, inputs, targets)
        if step % CONFIG["validation_interval"] == 0 or step == CONFIG["steps"]:
            seal_check()
            selected = evaluate(model, valid, CONFIG["selection_start"], CONFIG["selection_windows"])
            entry = {"step": step, "lr": actual_lr, **selected}
            history.append(entry)
            if best_record is None or (entry["ce"], entry["step"]) < (best_record["ce"], best_record["step"]):
                best_record = entry
                best_state = copy.deepcopy(model.state_dict())
            write_json(output / "ACTIVE_TRIAL.json",
                       {"seed": seed, "arm": arm, "lr": lr, "step": step, "selection_history": history})
        if step % CONFIG["progress_interval"] == 0 or step == CONFIG["steps"]:
            seal_check()
            emit({"event": "trial_progress", "seed": seed, "arm": arm, "lr": lr, "step": step,
                  "steps": CONFIG["steps"], "actual_lr": actual_lr, **stats,
                  "learned_feature_diagnostics": learned_feature_diagnostics(model, arm),
                  "elapsed_seconds": time.perf_counter() - started})
    require(best_state is not None and best_record is not None, "No selection checkpoint")
    validate_state(model, best_state, arm)
    filename = seed + "-" + arm + "-" + digest(repr(lr).encode())[:12] + ".pt"
    checkpoint = output / "checkpoints" / filename
    checkpoint_sha = checkpoint_write(checkpoint, best_state)
    selection = evaluate(model, valid, CONFIG["selection_start"], CONFIG["selection_windows"])
    require(selection["ce"] == best_record["ce"] and selection["logits_sha256"] == best_record["logits_sha256"],
            "Saved selected state fails native exact selection replay")
    return {"seed": seed, "arm": arm, "lr": lr, "best_step": best_record["step"],
            "completed_steps": CONFIG["steps"], "parameters": count(model), "selection": selection,
            "selection_history": history, "checkpoint": str(checkpoint), "checkpoint_sha256": checkpoint_sha,
            "checkpoint_state_sha256": state_hash(best_state), "initialization": initialization,
            "train_window_indices_sha256": window_hash.hexdigest(), "window_rng_seed": str(int(seed) + CONFIG["window_seed_offset"]),
            "train_target_exposure": CONFIG["steps"] * CONFIG["batch"] * CONFIG["context"],
            "training_seconds": time.perf_counter() - started, "provenance": provenance()}


def verify_selected(rows, frozen, info, valid, output):
    candidate_slots(rows)
    require(len(frozen) == 12 and {(r["seed"], r["arm"]) for r in frozen}
            == {(seed, arm) for seed in CONFIG["seeds"] for arm in ARMS}, "Frozen slots incomplete")
    receipts = []
    for row in frozen:
        require(row in rows and row["provenance"] == provenance(), "Selected provenance mismatch")
        options = [candidate for candidate in rows if candidate["seed"] == row["seed"] and candidate["arm"] == row["arm"]]
        require(row == min(options, key=lambda r: (r["selection"]["ce"], r["lr"], r["best_step"], r["checkpoint_sha256"])),
                "Freeze did not use selection-only canonical ranking")
        checkpoint = guarded_path(row["checkpoint"], exists=True)
        require(checkpoint.parent == output / "checkpoints" and sha(checkpoint) == row["checkpoint_sha256"], "Selected checkpoint seal mismatch")
        model, _ = make_model(row["arm"], row["seed"], info)
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)
        validate_state(model, state, row["arm"])
        require(state_hash(state) == row["checkpoint_state_sha256"], "Selected state content changed")
        replay = evaluate(model, valid, CONFIG["selection_start"], CONFIG["selection_windows"])
        require(replay == row["selection"], "Frozen checkpoint selection replay is not exact")
        receipts.append({"seed": row["seed"], "arm": row["arm"], "lr": row["lr"], "best_step": row["best_step"],
                         "checkpoint_sha256": row["checkpoint_sha256"], "dtype": "FP32", "strict_keys_shapes_finite": True,
                         "parameters": count(model), "selection_replay_exact": True, "selection": replay})
    return receipts


def run_full(output, runtime_receipt):
    record = acquire(output)
    rows = []
    boundary_seals = {}
    stage = "pre_data_protocol"
    try:
        info = architecture()
        initialization = []
        for seed in CONFIG["seeds"]:
            receipts = [make_model(arm, seed, info)[1] for arm in ARMS]
            require(len({r["common_state_sha256"] for r in receipts if r["arm"] != "transformer"}) == 1,
                    "Recurrent common initialization mismatch")
            initialization.extend(receipts)
        seal_check()
        protocol = {"config": CONFIG, "config_sha256": CONFIG_SHA, "driver_sha256": CONFIG["driver_sha256"],
                    "runtime": runtime_receipt, "architecture": info, "initialization": initialization,
                    "source_pins": seal_check(), "expected_data": CONFIG["data"], "data_content_read": False,
                    "candidate_source_sha256": CONFIG["candidate_source_sha256"],
                    "primary_gate": "Energy confirmation CE strictly below odd-query shape in every registered seed",
                    "diagnostics": "Energy versus geometric and Transformer; not primary gate",
                    "overall_local_advance_gate": "Primary gate AND energy strictly below geometry AND Transformer in every seed",
                    "confirmation_policy": "All24 completed, freeze12 by selection prefix, verify all12 before first reserved score; two independent FP32 passes exact CE and logits drift zero",
                    "limitations": "Same corpus/region, not independent domains/significance; parameter matching not FLOPs; no official test, word-level perplexity, novelty, SOTA, contraction or original-hierarchy claim"}
        protocol_sha = write_json(output / "PROTOCOL.json", protocol, exclusive=True)
        boundary_seals["PROTOCOL.json"] = protocol_sha
        stage = "named_train_valid_reads"
        raw = {split: Path(CONFIG["data"][split]["path"]).read_bytes() for split in ("train", "valid")}
        actual_data = {split: {"path": CONFIG["data"][split]["path"], "sha256": digest(value), "bytes": len(value)}
                       for split, value in raw.items()}
        require(all(actual_data[split]["sha256"] == CONFIG["data"][split]["sha256"] for split in raw), "Task data SHA256 mismatch")
        boundary_seals["DATA_RECEIPTS.json"] = write_json(output / "DATA_RECEIPTS.json",
            {"data": actual_data, "protocol_sha256_before_data_reads": protocol_sha,
             "whole_valid_hashed_loaded_not_reserved_scored": True}, exclusive=True)
        train = torch.tensor(list(raw["train"]), dtype=torch.long)
        valid = torch.tensor(list(raw["valid"]), dtype=torch.long)
        del raw
        require(len(train) > CONFIG["context"] + 1, "Train corpus too short")
        require(CONFIG["confirmation_start"] + CONFIG["confirmation_windows"] * CONFIG["context"] + 1 <= len(valid),
                "Registered confirmation exceeds valid bytes")
        stage = "training"
        for seed in CONFIG["seeds"]:
            for arm in CONFIG["arms"]:
                for lr in CONFIG["lrs"]:
                    seal_check()
                    row = train_trial(seed, arm, lr, info, train, valid, output)
                    rows.append(row)
                    candidates_sha = write_json(output / "CANDIDATES.json", sorted(rows, key=trial_key))
                    emit({"event": "trial_complete", "completed": len(rows), "total": 24,
                          "seed": seed, "arm": arm, "lr": lr, "selection_ce": row["selection"]["ce"],
                          "best_step": row["best_step"], "checkpoint_sha256": row["checkpoint_sha256"]})
        candidate_slots(rows)
        boundary_seals["CANDIDATES.json"] = candidates_sha
        check_boundary_seals(output, boundary_seals)
        require(data_receipts() == {split: {"path": CONFIG["data"][split]["path"], "sha256": actual_data[split]["sha256"]}
                                   for split in ("train", "valid")}, "Data changed during training")
        frozen = [min([row for row in rows if row["seed"] == seed and row["arm"] == arm],
                      key=lambda r: (r["selection"]["ce"], r["lr"], r["best_step"], r["checkpoint_sha256"]))
                  for seed in sorted(CONFIG["seeds"], key=int) for arm in sorted(ARMS)]
        boundary_seals["FREEZE.json"] = write_json(output / "FREEZE.json", frozen, exclusive=True)
        training = {"completed_trials": 24, "frozen_checkpoints": 12, "config_sha256": CONFIG_SHA,
                    "protocol_sha256": protocol_sha, "candidates_sha256": boundary_seals["CANDIDATES.json"],
                    "freeze_sha256": boundary_seals["FREEZE.json"], "source_receipts": seal_check(),
                    "data_receipts": actual_data, "confirmation_scored": False, "official_test_read": False}
        boundary_seals["TRAINING_COMPLETION.json"] = write_json(output / "TRAINING_COMPLETION.json", training, exclusive=True)
        check_boundary_seals(output, boundary_seals)
        stage = "all_selected_verification_before_confirmation"
        verified = verify_selected(rows, frozen, info, valid, output)
        seal_check()
        boundary_seals["SELECTED_VERIFICATION.json"] = write_json(output / "SELECTED_VERIFICATION.json",
            {"all12_verified_before_any_confirmation": True, "checkpoints": verified,
             "freeze_sha256": boundary_seals["FREEZE.json"],
             "training_completion_sha256": boundary_seals["TRAINING_COMPLETION.json"]}, exclusive=True)
        check_boundary_seals(output, boundary_seals)
        stage = "reserved_confirmation"
        confirmation = []
        for row in frozen:
            check_boundary_seals(output, boundary_seals)
            seal_check()
            checkpoint = Path(row["checkpoint"])
            require(sha(checkpoint) == row["checkpoint_sha256"], "Frozen checkpoint changed before confirmation")
            model, _ = make_model(row["arm"], row["seed"], info)
            validate_state(model, torch.load(checkpoint, map_location="cpu", weights_only=True), row["arm"])
            first = evaluate(model, valid, CONFIG["confirmation_start"], CONFIG["confirmation_windows"])
            check_boundary_seals(output, boundary_seals)
            seal_check()
            second = evaluate(model, valid, CONFIG["confirmation_start"], CONFIG["confirmation_windows"])
            check_boundary_seals(output, boundary_seals)
            drift = finite(abs(first["ce"] - second["ce"]), "Duplicate CE drift")
            exact = first == second
            item = {"seed": row["seed"], "arm": row["arm"], "lr": row["lr"], "best_step": row["best_step"],
                    "checkpoint": row["checkpoint"], "checkpoint_sha256": row["checkpoint_sha256"],
                    "first": first, "second": second, "duplicate_ce_abs_drift": drift,
                    "all_metrics_and_logits_fingerprint_exact": exact}
            confirmation.append(item)
            confirmation_sha = write_json(output / "CONFIRMATION.json", confirmation)
            require(drift == 0. and exact, "Nonzero duplicate confirmation drift; failure preserved, no retry")
            emit({"event": "confirmation_complete", "completed": len(confirmation), "total": 12,
                  "seed": row["seed"], "arm": row["arm"], "ce": first["ce"], "duplicate_drift": drift})
        require(len(confirmation) == 12, "Incomplete confirmation")
        boundary_seals["CONFIRMATION.json"] = confirmation_sha
        check_boundary_seals(output, boundary_seals)
        indexed = {(row["seed"], row["arm"]): row for row in confirmation}
        paired = []
        for seed in sorted(CONFIG["seeds"], key=int):
            energy_ce = indexed[seed, "pair_energy"]["first"]["ce"]
            shape_ce = indexed[seed, "odd_query_shape"]["first"]["ce"]
            geo_ce = indexed[seed, "geometric_overlapping"]["first"]["ce"]
            tf_ce = indexed[seed, "transformer"]["first"]["ce"]
            paired.append({"seed": seed, "energy_ce": energy_ce, "shape_ce": shape_ce,
                           "energy_minus_shape": energy_ce - shape_ce, "energy_strictly_below_shape": energy_ce < shape_ce,
                           "diagnostics": {"energy_minus_geometric": energy_ce - geo_ce, "energy_minus_transformer": energy_ce - tf_ce,
                                           "energy_strictly_below_geometric": energy_ce < geo_ce,
                                           "energy_strictly_below_transformer": energy_ce < tf_ce}})
        completion = {"completed_checkpoints": 12, "fp32_evaluations": 24,
                      "all_duplicate_drift_exact_zero": True, "paired_primary_gate": paired,
                      "primary_gate_passed": all(row["energy_strictly_below_shape"] for row in paired),
                      "overall_local_advance_gate_passed": all(row["energy_strictly_below_shape"]
                          and row["diagnostics"]["energy_strictly_below_geometric"]
                          and row["diagnostics"]["energy_strictly_below_transformer"] for row in paired),
                      "canonical_confirmation_ranking": sorted(
                          [{"seed": row["seed"], "arm": row["arm"], "ce": row["first"]["ce"]} for row in confirmation],
                          key=lambda row: (int(row["seed"]), row["ce"], row["arm"])),
                      "config_sha256": CONFIG_SHA, "protocol_sha256": protocol_sha,
                      "training_completion_sha256": boundary_seals["TRAINING_COMPLETION.json"],
                      "selected_verification_sha256": boundary_seals["SELECTED_VERIFICATION.json"],
                      "freeze_sha256": boundary_seals["FREEZE.json"], "source_receipts_after": seal_check(),
                      "critical_receipt_expected_sha256": dict(boundary_seals),
                      "data_receipts_after": data_receipts(), "official_test_read": False,
                      "limitations": protocol["limitations"]}
        require(completion["data_receipts_after"] == {split: {"path": CONFIG["data"][split]["path"], "sha256": actual_data[split]["sha256"]}
                                                      for split in ("train", "valid")}, "Data changed before confirmation completion")
        check_boundary_seals(output, boundary_seals)
        boundary_seals["CONFIRMATION_COMPLETION.json"] = write_json(output / "CONFIRMATION_COMPLETION.json", completion, exclusive=True)
        check_boundary_seals(output, boundary_seals)
        record.update(state="completed", completed_unix_seconds=time.time(), primary_gate_passed=completion["primary_gate_passed"],
                      overall_local_advance_gate_passed=completion["overall_local_advance_gate_passed"])
        write_json(Path(CONFIG["runtime_outputs"]["lock_path"]), record)
        write_json(Path(CONFIG["runtime_outputs"]["pid_path"]), record)
        emit({"event": "run_complete", "output": str(output), "primary_gate_passed": completion["primary_gate_passed"],
              "overall_local_advance_gate_passed": completion["overall_local_advance_gate_passed"]})
    except BaseException as error:
        record.update(state="failed", failed_unix_seconds=time.time(), stage=stage,
                      error_type=type(error).__name__, error=str(error), completed_trials=len(rows))
        failure = {"record": record, "traceback": traceback.format_exc(), "config_sha256": CONFIG_SHA,
                   "provenance": provenance(), "preserved_without_rerun": True, "official_test_read": False}
        try:
            write_json(output / "FAILURE.json", failure, exclusive=True)
            write_json(Path(CONFIG["runtime_outputs"]["lock_path"]), record)
            write_json(Path(CONFIG["runtime_outputs"]["pid_path"]), record)
        except BaseException as preservation_error:
            emit({"event": "failure_preservation_error", "error": str(preservation_error), "original": record})
        raise


def canary(info, runtime_receipt):
    # No output, lock, PID, checkpoint, protocol, or task-data content writes/reads.
    results = []
    seed = CONFIG["seeds"][0]
    generator = torch.Generator().manual_seed(int(seed) + CONFIG["window_seed_offset"])
    inputs = torch.randint(256, (CONFIG["batch"], CONFIG["context"]), generator=generator)
    targets = torch.randint(256, (CONFIG["batch"], CONFIG["context"]), generator=generator)
    initial_receipts = []
    for arm in ARMS:
        model, initialization = make_model(arm, seed, info)
        initial_receipts.append(initialization)
        opt = optimizer(model, CONFIG["lrs"][0])
        started = time.perf_counter()
        stats = [update(model, opt, inputs, targets) for _ in range(CONFIG["canary_steps"])]
        results.append({"arm": arm, "steps": CONFIG["canary_steps"], "parameters": count(model),
                        "all_finite": True, "steps_stats": stats, "completed_seconds": time.perf_counter() - started})
    require(len({receipt["common_state_sha256"] for receipt in initial_receipts if receipt["arm"] != "transformer"}) == 1,
            "Canary recurrent common-init mismatch")
    emit({"event": "synthetic_canary_complete", "config_sha256": CONFIG_SHA, "driver_sha256": CONFIG["driver_sha256"],
          "runtime": runtime_receipt, "architecture": info, "initialization": initial_receipts, "arms": results,
          "input_uint8_sha256": digest(bytes(inputs.flatten().tolist())),
          "target_uint8_sha256": digest(bytes(targets.flatten().tolist())),
          "synthetic_rng_seed": str(int(seed) + CONFIG["window_seed_offset"]),
          "source_receipts_after": seal_check(), "dataset_content_reads": 0, "artifact_writes": 0,
          "sealed_run_outputs_modified": False,
          "limits": "Synthetic finiteness/runtime canary only; no task metric, confirmation, or optimizer-throughput extrapolation"})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--config-sha256", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--canary", action="store_true")
    args = parser.parse_args()
    output, runtime_receipt = preflight(args)
    if args.canary:
        canary(architecture(), runtime_receipt)
    else:
        run_full(output, runtime_receipt)


if __name__ == "__main__":
    main()
