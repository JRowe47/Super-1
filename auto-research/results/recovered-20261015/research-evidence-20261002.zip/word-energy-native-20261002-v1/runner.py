#!/usr/bin/env python3
"""Fresh native word mechanism runner. Importing this file performs no work."""
import argparse
import ast
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time

SSD = Path("/Volumes/SP AI 01_16")
WORK = SSD / "CodexWorkspaces"
ARMS = ("pair_energy", "odd_query_shape", "transformer")
FEATURES = {"energy_gain", "second_energy_gain", "shape_gain", "second_shape_gain"}
CLOSURE = {"phase_transition_language", "capacity_sweep", "direct_distance", "run",
           "noncommuting_phase_candidate", "pair_energy_phase_candidate"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    with Path(path).open("rb") as source:
        value = hashlib.sha256()
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


def mounted():
    lines = subprocess.check_output(["/sbin/mount"], text=True).splitlines()
    matched = [line for line in lines if " on " + str(SSD) + " (" in line]
    require(len(matched) == 1 and matched[0].startswith("/dev/") and "read-only" not in matched[0],
            "Actual writable external SSD mount is required; no fallback")
    require(SSD.resolve(strict=True) == SSD and WORK.resolve(strict=True) == WORK and os.access(WORK, os.W_OK),
            "SSD workspace must resolve to its mounted writable path")
    return matched[0]


def work_path(value, exists=False):
    path = Path(value)
    require(path.is_absolute(), "Paths must be absolute")
    resolved = path.resolve(strict=exists)
    require(resolved == path and resolved != WORK and WORK in resolved.parents,
            "All new outputs/config/code/cache must resolve below mounted CodexWorkspaces")
    require(not any(part in {"Documents", "Desktop", "Mobile Documents"} for part in resolved.parts),
            "iCloud/Documents/Desktop output is forbidden")
    if not exists:
        require(path.parent.is_dir() and os.access(path.parent, os.W_OK), "Output parent must exist and be writable")
    return path


def pin_check(pin, workspace=False):
    path = work_path(pin["path"], exists=True) if workspace else Path(pin["path"])
    require(path.is_absolute() and path.resolve(strict=True) == path and SSD in path.parents,
            "Pin must be an existing resolved SSD path")
    require(len(pin["sha256"]) == 64 and file_sha(path) == pin["sha256"], "Hash pin failed: " + str(path))
    return path


def write_json(path, payload):
    raw = json_bytes(payload)
    # Exclusive publication. Every finalized boundary captures these exact bytes.
    with Path(path).open("xb") as destination:
        destination.write(raw)
        destination.flush()
        os.fsync(destination.fileno())
    expected = digest(raw)
    require(file_sha(path) == expected, "Published receipt differs from canonical bytes")
    return expected


def append_json(path, value):
    with Path(path).open("ab") as destination:
        destination.write((json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode("utf-8"))
        destination.flush()


def validate_config(cfg):
    require(cfg["experiment_id"] == "word-energy-native-20261002-v1", "Unexpected experiment")
    require(cfg["arms"] == list(ARMS), "Arm order and set must be preregistered")
    seeds = cfg["seeds"]
    require(len(seeds) == 3 and len(set(seeds)) == 3 and all(isinstance(s, str) and s.isdecimal() for s in seeds),
            "Exactly three distinct decimal-string seeds required")
    require(cfg["lrs"] == [.001, .003], "Two-LR budget must remain .001/.003")
    require(cfg["steps"] == 24000 and cfg["batch"] == 4 and cfg["context"] == 70 and cfg["width"] == 256,
            "Registered word horizon is 24000 updates at B4/T70/width256")
    require(cfg["validation_interval"] == 1000 and cfg["steps"] % cfg["validation_interval"] == 0,
            "All 1000-step curves must be retained; no early stopping")
    require(cfg["threads"] == 1 and cfg["canary_steps"] in (1, 2), "CPU1 and bounded 1/2-update synthetic fixture required")
    require(cfg["vocabulary"]["size"] == 33278 and cfg["vocabulary"]["special_ids"] == {"<eos>": 0, "<unk>": 9},
            "Frozen vocabulary contract mismatch")
    require(set(cfg["source_pins"]) == CLOSURE, "Exact six-module import closure required")
    require(set(cfg["code_pins"]) == {"runner.py", "word_models.py", "fixtures.py"}, "Own complete source closure required")
    require(cfg["selection_start"] == 0 and cfg["selection_windows"] > 0 and cfg["confirmation_windows"] > 0,
            "Selection prefix and positive confirmation windows required")
    selection_end = cfg["selection_start"] + cfg["selection_windows"] * cfg["context"]
    require(cfg["confirmation_start"] > selection_end, "Reserved scoring targets must be disjoint from selection")
    require(cfg["fresh_state_per_window"] is True and cfg["official_test_read"] is False,
            "All arms reset per window; official test is forbidden")
    require(cfg["gradient_clip"] == 1 and cfg["cosine_floor"] == .1, "Optimizer schedule/clip changed")
    adam = cfg["adamw"]
    require(adam == {"betas": [.9, .999], "eps": 1e-8, "weight_decay": .01, "foreach": False,
                     "amsgrad": False, "maximize": False, "capturable": False,
                     "differentiable": False, "fused": False}, "Native AdamW settings changed")
    require(cfg["clip_norm_type"] == 2 and cfg["clip_foreach"] is False, "Native clip settings changed")
    require(isinstance(cfg["full_run_approved"], bool), "Explicit reviewed full-run approval field required")
    for kind in ("train", "valid"):
        require(Path(cfg["data"][kind]["path"]).name == kind + ".txt", "Only explicit train.txt/valid.txt are approved")


def preflight(config, expected):
    mounted()
    config = work_path(config, exists=True)
    require(file_sha(config) == expected, "External config SHA required")
    cfg = json.loads(config.read_text(encoding="utf-8"))
    validate_config(cfg)
    own = Path(__file__).resolve(strict=True)
    require(work_path(own, exists=True) == own, "Runner must live in new SSD project")
    for name, pin in cfg["code_pins"].items():
        require(Path(pin["path"]).parent == own.parent and Path(pin["path"]).name == name, "Own source closure path mismatch")
        pin_check(pin, workspace=True)
    require(Path(cfg["code_pins"]["runner.py"]["path"]) == own, "Invoked runner is not pinned runner")
    for pin in cfg["source_pins"].values():
        pin_check(pin)
    for name in ("shape_driver", "shape_config", "seed_draw"):
        pin_check(cfg[name], workspace=True)
    seed_draw = json.loads(Path(cfg["seed_draw"]["path"]).read_text(encoding="utf-8"))
    require(seed_draw["seeds"] == cfg["seeds"], "Seeds must equal archived one-time root draw")
    # Read sealed source as text/AST only; never execute the old runner.
    tree = ast.parse(Path(cfg["shape_driver"]["path"]).read_text(encoding="utf-8"))
    found = [node.value.value for node in tree.body if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == "SHAPE_QUERY_SOURCE" for target in node.targets)
             and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)]
    require(len(found) == 1, "Exactly one sealed shape law string required")
    shape = found[0]
    require(len(shape.encode("utf-8")) == cfg["shape_source_utf8_bytes"] and digest(shape.encode("utf-8")) == cfg["shape_source_sha256"],
            "Exact sealed 907-byte shape law required")
    require(os.path.realpath(sys.executable) == cfg["runtime"]["python_executable"], "Resolved Python runtime mismatch")
    require(sys.dont_write_bytecode and os.environ.get("PYTHONDONTWRITEBYTECODE") == "1", "Use python -B and no-bytecode env")
    env_names = {"TMPDIR": "tmp_dir", "XDG_CACHE_HOME": "xdg_cache_home", "TORCH_HOME": "torch_home"}
    for env, key in env_names.items():
        path = work_path(cfg["runtime_outputs"][key], exists=True)
        require(path.is_dir() and os.access(path, os.W_OK) and os.environ.get(env) == str(path),
                "Runtime temp/cache must already exist and exactly match SSD config: " + env)
    return cfg, config, shape


def seal_check(cfg, config, config_sha, boundary=None):
    mounted()
    require(file_sha(config) == config_sha, "Config changed after registration")
    for group in ("code_pins", "source_pins"):
        for pin in cfg[group].values():
            pin_check(pin)
    for name in ("shape_driver", "shape_config", "seed_draw"):
        pin_check(cfg[name], workspace=True)
    if boundary:
        for path, expected in boundary.items():
            require(file_sha(path) == expected, "Immutable boundary receipt changed: " + str(path))


def registration(cfg, config, config_sha):
    return {"experiment_id": cfg["experiment_id"], "config_path": str(config), "config_sha256": config_sha,
            "code_pins": cfg["code_pins"], "source_pins": cfg["source_pins"],
            "shape_driver": cfg["shape_driver"], "shape_source_sha256": cfg["shape_source_sha256"],
            "seed_draw": cfg["seed_draw"], "seeds": cfg["seeds"], "data_expected": cfg["data"],
            "vocabulary_expected": cfg["vocabulary"], "budget": {"trials": 18, "frozen": 9, "lrs_per_seed_arm": 2,
            "updates_per_trial": cfg["steps"], "target_word_exposures_per_trial": cfg["steps"] * cfg["batch"] * cfg["context"]},
            "fresh_state_per_window_all_arms": True, "no_corpus_content_read_by_registration": True,
            "horizon_policy": "Fixed equal horizon and full curves; no early stop, adaptive extension, or endpoint convergence claim.",
            "primary_gate": "Complete all18 slots and selection-only freeze9; strict provenance/replay gate before reserved scoring; two exact FP32 confirmation duplicates; Energy<Shape every seed.",
            "transformer_gate": "Energy<matched Transformer every seed; separate diagnostic/conjunction, not FLOP matching.",
            "limitations": cfg["limitations"]}


def load_runtime(cfg, shape):
    import torch
    require(torch.__version__ == cfg["runtime"]["torch_version"], "Torch version mismatch")
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float32)
    torch.use_deterministic_algorithms(True)
    require(torch.get_num_threads() == 1 and torch.get_num_interop_threads() == 1, "CPU1 required")
    roots = {str(Path(pin["path"]).parent) for pin in cfg["source_pins"].values()}
    require(len(roots) == 1, "Pinned native closure must share authoritative root")
    sys.path.insert(0, roots.pop())
    energy = importlib.import_module("pair_energy_phase_candidate")
    source = importlib.import_module("noncommuting_phase_candidate")
    for name, pin in cfg["source_pins"].items():
        module = sys.modules.get(name)
        require(module is not None and Path(module.__file__).resolve(strict=True) == Path(pin["path"]),
                "Imported dependency closure path mismatch: " + name)
        pin_check(pin)
    loaded = {}
    for name in ("word_models", "fixtures"):
        spec = importlib.util.spec_from_file_location("word_native_" + name, cfg["code_pins"][name + ".py"]["path"])
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        loaded[name] = module
        require(Path(module.__file__).resolve(strict=True) == Path(cfg["code_pins"][name + ".py"]["path"]), "Own import path drift")
    models = loaded["word_models"]
    types = models.build_types(torch, energy, source, shape)
    def make(arm, vocabulary_size=None, width=None, context=None):
        v, d, t = vocabulary_size or cfg["vocabulary"]["size"], width or cfg["width"], context or cfg["context"]
        if arm == "pair_energy":
            return types[0](v, d)
        if arm == "odd_query_shape":
            return types[1](v, d)
        td, ff = models.match_transformer(v, t, models.recurrent_count(v, d))
        return types[2](v, td, ff, t)
    def finite(value, label):
        require(bool(torch.isfinite(value).all()), "Nonfinite " + label)
    def optimizer(model, lr):
        options = dict(cfg["adamw"]); options["betas"] = tuple(options["betas"])
        return torch.optim.AdamW(model.parameters(), lr=lr, **options)
    def clip(model):
        value = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["gradient_clip"],
                    norm_type=cfg["clip_norm_type"], error_if_nonfinite=True, foreach=cfg["clip_foreach"])
        finite(value, "preclip norm")
        return float(value)
    return torch, energy, source, loaded["fixtures"], models, types, make, finite, optimizer, clip


def common_initialization(torch, make, seed):
    torch.manual_seed(int(seed))
    base = make("pair_energy")
    shared = {name: value.detach().clone() for name, value in base.state_dict().items() if name not in FEATURES}
    shape = make("odd_query_shape")
    result = shape.load_state_dict(shared, strict=False)
    require(set(result.missing_keys) == {"shape_gain", "second_shape_gain"} and not result.unexpected_keys,
            "Only exact shape feature banks may be absent")
    require(all(torch.equal(value, shape.state_dict()[name]) for name, value in shared.items()), "Common primary initialization is not exact")
    require(all(torch.count_nonzero(p) == 0 for n, p in base.named_parameters() if n in FEATURES), "Energy banks must start zero")
    require(all(torch.count_nonzero(p) == 0 for n, p in shape.named_parameters() if n in FEATURES), "Shape banks must start zero")
    torch.manual_seed(int(seed))
    transformer = make("transformer")
    states = {arm: {name: value.detach().clone() for name, value in model.state_dict().items()}
              for arm, model in zip(ARMS, (base, shape, transformer))}
    # Independent cloned storage in each model; no parameter tying across arms.
    a, b = dict(base.named_parameters()), dict(shape.named_parameters())
    require(all(a[name].data_ptr() != b[name].data_ptr() for name in shared), "Models must not share writable parameter storage")
    return states


def tokenize(raw, vocabulary, torch):
    # Exact legacy per-line split + EOS semantics, explicit named file only.
    values = []
    for line in raw.decode("utf-8").splitlines():
        for word in line.split() + ["<eos>"]:
            values.append(vocabulary.get(word, vocabulary["<unk>"]))
    return torch.tensor(values, dtype=torch.int64)


def read_approved_data(cfg, torch):
    vocab_path = pin_check(cfg["vocabulary"])
    payload = torch.load(vocab_path, map_location="cpu", weights_only=True)
    require(set(payload) == {"vocabulary", "source_checkpoint_sha256"}, "Frozen vocabulary-only payload keys mismatch")
    vocabulary = payload["vocabulary"]
    require(isinstance(vocabulary, dict) and all(isinstance(k, str) and type(v) is int for k, v in vocabulary.items()),
            "Vocabulary must map strings to integer IDs")
    require(len(vocabulary) == cfg["vocabulary"]["size"] and set(vocabulary.values()) == set(range(len(vocabulary))),
            "Vocabulary IDs must be dense and unique")
    require({k: vocabulary[k] for k in cfg["vocabulary"]["special_ids"]} == cfg["vocabulary"]["special_ids"], "Special IDs mismatch")
    data, receipts = {}, {}
    for kind in ("train", "valid"):
        pin = cfg["data"][kind]
        path = Path(pin["path"])
        require(path.resolve(strict=True) == path and SSD in path.parents and path.name == kind + ".txt", "Data path violates explicit approval")
        raw = path.read_bytes()
        require(digest(raw) == pin["sha256"], "Approved raw " + kind + " hash mismatch")
        data[kind] = tokenize(raw, vocabulary, torch)
        receipts[kind] = {"path": str(path), "raw_sha256": digest(raw), "raw_bytes": len(raw),
                          "word_tokens_with_per_line_eos": len(data[kind]),
                          "token_int64_sha256": digest(data[kind].numpy().tobytes())}
    require(len(data["train"]) > cfg["context"] and len(data["valid"]) > cfg["confirmation_start"] + cfg["confirmation_windows"] * cfg["context"],
            "Registered token regions outside corpus")
    exposures = cfg["steps"] * cfg["batch"] * cfg["context"]
    receipts["exposure"] = {"word_target_exposures_per_trial": exposures,
                           "train_word_tokens": len(data["train"]),
                           "exposure_over_train_token_count": exposures / len(data["train"]),
                           "not_same_epochs_across_byte_and_word_units": True}
    receipts["vocabulary"] = {"path": str(vocab_path), "sha256": cfg["vocabulary"]["sha256"],
                             "size": len(vocabulary), "special_ids": cfg["vocabulary"]["special_ids"],
                             "legacy_lexical_membership": True}
    return data, receipts


def state_sha(model):
    value = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        value.update(name.encode("utf-8")); value.update(str(tuple(tensor.shape)).encode("ascii"))
        value.update(str(tensor.dtype).encode("ascii")); value.update(tensor.detach().contiguous().numpy().tobytes())
    return value.hexdigest()


def score(torch, model, valid, start, windows, context, finite):
    model.eval()
    losses, logits_hash = [], hashlib.sha256()
    with torch.no_grad():
        for index in range(windows):
            begin = start + index * context
            x = valid[begin:begin + context].unsqueeze(0)
            y = valid[begin + 1:begin + context + 1].unsqueeze(0)
            # No carry and no earlier-region Transformer prefix in any arm.
            logits = model(x); finite(logits, "scoring logits")
            loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten(), reduction="mean")
            finite(loss, "scoring loss")
            losses.append(float(loss))
            logits_hash.update(logits.contiguous().numpy().tobytes())
    ce = math.fsum(losses) / len(losses)
    require(math.isfinite(ce), "Nonfinite scoring aggregate")
    return {"ce": ce, "window_ce": losses, "logits_sha256": logits_hash.hexdigest(),
            "target_tokens": windows * context, "fresh_state_per_window": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--config-sha256", required=True)
    parser.add_argument("--mode", required=True, choices=("register", "canary", "run"))
    parser.add_argument("--registration-sha256")
    parser.add_argument("--authorize-full-run", action="store_true")
    args = parser.parse_args()
    cfg, config, shape = preflight(args.config, args.config_sha256)
    registration_payload = registration(cfg, config, args.config_sha256)
    registration_path = work_path(cfg["runtime_outputs"]["registration_path"])
    if args.mode == "register":
        require(not args.authorize_full_run, "Registration mode cannot train")
        sha = write_json(registration_path, registration_payload)
        seal_check(cfg, config, args.config_sha256)
        print(json.dumps({"registration_path": str(registration_path), "sha256": sha,
                          "task_content_read": False, "training_launched": False}, sort_keys=True))
        return
    require(args.mode != "run" or (args.authorize_full_run and args.registration_sha256),
            "Full run needs explicit root authorization and externally pinned registration")
    if args.mode == "run":
        require(cfg["full_run_approved"], "Template is not approved for full training")
        require(file_sha(registration_path) == args.registration_sha256 and
                registration_path.read_bytes() == json_bytes(registration_payload), "Registration/config lineage changed")
    output = work_path(cfg["runtime_outputs"]["canary_output_dir" if args.mode == "canary" else "output_dir"])
    lock = work_path(cfg["runtime_outputs"]["canary_lock_path" if args.mode == "canary" else "lock_path"])
    pid = work_path(cfg["runtime_outputs"]["canary_pid_path" if args.mode == "canary" else "pid_path"])
    require(not output.exists() and not lock.exists() and not pid.exists(), "Fresh output/lock/PID required; no resume/restart")
    acquired, created = False, False
    boundary = {}
    try:
        # O_EXCL protects concurrent attempts; only owned guards can be released.
        with lock.open("xb") as destination:
            destination.write(json_bytes({"pid": os.getpid(), "config_sha256": args.config_sha256}))
        acquired = True
        output.mkdir(); created = True
        write_json(pid, {"pid": os.getpid(), "mode": args.mode, "output": str(output), "config_sha256": args.config_sha256})
        protocol = output / "PROTOCOL.json"
        boundary[str(protocol)] = write_json(protocol, registration_payload)
        runtime = load_runtime(cfg, shape)
        torch, energy, source, fixtures, models, types, make, finite, optimizer, clip = runtime
        counts = {arm: sum(p.numel() for p in make(arm).parameters()) for arm in ARMS}
        require(counts == cfg["expected_parameters"], "Actual parameter counts differ from registration")
        require(counts["pair_energy"] == counts["odd_query_shape"] and
                abs(counts["transformer"] - counts["pair_energy"]) / counts["pair_energy"] <= cfg["parameter_relative_tolerance"],
                "Registered parameter matching failed")
        td, ff = models.match_transformer(cfg["vocabulary"]["size"], cfg["context"], counts["pair_energy"])
        initial_receipts = {}
        for seed in cfg["seeds"]:
            states = common_initialization(torch, make, seed)
            initial_receipts[seed] = {arm: digest(b"".join(name.encode("utf-8") + tensor.numpy().tobytes()
                                                      for name, tensor in sorted(state.items())))
                                      for arm, state in states.items()}
        initialization = {"parameters": counts, "transformer_width": td, "transformer_ff": ff,
                          "shared_recurrent_primary_exact": True, "independent_model_storage": True,
                          "zero_feature_banks": True, "initial_state_sha256": initial_receipts,
                          "parameter_not_flop_matching": True}
        boundary[str(output / "INITIALIZATION.json")] = write_json(output / "INITIALIZATION.json", initialization)
        boundary[str(output / "EXECUTION_RECEIPT.json")] = write_json(output / "EXECUTION_RECEIPT.json", {
            "argv": sys.argv, "python_executable": os.path.realpath(sys.executable), "torch_version": torch.__version__,
            "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
            "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(), "mode": args.mode,
            "runtime_environment": {key: os.environ.get(key) for key in ("TMPDIR", "XDG_CACHE_HOME", "TORCH_HOME", "PYTHONDONTWRITEBYTECODE")},
            "existing_process_changes": False, "official_test_read": False})
        seal_check(cfg, config, args.config_sha256, boundary)
        if args.mode == "canary":
            report = fixtures.run(torch, types, energy, cfg, make, optimizer, finite, clip)
            report["initialization"] = initialization
            seal_check(cfg, config, args.config_sha256, boundary)
            write_json(output / "CANARY_COMPLETION.json", report)
            print(json.dumps({"output": str(output), "completion_sha256": file_sha(output / "CANARY_COMPLETION.json"),
                              "task_content_read": False, "full_training_launched": False, "fixture_passed": True}, sort_keys=True))
            return
        # Registration and immutable code receipts exist BEFORE explicit train/valid content load.
        data, data_receipts = read_approved_data(cfg, torch)
        boundary[str(output / "DATA_RECEIPTS.json")] = write_json(output / "DATA_RECEIPTS.json", data_receipts)
        data_binding = digest(json_bytes(data_receipts))
        rows, slots, train_rng_hashes = [], set(), {}
        progress = output / "progress.jsonl"
        candidates_log = output / "candidates.jsonl"
        checkpoint_dir = output / "checkpoints"; checkpoint_dir.mkdir()
        training_start = time.perf_counter()
        for seed in cfg["seeds"]:
            initial = common_initialization(torch, make, seed)
            for arm in ARMS:
                for lr in cfg["lrs"]:
                    slot = (seed, arm, lr)
                    require(slot not in slots, "Duplicate trial slot")
                    torch.manual_seed(int(seed))
                    model = make(arm); model.load_state_dict(initial[arm], strict=True)
                    require(all(p.dtype == torch.float32 and p.device.type == "cpu" for p in model.parameters()),
                            "Native FP32 CPU parameters required")
                    opt = optimizer(model, lr)
                    rng = random.Random(int(seed) + cfg["window_seed_offset"])
                    window_hash = hashlib.sha256()
                    history, best = [], None
                    trial_start = time.perf_counter()
                    for step in range(1, cfg["steps"] + 1):
                        starts = [rng.randrange(len(data["train"]) - cfg["context"]) for _ in range(cfg["batch"])]
                        window_hash.update(json_bytes(starts))
                        x = torch.stack([data["train"][n:n + cfg["context"]] for n in starts])
                        y = torch.stack([data["train"][n + 1:n + cfg["context"] + 1] for n in starts])
                        scale = cfg["cosine_floor"] + (1 - cfg["cosine_floor"]) * .5 * (1 + math.cos(math.pi * (step - 1) / cfg["steps"]))
                        for group in opt.param_groups:
                            group["lr"] = lr * scale
                        model.train(); opt.zero_grad(set_to_none=True)
                        logits = model(x); finite(logits, "training logits")
                        loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten(), reduction="mean")
                        finite(loss, "training loss"); loss.backward()
                        for name, parameter in model.named_parameters():
                            require(parameter.grad is not None, "Missing native gradient " + name)
                            finite(parameter.grad, "gradient " + name)
                        preclip = clip(model); opt.step()
                        for name, parameter in model.named_parameters():
                            finite(parameter, "parameter " + name)
                            for key, tensor in opt.state[parameter].items():
                                if torch.is_tensor(tensor):
                                    finite(tensor, "optimizer moment " + name + "/" + key)
                        if step % cfg["progress_interval"] == 0:
                            feature = {name: {"coefficient_max_abs": float(p.abs().max()),
                                             "coefficient_rms": float(p.square().mean().sqrt()),
                                             "gradient_nonzero": int(torch.count_nonzero(p.grad)),
                                             "gradient_norm": float(p.grad.norm())}
                                       for name, p in model.named_parameters() if name in FEATURES}
                            event = {"seed": seed, "arm": arm, "lr": lr, "step": step,
                                     "train_loss": float(loss), "preclip_norm": preclip,
                                     "target_exposures": step * cfg["batch"] * cfg["context"],
                                     "features": feature, "trial_elapsed_seconds": time.perf_counter() - trial_start}
                            append_json(progress, event); print(json.dumps(event, sort_keys=True), flush=True)
                        if step % cfg["validation_interval"] == 0:
                            metric = score(torch, model, data["valid"], cfg["selection_start"], cfg["selection_windows"], cfg["context"], finite)
                            history.append({"step": step, **metric})
                            if best is None or (metric["ce"], step) < (best["selection"]["ce"], best["step"]):
                                checkpoint = checkpoint_dir / (seed + "-" + arm + "-" + str(lr) + "-" + str(step) + ".pt")
                                payload = {"state_dict": model.state_dict(), "arm": arm, "seed": seed, "lr": lr, "step": step,
                                           "config_sha256": args.config_sha256, "data_binding_sha256": data_binding,
                                           "source_pins": cfg["source_pins"], "shape_source_sha256": cfg["shape_source_sha256"],
                                           "state_sha256": state_sha(model), "parameters": counts[arm], "selection": metric}
                                require(not checkpoint.exists(), "Checkpoint overwrite refused")
                                temporary = checkpoint.with_suffix(".pt.tmp")
                                with temporary.open("xb") as destination:
                                    torch.save(payload, destination); destination.flush(); os.fsync(destination.fileno())
                                os.rename(temporary, checkpoint)
                                best = {"seed": seed, "arm": arm, "lr": lr, "step": step, "parameters": counts[arm],
                                        "checkpoint": str(checkpoint), "checkpoint_sha256": file_sha(checkpoint),
                                        "state_sha256": payload["state_sha256"], "selection": metric}
                    require(len(history) == cfg["steps"] // cfg["validation_interval"] and best is not None, "Incomplete trial curve")
                    row = {**best, "completed_steps": cfg["steps"], "selection_history": history,
                           "training_windows_sha256": window_hash.hexdigest(), "elapsed_seconds": time.perf_counter() - trial_start}
                    rows.append(row); slots.add(slot); append_json(candidates_log, row)
                    train_rng_hashes.setdefault(seed, set()).add(window_hash.hexdigest())
                    seal_check(cfg, config, args.config_sha256, boundary)
                    del model, opt
        expected_slots = {(seed, arm, lr) for seed in cfg["seeds"] for arm in ARMS for lr in cfg["lrs"]}
        require(slots == expected_slots and len(rows) == 18 and all(len(v) == 1 for v in train_rng_hashes.values()),
                "Missing/duplicate trials or unmatched training windows")
        # Canonical ranking fixed before confirmation; never use confirmation to select.
        rows.sort(key=lambda row: (row["seed"], row["arm"], row["lr"]))
        frozen = [min([row for row in rows if row["seed"] == seed and row["arm"] == arm],
                      key=lambda row: (row["selection"]["ce"], row["step"], row["lr"]))
                  for seed in cfg["seeds"] for arm in ARMS]
        require(len(frozen) == 9, "Freeze must contain nine selection-only winners")
        for name, payload in [("CANDIDATES.json", rows), ("FREEZE.json", frozen),
                ("TRAINING_COMPLETION.json", {"trials": 18, "all_steps_complete": True,
                 "training_elapsed_seconds": time.perf_counter() - training_start, "training_windows_matched": True,
                 "target_exposures_per_trial": cfg["steps"] * cfg["batch"] * cfg["context"], "confirmation_scored": False})]:
            boundary[str(output / name)] = write_json(output / name, payload)

        def selected_model(row):
            checkpoint = work_path(row["checkpoint"], exists=True)
            require(file_sha(checkpoint) == row["checkpoint_sha256"], "Frozen checkpoint bytes changed")
            payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
            for key in ("arm", "seed", "lr", "step", "parameters", "state_sha256", "selection"):
                require(payload[key] == row[key], "Frozen checkpoint binding mismatch " + key)
            require(payload["config_sha256"] == args.config_sha256 and payload["data_binding_sha256"] == data_binding
                    and payload["source_pins"] == cfg["source_pins"] and payload["shape_source_sha256"] == cfg["shape_source_sha256"],
                    "Frozen checkpoint provenance mismatch")
            model = make(row["arm"])
            expected = model.state_dict(); actual = payload["state_dict"]
            require(set(expected) == set(actual), "Checkpoint keys mismatch")
            for name, tensor in actual.items():
                require(tensor.dtype == torch.float32 and tensor.shape == expected[name].shape, "Checkpoint FP32/shape mismatch " + name)
                finite(tensor, "checkpoint " + name)
            model.load_state_dict(actual, strict=True)
            require(sum(p.numel() for p in model.parameters()) == row["parameters"] and state_sha(model) == row["state_sha256"],
                    "Checkpoint parameter/state digest mismatch")
            return model

        verification = []
        for row in frozen:
            seal_check(cfg, config, args.config_sha256, boundary)
            model = selected_model(row)
            replay = score(torch, model, data["valid"], cfg["selection_start"], cfg["selection_windows"], cfg["context"], finite)
            require(replay == row["selection"], "Native selection replay must be exactly identical")
            verification.append({"seed": row["seed"], "arm": row["arm"], "checkpoint_sha256": row["checkpoint_sha256"],
                                 "strict_state_verified": True, "selection_replay_exact": True})
            del model
        boundary[str(output / "SELECTED_VERIFICATION.json")] = write_json(output / "SELECTED_VERIFICATION.json", verification)
        # All nine checkpoints verified before ANY reserved scoring target.
        seal_check(cfg, config, args.config_sha256, boundary)
        pin_check(cfg["vocabulary"])
        for pin in cfg["data"].values():
            pin_check(pin)
        confirmation = []
        for row in frozen:
            seal_check(cfg, config, args.config_sha256, boundary)
            model = selected_model(row)
            first = score(torch, model, data["valid"], cfg["confirmation_start"], cfg["confirmation_windows"], cfg["context"], finite)
            seal_check(cfg, config, args.config_sha256, boundary)
            require(file_sha(row["checkpoint"]) == row["checkpoint_sha256"], "Checkpoint changed between duplicate passes")
            second = score(torch, model, data["valid"], cfg["confirmation_start"], cfg["confirmation_windows"], cfg["context"], finite)
            require(first == second, "Two native FP32 confirmation passes must have exact zero drift")
            confirmation.append({"seed": row["seed"], "arm": row["arm"], "lr": row["lr"], "step": row["step"],
                                 "checkpoint_sha256": row["checkpoint_sha256"], "first": first, "second": second,
                                 "duplicate_exact": True, "duplicate_ce_abs_drift": 0.})
            del model
            seal_check(cfg, config, args.config_sha256, boundary)
        paired = []
        for seed in cfg["seeds"]:
            scores = {row["arm"]: row["first"]["ce"] for row in confirmation if row["seed"] == seed}
            paired.append({"seed": seed, "energy_minus_shape": scores["pair_energy"] - scores["odd_query_shape"],
                           "energy_minus_transformer": scores["pair_energy"] - scores["transformer"],
                           "energy_below_shape": scores["pair_energy"] < scores["odd_query_shape"],
                           "energy_below_transformer": scores["pair_energy"] < scores["transformer"]})
        primary = all(row["energy_below_shape"] for row in paired)
        tf_gate = all(row["energy_below_transformer"] for row in paired)
        seal_check(cfg, config, args.config_sha256, boundary)
        pin_check(cfg["vocabulary"])
        for pin in cfg["data"].values():
            pin_check(pin)
        boundary[str(output / "CONFIRMATION.json")] = write_json(output / "CONFIRMATION.json", confirmation)
        completion = {"trials_completed": 18, "frozen": 9, "duplicates": 18, "primary_energy_shape_gate_passed": primary,
                      "matched_transformer_gate_passed": tf_gate, "overall_local_advance_gate_passed": primary and tf_gate,
                      "paired": paired, "boundary_seals": boundary, "official_test_read": False,
                      "all_native_gradients_parameters_moments_finite": True, "limitations": cfg["limitations"]}
        seal_check(cfg, config, args.config_sha256, boundary)
        write_json(output / "CONFIRMATION_COMPLETION.json", completion)
        print(json.dumps(completion, sort_keys=True), flush=True)
    except BaseException as error:
        if created:
            failure = {"type": type(error).__name__, "message": str(error), "mode": args.mode,
                       "config_sha256": args.config_sha256, "no_resume_or_retuning": True}
            try:
                write_json(output / "FAILURE.json", failure)
            except BaseException:
                pass
        raise
    finally:
        # Never delete another attempt's guards; output and failure remain preserved.
        if acquired:
            if pid.exists():
                require(json.loads(pid.read_text())["pid"] == os.getpid(), "PID ownership changed; refusing cleanup")
                pid.unlink()
            require(json.loads(lock.read_text())["pid"] == os.getpid(), "Lock ownership changed; refusing cleanup")
            lock.unlink()


if __name__ == "__main__":
    main()
