"""One bounded full-batch native cost probe; no corpus/checkpoint scoring."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import statistics
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--config-sha256", required=True)
    parser.add_argument("--driver-sha256", required=True)
    args = parser.parse_args()
    project = Path(__file__).resolve().parent
    expected_runner = "87fd0c4c2bbdb5a646adea20ce59fd7f5c1f5cad185223f7bf52f9dd362b0ee5"
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if sha(__file__) != args.driver_sha256 or sha(project / "runner.py") != expected_runner:
        raise RuntimeError("Externally reviewed source seals differ")
    spec = importlib.util.spec_from_file_location("word_budget_native_runner", project / "runner.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    cfg, config, shape = runner.preflight(args.config, args.config_sha256)
    output = runner.work_path(str(project / "budget"))
    if output.exists():
        raise RuntimeError("Budget probe already attempted; no automatic rerun")
    output.mkdir()
    blocked = []

    def audit(event, values):
        if event == "open" and values and isinstance(values[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(values[0]))
            if path.name in {"train.txt", "valid.txt", "test.txt"} or path.suffix == ".pt":
                blocked.append(str(path))
                raise RuntimeError("Corpus/checkpoint access forbidden in budget probe")

    sys.addaudithook(audit)
    protocol = {
        "driver_sha256": args.driver_sha256, "runner_sha256": expected_runner,
        "config_sha256": args.config_sha256, "arms": cfg["arms"],
        "seed": cfg["seeds"][0], "batch": cfg["batch"], "context": cfg["context"],
        "native_updates_per_arm": 2, "threads": 1, "task_content_reads_permitted": False,
        "scope": "Synthetic CPU cost feasibility, not corpus CE or defensible relative-speed benchmark. Concurrent sealed CPU job makes timings unisolated."
    }
    boundary = {str(output / "PROTOCOL.json"): runner.write_json(output / "PROTOCOL.json", protocol)}
    try:
        runtime = runner.load_runtime(cfg, shape)
        torch, energy, source, fixtures, models, types, make, finite, optimizer, clip = runtime
        initial = runner.common_initialization(torch, make, cfg["seeds"][0])
        generator = torch.Generator(device="cpu").manual_seed(int(cfg["seeds"][0]))
        x = torch.randint(cfg["vocabulary"]["size"], (cfg["batch"], cfg["context"]), generator=generator)
        y = torch.randint(cfg["vocabulary"]["size"], x.shape, generator=generator)
        receipts = {"x_int64_sha256": hashlib.sha256(x.numpy().tobytes()).hexdigest(),
                    "y_int64_sha256": hashlib.sha256(y.numpy().tobytes()).hexdigest()}
        rows = []
        for arm in cfg["arms"]:
            torch.manual_seed(int(cfg["seeds"][0]))
            model = make(arm)
            model.load_state_dict(initial[arm], strict=True)
            count = sum(p.numel() for p in model.parameters())
            runner.require(count == cfg["expected_parameters"][arm], "Parameter count drift")
            opt = optimizer(model, .003)
            timings = []
            for index in range(2):
                begin = time.perf_counter()
                model.train()
                opt.zero_grad(set_to_none=True)
                logits = model(x)
                finite(logits, "budget logits")
                loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten())
                finite(loss, "budget loss")
                loss.backward()
                for name, parameter in model.named_parameters():
                    runner.require(parameter.grad is not None, "Missing gradient " + name)
                    finite(parameter.grad, "gradient " + name)
                clip(model)
                opt.step()
                for name, parameter in model.named_parameters():
                    finite(parameter, "parameter " + name)
                    for slot, tensor in opt.state[parameter].items():
                        if torch.is_tensor(tensor):
                            finite(tensor, "optimizer " + name + "/" + slot)
                timings.append(time.perf_counter() - begin)
            rows.append({"arm": arm, "parameters": count, "update_seconds": timings,
                         "median_update_seconds": statistics.median(timings),
                         "all_native_gradients_parameters_moments_finite": True})
            runner.seal_check(cfg, config, args.config_sha256, boundary)
            del model, opt, logits, loss
        estimate = sum(row["median_update_seconds"] * cfg["steps"] * len(cfg["seeds"]) * len(cfg["lrs"]) for row in rows)
        report = {"status": "passed", "protocol": protocol, "input_receipts": receipts,
                  "rows": rows, "all18_training_updates_extrapolated_seconds": estimate,
                  "estimate_excludes": ["validation", "checkpoint IO", "setup", "scheduler/load changes", "long-run thermal behavior"],
                  "process_peak_RSS_bytes_Darwin": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  "forbidden_open_attempts": blocked, "task_content_reads": 0,
                  "official_test_read": False, "cloud_resources_created": 0,
                  "runtime": {"python": sys.version, "torch": torch.__version__, "device": "cpu", "threads": torch.get_num_threads()},
                  "task_prediction_improvement_established": False, "novelty_established": False}
        runner.require(not blocked, "Forbidden open attempted")
        runner.seal_check(cfg, config, args.config_sha256, boundary)
        runner.write_json(output / "REPORT.json", report)
        print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
    except BaseException as exc:
        runner.write_json(output / "FAILURE.json", {"type": type(exc).__name__, "message": str(exc), "forbidden_open_attempts": blocked})
        raise


if __name__ == "__main__":
    main()
