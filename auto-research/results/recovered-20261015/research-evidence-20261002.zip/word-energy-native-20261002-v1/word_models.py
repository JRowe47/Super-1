"""Native tied-head word wrappers; no work occurs at import time."""


def recurrent_count(vocabulary_size, width):
    return 2 * width * width + (vocabulary_size + 8) * width


def transformer_count(vocabulary_size, context, width, feedforward):
    return vocabulary_size * width + context * width + 4 * width * width + 11 * width + (2 * width + 1) * feedforward


def match_transformer(vocabulary_size, context, target):
    # Same even-width growth / nearest nominal FF=2d, then closest FF rule.
    upper = 8
    while transformer_count(vocabulary_size, context, upper, 2 * upper) < target:
        upper *= 2
    width = min(range(2, upper + 1, 2),
                key=lambda d: (abs(transformer_count(vocabulary_size, context, d, 2 * d) - target), d))
    feedforward = min(range(width, 4 * width + 1),
                      key=lambda f: (abs(transformer_count(vocabulary_size, context, width, f) - target), f))
    return width, feedforward


def build_types(torch, energy, source, shape_source):
    nn = torch.nn
    namespace = {"nn": nn, "torch": torch, "source": source}
    exec(compile(shape_source, "<sealed-907-byte-ShapeQueryLM>", "exec"), namespace)
    ShapeQueryLM = namespace["ShapeQueryLM"]

    class StatefulWordMixin:
        def replace_vocabulary(self, vocabulary_size):
            if vocabulary_size != self.embedding.num_embeddings:
                self.embedding = nn.Embedding(vocabulary_size, self.d)
                nn.init.normal_(self.embedding.weight, std=.02)

        def forward(self, tokens, state=None, return_state=False):
            if tokens.ndim != 2 or tokens.shape[1] < 1:
                raise ValueError("tokens must be nonempty batch by time")
            embedded = self.embedding(tokens)
            drive = torch.tanh(self.drive(embedded))
            retention = torch.sigmoid(self.write(embedded) + self.retention)
            if state is None:
                state = embedded.new_zeros((len(tokens), self.d))
            elif state.shape != (len(tokens), self.d) or state.dtype != embedded.dtype or state.device != embedded.device:
                raise ValueError("carry state shape/dtype/device mismatch")
            history = []
            for step in range(tokens.shape[1]):
                theta = self.angle_for(state, drive[:, step], self.angle, self.gain, 0)
                transported = source.rotate(state, theta, 0)
                theta2 = self.angle_for(transported, drive[:, step], self.second_angle, self.second_gain, 1)
                transported = source.rotate(transported, theta2, 1)
                state = retention[:, step] * transported + (1 - retention[:, step]) * drive[:, step]
                history.append(state)
            logits = self.norm(torch.stack(history, 1)) @ self.embedding.weight.T
            return (logits, state) if return_state else logits

    class WordEnergyLM(StatefulWordMixin, energy.PairEnergyPhaseLM):
        def __init__(self, vocabulary_size, width):
            super().__init__(width, True)
            self.replace_vocabulary(vocabulary_size)

    class WordShapeLM(StatefulWordMixin, ShapeQueryLM):
        def __init__(self, vocabulary_size, width):
            super().__init__(width, True)
            self.replace_vocabulary(vocabulary_size)

    class WordTransformerLM(nn.Module):
        def __init__(self, vocabulary_size, width, feedforward, context):
            super().__init__()
            self.embedding = nn.Embedding(vocabulary_size, width)
            nn.init.normal_(self.embedding.weight, std=.02)
            self.position = nn.Parameter(torch.randn(context, width) * .02)
            self.block = nn.TransformerEncoderLayer(width, 2, feedforward, dropout=0.,
                                                   batch_first=True, norm_first=True)
            self.norm = nn.LayerNorm(width)

        def forward(self, tokens):
            if tokens.ndim != 2 or not 1 <= tokens.shape[1] <= len(self.position):
                raise ValueError("Transformer context outside registered limit")
            hidden = self.embedding(tokens) + self.position[:tokens.shape[1]]
            mask = torch.ones((tokens.shape[1], tokens.shape[1]), dtype=torch.bool,
                              device=tokens.device).triu(1)
            return self.norm(self.block(hidden, src_mask=mask)) @ self.embedding.weight.T

    return WordEnergyLM, WordShapeLM, WordTransformerLM, ShapeQueryLM

