"""Bounded configuration/authorization regressions; no numerical execution."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--config-sha256", required=True)
    parser.add_argument("--driver-sha256", required=True)
    args = parser.parse_args()
    project = Path(__file__).resolve().parent
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if sha(__file__) != args.driver_sha256 or sha(project / "runner.py") != "87fd0c4c2bbdb5a646adea20ce59fd7f5c1f5cad185223f7bf52f9dd362b0ee5":
        raise RuntimeError("Reviewed driver/runner source changed")
    spec = importlib.util.spec_from_file_location("word_gate_runner", project / "runner.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    cfg, config, shape = runner.preflight(args.config, args.config_sha256)
    output = runner.work_path(str(project / "gates"))
    if output.exists():
        raise RuntimeError("Gate suite already attempted; no automatic rerun")
    output.mkdir()
    protocol = {"config_sha256": args.config_sha256, "driver_sha256": args.driver_sha256,
                "scope": "Configuration and authorization gates only. Checkpoint replay/duplicate gates are source-reviewed, not fault-injected by this suite.",
                "numerical_model_calls_permitted": 0, "corpus_content_reads_permitted": 0}
    runner.write_json(output / "PROTOCOL.json", protocol)
    rows = []

    def rejected(label, call):
        try:
            call()
        except RuntimeError as error:
            rows.append({"check": label, "rejected": True, "message": str(error)})
        else:
            raise AssertionError("Gate failed open: " + label)

    try:
        runner.validate_config(cfg)
        rows.append({"check": "reviewed_template_validates", "passed": True})
        changes = [
            ("wrong_arms", ("arms",), ["pair_energy", "transformer", "odd_query_shape"]),
            ("duplicate_seeds", ("seeds",), [cfg["seeds"][0]] * 3),
            ("missing_seed", ("seeds",), cfg["seeds"][:2]),
            ("changed_lr_budget", ("lrs",), [.001]),
            ("changed_horizon", ("steps",), 23000),
            ("changed_batch", ("batch",), 1),
            ("changed_context", ("context",), 128),
            ("changed_width", ("width",), 128),
            ("changed_validation_frequency", ("validation_interval",), 500),
            ("canary_budget_expansion", ("canary_steps",), 3),
            ("vocabulary_size_changed", ("vocabulary", "size"), 256),
            ("special_ids_changed", ("vocabulary", "special_ids"), {"<eos>": 9, "<unk>": 0}),
            ("source_closure_missing", ("source_pins",), {}),
            ("code_closure_missing", ("code_pins",), {}),
            ("confirmation_selection_overlap", ("confirmation_start",), 1),
            ("carry_advantage_enabled", ("fresh_state_per_window",), False),
            ("official_test_enabled", ("official_test_read",), True),
            ("non_native_optimizer", ("adamw", "foreach"), True),
            ("test_named_as_validation", ("data", "valid", "path"), "/Volumes/SP AI 01_16/test.txt")
        ]
        for label, keys, value in changes:
            mutated = copy.deepcopy(cfg)
            cursor = mutated
            for key in keys[:-1]:
                cursor = cursor[key]
            cursor[keys[-1]] = value
            rejected(label, lambda c=mutated: runner.validate_config(c))
        rejected("external_config_seal_mismatch", lambda: runner.preflight(str(config), "0" * 64))
        wrong = dict(cfg["source_pins"]["pair_energy_phase_candidate"])
        wrong["sha256"] = "0" * 64
        rejected("dependency_seal_mismatch", lambda: runner.pin_check(wrong))
        model_calls = []

        def forbidden_runtime(*values):
            model_calls.append("load_runtime")
            raise AssertionError("Numerical runtime reached during rejected authorization")

        base_argv = [str(project / "runner.py"), "--config", str(config),
                     "--config-sha256", args.config_sha256, "--mode", "run"]
        with patch.object(runner, "load_runtime", forbidden_runtime):
            with patch.object(sys, "argv", base_argv):
                rejected("missing_root_full_run_authorization", runner.main)
            with patch.object(sys, "argv", base_argv + ["--authorize-full-run", "--registration-sha256", "0" * 64]):
                rejected("unapproved_template_cannot_train", runner.main)
        runner.require(not model_calls, "Rejected gates touched numerical runtime")
        runner.require(not Path(cfg["runtime_outputs"]["output_dir"]).exists(), "Rejected gates created training output")
        runner.require("torch" not in sys.modules, "Configuration-only tests imported torch")
        runner.seal_check(cfg, config, args.config_sha256)
        report = {"status": "passed", "checks": rows, "total_checks": len(rows),
                  "numerical_runtime_calls": len(model_calls), "task_content_reads": 0,
                  "training_launches": 0, "official_test_access": False,
                  "scope": protocol["scope"]}
        runner.write_json(output / "REPORT.json", report)
        print(json.dumps(report, sort_keys=True), flush=True)
    except BaseException as exc:
        runner.write_json(output / "FAILURE.json", {"type": type(exc).__name__, "message": str(exc), "completed_checks": rows})
        raise


if __name__ == "__main__":
    main()
