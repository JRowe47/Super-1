"""Frozen-backbone synthetic bridge. No task text/checkpoint reads."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time

import torch
import torch.nn.functional as F
from canary import GeometricHead, require, save


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main(output, archive, source):
    output = Path(output).resolve(strict=True)
    root = Path('/Volumes/SP AI 01_16/CodexWorkspaces').resolve(strict=True)
    require(root in output.parents and Path('/Volumes/SP AI 01_16').is_mount(), 'SSD required')
    archive = Path(archive).resolve(strict=True)
    source = Path(source).resolve(strict=True)
    manifest = json.loads(archive.read_text())['manifest']['files']
    names = ('pair_energy_phase_candidate.py', 'noncommuting_phase_candidate.py',
             'phase_transition_language.py', 'capacity_sweep.py', 'direct_distance.py', 'run.py')
    pins = {name: manifest['code/'+name]['sha256'] for name in names}
    for name, expected in pins.items():
        require(sha(source/name) == expected, 'Source seal mismatch: '+name)
    save(output/'BRIDGE_PROTOCOL.json', {'source_pins': pins, 'archive_receipt_sha256': sha(archive),
         'driver_sha256': sha(__file__), 'head_sha256': sha(Path(__file__).with_name('canary.py')),
         'width': 256, 'batch': 4, 'context': 128, 'seed': 174682993,
         'updates_per_arm': 2, 'corpus_reads': 0, 'checkpoint_reads': 0,
         'scope': 'Synthetic frozen random-backbone compatibility, not language accuracy'})
    sys.path.insert(0, str(source))
    energy = importlib.import_module('pair_energy_phase_candidate')
    for name in names:
        module = sys.modules[Path(name).stem]
        require(Path(module.__file__).resolve() == source/name, 'Wrong imported module')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(174682993)
    backbone = energy.PairEnergyPhaseLM(256).eval()
    for p in backbone.parameters():
        p.requires_grad_(False)
    before = {name: value.clone() for name, value in backbone.state_dict().items()}
    captured = []
    hook = backbone.norm.register_forward_hook(lambda module, inputs, result: captured.append(result))
    tokens = torch.randint(256, (4,128))
    targets = torch.randint(256, (4,128))
    with torch.no_grad():
        reference = backbone(tokens)
    hook.remove()
    require(len(captured) == 1, 'Unexpected norm hook calls')
    hidden = captured[0].detach()
    prototypes = backbone.embedding.weight.detach()
    rows = []
    for dynamic in (False, True):
        head = GeometricHead(4, dynamic, torch.float32)
        require(torch.equal(head(hidden,prototypes), reference), 'Bridge baseline differs')
        optimizer = torch.optim.AdamW(head.parameters(), lr=.001, foreach=False, fused=False)
        times = []
        for _ in range(2):
            start = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            F.cross_entropy(head(hidden,prototypes).reshape(-1,256), targets.flatten()).backward()
            require(all(p.grad is not None and torch.isfinite(p.grad).all() for p in head.parameters()), 'Head gradient invalid')
            optimizer.step()
            require(all(torch.isfinite(p).all() for p in head.parameters()), 'Head parameters invalid')
            times.append(time.perf_counter()-start)
        rows.append({'dynamic':dynamic, 'baseline_logits_exact':True,
                     'finite_native_updates':2, 'unisolated_update_seconds':times,
                     'added_parameters':sum(p.numel() for p in head.parameters())})
    require(all(torch.equal(before[name],value) for name,value in backbone.state_dict().items()), 'Backbone changed')
    require(all(p.grad is None for p in backbone.parameters()), 'Backbone gradient present')
    for name, expected in pins.items():
        require(sha(source/name) == expected, 'Source changed during probe')
    save(output/'BRIDGE_REPORT.json', {'arms':rows, 'backbone_unchanged_exact':True,
         'backbone_gradients_absent':True, 'task_accuracy_untested':True,
         'corpus_reads':0, 'checkpoint_reads':0,
         'scope':'Full byte-model shape compatibility, not a trained checkpoint result or speed benchmark'})


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--output',required=True)
    p.add_argument('--archive-receipt',required=True)
    p.add_argument('--source',required=True)
    a=p.parse_args()
    main(a.output,a.archive_receipt,a.source)
