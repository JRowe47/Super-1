"""Freeze a head-only language comparison before reading language data.

Does not train, import the backbone, or evaluate a checkpoint.
"""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(evidence, training, destination):
    evidence = Path(evidence).resolve(strict=True)
    training = Path(training).resolve(strict=True)
    destination = Path(destination).resolve(strict=True)
    workspace = Path('/Volumes/SP AI 01_16/CodexWorkspaces').resolve(strict=True)
    assert Path('/Volumes/SP AI 01_16').is_mount() and workspace in destination.parents
    result = evidence/'RESULT.json'
    assert sha(result) == '5fcb29ec7f66e4740363d93849779f943871205c07ccfe0d0b5a00e9214792c8'
    freeze = training/'FREEZE.json'
    assert sha(freeze) == '7bf5bb517bef2ebf975231885572047eb5a15db8ddd1c279dd82cca561e5b798'
    results = json.loads(result.read_text())
    frozen = json.loads(freeze.read_text())
    selected = []
    for row in frozen:
        if row['arm'] != 'pair_energy':
            continue
        verified = [r for r in results if r['arm'] == row['arm'] and r['seed'] == row['seed']]
        assert len(verified) == 1 and verified[0]['sha256'] == row['sha256'] and verified[0]['duplicate_drift'] == 0
        path = training/Path(row['checkpoint']).name
        assert path.resolve(strict=True).parent == training and sha(path) == row['sha256']
        selected.append({'seed': row['seed'], 'checkpoint': str(path), 'sha256': row['sha256'],
                         'source_selection_best_step': row['best_step']})
    assert len(selected) == 3 and {r['seed'] for r in selected} == {3361,3407,3457}
    protocol = {
        'hypothesis': 'A jointly context/prototype-conditioned rotation improves frozen-backbone byte CE beyond an equal-parameter static linear adaptation.',
        'backbones': sorted(selected,key=lambda r:r['seed']),
        'source_result_sha256':sha(result),'source_freeze_sha256':sha(freeze),
        'head_source': str(destination/'canary.py'), 'head_source_sha256':sha(destination/'canary.py'),
        'registration_driver_sha256':sha(Path(__file__)),
        'scope': 'Local head-only byte pilot; not original hierarchy, word perplexity, globally pristine validation, matched FLOPs, novelty or SOTA.',
        'arms':['unchanged_frozen_baseline','static_geometric_head','dynamic_geometric_head'],
        'planes':4,'plane_indices':[0,1,2,3],'added_parameters_per_adapted_arm':8,
        'backbone_parameters_frozen':True,'embedding_frozen':True,
        'dtype':'FP32','device':'cpu','threads':1,'batch':4,'context':128,
        'lrs':[.001,.003],'steps':500,'selection_interval':100,
        'optimizer':{'name':'native_AdamW','betas':[.9,.999],'eps':1e-8,'weight_decay':.01,'foreach':False,'fused':False,'clip':1.0},
        'train_windows':'Same random with-replacement byte windows per source seed across arms and LRs, seed+10000; frozen hidden states may be cached on SSD.',
        'target_exposures_per_trial':256000,
        'selection':{'start':0,'windows':128,'target_region_inclusive':[1,16384]},
        'confirmation':{'start':700000,'windows':256,'target_region_inclusive':[700001,732768],
                        'passes':2,'duplicate_drift_required':0},
        'selection_rule':'All12 adapted trials complete. Freeze six winners by selection CE, then step, then LR. Include all three unchanged backbones. Strictly verify and selection-replay every frozen head before any confirmation.',
        'advance_gate':'Duplicate exact FP32 metrics/logit hashes for all9. Dynamic CE strictly below static and unchanged baseline in every source seed; a favorable mean alone fails.',
        'validation_region_caveat':'Disjoint selection/confirmation within this probe. The valid file was read in prior experiments; no globally untouched holdout claim.',
        'train_data':{'path':'/Volumes/SP AI 01_16/w560-function-weight-wt2-word-sota-20260828/data/wikitext-2/train.txt',
                      'sha256':'71220dd7735e8715884cf57d21fa6306ebc3249c0979f51c1fb22314e0842298'},
        'valid_data':{'path':'/Volumes/SP AI 01_16/w560-function-weight-wt2-word-sota-20260828/data/wikitext-2/valid.txt',
                      'sha256':'1bd7ccbea6740d1f3837c268e41cd6c983e2e1d2673843b3d2c641f412c640b7'},
        'official_test_reads':0,'cloud_resources':0,'training_launched':False,
        'implementation_required_before_launch':['Strict source/runtime closure','Frozen checkpoint native validation and capture parity',
                                               'Canonical selection and duplicate fault tests','Exclusive output and immutable protocol check']}
    with (destination/'LANGUAGE_PREREGISTRATION.json').open('x') as stream:
        json.dump(protocol,stream,indent=2,sort_keys=True,allow_nan=False)
        stream.write('\n')
    print(json.dumps({'registered':True,'checkpoint_file_hashes_verified':3,'task_text_reads':0,
                      'training_launched':False,'protocol_sha256':sha(destination/'LANGUAGE_PREREGISTRATION.json')}))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--evidence',required=True)
    p.add_argument('--training',required=True)
    p.add_argument('--destination',required=True)
    a=p.parse_args()
    main(a.evidence,a.training,a.destination)
