"""Independent artifact audit, without model evaluation or task-text reads."""
import hashlib
import json
import math
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root=Path(__file__).resolve().parent
    output=root/'language-run'
    terminal=output/'COMPLETION.json'
    if not terminal.exists():
        print(json.dumps({'terminal':False,'failure_preserved':(output/'FAILURE.json').exists()}))
        return
    protocol=root/'LANGUAGE_PREREGISTRATION.json'
    assert sha(protocol)=='b7b00f6660df570ed51bafc9e45feb97a9c48af7bb401b602c8c04837fd7c6eb'
    c=json.loads(protocol.read_text())
    end=json.loads(terminal.read_text())
    assert sha(output/'FREEZE.json')==end['freeze_sha256']
    assert sha(output/'CONFIRMATION.json')==end['confirmation_sha256']
    rows=json.loads((output/'CANDIDATES.json').read_text())
    seeds={r['seed'] for r in c['backbones']}
    arms={'static_geometric_head','dynamic_geometric_head'}
    slots={(r['seed'],r['arm'],r['lr']) for r in rows}
    assert len(rows)==12 and slots=={(s,a,l) for s in seeds for a in arms for l in c['lrs']}
    assert all(r['completed_steps']==c['steps'] for r in rows)
    for seed in seeds:
        assert len({r['window_sha256'] for r in rows if r['seed']==seed})==1
    frozen=json.loads((output/'FREEZE.json').read_text())
    assert len(frozen)==9 and {(r['seed'],r['arm']) for r in frozen}=={(s,a) for s in seeds for a in c['arms']}
    for row in rows+frozen:
        path=Path(row['checkpoint']).resolve(strict=True)
        assert path.parent==output and sha(path)==row['sha256']
        assert math.isfinite(row['selection']['ce'])
    for row in frozen:
        if row['arm'] in arms:
            candidates=[r for r in rows if r['seed']==row['seed'] and r['arm']==row['arm']]
            chosen=min(candidates,key=lambda r:(r['selection']['ce'],r['step'],r['lr']))
            assert all(row[k]==chosen[k] for k in ('seed','arm','lr','step','selection','window_sha256'))
    scores=json.loads((output/'CONFIRMATION.json').read_text())
    assert len(scores)==9 and {(r['seed'],r['arm']) for r in scores}=={(s,a) for s in seeds for a in c['arms']}
    for row in scores:
        assert row['first']==row['second'] and row['duplicate_drift']==0
        assert math.isfinite(row['first']['ce']) and row['first']['targets']==32768
    report=[]
    for seed in sorted(seeds):
        ce={r['arm']:r['first']['ce'] for r in scores if r['seed']==seed}
        dynamic=ce['dynamic_geometric_head']
        report.append({'seed':seed,'ce':ce,
                       'dynamic_minus_static':dynamic-ce['static_geometric_head'],
                       'dynamic_minus_baseline':dynamic-ce['unchanged_frozen_baseline'],
                       'passed':dynamic<min(ce['static_geometric_head'],ce['unchanged_frozen_baseline'])})
    passed=all(r['passed'] for r in report)
    assert passed==end['advance_gate_passed'] and end['all9_duplicate_exact'] is True
    result={'terminal':True,'all12_completed':True,'canonical_selection_verified':True,
            'all9_duplicate_exact':True,'paired':report,'advance_gate_passed':passed,
            'terminal_sha256':sha(terminal),'task_text_reads':0,'new_model_evaluations':0,
            'limitations':c['scope'],'globally_pristine_holdout':False}
    with (root/'INDEPENDENT_LANGUAGE_AUDIT.json').open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False,sort_keys=True)
        stream.write('\n')
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__': main()
