"""Synthetic fault tests. No task text or checkpoint reads."""
import copy
from pathlib import Path
import torch
from canary import GeometricHead, save
from language_probe import duplicate, state_check, winner


def rejected(call):
    try:
        call()
    except RuntimeError:
        return True
    raise RuntimeError('Invalid evidence was accepted')


def main():
    tests=[]
    rows=[{'lr':.001,'step':100,'selection':{'ce':2.}},
          {'lr':.003,'step':200,'selection':{'ce':1.9}}]
    assert winner(rows)==rows[1]
    tests.append('canonical_minimum')
    assert rejected(lambda:winner(rows[:1])); tests.append('missing_trial_rejected')
    bad=copy.deepcopy(rows); bad[1]['lr']=bad[0]['lr']
    assert rejected(lambda:winner(bad)); tests.append('duplicate_lr_rejected')
    bad=copy.deepcopy(rows); bad[1]['selection']['ce']=float('nan')
    assert rejected(lambda:winner(bad)); tests.append('nonfinite_selection_rejected')
    tied=copy.deepcopy(rows); tied[1]['selection']['ce']=2.
    assert winner(tied)==tied[0]; tests.append('earlier_step_tie_break')
    first={'ce':1.5,'logits_sha256':'first'}
    duplicate(first,dict(first)); tests.append('exact_duplicate_accepted')
    assert rejected(lambda:duplicate(first,{'ce':1.5,'logits_sha256':'changed'}))
    tests.append('equal_ce_changed_logits_rejected')
    head=GeometricHead(4,True,torch.float32)
    state_check(head.state_dict(),head); tests.append('valid_state_accepted')
    bad=copy.deepcopy(head.state_dict()); bad.pop('gain')
    assert rejected(lambda:state_check(bad,head)); tests.append('missing_state_key_rejected')
    bad=copy.deepcopy(head.state_dict()); bad['gain']=bad['gain'].double()
    assert rejected(lambda:state_check(bad,head)); tests.append('nonfp32_state_rejected')
    bad=copy.deepcopy(head.state_dict()); bad['gain']=torch.zeros(5)
    assert rejected(lambda:state_check(bad,head)); tests.append('state_shape_rejected')
    bad=copy.deepcopy(head.state_dict()); bad['gain'][0]=float('inf')
    assert rejected(lambda:state_check(bad,head)); tests.append('nonfinite_state_rejected')
    save(Path(__file__).with_name('PROBE_GATE_TESTS.json'),{'passed':tests,'task_text_reads':0,
         'checkpoint_reads':0,'training_updates':0,
         'scope':'Unit faults for winner/duplicate/state gates only; not end-to-end training verification'})
    print({'passed':len(tests)})


if __name__=='__main__': main()
