"""Synthetic structural test only; no corpus or checkpoint access.

The dynamic head rotates each vocabulary prototype conditionally on the
current hidden vector. The matched static head has the same trainable count,
but stays linear in the hidden vector. Neither creates independent free data.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import torch
from torch import nn
import torch.nn.functional as F


class GeometricHead(nn.Module):
    def __init__(self, planes, dynamic, dtype):
        super().__init__()
        self.angle = nn.Parameter(torch.zeros(planes, dtype=dtype))
        self.gain = nn.Parameter(torch.zeros(planes, dtype=dtype))
        self.dynamic = dynamic

    def forward(self, hidden, prototypes):
        logits = hidden @ prototypes.T
        for j in range(len(self.angle)):
            h = hidden[..., 2*j:2*j+2]
            e = prototypes[:, 2*j:2*j+2]
            dot = h[..., 0, None]*e[:, 0] + h[..., 1, None]*e[:, 1]
            cross = h[..., 0, None]*e[:, 1] - h[..., 1, None]*e[:, 0]
            if self.dynamic:
                denominator = torch.sqrt(h.square().sum(-1, keepdim=True)
                                         * e.square().sum(-1) + 1e-12)
                query = cross / denominator
                theta = self.angle[j] + self.gain[j]*torch.tanh(query)
                logits = logits + (torch.cos(theta)-1)*dot + torch.sin(theta)*cross
            else:
                theta = self.angle[j]
                logits = logits + (torch.cos(theta)-1)*dot + torch.sin(theta)*cross + self.gain[j]*dot
        return logits


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def run(output, seed):
    output = Path(output).resolve(strict=True)
    workspace = Path("/Volumes/SP AI 01_16/CodexWorkspaces").resolve(strict=True)
    require(workspace in output.parents, "Output must be on the mounted SSD workspace")
    require(Path("/Volumes/SP AI 01_16").is_mount(), "SSD unavailable")
    source_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    save(output / "PROTOCOL.json", {"source_sha256": source_sha, "seed": seed,
         "scope": "Synthetic feasibility, not language accuracy, novelty or SOTA",
         "width": 8, "vocabulary": 24, "planes": 4,
         "equal_added_parameters": 8, "updates_per_arm": 10,
         "corpus_reads": 0, "checkpoint_reads": 0, "official_test_reads": 0})
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(seed)
    checks = []
    for dtype in (torch.float64, torch.float32):
        h = torch.randn(32, 8, dtype=dtype, requires_grad=True)
        e = torch.randn(24, 8, dtype=dtype, requires_grad=True)
        probe = torch.randn(32, 24, dtype=dtype)
        base = h @ e.T
        base_grad = torch.autograd.grad((base*probe).sum(), (h, e))
        for dynamic in (False, True):
            model = GeometricHead(4, dynamic, dtype)
            logits = model(h, e)
            grads = torch.autograd.grad((logits*probe).sum(), (h, e, *model.parameters()))
            require(torch.equal(logits, base), "Identity logits differ")
            require(all(torch.equal(a,b) for a,b in zip(base_grad, grads[:2])), "Identity input gradient differs")
            require(all(torch.isfinite(g).all() for g in grads), "Nonfinite identity gradient")
            with torch.no_grad():
                model.angle.copy_(torch.randn(4, dtype=dtype)*.2)
                model.gain.copy_(torch.randn(4, dtype=dtype)*.4)
            isolated = h.detach().clone()
            isolated[1:] *= 7
            alone = model(isolated, e)[:1]
            batched = model(h, e)[:1]
            require(torch.equal(alone, batched), "Sample isolation failed")
            edge = model(torch.zeros_like(h), torch.zeros_like(e))
            require(torch.isfinite(edge).all(), "Zero norm edge failed")
            require(sum(p.numel() for p in model.parameters()) == 8, "Count mismatch")
            checks.append({"dtype": str(dtype), "dynamic": dynamic,
                           "identity_logits_exact": True, "identity_input_gradients_exact": True,
                           "sample_isolation_exact": True, "zero_norm_finite": True})
    # Rank probes use FP64 and fixed nonzero parameters, not selected task scores.
    h = torch.randn(32, 8, dtype=torch.float64)
    e = torch.randn(24, 8, dtype=torch.float64)
    ranks = {}
    for dynamic in (False, True):
        model = GeometricHead(4, dynamic, torch.float64)
        with torch.no_grad():
            model.angle.fill_(.2)
            model.gain.fill_(.7)
        rank = int(torch.linalg.matrix_rank(model(h,e), atol=1e-9, rtol=0))
        ranks[str(dynamic)] = rank
        require(rank > 8 if dynamic else rank <= 8, "Expected structural rank distinction absent")
    updates = []
    h = torch.randn(32, 8)
    e = torch.randn(24, 8)
    targets = torch.randint(24, (32,))
    for dynamic in (False, True):
        model = GeometricHead(4, dynamic, torch.float32)
        optimizer = torch.optim.AdamW(model.parameters(), lr=.001, foreach=False, fused=False)
        for step in range(10):
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(h,e), targets)
            loss.backward()
            require(all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters()), "Bad training gradient")
            optimizer.step()
            require(all(torch.isfinite(p).all() for p in model.parameters()), "Bad updated parameter")
        updates.append({"dynamic": dynamic, "updates": 10, "all_finite": True})
    save(output / "REPORT.json", {"source_sha256": source_sha, "checks": checks,
         "numerical_rank_probe": ranks, "native_adamw_smokes": updates,
         "added_FP32_parameter_bytes": 32,
         "latency_and_full_model_memory_unmeasured": True,
         "task_accuracy_untested": True, "novelty_unproven": True,
         "elapsed_unix_seconds": time.time()})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", required=True, type=int)
    args = parser.parse_args()
    run(args.output, args.seed)
