"""Sealed head-only byte comparison; no official-test access or resume."""
import argparse
import copy
import hashlib
import importlib
import json
import math
from pathlib import Path
import random
import sys
import traceback

import torch
import torch.nn.functional as F
from canary import GeometricHead, require, save


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def state_check(state, model):
    template = model.state_dict()
    require(set(state) == set(template), 'State keys differ')
    require(all(isinstance(v,torch.Tensor) and v.device.type == 'cpu'
                and v.dtype == torch.float32 and v.shape == template[k].shape
                and torch.isfinite(v).all() for k,v in state.items()), 'Invalid state tensor')
    model.load_state_dict(state, strict=True)


def winner(rows):
    require(len(rows) == 2 and len({r['lr'] for r in rows}) == 2, 'Missing LR trials')
    require(all(math.isfinite(r['selection']['ce']) for r in rows), 'Nonfinite selection')
    return min(rows,key=lambda r:(r['selection']['ce'],r['step'],r['lr']))


def duplicate(first, second):
    require(first == second and math.isfinite(first['ce']), 'Duplicate drift/nonfinite CE')


def features(backbone, data, starts, context, batch):
    hidden, targets = [], []
    for offset in range(0,len(starts),batch):
        indices=starts[offset:offset+batch]
        x=torch.stack([data[i:i+context] for i in indices])
        y=torch.stack([data[i+1:i+context+1] for i in indices])
        captured=[]
        hook=backbone.norm.register_forward_hook(lambda m,a,r:captured.append(r))
        try:
            with torch.no_grad():
                logits=backbone(x)
        finally:
            hook.remove()
        require(len(captured)==1 and torch.equal(captured[0]@backbone.embedding.weight.T,logits), 'Capture parity failed')
        hidden.append(captured[0].detach()); targets.append(y)
    return torch.cat(hidden),torch.cat(targets)


def evaluate(head, hidden, targets, prototypes, batch):
    total=0.; count=0; fingerprint=hashlib.sha256(); losses=[]
    with torch.no_grad():
        for i in range(0,len(hidden),batch):
            logits=head(hidden[i:i+batch],prototypes)
            loss=F.cross_entropy(logits.reshape(-1,256),targets[i:i+batch].flatten(),reduction='sum').item()
            require(math.isfinite(loss) and torch.isfinite(logits).all(), 'Nonfinite evaluation')
            total+=loss; count+=targets[i:i+batch].numel(); losses.append(loss)
            fingerprint.update(logits.contiguous().numpy().tobytes())
    return {'ce':total/count,'targets':count,'batch_loss_sums':losses,'logits_sha256':fingerprint.hexdigest()}


def run(args):
    root=Path(args.protocol).resolve(strict=True).parent
    workspace=Path('/Volumes/SP AI 01_16/CodexWorkspaces').resolve(strict=True)
    require(Path('/Volumes/SP AI 01_16').is_mount() and workspace in root.parents,'SSD required')
    require(sha(args.protocol)==args.protocol_sha256 and sha(__file__)==args.driver_sha256,'Protocol/driver seal changed')
    c=json.loads(Path(args.protocol).read_text())
    require(sha(c['head_source'])==c['head_source_sha256'],'Head changed')
    require(sha(args.archive)==args.archive_sha256,'Archive changed')
    manifest=json.loads(Path(args.archive).read_text())['manifest']['files']
    source=Path(args.source).resolve(strict=True)
    names=('pair_energy_phase_candidate.py','noncommuting_phase_candidate.py','phase_transition_language.py',
           'capacity_sweep.py','direct_distance.py','run.py')
    pins={name:manifest['code/'+name]['sha256'] for name in names}
    def seals():
        require(sha(args.protocol)==args.protocol_sha256 and sha(__file__)==args.driver_sha256
                and sha(c['head_source'])==c['head_source_sha256'],'Experiment source changed')
        for name,expected in pins.items():
            require(sha(source/name)==expected,'Backbone source changed')
        for row in c['backbones']:
            require(sha(row['checkpoint'])==row['sha256'],'Frozen backbone changed')
    seals()
    require(args.authorize_training,'Explicit training authorization required')
    output=root/'language-run'
    output.mkdir(exist_ok=False)
    save(output/'EXECUTION.json',{'protocol_sha256':args.protocol_sha256,'driver_sha256':args.driver_sha256,
         'source_pins':pins,'archive_sha256':args.archive_sha256,'official_test_reads':0,
         'storage_policy':'All generated output is on mounted SSD; no iCloud fallback.',
         'runtime':{'python':sys.version,'torch':torch.__version__,'device':'cpu','dtype':'FP32'}})
    try:
        sys.path.insert(0,str(source))
        module=importlib.import_module('pair_energy_phase_candidate')
        require(all(Path(sys.modules[Path(n).stem].__file__).resolve()==source/n for n in names),'Wrong module closure')
        torch.set_num_threads(c['threads']); torch.set_num_interop_threads(1)
        torch.use_deterministic_algorithms(True)
        models={}
        for row in c['backbones']:
            model=module.PairEnergyPhaseLM(256).eval()
            state=torch.load(row['checkpoint'],map_location='cpu',weights_only=True)
            state_check(state,model)
            for p in model.parameters(): p.requires_grad_(False)
            models[row['seed']]=model
        # Only explicitly named train/valid are read. No stock Corpus loader.
        data={}; receipts={}
        for split in ('train','valid'):
            spec=c[split+'_data']; raw=Path(spec['path']).read_bytes()
            require(hashlib.sha256(raw).hexdigest()==spec['sha256'],'Data seal mismatch')
            data[split]=torch.tensor(list(raw),dtype=torch.long)
            receipts[split]={'sha256':spec['sha256'],'bytes':len(raw)}
            del raw
        save(output/'DATA_RECEIPTS.json',receipts)
        require(c['confirmation']['start']+c['confirmation']['windows']*c['context']+1<=len(data['valid']),'Confirmation bounds')
        rows=[]; frozen=[]; selection_cache={}
        for row in c['backbones']:
            seed=row['seed']; model=models[seed]; prototypes=model.embedding.weight.detach()
            rng=random.Random(seed+10000)
            starts=[rng.randrange(len(data['train'])-c['context']) for _ in range(c['steps']*c['batch'])]
            stream_sha=hashlib.sha256(json.dumps(starts).encode()).hexdigest()
            train_h,train_y=features(model,data['train'],starts,c['context'],c['batch'])
            s=c['selection']; starts=[s['start']+i*c['context'] for i in range(s['windows'])]
            select_h,select_y=features(model,data['valid'],starts,c['context'],c['batch'])
            selection_cache[seed]=(select_h,select_y)
            baseline=GeometricHead(c['planes'],False,torch.float32)
            frozen.append({'seed':seed,'arm':'unchanged_frozen_baseline','lr':None,'step':0,
                           'selection':evaluate(baseline,select_h,select_y,prototypes,c['batch']),
                           'state':copy.deepcopy(baseline.state_dict())})
            for arm,dynamic in [('static_geometric_head',False),('dynamic_geometric_head',True)]:
                options=[]
                for lr in c['lrs']:
                    head=GeometricHead(c['planes'],dynamic,torch.float32)
                    o=c['optimizer']
                    optimizer=torch.optim.AdamW(head.parameters(),lr=lr,betas=tuple(o['betas']),eps=o['eps'],
                                                weight_decay=o['weight_decay'],foreach=o['foreach'],fused=o['fused'])
                    best=None
                    for step in range(1,c['steps']+1):
                        i=(step-1)*c['batch']; optimizer.zero_grad(set_to_none=True)
                        loss=F.cross_entropy(head(train_h[i:i+c['batch']],prototypes).reshape(-1,256),train_y[i:i+c['batch']].flatten())
                        loss.backward()
                        require(torch.isfinite(loss) and all(p.grad is not None and torch.isfinite(p.grad).all() for p in head.parameters()),'Nonfinite update')
                        torch.nn.utils.clip_grad_norm_(head.parameters(),o['clip'],foreach=False); optimizer.step()
                        if step%c['selection_interval']==0:
                            score=evaluate(head,select_h,select_y,prototypes,c['batch'])
                            candidate={'seed':seed,'arm':arm,'lr':lr,'step':step,'selection':score,
                                       'state':copy.deepcopy(head.state_dict()),'completed_steps':c['steps'],'window_sha256':stream_sha}
                            if best is None or (score['ce'],step)<(best['selection']['ce'],best['step']): best=candidate
                    options.append(best)
                    print(json.dumps({'event':'trial_completed','seed':seed,'arm':arm,'lr':lr,'steps':c['steps']}),flush=True)
                rows.extend(options); frozen.append(winner(options))
            del train_h,train_y
        require(len(rows)==12 and len(frozen)==9,'Incomplete search')
        # Persist every candidate, then all nine selection-only winners.
        for index,row in enumerate(rows):
            path=output/('candidate-%02d.pt'%index)
            torch.save(row['state'],path); row['checkpoint']=str(path); row['sha256']=sha(path)
        freeze=[]
        for index,row in enumerate(frozen):
            path=output/('frozen-%02d.pt'%index)
            torch.save(row['state'],path)
            freeze.append({k:v for k,v in row.items() if k!='state'} | {'checkpoint':str(path),'sha256':sha(path)})
        save(output/'CANDIDATES.json',[{k:v for k,v in r.items() if k!='state'} for r in rows])
        save(output/'FREEZE.json',freeze)
        for row in freeze:
            head=GeometricHead(c['planes'],row['arm']=='dynamic_geometric_head',torch.float32)
            require(sha(row['checkpoint'])==row['sha256'],'Head checkpoint changed')
            state_check(torch.load(row['checkpoint'],map_location='cpu',weights_only=True),head)
            h,y=selection_cache[row['seed']]
            require(evaluate(head,h,y,models[row['seed']].embedding.weight.detach(),c['batch'])==row['selection'],'Selection replay drift')
        seals()
        save(output/'SELECTED_VERIFICATION.json',{'all9_exact_before_confirmation':True,'freeze_sha256':sha(output/'FREEZE.json')})
        scores=[]
        for seed,model in models.items():
            s=c['confirmation']; starts=[s['start']+i*c['context'] for i in range(s['windows'])]
            h,y=features(model,data['valid'],starts,c['context'],c['batch'])
            for row in [r for r in freeze if r['seed']==seed]:
                require(sha(row['checkpoint'])==row['sha256'],'Head changed before confirmation')
                head=GeometricHead(c['planes'],row['arm']=='dynamic_geometric_head',torch.float32)
                state_check(torch.load(row['checkpoint'],map_location='cpu',weights_only=True),head)
                first=evaluate(head,h,y,model.embedding.weight.detach(),c['batch'])
                second=evaluate(head,h,y,model.embedding.weight.detach(),c['batch'])
                duplicate(first,second)
                scores.append({'seed':seed,'arm':row['arm'],'first':first,'second':second,'duplicate_drift':0})
        seals()
        paired=[]
        for seed in models:
            ce={r['arm']:r['first']['ce'] for r in scores if r['seed']==seed}
            paired.append({'seed':seed,'ce':ce,'passed':ce['dynamic_geometric_head']<min(ce['static_geometric_head'],ce['unchanged_frozen_baseline'])})
        save(output/'CONFIRMATION.json',scores)
        save(output/'COMPLETION.json',{'all9_duplicate_exact':True,'paired':paired,'advance_gate_passed':all(r['passed'] for r in paired),
             'official_test_reads':0,'scope':c['scope'],'freeze_sha256':sha(output/'FREEZE.json'),
             'confirmation_sha256':sha(output/'CONFIRMATION.json')})
    except BaseException:
        save(output/'FAILURE.json',{'traceback':traceback.format_exc(),'no_automatic_resume':True})
        raise


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('protocol','protocol-sha256','driver-sha256','archive','archive-sha256','source'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--authorize-training',action='store_true')
    run(p.parse_args())
