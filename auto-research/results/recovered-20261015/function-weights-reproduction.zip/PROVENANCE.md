# Provenance

The predictive-state and distribution-compilation sources were copied from the
active Function Weights workspace on 7 August 2026. The completed-result lane
retains the original manifest and training logic.

The following additions implement the new combined experiment:

- `FunctionalLowRankAffine`
- `FunctionWeightedGRUCell`
- `HierarchicalFunctionWeightsStudent`
- auxiliary routing-balance integration in distribution distillation
- the hierarchical function-weights manifest
- the manifest-driven launcher and matched summary gates
- package-specific verification and smoke tests

The completed metrics in `evidence/reported_result_snapshot.json` were
transcribed from the verified research report. Raw checkpoints, baked shards,
and cloud result directories are not included, so downstream users must run the
original manifest to independently reproduce those numbers.
