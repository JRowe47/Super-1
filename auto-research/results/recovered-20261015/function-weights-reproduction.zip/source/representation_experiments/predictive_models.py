"""Equal-storage students for predictive-state compilation."""
from __future__ import annotations

import math
from dataclasses import dataclass
from types import SimpleNamespace

import torch
import torch.nn as nn
import torch.nn.functional as F

from representation_experiments.common import parameter_count


class StudentBase(nn.Module):
    def __init__(self, vocab_size: int, width: int, max_context: int):
        super().__init__()
        self.vocab_size = int(vocab_size)
        self.width = int(width)
        self.max_context = int(max_context)
        self.embedding = nn.Embedding(vocab_size, width)
        nn.init.normal_(self.embedding.weight, mean=0.0, std=width ** -0.5)
        self.final_norm = nn.LayerNorm(width)

    def logits(self, hidden: torch.Tensor) -> torch.Tensor:
        return F.linear(self.final_norm(hidden), self.embedding.weight)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        raise NotImplementedError


class TransformerStudent(StudentBase):
    kind = "transformer"

    def __init__(self, vocab_size: int, width: int, max_context: int,
                 layers: int, heads: int, expansion: int = 4):
        super().__init__(vocab_size, width, max_context)
        if width % heads:
            raise ValueError("transformer width must divide evenly into heads")
        self.layers = int(layers)
        self.heads = int(heads)
        self.position = nn.Embedding(max_context, width)
        block = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=expansion * width,
            activation="gelu", batch_first=True, norm_first=True)
        self.blocks = nn.TransformerEncoder(block, num_layers=layers)

    def forward(self, input_ids: torch.Tensor):
        length = input_ids.shape[1]
        if length > self.max_context:
            input_ids = input_ids[:, -self.max_context:]
            length = self.max_context
        positions = torch.arange(length, device=input_ids.device)
        hidden = self.embedding(input_ids) + self.position(positions).unsqueeze(0)
        mask = torch.ones(length, length, device=input_ids.device, dtype=torch.bool).triu(1)
        hidden = self.blocks(hidden, mask=mask, is_causal=True)
        return SimpleNamespace(logits=self.logits(hidden), hidden_states=hidden)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        # Standard autoregressive KV cache, two tensors per layer.
        return 2 * batch_size * min(context, self.max_context) * self.width * self.layers


class RecurrentLogitStudent(StudentBase):
    kind = "recurrent_logits"

    def __init__(self, vocab_size: int, width: int, max_context: int, layers: int):
        super().__init__(vocab_size, width, max_context)
        self.layers = int(layers)
        self.cells = nn.ModuleList([
            nn.GRUCell(width, width) for _ in range(layers)
        ])

    def initial_state(self, batch_size: int, device: torch.device,
                      dtype: torch.dtype | None = None):
        dtype = dtype or self.embedding.weight.dtype
        return [torch.zeros(batch_size, self.width, device=device, dtype=dtype)
                for _ in range(self.layers)]

    def step(self, token_ids: torch.Tensor, state=None):
        if state is None:
            state = self.initial_state(token_ids.shape[0], token_ids.device)
        hidden = self.embedding(token_ids)
        new_state = []
        for cell, previous in zip(self.cells, state):
            hidden = cell(hidden, previous)
            new_state.append(hidden)
        return self.logits(hidden), new_state, hidden

    def forward(self, input_ids: torch.Tensor):
        state = None
        hidden_values = []
        logits = []
        for index in range(input_ids.shape[1]):
            token_logits, state, hidden = self.step(input_ids[:, index], state)
            logits.append(token_logits)
            hidden_values.append(hidden)
        return SimpleNamespace(
            logits=torch.stack(logits, dim=1),
            hidden_states=torch.stack(hidden_values, dim=1),
            final_state=state)

    def last_logits(self, input_ids: torch.Tensor):
        state = None
        token_logits = None
        for index in range(input_ids.shape[1]):
            token_logits, state, _ = self.step(input_ids[:, index], state)
        if token_logits is None:
            raise ValueError("last_logits requires at least one input token")
        return token_logits.unsqueeze(1)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        del context
        return batch_size * self.width * self.layers


class HierarchicalPredictiveStudent(StudentBase):
    kind = "hierarchical_predictive"

    def __init__(self, vocab_size: int, width: int, max_context: int,
                 atoms: int, segment_length: int, document_segments: int,
                 future_horizons: list[int]):
        super().__init__(vocab_size, width, max_context)
        self.atoms = int(atoms)
        self.segment_length = int(segment_length)
        self.document_segments = int(document_segments)
        self.future_horizons = tuple(int(value) for value in future_horizons)
        self.fast_cell = nn.GRUCell(3 * width, width)
        self.segment_cell = nn.GRUCell(width, width)
        self.document_cell = nn.GRUCell(width, width)
        self.combine = nn.Sequential(
            nn.Linear(3 * width, 2 * width), nn.SiLU(), nn.Linear(2 * width, width))
        self.atom_head = nn.Linear(width, atoms)
        self.future_heads = nn.ModuleList([
            nn.Linear(width, atoms) for _ in self.future_horizons
        ])

    def initial_state(self, batch_size: int, device: torch.device,
                      dtype: torch.dtype | None = None):
        dtype = dtype or self.embedding.weight.dtype
        zero = lambda: torch.zeros(batch_size, self.width, device=device, dtype=dtype)
        return {
            "fast": zero(), "segment": zero(), "document": zero(),
            "segment_sum": zero(), "segment_tokens": 0, "segments": 0,
        }

    def step(self, token_ids: torch.Tensor, state=None):
        if state is None:
            state = self.initial_state(token_ids.shape[0], token_ids.device)
        token = self.embedding(token_ids)
        fast_input = torch.cat((token, state["segment"], state["document"]), dim=-1)
        fast = self.fast_cell(fast_input, state["fast"])
        segment_sum = state["segment_sum"] + fast
        segment_tokens = int(state["segment_tokens"]) + 1
        segment = state["segment"]
        document = state["document"]
        segments = int(state["segments"])
        if segment_tokens == self.segment_length:
            segment = self.segment_cell(segment_sum / segment_tokens, segment)
            segment_sum = torch.zeros_like(segment_sum)
            segment_tokens = 0
            segments += 1
            if segments == self.document_segments:
                document = self.document_cell(segment, document)
                segments = 0
        combined = self.combine(torch.cat((fast, segment, document), dim=-1))
        new_state = {
            "fast": fast, "segment": segment, "document": document,
            "segment_sum": segment_sum, "segment_tokens": segment_tokens,
            "segments": segments,
        }
        return {
            "logits": self.logits(combined),
            "atom_logits": self.atom_head(combined),
            "future_atom_logits": [head(combined) for head in self.future_heads],
            "hidden": combined,
        }, new_state

    def forward(self, input_ids: torch.Tensor):
        state = None
        records = []
        for index in range(input_ids.shape[1]):
            record, state = self.step(input_ids[:, index], state)
            records.append(record)
        return SimpleNamespace(
            logits=torch.stack([item["logits"] for item in records], dim=1),
            atom_logits=torch.stack([item["atom_logits"] for item in records], dim=1),
            future_atom_logits=[
                torch.stack([item["future_atom_logits"][head] for item in records], dim=1)
                for head in range(len(self.future_horizons))
            ],
            hidden_states=torch.stack([item["hidden"] for item in records], dim=1),
            final_state=state)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        del context
        # fast, segment, document, and the active segment accumulator.
        return 4 * batch_size * self.width


class FunctionalLowRankAffine(nn.Module):
    """A state-routed mixture of low-rank affine operators.

    The always-active control supplies a stable base map. The chart controls
    supply state-dependent residual maps without materializing a dense weight
    matrix for every chart.
    """

    def __init__(self, input_size: int, output_size: int, rank: int, charts: int):
        super().__init__()
        if min(input_size, output_size, rank, charts) <= 0:
            raise ValueError("functional affine dimensions must be positive")
        self.input_size = int(input_size)
        self.output_size = int(output_size)
        self.rank = int(rank)
        self.charts = int(charts)
        self.base_left = nn.Parameter(torch.empty(input_size, rank))
        self.base_right = nn.Parameter(torch.empty(rank, output_size))
        self.chart_left = nn.Parameter(torch.empty(charts, input_size, rank))
        self.chart_right = nn.Parameter(torch.empty(charts, rank, output_size))
        self.bias = nn.Parameter(torch.zeros(output_size))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.normal_(self.base_left, std=self.input_size ** -0.5)
        nn.init.normal_(self.base_right, std=self.rank ** -0.5)
        nn.init.normal_(self.chart_left, std=self.input_size ** -0.5)
        # A small nonzero initialization lets both the chart factors and router
        # receive gradients on the first update while keeping the base stable.
        nn.init.normal_(self.chart_right, std=1e-3)
        nn.init.zeros_(self.bias)

    def forward(self, values: torch.Tensor,
                coefficients: torch.Tensor) -> torch.Tensor:
        if values.shape[-1] != self.input_size:
            raise ValueError("functional affine input width mismatch")
        if coefficients.shape[-1] != self.charts:
            raise ValueError("functional affine chart count mismatch")
        base = (values @ self.base_left) @ self.base_right
        coordinates = torch.einsum("bi,kir->bkr", values, self.chart_left)
        chart_outputs = torch.einsum(
            "bkr,kro->bko", coordinates, self.chart_right)
        routed = torch.einsum("bk,bko->bo", coefficients, chart_outputs)
        return base + routed + self.bias


class FunctionWeightedGRUCell(nn.Module):
    """GRU transition whose input and recurrent maps are functions of state."""

    def __init__(self, input_size: int, hidden_size: int, rank: int,
                 charts: int, router_width: int, topk: int,
                 temperature: float):
        super().__init__()
        if not 1 <= topk <= charts:
            raise ValueError("topk must be between one and the chart count")
        if temperature <= 0:
            raise ValueError("routing temperature must be positive")
        self.input_size = int(input_size)
        self.hidden_size = int(hidden_size)
        self.charts = int(charts)
        self.topk = int(topk)
        self.temperature = float(temperature)
        self.router = nn.Sequential(
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, router_width),
            nn.SiLU(),
            nn.Linear(router_width, charts),
        )
        self.input_function = FunctionalLowRankAffine(
            input_size, 3 * hidden_size, rank, charts)
        self.hidden_function = FunctionalLowRankAffine(
            hidden_size, 3 * hidden_size, rank, charts)

    def routing_coefficients(self, previous: torch.Tensor) -> torch.Tensor:
        logits = self.router(previous) / self.temperature
        if self.topk < self.charts:
            selected, indices = torch.topk(logits, self.topk, dim=-1)
            sparse = torch.full_like(logits, -torch.inf)
            logits = sparse.scatter(-1, indices, selected)
        return torch.softmax(logits, dim=-1)

    def forward(self, values: torch.Tensor,
                previous: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        coefficients = self.routing_coefficients(previous)
        input_gates = self.input_function(values, coefficients)
        hidden_gates = self.hidden_function(previous, coefficients)
        input_reset, input_update, input_new = input_gates.chunk(3, dim=-1)
        hidden_reset, hidden_update, hidden_new = hidden_gates.chunk(3, dim=-1)
        reset = torch.sigmoid(input_reset + hidden_reset)
        update = torch.sigmoid(input_update + hidden_update)
        candidate = torch.tanh(input_new + reset * hidden_new)
        state = candidate + update * (previous - candidate)
        return state, coefficients


class HierarchicalFunctionWeightsStudent(StudentBase):
    """Three-timescale constant-state model with functional GRU transitions."""

    kind = "hierarchical_function_weights"

    def __init__(self, vocab_size: int, width: int, max_context: int,
                 segment_length: int, document_segments: int,
                 function_weights: dict):
        super().__init__(vocab_size, width, max_context)
        self.segment_length = int(segment_length)
        self.document_segments = int(document_segments)
        self.function_weights = dict(function_weights)
        cell_arguments = {
            "hidden_size": width,
            "rank": int(function_weights["rank"]),
            "charts": int(function_weights["charts"]),
            "router_width": int(function_weights["router_width"]),
            "topk": int(function_weights["topk"]),
            "temperature": float(function_weights["temperature"]),
        }
        self.fast_cell = FunctionWeightedGRUCell(
            input_size=3 * width, **cell_arguments)
        self.segment_cell = FunctionWeightedGRUCell(
            input_size=width, **cell_arguments)
        self.document_cell = FunctionWeightedGRUCell(
            input_size=width, **cell_arguments)
        self.combine = nn.Sequential(
            nn.Linear(3 * width, 2 * width), nn.SiLU(), nn.Linear(2 * width, width))

    def initial_state(self, batch_size: int, device: torch.device,
                      dtype: torch.dtype | None = None):
        dtype = dtype or self.embedding.weight.dtype
        zero = lambda: torch.zeros(batch_size, self.width, device=device, dtype=dtype)
        return {
            "fast": zero(), "segment": zero(), "document": zero(),
            "segment_sum": zero(), "segment_tokens": 0, "segments": 0,
        }

    def transition(self, token_ids: torch.Tensor, state=None):
        if state is None:
            state = self.initial_state(token_ids.shape[0], token_ids.device)
        token = self.embedding(token_ids)
        fast_input = torch.cat((token, state["segment"], state["document"]), dim=-1)
        fast, fast_route = self.fast_cell(fast_input, state["fast"])
        segment_sum = state["segment_sum"] + fast
        segment_tokens = int(state["segment_tokens"]) + 1
        segment = state["segment"]
        document = state["document"]
        segments = int(state["segments"])
        routes = {"fast": fast_route}
        if segment_tokens == self.segment_length:
            segment, segment_route = self.segment_cell(
                segment_sum / segment_tokens, segment)
            routes["segment"] = segment_route
            segment_sum = torch.zeros_like(segment_sum)
            segment_tokens = 0
            segments += 1
            if segments == self.document_segments:
                document, document_route = self.document_cell(segment, document)
                routes["document"] = document_route
                segments = 0
        combined = self.combine(torch.cat((fast, segment, document), dim=-1))
        new_state = {
            "fast": fast, "segment": segment, "document": document,
            "segment_sum": segment_sum, "segment_tokens": segment_tokens,
            "segments": segments,
        }
        return combined, new_state, routes

    @staticmethod
    def routing_balance(route_values: dict[str, list[torch.Tensor]],
                        reference: torch.Tensor) -> torch.Tensor:
        losses = []
        for values in route_values.values():
            if not values:
                continue
            probabilities = torch.cat(values, dim=0)
            target = probabilities.new_full(
                (probabilities.shape[-1],), 1.0 / probabilities.shape[-1])
            losses.append(
                probabilities.mean(dim=0).sub(target).square().mean()
                * probabilities.shape[-1])
        return torch.stack(losses).mean() if losses else reference.new_zeros(())

    def step(self, token_ids: torch.Tensor, state=None):
        hidden, new_state, routes = self.transition(token_ids, state)
        return self.logits(hidden), new_state, hidden, routes

    def forward(self, input_ids: torch.Tensor):
        state = None
        hidden_values = []
        logits = []
        route_values = {"fast": [], "segment": [], "document": []}
        for index in range(input_ids.shape[1]):
            token_logits, state, hidden, routes = self.step(
                input_ids[:, index], state)
            logits.append(token_logits)
            hidden_values.append(hidden)
            for family, coefficients in routes.items():
                route_values[family].append(coefficients)
        if not logits:
            raise ValueError("forward requires at least one input token")
        routing_balance = self.routing_balance(route_values, hidden_values[-1])
        return SimpleNamespace(
            logits=torch.stack(logits, dim=1),
            hidden_states=torch.stack(hidden_values, dim=1),
            final_state=state,
            auxiliary_losses={"routing_balance": routing_balance})

    def last_logits(self, input_ids: torch.Tensor):
        state = None
        hidden = None
        for index in range(input_ids.shape[1]):
            hidden, state, _ = self.transition(input_ids[:, index], state)
        if hidden is None:
            raise ValueError("last_logits requires at least one input token")
        return self.logits(hidden).unsqueeze(1)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        del context
        return 4 * batch_size * self.width


class HierarchicalDistributionStudent(StudentBase):
    """Three-timescale recurrent state without the failed discrete atom heads."""

    kind = "hierarchical_distribution"

    def __init__(self, vocab_size: int, width: int, max_context: int,
                 segment_length: int, document_segments: int):
        super().__init__(vocab_size, width, max_context)
        self.segment_length = int(segment_length)
        self.document_segments = int(document_segments)
        self.fast_cell = nn.GRUCell(3 * width, width)
        self.segment_cell = nn.GRUCell(width, width)
        self.document_cell = nn.GRUCell(width, width)
        self.combine = nn.Sequential(
            nn.Linear(3 * width, 2 * width), nn.SiLU(), nn.Linear(2 * width, width))

    def initial_state(self, batch_size: int, device: torch.device,
                      dtype: torch.dtype | None = None):
        dtype = dtype or self.embedding.weight.dtype
        zero = lambda: torch.zeros(batch_size, self.width, device=device, dtype=dtype)
        return {
            "fast": zero(), "segment": zero(), "document": zero(),
            "segment_sum": zero(), "segment_tokens": 0, "segments": 0,
        }

    def transition(self, token_ids: torch.Tensor, state=None):
        if state is None:
            state = self.initial_state(token_ids.shape[0], token_ids.device)
        token = self.embedding(token_ids)
        fast_input = torch.cat((token, state["segment"], state["document"]), dim=-1)
        fast = self.fast_cell(fast_input, state["fast"])
        segment_sum = state["segment_sum"] + fast
        segment_tokens = int(state["segment_tokens"]) + 1
        segment = state["segment"]
        document = state["document"]
        segments = int(state["segments"])
        if segment_tokens == self.segment_length:
            segment = self.segment_cell(segment_sum / segment_tokens, segment)
            segment_sum = torch.zeros_like(segment_sum)
            segment_tokens = 0
            segments += 1
            if segments == self.document_segments:
                document = self.document_cell(segment, document)
                segments = 0
        combined = self.combine(torch.cat((fast, segment, document), dim=-1))
        new_state = {
            "fast": fast, "segment": segment, "document": document,
            "segment_sum": segment_sum, "segment_tokens": segment_tokens,
            "segments": segments,
        }
        return combined, new_state

    def step(self, token_ids: torch.Tensor, state=None):
        hidden, new_state = self.transition(token_ids, state)
        return self.logits(hidden), new_state, hidden

    def forward(self, input_ids: torch.Tensor):
        state = None
        hidden_values = []
        logits = []
        for index in range(input_ids.shape[1]):
            token_logits, state, hidden = self.step(input_ids[:, index], state)
            logits.append(token_logits)
            hidden_values.append(hidden)
        if not logits:
            raise ValueError("forward requires at least one input token")
        return SimpleNamespace(
            logits=torch.stack(logits, dim=1),
            hidden_states=torch.stack(hidden_values, dim=1),
            final_state=state)

    def last_logits(self, input_ids: torch.Tensor):
        state = None
        hidden = None
        for index in range(input_ids.shape[1]):
            hidden, state = self.transition(input_ids[:, index], state)
        if hidden is None:
            raise ValueError("last_logits requires at least one input token")
        return self.logits(hidden).unsqueeze(1)

    def stored_state_elements(self, batch_size: int = 1, context: int = 512) -> int:
        del context
        return 4 * batch_size * self.width


def build_student(kind: str, vocab_size: int, width: int, max_context: int,
                  config: dict) -> StudentBase:
    if kind == "transformer":
        return TransformerStudent(
            vocab_size, width, max_context, int(config["layers"]),
            int(config["heads"]), int(config.get("expansion", 4)))
    if kind == "recurrent_logits":
        return RecurrentLogitStudent(
            vocab_size, width, max_context, int(config["layers"]))
    if kind in ("hierarchical_predictive", "hierarchical_logit_control"):
        return HierarchicalPredictiveStudent(
            vocab_size, width, max_context, int(config["atoms"]),
            int(config["segment_length"]), int(config["document_segments"]),
            list(config["future_horizons"]))
    if kind == "hierarchical_distribution":
        return HierarchicalDistributionStudent(
            vocab_size, width, max_context, int(config["segment_length"]),
            int(config["document_segments"]))
    if kind == "hierarchical_function_weights":
        return HierarchicalFunctionWeightsStudent(
            vocab_size, width, max_context, int(config["segment_length"]),
            int(config["document_segments"]), dict(config["function_weights"]))
    raise ValueError(f"unknown student kind {kind}")


@dataclass
class BudgetedStudent:
    model: StudentBase
    width: int
    parameters: int
    target_parameters: int


def build_to_budget(kind: str, vocab_size: int, max_context: int, config: dict,
                    target_parameters: int) -> BudgetedStudent:
    """Choose the widest multiple-of-32 model that does not exceed the budget."""
    widths = list(range(int(config["minimum_width"]),
                        int(config["maximum_width"]) + 1,
                        int(config.get("width_step", 32))))
    if kind == "transformer":
        heads = int(config["heads"])
        widths = [width for width in widths if width % heads == 0]
    chosen = None
    for width in widths:
        with torch.device("meta"):
            candidate = build_student(kind, vocab_size, width, max_context, config)
        count = parameter_count(candidate)
        if count <= target_parameters:
            chosen = (width, count)
        else:
            break
    if chosen is None:
        raise ValueError(f"{kind} cannot fit minimum width under parameter budget")
    width, count = chosen
    model = build_student(kind, vocab_size, width, max_context, config)
    actual = parameter_count(model)
    if actual != count:
        raise RuntimeError("meta-device parameter count disagrees with real model")
    return BudgetedStudent(model, width, actual, int(target_parameters))
