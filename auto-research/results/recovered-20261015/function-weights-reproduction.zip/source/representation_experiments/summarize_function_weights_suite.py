"""Summarize the matched hierarchical function-weight experiment."""
from __future__ import annotations

import argparse

from representation_experiments.common import atomic_json, load_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--root", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    config = load_json(args.config)
    rows = []
    for arm in config["arms"]:
        result = load_json(f"{args.root}/{arm}/result.json")
        result["benchmarks"] = load_json(f"{args.root}/{arm}/benchmarks.json")
        rows.append(result)
    by_name = {row["arm"]: row for row in rows}
    gates = config["promotion_gates"]
    fixed = by_name[gates["fixed_reference"]]
    function = by_name[gates["function_reference"]]
    branch = by_name[gates["function_branch"]]

    def metric(row, name):
        return float(row["metrics"][name])

    minimum_ce = float(gates["minimum_ce_improvement"])
    checks = {
        "function_beats_fixed_ce": metric(function, "student_ce")
        <= metric(fixed, "student_ce") - minimum_ce,
        "branch_beats_function_ce": metric(branch, "student_ce")
        <= metric(function, "student_ce") - minimum_ce,
        "branch_improves_transition_kl": metric(branch, "branch_kl_t1")
        <= metric(function, "branch_kl_t1")
        - float(gates["minimum_branch_kl_improvement"]),
        "function_rollout_stable": metric(function, "rollout_degradation")
        <= float(gates["maximum_rollout_ce_degradation"]),
        "branch_rollout_stable": metric(branch, "rollout_degradation")
        <= float(gates["maximum_rollout_ce_degradation"]),
        "equal_storage": max(float(row["budget_utilization"]) for row in rows)
        - min(float(row["budget_utilization"]) for row in rows)
        <= float(gates["maximum_budget_utilization_spread"]),
    }
    decision = "promote_function_weighted_hierarchy" \
        if all(checks.values()) else "reject_or_iterate"
    summary = {
        "study": "qwen06b_hierarchical_function_weights_v1",
        "rows": rows,
        "checks": checks,
        "decision": decision,
    }
    atomic_json(summary, args.out)
    print(summary)


if __name__ == "__main__":
    main()
