"""Resume-safe multi-GPU launcher driven entirely by the experiment manifest."""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from representation_experiments.common import load_json


def free_gb(path: Path) -> int:
    return shutil.disk_usage(path).free // (1024 ** 3)


def run_batches(commands, gpu_ids, logs, environment):
    for start in range(0, len(commands), len(gpu_ids)):
        processes = []
        for gpu, (name, command) in zip(gpu_ids, commands[start:start + len(gpu_ids)]):
            log_path = logs / f"{name}.log"
            stream = log_path.open("ab")
            child_environment = dict(environment)
            child_environment["CUDA_VISIBLE_DEVICES"] = gpu
            process = subprocess.Popen(
                command, stdout=stream, stderr=subprocess.STDOUT,
                env=child_environment)
            processes.append((name, process, stream, log_path))
        failures = []
        for name, process, stream, log_path in processes:
            return_code = process.wait()
            stream.close()
            if return_code:
                failures.append(f"{name} exited {return_code}; inspect {log_path}")
        if failures:
            raise RuntimeError("; ".join(failures))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--gpus", default=os.environ.get("GPU_LIST", "0,1,2,3"))
    args = parser.parse_args()
    config_path = Path(args.config).expanduser().resolve()
    output = Path(args.out).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    logs = output / "logs"
    logs.mkdir(exist_ok=True)
    config = load_json(config_path)
    minimum_free = int(config["safety"]["minimum_free_gb"])
    if free_gb(output) < minimum_free:
        raise RuntimeError("free disk is below the manifest safety floor")
    gpu_ids = [item.strip() for item in args.gpus.split(",") if item.strip()]
    if not gpu_ids:
        raise ValueError("at least one GPU id is required")
    source_root = Path(__file__).resolve().parent.parent
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(source_root)
    script_root = Path(__file__).resolve().parent
    arms = list(config["arms"])

    training_commands = []
    for arm in arms:
        if (output / arm / "result.json").is_file():
            continue
        (output / arm).mkdir(exist_ok=True)
        training_commands.append((arm, [
            sys.executable, "-u", str(script_root / "distribution_distillation.py"),
            "--config", str(config_path), "--arm", arm,
            "--out", str(output / arm),
        ]))
    run_batches(training_commands, gpu_ids, logs, environment)

    if free_gb(output) < minimum_free:
        raise RuntimeError("paused before benchmarks: disk is below safety floor")
    limit = str(int(config["benchmark"]["limit"]))
    benchmark_commands = []
    for arm in arms:
        benchmark = output / arm / "benchmarks.json"
        if benchmark.is_file():
            continue
        benchmark_commands.append((f"{arm}-benchmarks", [
            sys.executable, "-u", str(script_root / "distribution_benchmarks.py"),
            "--config", str(config_path), "--arm", arm,
            "--checkpoint", str(output / arm / "student_final.pt"),
            "--limit", limit, "--out", str(benchmark),
        ]))
    run_batches(benchmark_commands, gpu_ids, logs, environment)

    subprocess.run([
        sys.executable, str(script_root / "summarize_function_weights_suite.py"),
        "--config", str(config_path), "--root", str(output),
        "--out", str(output / "summary.json"),
    ], check=True, env=environment)


if __name__ == "__main__":
    main()
