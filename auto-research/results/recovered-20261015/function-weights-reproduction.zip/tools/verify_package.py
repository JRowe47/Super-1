"""Verify package completeness, hashes, configs, and absence of common secrets."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path


SECRET_PATTERNS = {
    "openai_key": re.compile(rb"sk-[A-Za-z0-9_-]{32,}"),
    "google_service_account": re.compile(rb'"private_key"\s*:\s*"-----BEGIN'),
    "aws_access_key": re.compile(rb"AKIA[0-9A-Z]{16}"),
    "github_token": re.compile(rb"gh[pousr]_[A-Za-z0-9]{30,}"),
}


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def main():
    root = Path(__file__).resolve().parents[1]
    required = [
        "README.md",
        "ENVIRONMENT.md",
        "PROVENANCE.md",
        "LICENSE_NOTICE.md",
        "evidence/reported_result_snapshot.json",
        "evidence/model_budget_report.json",
        "docs/hierarchical_predictive_why_it_works_report.pdf",
        "source/prepare_pythia_data.py",
        "source/representation_experiments/predictive_models.py",
        "source/representation_experiments/distribution_distillation.py",
        "source/representation_experiments/run_function_weights_suite.py",
        "source/representation_experiments/configs/qwen06b_representation_studies.json",
        "source/representation_experiments/configs/qwen06b_hierarchical_function_weights_v1.json",
    ]
    missing = [value for value in required if not (root / value).is_file()]
    if missing:
        raise FileNotFoundError(f"missing required package files: {missing}")
    for config_path in (root / "source/representation_experiments/configs").glob("*.json"):
        json.loads(config_path.read_text())
    json.loads((root / "evidence/reported_result_snapshot.json").read_text())
    json.loads((root / "evidence/model_budget_report.json").read_text())
    pdf = root / "docs/hierarchical_predictive_why_it_works_report.pdf"
    if pdf.read_bytes()[:5] != b"%PDF-":
        raise ValueError("report does not have a PDF header")
    findings = []
    files = [path for path in root.rglob("*") if path.is_file()
             and path.name != "MANIFEST.sha256"]
    for path in files:
        data = path.read_bytes()
        for name, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                findings.append(f"{name}: {path.relative_to(root)}")
    if findings:
        raise ValueError("possible credentials found: " + "; ".join(findings))
    manifest = root / "MANIFEST.sha256"
    if manifest.exists():
        expected = {}
        for line in manifest.read_text().splitlines():
            checksum, relative = line.split("  ", 1)
            expected[relative] = checksum
        actual = {
            str(path.relative_to(root)): digest(path)
            for path in files
        }
        if expected != actual:
            missing_hashes = sorted(set(actual) - set(expected))
            stale_hashes = sorted(
                name for name in set(actual) & set(expected)
                if actual[name] != expected[name])
            raise ValueError(
                f"manifest mismatch; missing={missing_hashes}; stale={stale_hashes}")
    print(f"package verification: PASS ({len(files)} files)")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"package verification: FAIL: {error}", file=sys.stderr)
        raise
