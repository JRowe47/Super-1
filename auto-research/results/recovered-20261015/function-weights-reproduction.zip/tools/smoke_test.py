"""CPU checks for causality, routing, gradients, budgets, and constant state."""
from __future__ import annotations

import sys
from pathlib import Path

import torch


def main():
    source = Path(__file__).resolve().parents[1] / "source"
    sys.path.insert(0, str(source))
    from representation_experiments.distribution_distillation import exact_forward_kl
    from representation_experiments.predictive_models import (
        FunctionWeightedGRUCell,
        build_to_budget,
    )

    torch.manual_seed(41)
    cell = FunctionWeightedGRUCell(
        input_size=32, hidden_size=24, rank=8, charts=4,
        router_width=12, topk=2, temperature=1.0)
    values = torch.randn(3, 32)
    previous = torch.randn(3, 24)
    state, routing = cell(values, previous)
    assert state.shape == (3, 24)
    assert torch.allclose(routing.sum(-1), torch.ones(3), atol=1e-6)
    assert torch.equal((routing > 0).sum(-1), torch.full((3,), 2))

    spec = {
        "minimum_width": 64, "maximum_width": 128, "width_step": 8,
        "segment_length": 4, "document_segments": 2,
        "function_weights": {
            "charts": 4, "rank": 8, "router_width": 16,
            "topk": 2, "temperature": 1.0,
        },
        "auxiliary_loss_weights": {"routing_balance": 0.01},
    }
    budgeted = build_to_budget(
        "hierarchical_function_weights", 256, 32, spec, 500_000)
    model = budgeted.model
    tokens = torch.randint(0, 256, (2, 16))
    changed = tokens.clone()
    changed[:, -1] = (changed[:, -1] + 1) % 256
    output = model(tokens)
    future_changed = model(changed)
    assert output.logits.shape == (2, 16, 256)
    assert torch.allclose(
        output.logits[:, :-1], future_changed.logits[:, :-1],
        atol=1e-6, rtol=1e-6)
    assert model.stored_state_elements(2, 16) == model.stored_state_elements(2, 8192)
    loss = output.logits.float().square().mean()
    loss = loss + output.auxiliary_losses["routing_balance"]
    loss.backward()
    assert all(torch.isfinite(parameter.grad).all()
               for parameter in model.parameters() if parameter.grad is not None)
    teacher = torch.randn(2, 3, 256)
    student = torch.randn(2, 3, 256, requires_grad=True)
    kl = exact_forward_kl(student, teacher, 2.0, 64)
    assert torch.isfinite(kl)
    kl.backward()
    assert torch.isfinite(student.grad).all()
    print("hierarchical function-weights smoke test: PASS")


if __name__ == "__main__":
    main()
