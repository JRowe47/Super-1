"""Verify baked predictive artifacts before enabling student training."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import torch


def validate_manifest(path: Path, expected_split: str, expected_context: int):
    payload = json.loads(path.read_text())
    if payload.get("format") != "predictive_sequence_bake_v1":
        raise ValueError(f"unexpected manifest format in {path}")
    if payload.get("split") != expected_split:
        raise ValueError(f"unexpected split in {path}")
    if int(payload.get("context", -1)) != expected_context:
        raise ValueError(f"unexpected context in {path}")
    shards = []
    for value in payload.get("shards", []):
        shard = Path(value)
        if not shard.is_absolute():
            shard = path.parent / shard
        if not shard.is_file() or shard.stat().st_size == 0:
            raise FileNotFoundError(shard)
        shards.append(shard)
    if not shards:
        raise ValueError(f"no shards in {path}")
    required = {
        "input_ids", "target_ids", "teacher_topk_indices",
        "teacher_topk_logprobs", "atom_ids", "future_atom_ids",
        "intervention_ids", "intervention_atom_ids",
    }
    for shard in (shards[0], shards[-1]):
        record = torch.load(shard, map_location="cpu", weights_only=False)
        missing = required - set(record)
        if missing:
            raise ValueError(f"{shard} is missing {sorted(missing)}")
        if int(record["input_ids"].shape[1]) != expected_context:
            raise ValueError(f"unexpected tensor context in {shard}")
    return payload, shards


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--write-marker", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    config = json.loads(Path(args.config).read_text())
    context = int(config["predictive_bake"]["context"])
    atlas = root / "atlas" / "atlas.pt"
    if not atlas.is_file() or atlas.stat().st_size == 0:
        raise FileNotFoundError(atlas)
    train, train_shards = validate_manifest(
        root / "baked-train" / "manifest.json", "train", context)
    validation, validation_shards = validate_manifest(
        root / "baked-val" / "manifest.json", "val", context)
    expected_train = int(config["predictive_bake"]["sequences"])
    if int(train["sequences"]) != expected_train:
        raise ValueError("train sequence count differs from the manifest")
    if int(validation["sequences"]) <= 0:
        raise ValueError("validation sequence count must be positive")
    result = {
        "atlas_bytes": atlas.stat().st_size,
        "train_sequences": int(train["sequences"]),
        "train_shards": len(train_shards),
        "validation_sequences": int(validation["sequences"]),
        "validation_shards": len(validation_shards),
        "context": context,
    }
    if args.write_marker:
        marker = root / "sync.complete"
        temporary = marker.with_suffix(".tmp")
        temporary.write_text(json.dumps(result, sort_keys=True) + "\n")
        os.replace(temporary, marker)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
