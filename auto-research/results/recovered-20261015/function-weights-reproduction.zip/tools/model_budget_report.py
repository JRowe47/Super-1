"""Resolve matched widths and quantify transition compression from a manifest."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--fixed", required=True)
    parser.add_argument("--function", required=True)
    parser.add_argument("--out")
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[1] / "source"
    sys.path.insert(0, str(source))
    from representation_experiments.common import load_json, parameter_count
    from representation_experiments.predictive_models import build_student, build_to_budget

    config = load_json(args.config)
    budget = int(config["student_parameter_budget"])
    context = int(config["training"]["context"])
    vocab = int(config["vocab_size"])
    fixed = build_to_budget(
        args.fixed, vocab, context, config["models"][args.fixed], budget)
    function = build_to_budget(
        args.function, vocab, context, config["models"][args.function], budget)
    function_at_fixed_width = build_student(
        args.function, vocab, fixed.width, context,
        config["models"][args.function])
    same_width_parameters = parameter_count(function_at_fixed_width)
    result = {
        "parameter_budget": budget,
        "fixed": {"architecture": args.fixed, "width": fixed.width,
                  "parameters": fixed.parameters},
        "function_reinvested": {
            "architecture": args.function, "width": function.width,
            "parameters": function.parameters,
        },
        "function_at_fixed_width": {
            "width": fixed.width,
            "parameters": same_width_parameters,
            "parameter_reduction": fixed.parameters - same_width_parameters,
            "compression_ratio": fixed.parameters / same_width_parameters,
        },
    }
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.out:
        Path(args.out).write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
