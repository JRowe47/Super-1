# Hierarchical Recurrent Function Weights - reproduction package

This package contains two related, explicitly separated experiments:

1. **Completed-result reproduction.** The original equal-storage Qwen3-0.6B
   predictive-state study that produced hierarchical predictive CE 6.5123,
   transformer CE 7.0100, stable 512-token recurrent evaluation, and a small
   mean benchmark advantage.
2. **Untrained follow-up.** A matched function-weighted hierarchy that replaces
   each fixed GRU transition with a state-routed mixture of low-rank operators.
   This code is tested, but no quality result is claimed until its four manifest
   arms finish.

Model weights, Hugging Face caches, token corpora, baked teacher shards, and
checkpoints are intentionally excluded. They are large and may be governed by
separate licenses. The code downloads or consumes them from paths selected in
the JSON manifests.

## What the combined model changes

The fast, segment, and document memories retain separate operator families.
Each family uses an always-active low-rank control plus four state-routed
low-rank chart controls. The router activates the top two charts for each state.
The model therefore keeps constant recurrent memory while representing more
than one transition rule at each timescale.

At the included 120M-parameter ceiling, the resolver reports:

| Architecture | Resolved width | Stored parameters |
|---|---:|---:|
| Fixed hierarchical recurrence | 688 | 119,694,800 |
| Function hierarchy, savings reinvested | 736 | 119,383,852 |
| Function hierarchy at fixed width 688 | 688 | 111,333,820 |

The fixed-width functional model uses 8,360,980 fewer parameters. The primary
test reinvests that saving into a wider state while remaining below the same
storage ceiling.

## Package map

- `source/representation_experiments/predictive_*.py`: exact predictive-state
  preprocessing, student training, rollout evaluation, and benchmarks.
- `source/representation_experiments/distribution_distillation.py`: full Qwen
  forward-KL compiler, multi-temperature targets, and branch distillation.
- `source/representation_experiments/predictive_models.py`: fixed recurrent,
  transformer, hierarchical, and function-weighted hierarchical students.
- `source/representation_experiments/configs/`: immutable experiment manifests.
- `tools/smoke_test.py`: CPU causality, routing, gradient, KL, budget, and
  constant-state tests.
- `tools/model_budget_report.py`: programmatic equal-budget resolution.
- `evidence/reported_result_snapshot.json`: compact transcription of the
  completed result. It is evidence, not a substitute for a fresh run.
- `docs/hierarchical_predictive_why_it_works_report.pdf`: technical analysis.

## Environment

Use Python 3.10 or newer. The large experiments require CUDA and were designed
for A100-class GPUs.

```bash
cd source
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cd ..
python tools/smoke_test.py
```

The smoke test runs on CPU and does not download Qwen or a dataset.

## Prepare the exact token corpus

The completed study used Qwen-tokenized FineWeb-Edu stored as uint32. From the
package root:

```bash
source/.venv/bin/python source/prepare_pythia_data.py \
  --tokenizer Qwen/Qwen3-0.6B-Base \
  --dataset HuggingFaceFW/fineweb-edu \
  --subset sample-10BT \
  --train_tokens 1200000000 \
  --val_tokens 10000000 \
  --token_dtype uint32 \
  --out data/qwen3-06b-representation
```

The manifests refer to `data/qwen3-06b-representation`. Change the manifest
path if the corpus lives elsewhere; do not edit Python source.

## Reproduce the completed predictive-state result

Teacher preprocessing is a resume-safe single-GPU stage:

```bash
PYTHON_BIN="$PWD/source/.venv/bin/python" GPU_ID=0 \
  source/representation_experiments/run_predictive_precompute_single_gpu.sh \
  source/representation_experiments/configs/qwen06b_representation_studies.json \
  runs/qwen06b-predictive-study
```

Verify the atlas, manifests, edge shards, counts, and tensor schema before
allowing student training:

```bash
source/.venv/bin/python tools/verify_precompute.py \
  --config source/representation_experiments/configs/qwen06b_representation_studies.json \
  --root runs/qwen06b-predictive-study \
  --write-marker
```

Then train the four equal-storage students and run the matched limit-1000
benchmarks:

```bash
PYTHON_BIN="$PWD/source/.venv/bin/python" GPU_LIST=0,1,2,3 \
  source/representation_experiments/run_predictive_students.sh \
  source/representation_experiments/configs/qwen06b_representation_studies.json \
  runs/qwen06b-predictive-study
```

The authoritative output is `runs/qwen06b-predictive-study/summary.json`.
Checkpoints and completed results are resume-safe and are not overwritten.

## Run the function-weighted follow-up

This study reads `train.bin` and `val.bin` directly and calls the frozen Qwen
teacher during training. Four arms isolate random versus projected embeddings,
fixed versus functional recurrence, and branch distillation:

```bash
source/.venv/bin/python \
  source/representation_experiments/run_function_weights_suite.py \
  --config source/representation_experiments/configs/qwen06b_hierarchical_function_weights_v1.json \
  --out runs/qwen06b-hierarchical-function-weights-v1 \
  --gpus 0,1,2,3
```

The launcher is manifest-driven, resume-safe, skips completed arms, limits
parallelism to the supplied GPU list, enforces the free-disk floor, runs matched
benchmarks, and writes `summary.json`.

To inspect storage resolution without training:

```bash
source/.venv/bin/python tools/model_budget_report.py \
  --config source/representation_experiments/configs/qwen06b_hierarchical_function_weights_v1.json \
  --fixed hierarchical_distribution \
  --function hierarchical_function_weights
```

## Interpretation boundary

The completed 6.5123 result belongs to `hierarchical_predictive` in the original
manifest. The function-weighted architecture is a preregistered next test. Its
implementation passing smoke tests does not establish that it improves loss,
benchmarks, or speed. Promotion requires every gate in the new manifest:
improved CE, improved branch KL, stable rollout, and matched stored parameters.

The reported rollout used true preceding validation tokens. It was autonomous
with respect to the teacher, but it was not a 512-token free-generation test in
which sampled student errors feed back into later inputs.
