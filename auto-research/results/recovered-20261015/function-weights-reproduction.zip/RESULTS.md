# Result status

## Completed predictive-state comparison

The completed run reported:

- hierarchical predictive validation CE: 6.5123;
- matched transformer validation CE: 7.0100;
- hierarchical CE at rollout positions 64 and 512: 6.5537 and 6.4844;
- mean limit-1000 benchmark accuracy: 0.2585 versus 0.2520;
- fixed recurrent state: approximately 10.1 KB at the evaluation batch size;
- matched transformer KV estimate at context 512: approximately 14.9 MB.

The identical hierarchical logit-only control reached CE 6.5106. Therefore the
result supports the hierarchical recurrence, while the additional discrete
atom/future/intervention targets did not improve language-model CE.

## Function-weighted comparison

No completed quality result is bundled or claimed. The code introduces the
functional transition family and preregisters comparisons against the fixed
hierarchy. Use the generated `summary.json` and require all configured gates
before promotion.
