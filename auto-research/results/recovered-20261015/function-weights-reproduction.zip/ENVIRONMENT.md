# Environment and resource notes

- Python: 3.10 or newer.
- Core packages: PyTorch 2.5+, Transformers 4.51+, Datasets 3.0+, Accelerate,
  Safetensors, and NumPy.
- Teacher: `Qwen/Qwen3-0.6B-Base`.
- Corpus: `HuggingFaceFW/fineweb-edu`, `sample-10BT`, tokenized by the teacher.
- Token storage: uint32 `train.bin` and `val.bin`.
- Original predictive preprocessing: one A100-class GPU.
- Four-arm student studies: four GPUs are fastest; the new Python launcher also
  batches arms safely across a smaller GPU list.
- Full-distribution KL creates large vocabulary tensors. A100-80GB is the
  conservative reference device for the included batch/context settings.
- The manifest refuses to begin a write-heavy stage below its configured free
  disk floor.

For offline runs, populate the Hugging Face cache first and export
`HF_HUB_OFFLINE=1`. The launcher inherits this variable but does not force it,
so a clean environment can download the teacher and benchmark datasets.
