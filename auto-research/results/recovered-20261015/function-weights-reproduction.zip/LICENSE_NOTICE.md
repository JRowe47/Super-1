# License notice

This archive contains experiment code and configuration, not Qwen model files
or FineWeb-Edu data. Users are responsible for reviewing and complying with the
licenses and terms attached to:

- `Qwen/Qwen3-0.6B-Base`
- `HuggingFaceFW/fineweb-edu`
- benchmark datasets loaded by the evaluation harness
- Python packages installed from `source/requirements.txt`

No license to third-party weights or datasets is granted by this package.
