"""Run an immutable phase-language implementation with a sealed budget config."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    assert not args.output.exists(), 'Never overwrite an existing experiment'
    allowed = set(pilot.C) | {'reserved_confirmation_start', 'budget_provenance'}
    assert set(config) <= allowed
    assert config['steps'] > 0 and config['validation_interval'] > 0
    assert config['steps'] % config['validation_interval'] == 0
    assert len(config['seeds']) == 3 and len(config['lrs']) == 2
    assert config['arms'] == pilot.C['arms']
    selection_end = config['validation_start'] + config['validation_windows'] * config['context']
    assert config['reserved_confirmation_start'] > selection_end
    config['budget_provenance'] = {
        'config_sha256': hashlib.sha256(args.config.read_bytes()).hexdigest(),
        'runner_sha256': pilot.shared.prior.sha(Path(__file__)),
        'initialization': 'All candidates freshly initialized; no pilot checkpoint continuation',
        'confirmation': 'Reserved region not scored during training or checkpoint selection',
    }
    pilot.C.update(config)
    sys.argv = [pilot.__file__, '--output', str(args.output)]
    pilot.main()


if __name__ == '__main__':
    main()
