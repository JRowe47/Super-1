# Direct-distance deployment capacity test

This experiment tests the unchanged scalar pair-distance generator against dense
and learned-coordinate controls. The training-only distance table is not shipped.
Raw exemplars, learned scales, and every other deployed FP32 tensor count toward
the storage cap. This is development evidence, not an independent confirmation
or a claim of novelty.

## Reproduce

From the repository root, with Python, PyTorch, NumPy, SciPy, scikit-learn, and
Matplotlib installed:

```sh
python3 -m unittest discover -s experiments/disparity_constraints -p test_sub8.py
python3 experiments/disparity_constraints/sub8_sweep.py --output /absolute/path/to/new-run
python3 experiments/disparity_constraints/summarize_sub8.py /absolute/path/to/new-run
```

Use a new output directory. The launcher refuses an existing one. No cloud
credentials or cloud resources are used. Exact configuration and source hashes
are preserved in `PROTOCOL.json`; dependency versions should also be recorded
when reproducing on another machine.

## Protocol

- Five seeds; digits and a 64-class synthetic context task.
- 2, 3, 4, 6, and 8 KiB deployed FP32 tensor caps. An architecture that does not
  fit is recorded as infeasible, not silently redesigned.
- Six arms, two learning rates, and 3,000 updates per feasible candidate.
- Validation-only checkpoint and conventional-reference selection, frozen
  globally before development assessment.
- The logits-only ablation retains the same distance-generator architecture and
  teacher logits but removes the pair-distance regression gradient.
- Exact frozen-model prediction parity is checked for inference variants.
- The comparison gates, multiplicity family, and reserved confirmation protocol
  are specified before training in `sub8_config.json`.

`REPORT.md`, `SUMMARY.json`, `capacity.png`, and `CONFIRMATION_GATE.json` are
generated only after completion. Training histories remain available in the
candidate records. Three thousand updates is a budget, not proof of convergence.

Do not load the reserved confirmation dataset if the development gate fails.
If it passes, freeze the selected configuration before loading that dataset;
the current sweep does not run confirmation automatically.

## Memory and latency boundaries

Stored tensor bytes are not checkpoint-file bytes. Model-plus-query CPU tensor
allocations are not process RSS or allocator reserve. CPU batch-one timings do
not establish GPU or production latency. Synthetic performance does not establish
real-world generalization. Digits has already been used in earlier development.
