"""Gradient-parity and timing canary for a scripted full recurrent token loop.

This does not change the sealed trainer or launch another training experiment.
It benchmarks synthetic batches without updating any checkpoint weights.
"""
import argparse
import copy
import json
import random
import statistics
import time
from pathlib import Path
from typing import List

import torch
from torch import nn
from torch.nn import functional as F
import phase_transition_language as pilot


class ScriptablePhase(nn.Module):
    __constants__ = ['dynamic', 'width']

    def __init__(self, model):
        super().__init__()
        self.dynamic, self.width = model.dynamic, model.d
        self.embedding = copy.deepcopy(model.embedding)
        self.drive = copy.deepcopy(model.drive)
        self.write = copy.deepcopy(model.write)
        self.norm = copy.deepcopy(model.norm)
        self.retention = nn.Parameter(model.retention.detach().clone())
        self.angle = nn.Parameter(model.angle.detach().clone())
        if self.dynamic:
            self.gain = nn.Parameter(model.gain.detach().clone())
        else:
            self.register_buffer('gain', torch.zeros_like(model.angle))

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        embedded = self.embedding(tokens)
        drive = torch.tanh(self.drive(embedded))
        retention = torch.sigmoid(self.write(embedded) + self.retention)
        state = embedded.new_zeros((tokens.shape[0], self.width))
        history = torch.jit.annotate(List[torch.Tensor], [])
        for index in range(tokens.shape[1]):
            pair = state.reshape(tokens.shape[0], -1, 2)
            theta = self.angle
            if self.dynamic:
                target = drive[:, index].reshape(tokens.shape[0], -1, 2)
                cross = pair[:, :, 0] * target[:, :, 1] - pair[:, :, 1] * target[:, :, 0]
                denominator = torch.sqrt(pair.square().sum(-1) * target.square().sum(-1) + 1e-6)
                theta = theta + self.gain * torch.tanh(cross / denominator)
            cosine, sine = theta.cos(), theta.sin()
            rotated = torch.stack((cosine * pair[:, :, 0] - sine * pair[:, :, 1],
                                   sine * pair[:, :, 0] + cosine * pair[:, :, 1]), -1).flatten(1)
            state = retention[:, index] * rotated + (1-retention[:, index]) * drive[:, index]
            history.append(state)
        return self.norm(torch.stack(history, 1)) @ self.embedding.weight.T


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, required=True)
    parser.add_argument('--warmups', type=int, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    config = json.loads(args.config.read_text())
    torch.set_num_threads(config['threads'])
    torch.manual_seed(config['seeds'][0])
    proof = []
    for dynamic in [False, True]:
        base = pilot.PhaseLM(config['width'], dynamic).double()
        scripted = torch.jit.script(ScriptablePhase(base).double())
        tokens = torch.randint(256, (config['batch'], config['context']))
        targets = torch.randint(256, tokens.shape)
        a, b = base(tokens), scripted(tokens)
        assert torch.allclose(a, b, atol=1e-12, rtol=1e-12)
        F.cross_entropy(a.reshape(-1, 256), targets.flatten()).backward()
        F.cross_entropy(b.reshape(-1, 256), targets.flatten()).backward()
        other = dict(scripted.named_parameters())
        maximum_gradient_error = 0.0
        for name, parameter in base.named_parameters():
            assert torch.allclose(parameter.grad, other[name].grad, atol=1e-12, rtol=1e-10), name
            maximum_gradient_error = max(maximum_gradient_error, (parameter.grad-other[name].grad).abs().max().item())
        proof.append({'dynamic': dynamic, 'logit_max_error': (a-b).abs().max().item(),
                      'gradient_max_error': maximum_gradient_error})
    base = pilot.PhaseLM(config['width'], True).float()
    scripted = torch.jit.script(ScriptablePhase(base).float())
    modes = {'eager': base, 'scripted': scripted}
    tokens = torch.randint(256, (config['batch'], config['context']))
    targets = torch.randint(256, tokens.shape)
    def iteration(model):
        model.zero_grad(set_to_none=True)
        F.cross_entropy(model(tokens).reshape(-1, 256), targets.flatten()).backward()
    for model in modes.values():
        for _ in range(args.warmups):
            iteration(model)
    times = {name: [] for name in modes}
    rng = random.Random(config['seeds'][0])
    for _ in range(args.repeats):
        order = list(modes)
        rng.shuffle(order)
        for name in order:
            start = time.perf_counter()
            iteration(modes[name])
            times[name].append(time.perf_counter()-start)
    args.output.mkdir()
    pilot.shared.write(args.output/'RESULT.json', {
        'checks': proof, 'median_forward_backward_seconds': {name: statistics.median(values) for name, values in times.items()},
        'config_sha256': pilot.shared.prior.sha(args.config), 'source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'baseline_source_sha256': pilot.shared.prior.sha(Path(pilot.__file__)),
        'scope': 'Synthetic-batch CPU forward/backward timing, seeded paired order, concurrent training contention. No optimizer steps. Scripted token loop, not a fused CUDA kernel or block-parallel recurrence.',
        'official_test_read': False, 'weights_updated': False,
    })
    print((args.output/'RESULT.json').read_text(), flush=True)


if __name__ == '__main__':
    main()
