# Geometric recurrent-transition language pilot

Validation-only WikiText-2 byte model, three seeds, 300 updates, two learning rates. This is an exploratory local screen. Every training window and context reset is matched; compute and runtime are not matched. The official test is sealed.

| Model | Parameters | Validation CE | BPC |
|---|---:|---:|---:|
| fixed_rotation | 24928 | 2.35308 | 3.39477 |
| geometric_rotation | 24960 | 2.34585 | 3.38435 |
| transformer | 24976 | 2.59345 | 3.74156 |

Only the first 4,096 nonoverlapping validation target bytes are scored, with window resets. All architectures and LRs use that same subset. This is not exhaustive validation, independent confirmation, word-level perplexity, novelty evidence, or SOTA. More training and larger independent validation are required for a promising result.
