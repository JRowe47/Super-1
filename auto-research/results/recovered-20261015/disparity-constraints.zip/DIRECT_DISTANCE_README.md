# Direct-distance compression pilot

This experiment implements the agreed training-heavy, compact-inference design,
not the earlier coordinate-vector distance head. It is a bounded synthetic test.

## Mechanism

1. A symmetric table has one independently learned positive value per training
   example pair. Its diagonal is zero. Labels supervise classification through
   exemplar distances and close/far penalties; sampled triangle penalties are
   also applied. The table is not inferred from coordinates.
2. A compact function takes two **raw input examples** together and emits one
   scalar distance. Symmetrizing the pair-conditioned function guarantees
   symmetry. No learned endpoint embedding, Euclidean norm or coordinate
   reconstruction is used.
3. The distilled arm trains the function with classification CE plus regression
   to the training table. The direct arm uses the identical function with CE
   only. The dense classifier matches all deployed FP32 tensor bytes, including
   the eight fixed raw exemplars stored by each distance model.
4. Deployment discards the training table. Queries compare against the stored
   exemplars using generated distances. `Generator.stream` processes exemplars
   sequentially. `verify_direct_distance.vectorized` evaluates them together to
   exchange more working memory for lower latency.

The function is still parameterized by ordinary network weights. This tests a
compact representation of relationships, not extra independent storage bits.
Its hidden activations are pair-dependent, not separate concept coordinates.
Triangle inequalities and unseen-example constraints are not guaranteed.

## Reproduce

From `/Users/rohanarun/Documents/trin`, using Python with PyTorch (tested 2.8.0):

```bash
python3 experiments/disparity_constraints/test_direct_distance.py
python3 experiments/disparity_constraints/direct_distance.py --output experiments/disparity_constraints/direct-distance-replication
python3 experiments/disparity_constraints/verify_direct_distance.py experiments/disparity_constraints/direct-distance-replication
```

Choose a fresh output directory for training. The verifier can be rerun; it
checks existing deployment copies rather than changing their weights.

Configuration is in `direct_distance_config.json`. `run.py` supplies the existing
synthetic data generator. All hyperparameters are frozen before training in
`PROTOCOL.json`. Test scores are collected only after all validation-selected
winners are written to `FREEZE.json`; no post-test training or tuning occurs.

`deploy-audit2-<seed>-<arm>/model.pt` contains only deployed model tensors.
Its `queries.pt` is an audit input fixture, not part of model storage. Child
verification processes receive no teacher table or training labels. The
configuration and executable/runtime overhead are separate from tensor bytes.
PyTorch checkpoint files include serialization overhead, so equal raw tensor
bytes do not imply identical `.pt` file sizes.

The original training script's leaf-event memory estimate is superseded by
`VERIFICATION-v2.json`, which uses actual profiler allocation/free events.
These measure incremental CPU tensor storage, not total process RSS, allocator
reserve, Python overhead or GPU memory. Streaming generates one distance per
call; it also retains best-so-far state and temporary activations.

## Scope

Three seeds, two learning rates per arm, 1,000 full-batch updates each. Training
compute is intentionally not matched. All models can saturate this simple task;
tiny CE differences alone do not establish stronger concept capacity. A harder
task and calibration controls would be required before any scaling claim.
