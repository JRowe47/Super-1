# Reserved-region phase-budget confirmation

Each candidate trained for 3,000 updates (1,536,000 target-byte exposures).
Frozen checkpoints evaluated twice in FP32 on 65,536 reserved validation target bytes.

| Arm | Mean byte CE | BPC |
|---|---:|---:|
| fixed_rotation | 1.902504 | 2.744733 |
| geometric_rotation | 1.867734 | 2.694571 |
| fixed_overlapping | 1.894210 | 2.732768 |
| geometric_overlapping | 1.852210 | 2.672174 |
| transformer | 1.918192 | 2.767366 |

Per-seed geometry-minus-fixed CE: [-0.03504007775336504, -0.026329733431339264, -0.04294086713343859]

Parameters and training windows matched; FLOPs are not matched. Byte-level pilot, not word-level perplexity, novelty proof, original-hierarchy validation, or SOTA. Official test remains sealed.
