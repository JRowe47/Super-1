"""Read-only checkpoint audit; compare cloned implementations on train windows."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import torch
from torch.nn import functional as F
import precomputed_input_phase as optimized
import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--steps', type=int, required=True)
    args = parser.parse_args()
    assert args.steps > 0 and not args.output.exists()
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    candidates = json.loads((args.source/'CANDIDATES.json').read_text())
    row = next(row for row in candidates if row['arm'] == 'input_generated_overlapping')
    sha = pilot.shared.prior.sha
    for path, digest in protocol['checks']['source_hashes'].items():
        assert sha(Path(path)) == digest
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    checkpoint = args.source/Path(row['checkpoint']).name
    assert sha(checkpoint) == row['sha256']
    raw = (pilot.DATA/'train.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['train']
    data = torch.tensor(list(raw), dtype=torch.long)
    generator = torch.Generator().manual_seed(row['seed']+config['window_seed_offset'])
    def window():
        starts = torch.randint(len(data)-config['context']-1, (config['batch'],), generator=generator)
        return (torch.stack([data[start:start+config['context']] for start in starts]),
                torch.stack([data[start+1:start+config['context']+1] for start in starts]))
    state = torch.load(checkpoint, weights_only=True)
    base = optimized.source.InputGeneratedPhaseLM(config['width'], True).double()
    fast = optimized.PrecomputedInputPhaseLM(config['width'], True).double()
    for model in [base, fast]:
        model.load_state_dict(state)
    x, target = window()
    reference, actual = base(x), fast(x)
    output_error = (reference-actual).abs().max().item()
    assert torch.allclose(reference, actual, atol=1e-11, rtol=1e-11)
    for model, logits in [(base, reference), (fast, actual)]:
        F.cross_entropy(logits.flatten(0, 1), target.flatten()).backward()
    errors = {}
    for (name, left), (_, right) in zip(base.named_parameters(), fast.named_parameters()):
        assert torch.allclose(left.grad, right.grad, atol=1e-11, rtol=1e-10), name
        errors[name] = (left.grad-right.grad).abs().max().item()
    base, fast = base.float(), fast.float()
    optimizers = [torch.optim.AdamW(model.parameters(), lr=row['lr'], weight_decay=config['weight_decay']) for model in [base, fast]]
    trajectory = []
    for index in range(args.steps):
        x, target = window()
        losses = []
        for model, optimizer in zip([base, fast], optimizers):
            optimizer.zero_grad()
            loss = F.cross_entropy(model(x).flatten(0, 1), target.flatten())
            assert torch.isfinite(loss)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), config['gradient_clip'])
            optimizer.step()
            losses.append(loss.item())
        weight_error = max((left-right).abs().max().item() for left, right in zip(base.parameters(), fast.parameters()))
        trajectory.append({'step': index+1, 'loss_absolute_difference': abs(losses[0]-losses[1]), 'weight_max_absolute_difference': weight_error})
    assert sha(checkpoint) == row['sha256'], 'Source checkpoint was changed'
    args.output.mkdir()
    result = {'checkpoint_sha256': row['sha256'], 'audited_trial': {key: row[key] for key in ['seed', 'arm', 'lr', 'best_step']},
              'fp64_output_max_error': output_error, 'fp64_gradient_max_errors': errors,
              'fp32_cloned_training_trajectory': trajectory, 'active_training_changed': False,
              'source_checkpoint_unchanged': True, 'validation_read': False, 'official_test_read': False,
              'scope': 'First completed input-generated trial, not a selected sweep winner. Short cloned AdamW trajectory on sampled training windows; no long-run equivalence claim.',
              'source_sha256': {str(Path(path).resolve()): sha(Path(path)) for path in [__file__, optimized.__file__, optimized.source.__file__]}}
    (args.output/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'fp64_output_max_error': output_error, 'fp64_gradient_max_error': max(errors.values()),
                      'fp32_max_loss_difference': max(row['loss_absolute_difference'] for row in trajectory),
                      'fp32_max_weight_difference': max(row['weight_max_absolute_difference'] for row in trajectory),
                      'source_checkpoint_unchanged': True, 'steps': args.steps}))


if __name__ == '__main__':
    main()
