"""Fresh matched-budget test of bounded versus unconstrained generated rotations.

Reuse the audited window/training/selection protocol, without modifying it or
any active experiment. This tests a successor, not the original hierarchy.
"""
from pathlib import Path
import hashlib

import run_overlapping_phase as runner
import nonexpansive_phase_candidate as bounded


original_builders = runner.builders
original_checks = runner.candidate.checks


def builders(config):
    makes, width, ff = original_builders(config)
    makes['bounded_overlapping'] = lambda: bounded.NonexpansivePhaseLM(config['width'], True)
    return {name: makes[name] for name in config['arms']}, width, ff


def checks():
    return {
        'overlapping_checks': original_checks(),
        'bounded_checks': bounded.checks(),
        'source_hashes': {
            str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
            for path in [__file__, bounded.__file__]
        },
        'hypothesis': 'Bounding fixed-input state sensitivity preserves useful generated transport while reducing uncontrolled local expansion.',
        'limitation': 'No original-hierarchy, long-horizon stability, FLOP parity, novelty or SOTA claim.',
    }


if __name__ == '__main__':
    runner.builders = builders
    runner.candidate.checks = checks
    runner.main()
