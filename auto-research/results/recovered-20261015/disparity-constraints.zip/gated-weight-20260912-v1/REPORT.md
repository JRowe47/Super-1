# Learned weight-gate pilot

Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.

| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |
|---|---:|---:|---:|---:|---:|
| dense | 7300 | 0.11603 | 97.07% | 6.36 | 234 |
| factorized | 8132 | 0.14420 | 96.03% | 7.76 | 336 |
| static_gate | 8140 | 0.14459 | 96.03% | 40.39 | 16460 |
| input_gate | 8148 | 0.14690 | 96.14% | 78.08 | 20620 |

Gate parameters count toward storage. Inference generates connection tiles, not a full matrix; temporary allocations exclude model weights, allocator reserve and process RSS. Training can materialize all connections. The input gate is a four-scalar shared rule, not a general attention architecture. The static gate isolates a nonlinear reweighting without input conditioning. The ungated model uses efficient factored inference. Equal updates do not guarantee convergence or equal compute. No breakthrough or novelty claim.

Reproduce: python3 experiments/disparity_constraints/gated_weight_test.py --output NEW_DIRECTORY
