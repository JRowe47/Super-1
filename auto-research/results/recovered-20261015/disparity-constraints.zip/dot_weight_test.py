"""Directed weight dot products: local pilot, no input-distance teacher."""
import copy, hashlib, json, math, time
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
import capacity_sweep as shared

ROOT=Path(__file__).resolve().parent
C={'seeds':[1013,1061,1103,1151,1201],'caps_bytes':[8192,32768],
   'ranks':[4,16],'dense_width_fractions':[.75,1.0],'lrs':[.001,.01],
   'steps':2000,'validation_interval':200,'batch':64,'repeats':300,
   'digits_train_fraction':.6,'digits_validation_fraction':.2}

class Model(nn.Module):
    def __init__(self,h,rank=None):
        super().__init__();self.rank=rank
        if rank is None:self.weight=nn.Parameter(torch.randn(h,64)/8)
        else:
            self.q=nn.Parameter(torch.randn(h,rank)/math.sqrt(rank))
            self.k=nn.Parameter(torch.randn(64,rank)/8)
        self.bias=nn.Parameter(torch.zeros(h));self.output=nn.Linear(h,10)
    def forward(self,x,materialized=False):
        if self.rank is None:z=F.linear(x,self.weight,self.bias)
        elif materialized:z=F.linear(x,self.q@self.k.T,self.bias)
        else:z=(x@self.k)@self.q.T+self.bias
        return self.output(torch.tanh(z))

def size(h,r):return 4*((64*h if r is None else (64+h)*r)+h+10*h+10)
def score(m,data):
    with torch.inference_mode():
        logits=m(data[0]);return {'ce':F.cross_entropy(logits,data[1]).item(),'accuracy':(logits.argmax(-1)==data[1]).float().mean().item()}

def parity():
    torch.manual_seed(0);m=Model(23,4).double();x=torch.randn(7,64,dtype=torch.float64)
    a=m(x);g=torch.autograd.grad(a.square().sum(),tuple(m.parameters()))
    b=m(x,True);h=torch.autograd.grad(b.square().sum(),tuple(m.parameters()))
    assert torch.allclose(a,b,atol=1e-11,rtol=1e-10)
    assert all(torch.allclose(u,v,atol=1e-10,rtol=1e-9) for u,v in zip(g,h))
    # Aligned, orthogonal, and opposite vectors yield positive, zero, negative.
    q=torch.tensor([[1.,0.]]);k=torch.tensor([[1.,0.],[0.,1.],[-1.,0.]])
    assert torch.equal(q@k.T,torch.tensor([[1.,0.,-1.]]))
    return {'float64_forward_max_error':(a-b).abs().max().item(),'gradient_parity':True,'signed_alignment':True}

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    out=args.output;out.mkdir(parents=True,exist_ok=False)
    shared.write(out/'PROTOCOL.json',{'config':C,'parity':parity(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'claim':'Dot-product-generated directed weight matrix Q K^T, not distances between inputs. Algebraically a low-rank linear factorization, not a novelty claim.',
        'controls':'Same-byte dense model; same-width full dense model, explicitly larger. Each arm gets two architectures and two LRs. Classification CE only. No teacher, learned gate, exemplars, or attention added.',
        'selection':'Validation CE; all selected models frozen before held-out assessment. Digits is previously used development data; no independent confirmation.',
        'cloud_resources_created':0})
    records=[];chosen=[]
    for seed in C['seeds']:
        (train,valid,_),meta=shared.data('digits',seed,C)
        shared.write(out/f'data-{seed}.json',meta)
        for cap in C['caps_bytes']:
            widths={r:max(h for h in range(1,cap//4) if size(h,r)<=cap) for r in C['ranks']}
            dense_max=(cap//4-10)//75
            specs={'factorized':[(widths[r],r) for r in C['ranks']],
                   'dense_same_bytes':[(max(1,int(dense_max*f)),None) for f in C['dense_width_fractions']],
                   'dense_same_width':[(widths[r],None) for r in C['ranks']]}
            for arm,shapes in specs.items():
                candidates=[]
                for h,rank in shapes:
                    for lr in C['lrs']:
                        torch.manual_seed(seed);m=Model(h,rank);opt=torch.optim.Adam(m.parameters(),lr=lr)
                        rng=torch.Generator().manual_seed(seed+30000);history=[];best=float('inf');start=time.perf_counter()
                        for step in range(1,C['steps']+1):
                            ids=torch.randint(len(train[0]),(C['batch'],),generator=rng)
                            for group in opt.param_groups:group['lr']=lr*(.1+.9*.5*(1+math.cos(math.pi*step/C['steps'])))
                            opt.zero_grad();loss=F.cross_entropy(m(train[0][ids]),train[1][ids]);assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5);opt.step()
                            if step%C['validation_interval']==0:
                                val=score(m,valid);history.append({'step':step,**val})
                                if val['ce']<best:best=val['ce'];state=copy.deepcopy(m.state_dict());best_step=step
                        path=out/f'{seed}-{cap}-{arm}-{h}-{rank}-{lr}.pt';torch.save(state,path)
                        m.load_state_dict(state);n=sum(v.numel()*v.element_size() for v in state.values());assert n==size(h,rank)
                        if arm!='dense_same_width':assert n<=cap
                        row={'seed':seed,'cap':cap,'arm':arm,'width':h,'rank':rank,'lr':lr,'bytes':n,'checkpoint':str(path.resolve()),'sha256':shared.prior.sha(path),'validation':score(m,valid),'best_step':best_step,'history':history,'seconds':time.perf_counter()-start}
                        records.append(row);candidates.append(row);shared.write(out/'CANDIDATES.json',records)
                chosen.append(min(candidates,key=lambda r:r['validation']['ce']))
                print(json.dumps({'completed':len(records),'total':len(C['seeds'])*len(C['caps_bytes'])*12}),flush=True)
    shared.write(out/'FREEZE.json',chosen)
    result=[]
    for row in chosen:
        (_,valid,test),_=shared.data('digits',row['seed'],C);m=Model(row['width'],row['rank']);path=Path(row['checkpoint']);assert shared.prior.sha(path)==row['sha256'];m.load_state_dict(torch.load(path,weights_only=True));assert score(m,valid)==row['validation']
        r=copy.deepcopy(row);r['heldout']=score(m,test);assert score(m,test)==r['heldout']
        r['runtime']=shared.profile_call(lambda:m(valid[0][:1]),C['repeats'])
        if row['rank'] is not None:
            with torch.inference_mode():
                a=m(test[0]);b=m(test[0],True);r['materialization_max_logit_error']=(a-b).abs().max().item();r['materialization_prediction_mismatches']=(a.argmax(-1)!=b.argmax(-1)).sum().item();assert r['materialization_prediction_mismatches']==0
            r['materialized_runtime']=shared.profile_call(lambda:m(valid[0][:1],True),C['repeats'])
        result.append(r)
    shared.write(out/'RESULT.json',result)
    shared.write(out/'COMPLETION.json',{'candidates':len(records),'selected':len(result),'cloud_resources_created':0,'confirmation_dataset_loaded':False})

if __name__=='__main__':main()
