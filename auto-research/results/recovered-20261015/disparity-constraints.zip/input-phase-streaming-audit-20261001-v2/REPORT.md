# Trained input-generated rotation streaming audit

This is an implementation and deployment-tensor audit, not an accuracy promotion or SOTA result. It uses the first completed seed-2503 checkpoint for each arm, not the eventual canonically selected sweep winners. No validation or official test data was read.

| Measurement | Input-generated rotation | Matched-parameter Transformer |
| --- | ---: | ---: |
| FP32 weight tensor bytes | 265,728 | 265,704 |
| Persistent state at 128 tokens, batch 1 | 512 | 71,680 |
| Weights plus persistent state bytes | 266,240 | 337,384 |
| Maximum full-forward vs incremental logit error | 0.000003815 | 0.000006199 |
| Median CPU microseconds/token | 81.34 | 55.88 |

The recurrent adapter retains one hidden vector; the Transformer adapter retains the actual projected keys and values. Persistent state is 140 times smaller. Including weights, measured tensor storage is 21.1% smaller, not 140 times smaller. Temporary activations, allocator overhead, and runtime libraries are excluded.

Both adapters passed FP32 numerical parity at the configured absolute and relative tolerances of 0.00001. Checkpoint and sealed training-source hashes were verified; source checkpoints remained unchanged. Exact checkpoint hashes and adapter hashes are in RESULT.json.

Timing comprises ten batch-one synthetic-token decoding repeats after one warmup. Both training experiments were running concurrently. The input-generated Python adapter was approximately 45.6% slower in this CPU measurement. This is not GPU latency, peak memory, or an isolated production benchmark. Training and checkpoint selection were not altered.

Next accuracy decision remains the predeclared three-seed, equal-learning-rate-budget sweep followed by frozen-checkpoint duplicate FP32 evaluation of the reserved validation region. Parameter and token budgets are matched; FLOPs are not. Official test access remains prohibited at this stage.
