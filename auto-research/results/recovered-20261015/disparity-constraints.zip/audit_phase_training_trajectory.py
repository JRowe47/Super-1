"""Measure multi-step numerical drift; no exact-equivalence claim or promotion."""
import argparse
import hashlib
import json
import math
from pathlib import Path

import torch
from torch.nn import functional as F
import phase_transition_language as pilot
import compiled_phase_training_canary as implementation


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--steps', type=int, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.steps > 0
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    raw = (pilot.DATA/'train.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['train']
    train = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    pilot.shared.write(args.output/'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source/'FREEZE.json'),
        'compiled_implementation_sha256': pilot.shared.prior.sha(Path(implementation.__file__)),
        'audit_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'steps': args.steps, 'precision': 'FP32', 'base_lr': max(config['lrs']),
        'scope': 'Copied frozen checkpoints, fresh identical AdamW state, identical real training windows, original cosine LR schedule and clipping. Continuous drift measurements, no acceptance threshold or promotion. Source weights never changed.',
        'official_test_read': False, 'validation_read': False,
    })
    result = []
    for row in json.loads((args.source/'FREEZE.json').read_text()):
        if row['arm'] == 'transformer':
            continue
        path = args.source/Path(row['checkpoint']).name
        assert pilot.shared.prior.sha(path) == row['sha256']
        reference = pilot.PhaseLM(config['width'], row['arm']=='geometric_rotation').float()
        reference.load_state_dict(torch.load(path, weights_only=True))
        compiled = torch.jit.script(implementation.ScriptablePhase(reference).float())
        models = [reference, compiled]
        parameters = [dict(model.named_parameters()) for model in models]
        assert set(parameters[0]) == set(parameters[1])
        optimizers = [torch.optim.AdamW(model.parameters(), lr=max(config['lrs']), weight_decay=.01) for model in models]
        generator = torch.Generator().manual_seed(row['seed']+10000)
        history = []
        for step in range(1, args.steps+1):
            indices = torch.randint(len(train)-config['context']-1, (config['batch'],), generator=generator)
            inputs = torch.stack([train[i:i+config['context']] for i in indices])
            targets = torch.stack([train[i+1:i+config['context']+1] for i in indices])
            losses = []
            for model, optimizer in zip(models, optimizers):
                for group in optimizer.param_groups:
                    group['lr'] = max(config['lrs']) * (.1+.9*.5*(1+math.cos(math.pi*step/config['steps'])))
                optimizer.zero_grad(set_to_none=True)
                loss = F.cross_entropy(model(inputs).reshape(-1, 256), targets.flatten())
                assert torch.isfinite(loss)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step()
                losses.append(loss.item())
            error = max((parameters[0][name]-parameters[1][name]).abs().max().item() for name in parameters[0])
            history.append({'step': step, 'loss_difference': abs(losses[0]-losses[1]), 'weight_max_error': error})
        # A scripted graph that has executed backward must receive normal
        # tensors here; inference-mode tensors can violate its saved graph.
        with torch.no_grad():
            logit_error = (reference(inputs)-compiled(inputs)).abs().max().item()
        numerator = sum((parameters[0][name]-parameters[1][name]).double().square().sum().item() for name in parameters[0])
        denominator = sum(parameter.double().square().sum().item() for parameter in parameters[0].values())
        assert pilot.shared.prior.sha(path) == row['sha256']
        result.append({'seed': row['seed'], 'arm': row['arm'], 'checkpoint_sha256': row['sha256'],
                       'history': history, 'max_step_loss_difference': max(h['loss_difference'] for h in history),
                       'max_weight_error': max(h['weight_max_error'] for h in history),
                       'final_relative_parameter_l2_error': math.sqrt(numerator/denominator),
                       'final_batch_logit_max_error': logit_error})
        pilot.shared.write(args.output/'RESULT.json', result)
        print(json.dumps({key: value for key, value in result[-1].items() if key!='history'}), flush=True)
    pilot.shared.write(args.output/'COMPLETION.json', {'checkpoints': len(result), 'official_test_read': False,
                                                      'validation_read': False, 'source_weights_changed': False})


if __name__ == '__main__':
    main()
