# Geometric recurrent-transition language pilot

Validation-only WikiText-2 byte model, three seeds, 3,000 updates, two learning rates. Each trial received 1,536,000 training target-byte exposures. This is an exploratory local screen. Every training window and context reset is matched; compute and runtime are not matched. The official test is sealed.

| Model | Parameters | Validation CE | BPC |
|---|---:|---:|---:|
| fixed_rotation | 24928 | 2.01386 | 2.90538 |
| geometric_rotation | 24960 | 1.97920 | 2.85538 |
| transformer | 24976 | 2.02958 | 2.92807 |

The table scores the first 16,384 nonoverlapping validation target bytes, with window resets. All architectures and LRs use that same selection subset. This is not exhaustive validation, independent confirmation, word-level perplexity, novelty evidence, or SOTA. Independent reserved-region results are recorded separately in phase-language-validation-20261001-v2/REPORT.md.

Budget-label correction: the shared pilot report template contained the original 300-update/4,096-byte labels. This report was corrected after terminal completion against the sealed PROTOCOL.json; no training code, checkpoint, or metric was changed.
