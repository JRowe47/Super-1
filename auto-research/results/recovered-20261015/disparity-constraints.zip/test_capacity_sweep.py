import json
from pathlib import Path
import unittest
import torch
import capacity_sweep as s


class SweepChecks(unittest.TestCase):
    def setUp(self):
        self.c = json.loads(Path(__file__).with_name('capacity_config.json').read_text())
        torch.set_num_threads(1)

    def test_caps_and_identical_initializations(self):
        for task in self.c['tasks']:
            splits, metadata = s.data(task, 17, self.c)
            x, y = splits[0]
            classes = int(y.max())+1
            anchors = torch.stack([x[torch.where(y == i)[0][0]] for i in range(classes)])
            self.assertEqual(len(set(y.tolist())), classes)
            for cap in self.c['scalar_budgets']:
                models = {}
                for arm in self.c['arms']:
                    torch.manual_seed(17)
                    model = s.Student(self.c, x.shape[-1], classes, cap, arm, anchors)
                    self.assertLessEqual(s.prior.scalars(model), cap)
                    self.assertGreater(s.prior.scalars(model), cap*.90)
                    self.assertEqual(model(x[:2]).shape, (2, classes))
                    models[arm] = model
                for a, b in [('dense', 'dense_teacher'), ('direct', 'distilled')]:
                    self.assertTrue(all(torch.equal(v, models[b].state_dict()[k]) for k,v in models[a].state_dict().items()))
                g = models['distilled']
                self.assertTrue(torch.equal(g.distance(x[:2], x[2:4]), g.distance(x[2:4], x[:2])))
                self.assertTrue(torch.equal(g(x[:2]).argmax(-1), g.stream(x[:2])))

    def test_auxiliary_is_not_deployed(self):
        c = self.c
        m = s.Student(c, 16, 8, min(c['scalar_budgets']), 'dense_teacher', torch.zeros(8,16))
        aux = s.Auxiliary(m.shape[-1], c['auxiliary_width'])
        x, z = torch.randn(3,16), torch.randn(3,16)
        loss = aux(m.encoder(x), m.encoder(z)).mean()
        loss.backward()
        self.assertGreater(sum(p.grad.abs().sum().item() for p in m.encoder.parameters()),0)
        self.assertFalse(any('aux' in key for key in m.state_dict()))


if __name__ == '__main__':
    unittest.main()
