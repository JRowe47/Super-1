# Independent larger-scale phase-key replication

The 66K comparison confirmed a small 0.178% incremental mean CE gain over geometry across three seeds on a predeclared reserved validation region. That is not SOTA or novelty. Test whether the mechanism survives fresh seeds and larger capacity, rather than expanding claims from that result.

Use width 256, fresh seeds 3109/3163/3217, 6,000 steps, batch four, context 128, two learning rates per arm (0.001/0.003), and four arms: learned phase keys, existing geometry, fixed overlapping rotations, and a parameter-rematched Transformer. All arms receive identical sampled training windows per seed and 3,072,000 target-byte exposures per trial. No transfer, reused seeds, or imported checkpoint. Match parameter counts within 2%, not FLOPs. Compute/runtime differences remain reportable limitations.

Retain the exact trained mechanism; only the Transformer parameter-search ceiling must grow with target capacity. Preserve all prior sealed source files and evidence. Run a synthetic full-width candidate canary before launching one local sweep; no cloud resources.

Freeze steps and learning rates using the existing first 16,384 validation bytes. After all 24 trials complete, evaluate all 12 selected checkpoints twice in FP32 on 65,536 validation bytes starting at 1,048,576. This region is disjoint from the recent confirmation regions; it is not a new dataset or an official test. Verify source/data/checkpoint hashes and complete coverage. Advance only if keys beat existing geometry and fixed rotations in every seed, without duplicate drift. Report all other comparisons and negative results without cherry-picking. Keep the official test sealed.

Even a positive result would remain one byte-level dataset and one context size. Multi-task evidence, rigorous compute matching, inference deployment benchmarks, and protocol-compatible published targets remain necessary for a breakthrough claim.
