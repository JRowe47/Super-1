"""Mechanism checks; no cloud or model training required."""
import json
from pathlib import Path
import unittest
import torch
import direct_distance as d


class DirectDistanceTests(unittest.TestCase):
    def setUp(self):
        self.c = json.loads(Path(__file__).with_name('direct_distance_config.json').read_text())
        torch.set_num_threads(1)
        self.x = torch.randn(12, self.c['input_dim'])
        anchors = torch.randn(self.c['classes'], self.c['input_dim'])
        self.model = d.Generator(self.c, anchors)

    def test_direct_distance_properties_and_gradient(self):
        z = self.x.roll(1, 0)
        distance = self.model.distance(self.x, z)
        self.assertTrue(torch.equal(distance, self.model.distance(z, self.x)))
        self.assertTrue((distance > 0).all())
        self.assertTrue((self.model.distance(self.x, self.x) == 0).all())
        distance.sum().backward()
        self.assertGreater(sum(p.grad.abs().sum().item() for p in self.model.pair.parameters()), 0)
        self.assertFalse(any(isinstance(m, torch.nn.Embedding) for m in self.model.modules()))

    def test_streaming_and_storage(self):
        baseline = d.Dense(self.c, d.scalars(self.model))
        self.assertEqual(d.scalars(baseline), d.scalars(self.model))
        self.assertIn('anchors', self.model.state_dict())
        with torch.inference_mode():
            self.assertTrue(torch.equal(self.model(self.x).argmax(-1), self.model.stream(self.x, 1)))

    def test_table_is_independently_parameterized(self):
        table = d.DistanceTable(12, self.c['initial_scale'])
        self.assertEqual(table.raw.numel(), 12*11//2)
        distance = table()
        self.assertTrue(torch.equal(distance, distance.T))
        self.assertTrue((distance.diag() == 0).all())
        distance[0, 1].backward()
        self.assertEqual(int((table.raw.grad != 0).sum()), 1)


if __name__ == '__main__':
    unittest.main()
