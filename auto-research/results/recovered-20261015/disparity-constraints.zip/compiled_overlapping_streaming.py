"""Parity-gated compiled incremental deployment of frozen overlapping geometry."""
import argparse
import copy
import importlib
import json
import random
import statistics
import time
from pathlib import Path
from typing import Tuple

import torch
from torch import nn
import run_input_generated_phase as factory
import audit_phase_streaming as baseline
import compiled_transformer_streaming as compiled_control


class OverlappingStep(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.embedding = copy.deepcopy(model.embedding)
        self.drive = copy.deepcopy(model.drive)
        self.write = copy.deepcopy(model.write)
        self.norm = copy.deepcopy(model.norm)
        for name in ['angle', 'gain', 'second_angle', 'second_gain', 'retention']:
            setattr(self, name, nn.Parameter(getattr(model, name).detach().clone(), requires_grad=False))

    def bank(self, state: torch.Tensor, drive: torch.Tensor, angle: torch.Tensor,
             gain: torch.Tensor, offset: int) -> torch.Tensor:
        pair = torch.roll(state, shifts=offset, dims=-1).reshape(state.shape[0], -1, 2)
        target = torch.roll(drive, shifts=offset, dims=-1).reshape(state.shape[0], -1, 2)
        cross = pair[:, :, 0]*target[:, :, 1]-pair[:, :, 1]*target[:, :, 0]
        denominator = torch.sqrt(pair.square().sum(-1)*target.square().sum(-1)+1e-6)
        theta = angle+gain*torch.tanh(cross/denominator)
        cosine, sine = theta.cos(), theta.sin()
        rotated = torch.stack((cosine*pair[:, :, 0]-sine*pair[:, :, 1],
                               sine*pair[:, :, 0]+cosine*pair[:, :, 1]), -1).flatten(1)
        return torch.roll(rotated, shifts=-offset, dims=-1)

    def forward(self, token: torch.Tensor, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        embedded = self.embedding(token)
        drive = torch.tanh(self.drive(embedded))
        retention = torch.sigmoid(self.write(embedded)+self.retention)
        transported = self.bank(state, drive, self.angle, self.gain, 0)
        transported = self.bank(transported, drive, self.second_angle, self.second_gain, 1)
        updated = retention*transported+(1-retention)*drive
        return self.norm(updated)@self.embedding.weight.T, updated


def stream(step, tokens, width):
    state = torch.zeros((len(tokens), width), dtype=torch.float32)
    outputs = []
    for index in range(tokens.shape[1]):
        logits, state = step(tokens[:, index], state)
        outputs.append(logits)
    return torch.stack(outputs, 1), state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, required=True)
    parser.add_argument('--warmups', type=int, required=True)
    parser.add_argument('--parity-atol', type=float, required=True)
    parser.add_argument('--candidate-arm', choices=['geometric_overlapping', 'relative_phase_key'], default='geometric_overlapping')
    parser.add_argument('--factory-module', choices=['run_input_generated_phase', 'run_relative_phase_key'], default='run_input_generated_phase')
    args = parser.parse_args()
    factory = importlib.import_module(args.factory_module)
    candidate_arm = args.candidate_arm
    assert not args.output.exists() and args.repeats > 0 and args.warmups >= 0
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    frozen = json.loads((args.source/'FREEZE.json').read_text())
    sha = factory.runner.pilot.shared.prior.sha
    for path, digest in protocol['checks']['source_hashes'].items():
        assert sha(Path(path)) == digest
    for path, key in [(factory.runner.pilot.__file__, 'source_sha256'),
                      (factory.runner.__file__, 'runner_source_sha256'),
                      (factory.runner.candidate.__file__, 'candidate_source_sha256')]:
        assert sha(Path(path)) == protocol[key]
    config = protocol['config']
    factory.runner.pilot.C.update(config)
    makes, _, _ = factory.builders(config)
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(config['seeds'][0])
    order_rng = random.Random(config['seeds'][0])
    tokens = torch.randint(256, (1, config['context']))
    args.output.mkdir()
    factory.runner.pilot.shared.write(args.output/'PROTOCOL.json', {
        'source_freeze_sha256': sha(args.source/'FREEZE.json'), 'deployment_source_sha256': sha(Path(__file__)),
        'baseline_adapter_sha256': sha(Path(baseline.__file__)),
        'compiled_control_source_sha256': sha(Path(compiled_control.__file__)), 'repeats': args.repeats, 'warmups': args.warmups,
        'parity_atol': args.parity_atol, 'timing_order': 'Seeded shuffled paired modes per seed',
        'scope': 'FP32 CPU batch-one synthetic incremental decoding; eager and frozen TorchScript adapters for both geometry and projected-KV Transformer. Includes Python token loop. Concurrent training contention; not GPU or peak-memory evidence.',
        'official_test_read': False, 'validation_read': False})
    rows = []
    with torch.inference_mode():
        for seed in config['seeds']:
            entry = next(row for row in frozen if row['seed']==seed and row['arm']==candidate_arm)
            control = next(row for row in frozen if row['seed']==seed and row['arm']=='transformer')
            models = []
            for arm, row in [(candidate_arm, entry), ('transformer', control)]:
                checkpoint = args.source/Path(row['checkpoint']).name
                assert sha(checkpoint) == row['sha256']
                model = makes[arm]().float().eval()
                model.load_state_dict(torch.load(checkpoint, weights_only=True))
                assert sum(parameter.numel() for parameter in model.parameters()) == protocol['parameters'][arm]
                models.append(model)
            geometric, transformer = models
            if candidate_arm == 'relative_phase_key':
                from compiled_phase_key_streaming import PhaseKeyStep
                eager = PhaseKeyStep(geometric).eval()
            else:
                eager = OverlappingStep(geometric).eval()
            assert sum(parameter.numel() for parameter in eager.parameters()) == protocol['parameters'][candidate_arm]
            scripted = torch.jit.freeze(torch.jit.script(eager))
            tf_eager = compiled_control.TransformerStep(transformer).eval()
            assert sum(parameter.numel() for parameter in tf_eager.parameters()) == protocol['parameters']['transformer']
            tf_scripted = torch.jit.freeze(torch.jit.script(tf_eager))
            maximum_full_error, maximum_script_error = 0.0, 0.0
            tf_max_full_error, tf_max_script_error = 0.0, 0.0
            for batch in [1, 3]:
                for length in [1, 17, config['context']]:
                    probe = torch.randint(256, (batch, length))
                    full = geometric(probe)
                    a, state_a = stream(eager, probe, config['width'])
                    b, state_b = stream(scripted, probe, config['width'])
                    assert torch.allclose(full, a, atol=args.parity_atol, rtol=args.parity_atol)
                    assert torch.allclose(a, b, atol=args.parity_atol, rtol=args.parity_atol)
                    assert torch.allclose(state_a, state_b, atol=args.parity_atol, rtol=args.parity_atol)
                    maximum_full_error = max(maximum_full_error, (full-a).abs().max().item())
                    maximum_script_error = max(maximum_script_error, (a-b).abs().max().item())
                    tf_full_probe = transformer(probe)
                    tf_a, tf_state_a = compiled_control.stream(tf_eager, probe, transformer.embedding.embedding_dim, tf_eager.heads)
                    tf_b, tf_state_b = compiled_control.stream(tf_scripted, probe, transformer.embedding.embedding_dim, tf_eager.heads)
                    assert torch.allclose(tf_full_probe, tf_a, atol=args.parity_atol, rtol=args.parity_atol)
                    assert torch.allclose(tf_a, tf_b, atol=args.parity_atol, rtol=args.parity_atol)
                    assert all(torch.allclose(left, right, atol=args.parity_atol, rtol=args.parity_atol)
                               for left, right in zip(tf_state_a, tf_state_b))
                    tf_max_full_error = max(tf_max_full_error, (tf_full_probe-tf_a).abs().max().item())
                    tf_max_script_error = max(tf_max_script_error, (tf_a-tf_b).abs().max().item())
            tf_full = transformer(tokens)
            tf_actual, tf_state = baseline.stream(transformer, tokens, baseline.transformer_step)
            assert torch.allclose(tf_full, tf_actual, atol=args.parity_atol, rtol=args.parity_atol)
            modes = {'geometry_eager': lambda: stream(eager, tokens, config['width']),
                     'geometry_scripted': lambda: stream(scripted, tokens, config['width']),
                     'transformer_eager_kv': lambda: compiled_control.stream(tf_eager, tokens, transformer.embedding.embedding_dim, tf_eager.heads),
                     'transformer_scripted_kv': lambda: compiled_control.stream(tf_scripted, tokens, transformer.embedding.embedding_dim, tf_eager.heads)}
            for mode in modes.values():
                for _ in range(args.warmups):
                    mode()
            timings = {name: [] for name in modes}
            for _ in range(args.repeats):
                order = list(modes)
                order_rng.shuffle(order)
                for name in order:
                    begin = time.perf_counter()
                    modes[name]()
                    timings[name].append((time.perf_counter()-begin)*1e6/config['context'])
            scripted.save(str(args.output/f'{seed}-geometry-scripted.pt'))
            tf_scripted.save(str(args.output/f'{seed}-transformer-scripted.pt'))
            result = {'seed': seed, 'geometry_sha256': entry['sha256'], 'transformer_sha256': control['sha256'],
                      'scripted_artifact_sha256': sha(args.output/f'{seed}-geometry-scripted.pt'),
                      'transformer_scripted_artifact_sha256': sha(args.output/f'{seed}-transformer-scripted.pt'),
                      'full_vs_eager_max_error': maximum_full_error, 'scripted_vs_eager_max_error': maximum_script_error,
                      'transformer_full_vs_eager_max_error': tf_max_full_error,
                      'transformer_scripted_vs_eager_max_error': tf_max_script_error,
                      'median_cpu_us_per_token': {name: statistics.median(values) for name, values in timings.items()},
                      'state_bytes': {'geometry': config['width']*4, 'transformer': baseline.bytes_of(tf_state)}}
            rows.append(result)
            factory.runner.pilot.shared.write(args.output/'RESULT.json', rows)
            print(json.dumps(result), flush=True)
            for row in [entry, control]:
                assert sha(args.source/Path(row['checkpoint']).name) == row['sha256']
    factory.runner.pilot.shared.write(args.output/'COMPLETION.json', {'seeds': len(rows), 'checkpoint_weights_unchanged': True,
        'validation_read': False, 'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
