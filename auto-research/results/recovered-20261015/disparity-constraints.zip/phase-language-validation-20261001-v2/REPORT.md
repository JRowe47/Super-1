# Reserved-region phase-budget confirmation

Each candidate trained for 3,000 updates (1,536,000 target-byte exposures).
Frozen checkpoints evaluated twice in FP32 on 65,536 reserved validation target bytes.

| Arm | Mean byte CE | BPC |
|---|---:|---:|
| fixed_rotation | 1.956538 | 2.822688 |
| geometric_rotation | 1.919412 | 2.769126 |
| transformer | 1.973931 | 2.847780 |

Per-seed geometry-minus-fixed CE: [-0.046351672150194645, -0.02662115916609764, -0.03840574622154236]

Parameters and training windows matched; FLOPs are not matched. Byte-level pilot, not word-level perplexity, novelty proof, original-hierarchy validation, or SOTA. Official test remains sealed.
