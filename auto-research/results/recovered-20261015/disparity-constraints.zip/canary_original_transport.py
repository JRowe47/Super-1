"""Check actual native-hierarchy transport costs before a streaming experiment."""
import argparse
import json
import random
import statistics
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import original_hierarchy_transport as candidate
import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    config = json.loads(args.config.read_text())
    torch.set_num_threads(config['threads'])
    checks = candidate.checks()
    def base():
        return candidate.authoritative.PersistentMultiScaleLM(config['vocab'], config['hierarchy_width'], config['state_scales'])
    makes = {
        'original': base,
        'fixed_transport': lambda: candidate.GeometricHierarchy(base(), False),
        'geometric_transport': lambda: candidate.GeometricHierarchy(base(), True),
        'transformer': lambda: candidate.authoritative.DenseRoPETransformer(
            config['vocab'], config['transformer_width'], config['transformer_heads'],
            config['transformer_layers'], config['context']+config['transformer_prefix']),
    }
    models = {}
    for arm, make in makes.items():
        torch.manual_seed(config['seeds'][0])
        models[arm] = make()
    counts = {arm: pilot.count(model) for arm, model in models.items()}
    assert max(counts.values())/min(counts.values()) < config['maximum_parameter_ratio']
    torch.manual_seed(config['seeds'][0])
    inputs = torch.randint(config['vocab'], (config['batch'], config['context']))
    prefix = torch.randint(config['vocab'], (config['batch'], config['transformer_prefix']))
    targets = torch.randint(config['vocab'], inputs.shape)
    def iteration(arm):
        model = models[arm]
        model.zero_grad(set_to_none=True)
        if arm == 'transformer':
            logits = model(torch.cat((prefix, inputs), 1))[:, -config['context']:]
        else:
            logits = model(inputs)
        loss = F.cross_entropy(logits.reshape(-1, config['vocab']), targets.flatten())
        assert torch.isfinite(loss)
        loss.backward()
        assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        if arm == 'geometric_transport':
            assert model.gain.grad.abs().sum() > 0
    for arm in models:
        for _ in range(config['warmups']):
            iteration(arm)
    times = {arm: [] for arm in models}
    rng = random.Random(config['seeds'][0])
    for _ in range(config['canary_repeats']):
        order = list(models)
        rng.shuffle(order)
        for arm in order:
            start = time.perf_counter()
            iteration(arm)
            times[arm].append(time.perf_counter()-start)
    args.output.mkdir()
    result = {
        'config': config, 'checks': checks, 'parameters': counts,
        'median_forward_backward_seconds': {arm: statistics.median(values) for arm, values in times.items()},
        'config_sha256': pilot.shared.prior.sha(args.config),
        'canary_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'transport_source_sha256': pilot.shared.prior.sha(Path(candidate.__file__)),
        'authoritative_wrapper_sha256': pilot.shared.prior.sha(candidate.SOURCE),
        'authoritative_core_sha256': pilot.shared.prior.sha(candidate.authoritative.AUTHORITATIVE_MULTISCALE_PATH),
        'authoritative_transformer_sha256': pilot.shared.prior.sha(candidate.authoritative.AUTHORITATIVE_TRANSFORMER_PATH),
        'scope': 'Synthetic local CPU canary with concurrent training contention. No optimizer steps, no accuracy claim, no dataset access, not a fused kernel.',
        'training_started': False, 'official_test_read': False,
    }
    pilot.shared.write(args.output/'RESULT.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
