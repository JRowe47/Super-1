# Full-batch disparity constraints experiment

Eight synthetic concepts have context-dependent surface features. Noise and nuisance combinations vary. Training, validation, and test use disjoint nuisance combinations. This is a synthetic classification/interference test, not a language-model benchmark.

Every update uses every example in the current training set. The constrained model also uses every unordered training pair, with per-pair nonnegative multipliers, a quadratic violation penalty, and unit-norm embeddings. Different labels repel and same labels attract. Class labels define compatibility in this task; it is not a claim that all distinct real-world concepts should repel.

All arms receive the same two learning-rate candidates and optimizer-step budgets. Validation CE selects the learning rate and checkpoint; test is evaluated only afterward. Parameters are approximately matched; FLOPs and wall time are not. Constraint constants are fixed in advance, not tuned on the test set.

## Joint learning

| Model | Parameters | Test accuracy | Test CE | Conflicting-partner error | Training constraints satisfied | Worst squared-distance violation |
|---|---:|---:|---:|---:|---:|---:|
| dense | 608 | 100.00% | 0.0016 | 0.00% | N/A | N/A |
| distance | 607 | 99.80% | 0.0059 | 0.20% | 85.44% | 0.834612 |
| constrained_distance | 607 | 100.00% | 0.0014 | 0.00% | 99.86% | 0.090732 |

## New-concept interference

Pretrain on six classes, then add two classes. All arms use identical rehearsal examples; validation includes all classes during adaptation. The fixed-final-step columns prevent checkpoint selection from hiding eventual forgetting. Forgetting is old-class accuracy before adaptation minus afterward; negative values indicate improvement.

| Rehearsal per old class | Model | Old accuracy before | Old accuracy selected | New accuracy selected | Forgetting selected (pp) | Old accuracy final step | New accuracy final step |
|---:|---|---:|---:|---:|---:|---:|---:|
| 0 | dense | 100.00 | 100.00 | 100.00 | 0.00 | 100.00 | 100.00 |
| 0 | distance | 100.00 | 50.00 | 86.20 | 50.00 | 50.00 | 100.00 |
| 0 | constrained_distance | 100.00 | 65.28 | 100.00 | 34.72 | 60.07 | 100.00 |
| 4 | dense | 100.00 | 100.00 | 100.00 | 0.00 | 100.00 | 100.00 |
| 4 | distance | 100.00 | 88.80 | 100.00 | 11.20 | 88.80 | 100.00 |
| 4 | constrained_distance | 100.00 | 86.02 | 100.00 | 13.98 | 91.32 | 100.00 |

All values are means over three seeds except the worst violation. Full per-seed results, constraint coverage, held-out geometry, learning curves, checkpoint hashes, and data hashes are in RESULT.json and PROTOCOL.json. Data-generation mappings also vary by seed. No statistical significance or additional independent information capacity is claimed.

## Full replay: all old and new training inputs together

This supplementary control was declared after the primary results, before its training. It reuses the frozen configuration, selected pretraining learning rates, and 250-step adaptation budget. It presents all 256 training examples every update, with all 32,640 unordered relationships in the constrained arm. No original experiment was modified or retuned. The supplementary protocol and results are in full-replay/.

| Model | Old-class test accuracy | New-class test accuracy | Overall test CE |
|---|---:|---:|---:|
| Ordinary dense | 100.00% | 100.00% | 0.002207 |
| Distance, unconstrained | 99.91% | 100.00% | 0.002604 |
| Distance, constrained | 100.00% | 100.00% | 0.001459 |

The constrained model has lower mean CE than dense here, but does not win CE in every seed. Accuracy is saturated; this small task cannot establish a capacity advantage.

## Findings and limits

Explicit constraints organized the learned distances: training relationship satisfaction rose from 85.44% to 99.86%, and satisfaction on unseen test examples rose from 84.11% to 97.76%. The selected constrained checkpoints did not satisfy every training margin: the largest squared-distance violation was 0.090732. These are strong adaptive penalties with recorded violations, not guaranteed hard feasibility. Checkpoints were selected for prediction CE, not constraint satisfaction.

Interference evidence is mixed. Without rehearsal, constraints raised mean retained old-class accuracy from 50.00% to 65.28% relative to the unconstrained distance model. With four rehearsal examples per old class, selected-checkpoint retention was lower (86.02% versus 88.80%); at the fixed final step it was higher (91.32% versus 88.80%). The ordinary network retained 100% in both settings. Full replay brought the constrained model to 100%, matching the ordinary network. There is no demonstrated superiority over conventional parameters, and no demonstration of additional independent information capacity.

The complete encoder, prototypes, and temperature are counted: 607 learned scalars for both distance arms, versus 608 for the dense model. The constrained joint optimizer additionally maintains 32,640 pair multipliers (130,560 bytes in FP32), plus pair-index and intermediate tensors. These are training overhead, not inference parameters. All-pairs training scales quadratically with the number of examples.

The synthetic task uses a known contextual bit flip and nuisance variations; it does not use actual language paraphrases. Each class has one learned prototype and a normalized embedding. This tests representation geometry and local distance-based inference, not generation of every network weight from disparities as in the earlier prototype. Validation during adaptation includes old and new classes for every arm, including the no-rehearsal arm; no-rehearsal therefore means no old examples in gradient updates, not no old information in checkpoint selection. Fixed-final-step results are supplied for that reason.

## Verification and reproduction

Verified 54 primary and 18 full-replay checkpoint hashes and reproduced their recorded evaluation metrics exactly on CPU. Also verified data/source hashes, disjoint nuisance combinations, identical rehearsal indices across arms, complete pair coverage, unit-norm embeddings, nonzero finite constraint gradients, and validation-only checkpoint selection. See VERIFICATION.json.

Run `python3 experiments/disparity_constraints/run.py --output <fresh-output-directory>`, then `python3 experiments/disparity_constraints/verify.py --results <fresh-output-directory>`. The first command generates the primary report and chart; the second adds the full-replay data and audit. This interpretation was appended after both commands completed. All work ran locally; no cloud resources were started.
