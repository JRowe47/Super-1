"""Frozen, duplicate-FP32 comparison on the declared reserved byte region."""
import argparse
import hashlib
import importlib
import json
import math
import statistics
from pathlib import Path

import torch
import run_overlapping_phase as training
import phase_transition_language as pilot


def inspect(source):
    protocol = json.loads((source / 'PROTOCOL.json').read_text())
    completion = json.loads((source / 'COMPLETION.json').read_text())
    candidates = json.loads((source / 'CANDIDATES.json').read_text())
    frozen = json.loads((source / 'FREEZE.json').read_text())
    config = protocol['config']
    expected = {(seed, arm, lr) for seed in config['seeds']
                for arm in config['arms'] for lr in config['lrs']}
    assert completion['official_test_read'] is False
    assert completion['candidates'] == len(expected) == len(candidates)
    assert {(r['seed'], r['arm'], r['lr']) for r in candidates} == expected
    assert len(frozen) == len(config['seeds']) * len(config['arms'])
    assert {(r['seed'], r['arm']) for r in frozen} == {(s, a) for s in config['seeds'] for a in config['arms']}
    paths = {
        pilot.__file__: protocol['source_sha256'],
        training.__file__: protocol['runner_source_sha256'],
        training.candidate.__file__: protocol['candidate_source_sha256'],
        **protocol['checks']['source_hashes'],
    }
    for path, digest in paths.items():
        assert pilot.shared.prior.sha(Path(path)) == digest, f'Source drift: {path}'
    for row in candidates:
        assert pilot.shared.prior.sha(source / Path(row['checkpoint']).name) == row['sha256']
        best = min(row['history'], key=lambda score: score['ce'])
        assert row['best_step'] == best['step']
        assert row['validation'] == {key: value for key, value in best.items() if key != 'step'}, 'Selection score drift'
    for row in frozen:
        choices = [r for r in candidates if (r['seed'], r['arm']) == (row['seed'], row['arm'])]
        assert row == min(choices, key=lambda r: r['validation']['ce']), 'Selection must remain validation-only'
    assert config['reserved_confirmation_start'] > config['validation_start'] + config['context'] * config['validation_windows']
    return protocol, frozen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--windows', type=int, required=True)
    parser.add_argument('--experiment-module', choices=['run_nonexpansive_phase', 'run_input_generated_phase', 'run_relative_phase_key', 'run_relative_phase_key_scale', 'run_pair_energy_phase'],
                        default='run_nonexpansive_phase')
    parser.add_argument('--candidate-arm', default='bounded_overlapping')
    args = parser.parse_args()
    assert args.windows > 0 and not args.output.exists()
    protocol, frozen = inspect(args.source)
    config = protocol['config']
    assert args.candidate_arm in config['arms']
    if 'reserved_confirmation_windows' in config:
        assert args.windows == config['reserved_confirmation_windows'], 'Confirmation extent is preregistered'
    experiment = importlib.import_module(args.experiment_module)
    assert str(Path(experiment.__file__).resolve()) in protocol['checks']['source_hashes'], 'Factory is not part of the sealed experiment'
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    pilot.C.update(config)
    pilot.C.update(validation_start=config['reserved_confirmation_start'], validation_windows=args.windows)
    makes, _, _ = experiment.builders(config)
    assert set(makes) == set(config['arms'])
    assert {arm: pilot.count(make()) for arm, make in makes.items()} == protocol['parameters']
    raw = (pilot.DATA / 'valid.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['valid']
    assert config['reserved_confirmation_start'] + args.windows * config['context'] < len(raw)
    data = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    pilot.shared.write(args.output / 'PROTOCOL.json', {
        'source_protocol_sha256': pilot.shared.prior.sha(args.source / 'PROTOCOL.json'),
        'freeze_sha256': pilot.shared.prior.sha(args.source / 'FREEZE.json'),
        'confirmation_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'experiment_module': args.experiment_module, 'candidate_arm': args.candidate_arm,
        'validation_start': config['reserved_confirmation_start'],
        'scored_bytes': args.windows * config['context'], 'precision': 'FP32',
        'duplicate_evaluations': 2, 'official_test_read': False,
    })
    rows = []
    for row in frozen:
        model = makes[row['arm']]().float().eval()
        model.load_state_dict(torch.load(args.source / Path(row['checkpoint']).name, weights_only=True))
        assert all(p.dtype == torch.float32 for p in model.parameters())
        first, second = pilot.evaluate(model, data), pilot.evaluate(model, data)
        assert first == second, 'Duplicate drift forbids promotion'
        rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                     'validation': first, 'duplicate_drift': 0})
        pilot.shared.write(args.output / 'RESULT.json', rows)
        print(json.dumps(rows[-1]), flush=True)
    groups = [{'arm': arm, 'ce': statistics.mean(r['validation']['ce'] for r in rows if r['arm'] == arm)} for arm in config['arms']]
    for group in groups:
        group['bpc'] = group['ce'] / math.log(2)
    pairs = []
    for seed in config['seeds']:
        scores = {r['arm']: r['validation']['ce'] for r in rows if r['seed'] == seed}
        pairs.append({'seed': seed, 'candidate_minus_controls_ce': {
            arm: scores[args.candidate_arm] - score for arm, score in scores.items() if arm != args.candidate_arm}})
    pilot.shared.write(args.output / 'SUMMARY.json', {'groups': groups, 'pairs': pairs, 'duplicate_drift': 0,
        'candidate_arm': args.candidate_arm,
        'candidate_beats_all_controls_all_seeds': all(delta < 0 for pair in pairs for delta in pair['candidate_minus_controls_ce'].values()),
        'official_test_read': False, 'novelty_established': False})
    pilot.shared.write(args.output / 'COMPLETION.json', {'checkpoints': len(rows), 'duplicate_drift': 0,
        'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
