"""Efficient signed input-conditioned alignment on rank channels."""
import argparse,copy,json,math,time,statistics
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
import dot_weight_test as base
S=base.shared
C={**base.C,'caps_bytes':[8192],'seeds':[1601,1663,1721,1783,1847],
   'arms':['dense','factorized','constant','conditioned']}

class Model(base.Model):
    def __init__(self,h,rank,arm):
        super().__init__(h,rank);self.arm=arm
        if arm=='constant':self.coefficients=nn.Parameter(torch.ones(rank))
        if arm=='conditioned':
            self.conditioner=nn.Linear(rank,rank)
            nn.init.zeros_(self.conditioner.weight);nn.init.zeros_(self.conditioner.bias)
    def scales(self,z):
        if self.arm=='conditioned':return 1+self.conditioner(torch.tanh(z))
        if self.arm=='constant':return self.coefficients.expand_as(z)
        return torch.ones_like(z)
    def forward(self,x,materialized=False):
        if self.rank is None:return super().forward(x)
        if self.arm=='factorized' and not materialized:return super().forward(x)
        z=x@self.k;s=self.scales(z)
        if materialized:
            weight=(self.q[None]*s[:,None,:])@self.k.T
            hidden=torch.bmm(weight,x[:,:,None]).squeeze(-1)
        else:hidden=(z*s)@self.q.T
        return self.output(torch.tanh(hidden+self.bias))

def size(h,rank,arm):
    extra=(rank*rank+rank) if arm=='conditioned' else rank if arm=='constant' else 0
    return base.size(h,rank)+4*extra
def score(m,split):
    with torch.inference_mode():
        a=torch.cat([m(x) for x in split[0].split(C['batch'])]);return {'ce':F.cross_entropy(a,split[1]).item(),'accuracy':(a.argmax(-1)==split[1]).float().mean().item()}
def coefficient_stats(m,x):
    if m.rank is None:return None
    with torch.inference_mode():
        s=m.scales(x@m.k)
        return {'minimum':s.min().item(),'maximum':s.max().item(),'negative_fraction':(s<0).float().mean().item(),'mean_across_input_std':s.std(0).mean().item()}
def checks():
    torch.set_num_threads(1);torch.manual_seed(0);m=Model(37,4,'conditioned').double();x=torch.randn(5,64,dtype=torch.float64)
    ref=base.Model(37,4).double();ref.load_state_dict({k:v for k,v in m.state_dict().items() if not k.startswith('conditioner.')})
    assert torch.allclose(m(x),ref(x),atol=1e-12,rtol=1e-10)
    with torch.no_grad():
        m.conditioner.weight.normal_();m.conditioner.bias.fill_(-1)
    a=m(x);b=m(x,True);assert torch.allclose(a,b,atol=1e-12,rtol=1e-10)
    g=torch.autograd.grad(a.square().sum(),tuple(m.parameters()));h=torch.autograd.grad(b.square().sum(),tuple(m.parameters()))
    assert all(torch.allclose(u,v,atol=1e-10,rtol=1e-9) for u,v in zip(g,h))
    assert coefficient_stats(m,x)['mean_across_input_std']>0
    assert coefficient_stats(m,x)['negative_fraction']>0
    return {'identity_initialization':True,'materialized_forward_gradient_parity':True,'signed_input_variation':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);p.add_argument('--canary',action='store_true');a=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);proof=checks()
    if a.canary:
        m=Model(100,4,'conditioned');x=torch.randn(C['batch'],64);y=torch.arange(C['batch'])%10;opt=torch.optim.Adam(m.parameters());start=time.perf_counter()
        for _ in range(100):opt.zero_grad();F.cross_entropy(m(x),y).backward();opt.step()
        print({'checks':proof,'estimated_seconds_per_2000_updates':(time.perf_counter()-start)*20});return
    out=a.output;out.mkdir(parents=True,exist_ok=False)
    S.write(out/'PROTOCOL.json',{'config':C,'checks':proof,'sources':{str(Path(f).resolve()):S.prior.sha(Path(f)) for f in [__file__,base.__file__,S.__file__]},
        'equation':'z=x K; s(x)=1+A tanh(z)+b; hidden=(z*s(x)) Q^T + bias. Constant arm uses learned s. Dense output layer unchanged.',
        'scope':'Signed input-conditioned rank-channel modulation. Conditioner A,b count toward deployed bytes; A,b start at zero for identity. Constant coefficients start at one and can be absorbed into Q. No full matrix is needed for actual inference; materialized mode is verification only.',
        'selection':'Validation CE only, global freeze before assessment. Digits is development data. Same input batches, updates and tuning count, not equal FLOPs. No cloud or confirmation dataset.'})
    rows=[];selected=[]
    for seed in C['seeds']:
        (train,valid,_),meta=S.data('digits',seed,C);S.write(out/f'data-{seed}.json',meta)
        for cap in C['caps_bytes']:
            for arm in C['arms']:
                if arm=='dense':shapes=[(max(1,int(((cap//4-10)//75)*f)),None) for f in C['dense_width_fractions']]
                else:shapes=[(max(h for h in range(1,cap//4) if size(h,r,arm)<=cap),r) for r in C['ranks']]
                candidates=[]
                for width,rank in shapes:
                    for lr in C['lrs']:
                        torch.manual_seed(seed);m=Model(width,rank,arm);opt=torch.optim.Adam(m.parameters(),lr=lr);rng=torch.Generator().manual_seed(seed+30000);history=[];best=float('inf');start=time.perf_counter()
                        for step in range(1,C['steps']+1):
                            ids=torch.randint(len(train[0]),(C['batch'],),generator=rng)
                            for group in opt.param_groups:group['lr']=lr*(.1+.9*.5*(1+math.cos(math.pi*step/C['steps'])))
                            opt.zero_grad();loss=F.cross_entropy(m(train[0][ids]),train[1][ids]);assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5);opt.step()
                            if step%C['validation_interval']==0:
                                val=score(m,valid);history.append({'step':step,**val})
                                if val['ce']<best:best=val['ce'];state=copy.deepcopy(m.state_dict());best_step=step
                        m.load_state_dict(state);path=out/f'{seed}-{arm}-{width}-{rank}-{lr}.pt';torch.save(state,path);n=sum(v.numel()*v.element_size() for v in state.values());assert n==size(width,rank,arm) and n<=cap
                        r={'seed':seed,'arm':arm,'cap':cap,'width':width,'rank':rank,'lr':lr,'bytes':n,'validation':score(m,valid),'best_step':best_step,'history':history,'checkpoint':str(path.resolve()),'sha256':S.prior.sha(path),'seconds':time.perf_counter()-start}
                        rows.append(r);candidates.append(r);S.write(out/'CANDIDATES.json',rows)
                selected.append(min(candidates,key=lambda r:r['validation']['ce']));print('completed',len(rows),'of',80,flush=True)
    S.write(out/'FREEZE.json',selected);result=[]
    for r in selected:
        (_,valid,test),_=S.data('digits',r['seed'],C);m=Model(r['width'],r['rank'],r['arm']);path=Path(r['checkpoint']);assert S.prior.sha(path)==r['sha256'];m.load_state_dict(torch.load(path,weights_only=True));assert score(m,valid)==r['validation'];r=copy.deepcopy(r);r['heldout']=score(m,test);assert score(m,test)==r['heldout']
        with torch.inference_mode():
            original=torch.cat([m(x).argmax(-1) for x in test[0].split(C['batch'])]);tiled=torch.cat([m(x,materialized=True).argmax(-1) for x in test[0].split(C['batch'])]);assert torch.equal(original,tiled)
        r['runtime']=S.profile_call(lambda:m(valid[0][:1]),C['repeats']);r['coefficient_stats']=coefficient_stats(m,valid[0]);result.append(r)
    S.write(out/'RESULT.json',result)
    lines=['# Input-conditioned alignment pilot','','Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.','','| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |','|---|---:|---:|---:|---:|---:|']
    summary=[]
    for arm in C['arms']:
        rs=[r for r in result if r['arm']==arm];avg=lambda f:statistics.mean(f(r) for r in rs)
        g={'arm':arm,'bytes':avg(lambda r:r['bytes']),'ce':avg(lambda r:r['heldout']['ce']),'accuracy':avg(lambda r:r['heldout']['accuracy']),'us':avg(lambda r:r['runtime']['median_single_query_us']),'query_tensor_bytes':avg(lambda r:r['runtime']['incremental_cpu_tensor_peak_bytes'])};summary.append(g)
        lines.append(f"| {arm} | {g['bytes']:.0f} | {g['ce']:.5f} | {g['accuracy']:.2%} | {g['us']:.2f} | {g['query_tensor_bytes']:.0f} |")
    lines+=['','All conditioner parameters count toward storage. Actual inference uses rank-sized channels and never materializes the weight matrix. Full matrices are formed only for an independent equivalence check after freezing. Temporary allocations exclude model weights, allocator reserve and process RSS. Constant coefficients can be absorbed into Q: this control changes optimization, not the representable linear layer. Signed input-conditioned coefficients need not be probabilities. Equal updates do not guarantee convergence or equal compute. No breakthrough or novelty claim.','', 'Reproduce: python3 experiments/disparity_constraints/conditioned_alignment_test.py --output NEW_DIRECTORY']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');S.write(out/'SUMMARY.json',summary);S.write(out/'COMPLETION.json',{'candidates':len(rows),'selected':len(result),'materialization_prediction_mismatches':0,'cloud_resources_created':0});print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
