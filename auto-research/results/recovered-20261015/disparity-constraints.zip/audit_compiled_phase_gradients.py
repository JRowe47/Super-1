"""Trained-checkpoint forward, gradient, and optimizer-step parity audit."""
import argparse
import json
from pathlib import Path

import torch
from torch.nn import functional as F
import phase_transition_language as pilot
from compiled_phase_training_canary import ScriptablePhase
import compiled_phase_training_canary as implementation


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(config['seeds'][0])
    tokens = torch.randint(256, (config['batch'], config['context']))
    targets = torch.randint(256, tokens.shape)
    args.output.mkdir()
    pilot.shared.write(args.output/'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source/'FREEZE.json'),
        'compiled_implementation_sha256': pilot.shared.prior.sha(Path(implementation.__file__)),
        'audit_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'scope': 'Synthetic inputs, FP64 evaluation of copied trained FP32 weights, one AdamW update at the original lowest LR and original weight decay. Source checkpoints remain immutable. No validation scoring.',
        'official_test_read': False,
    })
    result = []
    for row in json.loads((args.source/'FREEZE.json').read_text()):
        if row['arm'] == 'transformer':
            continue
        path = args.source/Path(row['checkpoint']).name
        assert pilot.shared.prior.sha(path) == row['sha256']
        base = pilot.PhaseLM(config['width'], row['arm']=='geometric_rotation').double()
        base.load_state_dict(torch.load(path, weights_only=True))
        scripted = torch.jit.script(ScriptablePhase(base).double())
        reference, compiled = base(tokens), scripted(tokens)
        assert torch.equal(reference, compiled)
        F.cross_entropy(reference.reshape(-1, 256), targets.flatten()).backward()
        F.cross_entropy(compiled.reshape(-1, 256), targets.flatten()).backward()
        first, second = dict(base.named_parameters()), dict(scripted.named_parameters())
        assert set(first) == set(second)
        for name in first:
            assert torch.isfinite(first[name].grad).all()
            assert torch.equal(first[name].grad, second[name].grad), name
        if base.dynamic:
            assert base.gain.detach().abs().sum() > 0 and base.gain.grad.abs().sum() > 0
        lr = min(config['lrs'])
        a = torch.optim.AdamW(base.parameters(), lr=lr, weight_decay=.01)
        b = torch.optim.AdamW(scripted.parameters(), lr=lr, weight_decay=.01)
        a.step()
        b.step()
        assert all(torch.equal(first[name], second[name]) for name in first)
        assert pilot.shared.prior.sha(path) == row['sha256']
        result.append({'seed': row['seed'], 'arm': row['arm'], 'checkpoint_sha256': row['sha256'],
                       'forward_max_error': 0, 'gradient_max_error': 0, 'optimizer_step_max_error': 0})
        pilot.shared.write(args.output/'RESULT.json', result)
        print(json.dumps(result[-1]), flush=True)
    pilot.shared.write(args.output/'COMPLETION.json', {'checkpoints': len(result), 'official_test_read': False})


if __name__ == '__main__':
    main()
