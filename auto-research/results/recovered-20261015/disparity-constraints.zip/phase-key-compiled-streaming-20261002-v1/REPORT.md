# Frozen phase-key deployment audit

Actual three frozen 66K phase-key winners and paired Transformer controls; synthetic tokens only. No training, validation, or official-test evaluation. Checkpoint hashes checked before and after; weights unchanged. Adapter parameter counts equal the original models.

Command: `compiled_overlapping_streaming.py --source experiments/disparity_constraints/relative-phase-key-20261001-v1 --output <fresh-directory> --repeats 30 --warmups 3 --parity-atol 0.00001 --candidate-arm relative_phase_key --factory-module run_relative_phase_key`.

The inherited RESULT keys named geometry refer to **relative_phase_key**, not the earlier geometric_overlapping model. Extra adapter source `compiled_phase_key_streaming.py` SHA256: `e52e4844efa96042f1b2060b931bf476923863240cf9e60a5b4ee98f75f9daa7`. Main adapter/control hashes are in PROTOCOL.json. Compiled artifacts and original checkpoint hashes are in RESULT.json.

Both models' frozen TorchScript adapters matched their eager outputs exactly in all batch 1/3 and length 1/17/128 probes. Full-forward versus incremental maximum error was at most 6.67572021484375e-6 and passed the declared tolerance; this is not a claim of bitwise full-forward equivalence for arbitrary inputs.

| Seed | Keys eager us/token | Keys compiled | Transformer compiled KV |
|---|---:|---:|---:|
| 2503 | 100.508 | 57.413 | 33.532 |
| 2551 | 100.793 | 57.148 | 33.110 |
| 2609 | 101.375 | 56.604 | 32.966 |

Mean of medians: keys 57.055 us/token versus Transformer 33.203. Keys are approximately 72% slower, despite approximately 43% own improvement from compilation. Thirty shuffled paired repeats, three warmups, CPU FP32, batch one, context 128, including a Python token loop and concurrent-training contention. Not an isolated GPU/production benchmark; compiler setup excluded.

Persistent sequence state: keys 512 bytes versus Transformer KV 71,680 bytes (140x less). FP32 parameter tensors: keys 266,240 bytes versus Transformer 265,704 bytes. Parameters plus measured persistent state: 266,752 versus 337,384 bytes (about 20.9% lower). This excludes temporary tensors, allocator, runtime, and compiled-graph overhead, and is not a total process-memory claim.

Decision: successful function-preserving streaming deployment, but **no relative latency win**. Do not conflate the confirmed validation CE gain with inference superiority. Larger-scale training remains unchanged and active.
