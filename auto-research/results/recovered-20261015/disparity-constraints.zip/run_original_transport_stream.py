"""Contiguous byte-stream ablation using the authoritative native hierarchy."""
import argparse
import copy
import hashlib
import json
import math
import statistics
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import original_hierarchy_transport as transport
import phase_transition_language as shared


ARMS = ('original', 'fixed_transport', 'geometric_transport', 'transformer')


def make_model(arm, config):
    if arm == 'transformer':
        return transport.authoritative.DenseRoPETransformer(
            config['vocab'], config['transformer_width'], config['transformer_heads'],
            config['transformer_layers'], config['context']+config['transformer_prefix'])
    base = transport.authoritative.PersistentMultiScaleLM(
        config['vocab'], config['hierarchy_width'], config['state_scales'])
    if arm == 'original':
        return base
    assert arm in {'fixed_transport', 'geometric_transport'}
    return transport.GeometricHierarchy(base, arm == 'geometric_transport')


def lane_starts(length, config, seed):
    lane_length = length // config['batch']
    span = config['steps'] * config['context'] + 1
    assert span < lane_length
    generator = torch.Generator().manual_seed(seed + config['window_seed_offset'])
    offsets = torch.randint(lane_length-span, (config['batch'],), generator=generator)
    return torch.arange(config['batch'])*lane_length+offsets


def evaluate(model, arm, data, config, start, scored_bytes):
    assert scored_bytes % config['context'] == 0
    assert start >= 0 and start + scored_bytes < len(data)
    was_training = model.training
    model.eval()
    state, nll, total = None, 0.0, 0
    with torch.no_grad():
        for offset in range(0, scored_bytes, config['context']):
            position = start+offset
            targets = data[position+1:position+config['context']+1].unsqueeze(0)
            if arm == 'transformer':
                prefix = min(config['transformer_prefix'], offset)
                inputs = data[position-prefix:position+config['context']].unsqueeze(0)
                logits = model(inputs)[:, -config['context']:]
            else:
                inputs = data[position:position+config['context']].unsqueeze(0)
                logits, state = model(inputs, state, return_state=True)
            nll += F.cross_entropy(logits.reshape(-1, config['vocab']), targets.flatten(), reduction='sum').item()
            total += targets.numel()
    model.train(was_training)
    ce = nll/total
    return {'ce': ce, 'bpc': ce/math.log(2), 'scored_bytes': total}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    assert config['steps'] % config['validation_interval'] == 0
    assert config['reserved_confirmation_start'] > config['selection_start']+config['selection_bytes']
    checks = transport.checks()
    counts = {arm: shared.count(make_model(arm, config)) for arm in ARMS}
    assert max(counts.values())/min(counts.values()) < config['maximum_parameter_ratio']
    if args.smoke:
        synthetic = torch.arange(config['context']*config['batch']*config['steps']*2+1) % config['vocab']
        starts = lane_starts(len(synthetic), config, config['seeds'][0])
        assert torch.equal(starts, lane_starts(len(synthetic), config, config['seeds'][0]))
        for arm in ARMS:
            model = make_model(arm, config)
            inputs = torch.stack([synthetic[i:i+config['context']] for i in starts])
            targets = torch.stack([synthetic[i+1:i+config['context']+1] for i in starts])
            if arm == 'transformer':
                logits = model(inputs)
            else:
                logits, state = model(inputs, return_state=True)
                assert state.shape == (config['batch'], config['state_scales'], config['hierarchy_width'])
            loss = F.cross_entropy(logits.reshape(-1, config['vocab']), targets.flatten())
            loss.backward()
            assert torch.isfinite(loss)
            one = evaluate(model, arm, synthetic, config, 0, config['context']*2)
            two = evaluate(model, arm, synthetic, config, 0, config['context']*2)
            assert one == two
        print(json.dumps({'checks': checks, 'parameters': counts, 'lane_determinism': True,
                          'forward_backward_all_arms': True, 'duplicate_stream_evaluation': True}), flush=True)
        return
    assert not args.output.exists()
    raw = {name: (shared.DATA/(name+'.txt')).read_bytes() for name in ['train', 'valid']}
    train, valid = (torch.tensor(list(raw[name]), dtype=torch.long) for name in ['train', 'valid'])
    starts_by_seed = {seed: lane_starts(len(train), config, seed) for seed in config['seeds']}
    args.output.mkdir()
    shared.shared.write(args.output/'PROTOCOL.json', {
        'config': config, 'arms': list(ARMS), 'checks': checks, 'parameters': counts,
        'lane_starts': {str(seed): starts.tolist() for seed, starts in starts_by_seed.items()},
        'data_sha256': {name: hashlib.sha256(data).hexdigest() for name, data in raw.items()},
        'runner_sha256': shared.shared.prior.sha(Path(__file__)),
        'transport_sha256': shared.shared.prior.sha(Path(transport.__file__)),
        'authoritative_wrapper_sha256': shared.shared.prior.sha(transport.SOURCE),
        'authoritative_core_sha256': shared.shared.prior.sha(transport.authoritative.AUTHORITATIVE_MULTISCALE_PATH),
        'authoritative_transformer_sha256': shared.shared.prior.sha(transport.authoritative.AUTHORITATIVE_TRANSFORMER_PATH),
        'training_contract': 'Identical contiguous target streams per seed and LR. Hierarchy state is carried and detached after each optimizer step; no chunk reset. Transformer recomputes a bounded prefix, scoring only the new chunk. Both start without prior text. Matched parameters, target exposure, tuning count; not matched effective history or FLOPs.',
        'validation_contract': 'A fresh state at selection-region start, then continuous streaming across chunks. Validation-only checkpoint/LR selection. New reserved region for frozen confirmation. Only train.txt and valid.txt accessed.',
        'official_test_read': False, 'official_test_eligible': False, 'novelty_established': False,
    })
    candidates, frozen = [], []
    total = len(config['seeds'])*len(ARMS)*len(config['lrs'])
    for seed in config['seeds']:
        for arm in ARMS:
            trials = []
            for lr in config['lrs']:
                torch.manual_seed(seed)
                model = make_model(arm, config)
                optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=config['weight_decay'])
                state, best, history = None, float('inf'), []
                begin = time.perf_counter()
                for step in range(1, config['steps']+1):
                    offset = (step-1)*config['context']
                    ids = starts_by_seed[seed]+offset
                    targets = torch.stack([train[i+1:i+config['context']+1] for i in ids])
                    if arm == 'transformer':
                        prefix = min(config['transformer_prefix'], offset)
                        inputs = torch.stack([train[i-prefix:i+config['context']] for i in ids])
                        logits = model(inputs)[:, -config['context']:]
                    else:
                        inputs = torch.stack([train[i:i+config['context']] for i in ids])
                        logits, next_state = model(inputs, state, return_state=True)
                    for group in optimizer.param_groups:
                        group['lr'] = lr*(.1+.9*.5*(1+math.cos(math.pi*step/config['steps'])))
                    optimizer.zero_grad(set_to_none=True)
                    loss = F.cross_entropy(logits.reshape(-1, config['vocab']), targets.flatten())
                    assert torch.isfinite(loss)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), config['gradient_clip'])
                    optimizer.step()
                    if arm != 'transformer':
                        state = next_state.detach()
                    if step % config['validation_interval'] == 0:
                        score = evaluate(model, arm, valid, config, config['selection_start'], config['selection_bytes'])
                        history.append({'step': step, **score})
                        if score['ce'] < best:
                            best, best_step, best_state = score['ce'], step, copy.deepcopy(model.state_dict())
                        progress = {'seed': seed, 'arm': arm, 'lr': lr, 'step': step, 'validation': score}
                        with (args.output/'progress.jsonl').open('a') as handle:
                            handle.write(json.dumps(progress)+'\n')
                        print(json.dumps(progress), flush=True)
                model.load_state_dict(best_state)
                path = args.output/f'{seed}-{arm}-{lr}.pt'
                torch.save(best_state, path)
                row = {'seed': seed, 'arm': arm, 'lr': lr, 'best_step': best_step, 'history': history,
                       'validation': evaluate(model, arm, valid, config, config['selection_start'], config['selection_bytes']),
                       'checkpoint': str(path.resolve()), 'sha256': shared.shared.prior.sha(path),
                       'training_target_bytes': config['steps']*config['batch']*config['context'],
                       'parameters': counts[arm], 'training_seconds': time.perf_counter()-begin}
                candidates.append(row)
                trials.append(row)
                shared.shared.write(args.output/'CANDIDATES.json', candidates)
                print(json.dumps({'completed': len(candidates), 'total': total, 'arm': arm, 'validation': row['validation']}), flush=True)
            frozen.append(min(trials, key=lambda row: row['validation']['ce']))
    shared.shared.write(args.output/'FREEZE.json', frozen)
    shared.shared.write(args.output/'SUMMARY.json', [{'arm': arm, 'mean_selection_ce': statistics.mean(r['validation']['ce'] for r in frozen if r['arm']==arm)} for arm in ARMS])
    shared.shared.write(args.output/'COMPLETION.json', {'candidates': total, 'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
