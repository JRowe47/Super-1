"""Frozen-checkpoint intervention, not a new training or promotion experiment."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import torch
import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--confirmation', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    protocol = json.loads((args.source / 'PROTOCOL.json').read_text())
    confirmation = json.loads((args.confirmation / 'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    frozen = json.loads((args.source / 'FREEZE.json').read_text())
    rows = [r for r in frozen if r['arm'] == 'geometric_rotation']
    assert len(rows) == len(protocol['config']['seeds'])
    torch.set_num_threads(protocol['config']['threads'])
    torch.use_deterministic_algorithms(True)
    pilot.C.update(protocol['config'])
    pilot.C.update(validation_start=confirmation['validation_start'],
                   validation_windows=confirmation['validation_windows'])
    args.output.mkdir()
    pilot.shared.write(args.output / 'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source / 'FREEZE.json'),
        'confirmation_protocol_sha256': pilot.shared.prior.sha(args.confirmation / 'PROTOCOL.json'),
        'audit_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'intervention': 'Set only the learned state-conditioned rotation gain to zero in memory; keep every other trained parameter fixed.',
        'scope': 'Post-training dependence diagnostic. Not a retrained ablation, causal architecture advantage, tuning signal, or promotion authority.',
        'official_test_read': False,
    })
    raw = (pilot.DATA / 'valid.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['valid']
    valid = torch.tensor(list(raw), dtype=torch.long)
    result = []
    for row in rows:
        path = args.source / Path(row['checkpoint']).name
        assert pilot.shared.prior.sha(path) == row['sha256']
        model = pilot.PhaseLM(protocol['config']['width'], True).float().eval()
        model.load_state_dict(torch.load(path, weights_only=True))
        intact = pilot.evaluate(model, valid)
        assert intact == pilot.evaluate(model, valid)
        altered = copy.deepcopy(model)
        with torch.no_grad():
            altered.gain.zero_()
        ablated = pilot.evaluate(altered, valid)
        assert ablated == pilot.evaluate(altered, valid)
        result.append({'seed': row['seed'], 'checkpoint_sha256': row['sha256'],
                       'intact': intact, 'zero_gain': ablated,
                       'zero_gain_minus_intact_ce': ablated['ce'] - intact['ce'],
                       'learned_gain_abs_mean': model.gain.abs().mean().item(),
                       'learned_gain_abs_max': model.gain.abs().max().item(),
                       'duplicate_drift': 0})
        pilot.shared.write(args.output / 'RESULT.json', result)
        print(json.dumps(result[-1]), flush=True)
    pilot.shared.write(args.output / 'COMPLETION.json', {'checkpoints': len(result),
                                                       'official_test_read': False, 'duplicate_drift': 0})


if __name__ == '__main__':
    main()
