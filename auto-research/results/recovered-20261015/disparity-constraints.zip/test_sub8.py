import copy
import json
from pathlib import Path
import tempfile
import unittest
import torch
import sub8_sweep as s


class Sub8Checks(unittest.TestCase):
    def test_caps_initialization_and_training_paths(self):
        c=json.loads(Path(__file__).with_name('sub8_config.json').read_text())
        torch.set_num_threads(1)
        c['canary_steps']=2
        for dim,classes in [(64,10),(16,64)]:
            torch.manual_seed(211)
            x=torch.randn(classes*2,dim);y=torch.arange(len(x))%classes
            payload={'train':(x,y),'valid':(x,y),'anchors':x[:classes],
                     'matrix':torch.ones(len(x),len(x)),'target_logits':torch.zeros(len(x),classes)}
            for cap in c['scalar_budgets']:
                for arm in c['arms']:
                    minimum=s.old.architecture(c,dim,classes,1,s.kind(arm))[0]
                    if minimum>cap:
                        with self.assertRaises(ValueError):
                            s.old.Student(c,dim,classes,cap,s.actual_arm(arm),payload['anchors'])
                        continue
                    torch.manual_seed(211)
                    model=s.old.Student(c,dim,classes,cap,s.actual_arm(arm),payload['anchors'])
                    self.assertLessEqual(s.old.prior.scalars(model),cap)
                    config=copy.deepcopy(c)
                    if arm=='distilled_logits_only':config['distill_weight']=0.
                    with tempfile.TemporaryDirectory() as folder:
                        result=s.old.train(config,'unit',211,cap,s.actual_arm(arm),.003,payload,Path(folder),timing_only=True)
                        self.assertEqual(result['steps'],2)
                        self.assertEqual(list(Path(folder).iterdir()),[])
            cap=max(c['scalar_budgets'])
            torch.manual_seed(211);a=s.old.Student(c,dim,classes,cap,s.actual_arm('distilled'),payload['anchors'])
            torch.manual_seed(211);b=s.old.Student(c,dim,classes,cap,s.actual_arm('distilled_logits_only'),payload['anchors'])
            self.assertTrue(all(torch.equal(v,b.state_dict()[k]) for k,v in a.state_dict().items()))


if __name__=='__main__':unittest.main()
