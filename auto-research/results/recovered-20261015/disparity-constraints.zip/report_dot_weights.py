"""Summarize the completed weight-alignment pilot without further selection."""
import argparse,json,statistics,math
from pathlib import Path
from scipy.stats import t
import torch
import capacity_sweep as shared

def main(out):
    c=json.loads((out/'PROTOCOL.json').read_text())['config']
    rows=json.loads((out/'RESULT.json').read_text());candidates=json.loads((out/'CANDIDATES.json').read_text())
    assert len(rows)==len(c['seeds'])*len(c['caps_bytes'])*3
    for r in candidates:
        p=Path(r['checkpoint']);assert shared.prior.sha(p)==r['sha256']
        state=torch.load(p,weights_only=True);assert sum(v.numel()*v.element_size() for v in state.values())==r['bytes']
        assert r['history'][-1]['step']==c['steps']
    groups=[];comparisons=[]
    lines=['# Directed dot-product weight pilot','',
        'The input-to-hidden matrix is generated as W = Q K^T. Inference computes (x K) Q^T without materializing W. Entries can be positive or negative and contributions can cancel. The output layer remains dense. This is a low-rank factorization, not an input-distance model or a new attention mechanism.','',
        'Five seeds on previously used digits development data; 2,000 updates each. Each arm receives two architecture candidates and two learning rates. Validation CE selects checkpoints and configurations before any held-out scoring. Same-width controls deliberately exceed the storage cap.','',
        '| Cap KiB | Model | Stored bytes | Held-out CE | Accuracy | Query us | Query tensor peak bytes |',
        '|---|---|---:|---:|---:|---:|---:|']
    for cap in c['caps_bytes']:
        for arm in ['factorized','dense_same_bytes','dense_same_width']:
            rs=[r for r in rows if r['cap']==cap and r['arm']==arm]
            mean=lambda f:statistics.mean(f(r) for r in rs)
            g={'cap':cap,'arm':arm,'bytes':mean(lambda r:r['bytes']),'ce':mean(lambda r:r['heldout']['ce']),'accuracy':mean(lambda r:r['heldout']['accuracy']),'query_us':mean(lambda r:r['runtime']['median_single_query_us']),'query_tensor_bytes':mean(lambda r:r['runtime']['incremental_cpu_tensor_peak_bytes']),'selected_ranks':[r['rank'] for r in rs]}
            groups.append(g);lines.append(f"| {cap/1024:g} | {arm} | {g['bytes']:.0f} | {g['ce']:.5f} | {g['accuracy']:.2%} | {g['query_us']:.2f} | {g['query_tensor_bytes']:.0f} |")
        for arm in ['dense_same_bytes','dense_same_width']:
            a=sorted([r for r in rows if r['cap']==cap and r['arm']=='factorized'],key=lambda r:r['seed'])
            b=sorted([r for r in rows if r['cap']==cap and r['arm']==arm],key=lambda r:r['seed'])
            delta=[x['heldout']['ce']-y['heldout']['ce'] for x,y in zip(a,b)]
            m=statistics.mean(delta);radius=float(t.ppf(.975,len(delta)-1))*statistics.stdev(delta)/math.sqrt(len(delta))
            comparisons.append({'cap':cap,'reference':arm,'CE_difference_factorized_minus_dense':m,'exploratory_95pct_paired_seed_interval':[m-radius,m+radius]})
    lines+=['','## Per-seed comparisons','', 'CE difference is factorized minus dense; negative favors factorized. Intervals are exploratory, unadjusted, and based on only five overlapping dataset splits. They are not independent confirmation.','']
    for r in comparisons:lines.append(f"- {r['cap']/1024:g} KiB vs {r['reference']}: {r['CE_difference_factorized_minus_dense']:+.5f}, interval {r['exploratory_95pct_paired_seed_interval']}.")
    lines+=['','## Boundaries','',
        '- Every stored tensor counts. Query allocations exclude parameters and are reported separately; neither metric is process RSS or serialized checkpoint size.',
        '- The primary inference path never constructs Q K^T. Materialization is used only as a separate verification/reference measurement after model freezing.',
        '- Rank is bounded by the factor dimension. Many connections are generated, but they are coupled rather than independently stored.',
        '- No input-distance teacher, raw exemplars, normalization vectors, learned gates, or attention were used.',
        '- Equal updates and tuning counts do not mean equal training FLOPs or convergence. Results may depend on initialization, chosen ranks, and optimizer.',
        '- This small pilot tests usefulness, not novelty, a general capacity theorem, or a breakthrough. No cloud resources or reserved confirmation dataset were used.','',
        '## Reproduce','', 'Run dot_weight_test.py --output NEW_DIRECTORY, then report_dot_weights.py NEW_DIRECTORY. Dependencies: Python, PyTorch, scikit-learn, NumPy, SciPy. Configuration and source hash are in PROTOCOL.json.']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    shared.write(out/'SUMMARY.json',{'groups':groups,'comparisons':comparisons,'candidate_hashes_verified':len(candidates),'factorized_materialization_prediction_mismatches':sum(r.get('materialization_prediction_mismatches',0) for r in rows)})
    print(json.dumps(groups,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);main(p.parse_args().output)
