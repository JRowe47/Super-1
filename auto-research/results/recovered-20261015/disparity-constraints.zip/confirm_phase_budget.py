"""Confirm a completed budget run on its predeclared reserved validation region."""
import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

import torch
import phase_transition_language as pilot


def inspect(source):
    protocol = json.loads((source / 'PROTOCOL.json').read_text())
    completion = json.loads((source / 'COMPLETION.json').read_text())
    frozen = json.loads((source / 'FREEZE.json').read_text())
    config = protocol['config']
    assert completion['official_test_read'] is False
    assert completion['candidates'] == len(config['seeds']) * len(config['arms']) * len(config['lrs'])
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    if 'candidate_source_sha256' in protocol:
        import noncommuting_phase_candidate as candidate
        assert pilot.shared.prior.sha(Path(candidate.__file__)) == protocol['candidate_source_sha256']
    expected = {(seed, arm) for seed in config['seeds'] for arm in config['arms']}
    assert {(row['seed'], row['arm']) for row in frozen} == expected
    assert len(frozen) == len(expected)
    for row in frozen:
        assert pilot.shared.prior.sha(source / Path(row['checkpoint']).name) == row['sha256']
    start = config['reserved_confirmation_start']
    selection_end = config['validation_start'] + config['validation_windows'] * config['context']
    assert start > selection_end, 'Confirmation targets must not overlap selection targets'
    return protocol, frozen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--windows', type=int, required=True)
    args = parser.parse_args()
    assert args.windows > 0 and not args.output.exists()
    protocol, frozen = inspect(args.source)
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    pilot.C.update(config)
    pilot.C.update(validation_start=config['reserved_confirmation_start'], validation_windows=args.windows)
    raw = (pilot.DATA / 'valid.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['valid']
    scored = args.windows * config['context']
    assert pilot.C['validation_start'] + scored < len(raw)
    valid = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    pilot.shared.write(args.output / 'PROTOCOL.json', {
        'source_protocol_sha256': pilot.shared.prior.sha(args.source / 'PROTOCOL.json'),
        'source_freeze_sha256': pilot.shared.prior.sha(args.source / 'FREEZE.json'),
        'confirmation_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'validation_start': pilot.C['validation_start'], 'scored_bytes': scored,
        'windows': args.windows, 'context': config['context'],
        'precision': 'FP32', 'duplicate_evaluations': 2, 'official_test_read': False,
    })
    rows = []
    for row in frozen:
        if row['arm'] == 'transformer':
            model = pilot.TinyTransformer(protocol['transformer_width'], protocol['transformer_ff_width'])
        elif row['arm'] in {'fixed_overlapping', 'geometric_overlapping'}:
            import noncommuting_phase_candidate as candidate
            model = candidate.OverlappingPhaseLM(config['width'], row['arm'] == 'geometric_overlapping')
        else:
            assert row['arm'] in {'fixed_rotation', 'geometric_rotation'}
            model = pilot.PhaseLM(config['width'], row['arm'] == 'geometric_rotation')
        model.load_state_dict(torch.load(args.source / Path(row['checkpoint']).name, weights_only=True))
        model.float().eval()
        assert all(p.dtype == torch.float32 for p in model.parameters())
        first, second = pilot.evaluate(model, valid), pilot.evaluate(model, valid)
        assert first == second, 'Duplicate FP32 drift forbids promotion'
        rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                     'validation': first, 'duplicate_drift': 0})
        pilot.shared.write(args.output / 'RESULT.json', rows)
        print(json.dumps({'confirmed': len(rows), 'total': len(frozen), **rows[-1]}), flush=True)
    groups = [{'arm': arm, 'ce': statistics.mean(r['validation']['ce'] for r in rows if r['arm'] == arm)}
              for arm in config['arms']]
    for group in groups:
        group['bpc'] = group['ce'] / math.log(2)
    pairs = []
    for seed in config['seeds']:
        scores = {r['arm']: r['validation']['ce'] for r in rows if r['seed'] == seed}
        pairs.append({'seed': seed, 'geometric_minus_fixed_ce': scores['geometric_rotation'] - scores['fixed_rotation'],
                      'geometric_minus_transformer_ce': scores['geometric_rotation'] - scores['transformer']})
        if 'geometric_overlapping' in scores:
            pairs[-1].update(
                overlapping_geometry_minus_fixed_ce=scores['geometric_overlapping'] - scores['fixed_overlapping'],
                overlapping_minus_single_geometry_ce=scores['geometric_overlapping'] - scores['geometric_rotation'])
    summary = {'groups': groups, 'pairs': pairs, 'duplicate_drift': 0, 'official_test_read': False,
               'all_seeds_geometry_beats_fixed': all(p['geometric_minus_fixed_ce'] < 0 for p in pairs)}
    pilot.shared.write(args.output / 'SUMMARY.json', summary)
    exposure = config['steps'] * config['batch'] * config['context']
    lines = ['# Reserved-region phase-budget confirmation', '',
             f"Each candidate trained for {config['steps']:,} updates ({exposure:,} target-byte exposures).",
             f'Frozen checkpoints evaluated twice in FP32 on {scored:,} reserved validation target bytes.', '',
             '| Arm | Mean byte CE | BPC |', '|---|---:|---:|']
    lines.extend(f"| {r['arm']} | {r['ce']:.6f} | {r['bpc']:.6f} |" for r in groups)
    lines += ['', 'Per-seed geometry-minus-fixed CE: ' + str([p['geometric_minus_fixed_ce'] for p in pairs]), '',
              'Parameters and training windows matched; FLOPs are not matched. Byte-level pilot, not word-level perplexity, novelty proof, original-hierarchy validation, or SOTA. Official test remains sealed.']
    (args.output / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    pilot.shared.write(args.output / 'COMPLETION.json', {'checkpoints': len(rows), 'duplicate_drift': 0,
                                                       'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
