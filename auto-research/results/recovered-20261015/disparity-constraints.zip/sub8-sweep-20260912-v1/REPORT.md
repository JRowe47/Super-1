# Below-8-KiB direct-distance capacity test

Completed 440 feasible candidates and evaluated 220 validation-selected checkpoints. Explicitly recorded 80 infeasible configurations across seeds. New seeds, 3,000 updates per candidate, same-teacher ablation. No cloud resources.

**Comparisons passing every predeclared confirmation gate: 0. Confirmation dataset has not been loaded.**

## Development results

| Task | Cap KiB | Arm | Accuracy | CE | Actual tensor bytes | Fast query us | Late-improving seeds |
|---|---:|---|---:|---:|---:|---:|---:|
| digits | 2 | dense | 66.79% | 1.0334 | 1936 | 11.17 | 3 / 5 |
| digits | 2 | dense_teacher | 49.57% | 1.2002 | 1936 | 10.99 | 3 / 5 |
| digits | 2 | coordinates_teacher | 58.53% | 1.1025 | 1976 | 24.26 | 2 / 5 |
| digits | 2 | direct | Infeasible | — | — | — | — |
| digits | 2 | distilled_logits_only | Infeasible | — | — | — | — |
| digits | 2 | distilled | Infeasible | — | — | — | — |
| digits | 3 | dense | 88.26% | 0.4360 | 2812 | 11.06 | 0 / 5 |
| digits | 3 | dense_teacher | 88.42% | 0.4703 | 2812 | 11.08 | 2 / 5 |
| digits | 3 | coordinates_teacher | 92.12% | 0.3703 | 2840 | 24.19 | 4 / 5 |
| digits | 3 | direct | Infeasible | — | — | — | — |
| digits | 3 | distilled_logits_only | Infeasible | — | — | — | — |
| digits | 3 | distilled | Infeasible | — | — | — | — |
| digits | 4 | dense | 92.66% | 0.3510 | 3984 | 10.99 | 0 / 5 |
| digits | 4 | dense_teacher | 92.12% | 0.2948 | 3984 | 11.34 | 2 / 5 |
| digits | 4 | coordinates_teacher | 94.89% | 0.2043 | 4000 | 23.79 | 0 / 5 |
| digits | 4 | direct | 79.73% | 0.6841 | 3616 | 33.52 | 2 / 5 |
| digits | 4 | distilled_logits_only | 68.15% | 1.1227 | 3616 | 32.96 | 1 / 5 |
| digits | 4 | distilled | 50.22% | 1.4073 | 3616 | 33.28 | 1 / 5 |
| digits | 6 | dense | 94.40% | 0.2171 | 6144 | 11.29 | 0 / 5 |
| digits | 6 | dense_teacher | 96.25% | 0.1418 | 6144 | 11.27 | 0 / 5 |
| digits | 6 | coordinates_teacher | 96.58% | 0.1313 | 6136 | 23.52 | 1 / 5 |
| digits | 6 | direct | 94.46% | 0.2102 | 5696 | 35.49 | 0 / 5 |
| digits | 6 | distilled_logits_only | 88.64% | 0.3673 | 5696 | 35.34 | 2 / 5 |
| digits | 6 | distilled | 86.52% | 0.4112 | 5696 | 34.83 | 0 / 5 |
| digits | 8 | dense | 94.51% | 0.1886 | 7976 | 11.27 | 0 / 5 |
| digits | 8 | dense_teacher | 96.03% | 0.1651 | 7976 | 11.22 | 1 / 5 |
| digits | 8 | coordinates_teacher | 96.74% | 0.1231 | 7956 | 23.94 | 1 / 5 |
| digits | 8 | direct | 95.43% | 0.1857 | 7824 | 34.67 | 0 / 5 |
| digits | 8 | distilled_logits_only | 96.09% | 0.1192 | 7824 | 37.38 | 0 / 5 |
| digits | 8 | distilled | 96.20% | 0.1495 | 7824 | 35.10 | 0 / 5 |
| context64 | 2 | dense | 98.04% | 0.0891 | 2000 | 11.00 | 0 / 5 |
| context64 | 2 | dense_teacher | 47.34% | 1.5318 | 2000 | 11.10 | 5 / 5 |
| context64 | 2 | coordinates_teacher | Infeasible | — | — | — | — |
| context64 | 2 | direct | Infeasible | — | — | — | — |
| context64 | 2 | distilled_logits_only | Infeasible | — | — | — | — |
| context64 | 2 | distilled | Infeasible | — | — | — | — |
| context64 | 3 | dense | 98.49% | 0.0577 | 2896 | 11.02 | 0 / 5 |
| context64 | 3 | dense_teacher | 49.82% | 1.0490 | 2896 | 11.03 | 5 / 5 |
| context64 | 3 | coordinates_teacher | 35.58% | 2.2282 | 2992 | 24.00 | 5 / 5 |
| context64 | 3 | direct | Infeasible | — | — | — | — |
| context64 | 3 | distilled_logits_only | Infeasible | — | — | — | — |
| context64 | 3 | distilled | Infeasible | — | — | — | — |
| context64 | 4 | dense | 97.96% | 0.0727 | 4028 | 11.04 | 0 / 5 |
| context64 | 4 | dense_teacher | 92.03% | 0.3718 | 4028 | 11.07 | 5 / 5 |
| context64 | 4 | coordinates_teacher | 97.59% | 0.3986 | 4024 | 24.15 | 5 / 5 |
| context64 | 4 | direct | Infeasible | — | — | — | — |
| context64 | 4 | distilled_logits_only | Infeasible | — | — | — | — |
| context64 | 4 | distilled | Infeasible | — | — | — | — |
| context64 | 6 | dense | 98.26% | 0.0617 | 5840 | 11.17 | 0 / 5 |
| context64 | 6 | dense_teacher | 99.12% | 0.0636 | 5840 | 11.09 | 1 / 5 |
| context64 | 6 | coordinates_teacher | 99.66% | 0.0837 | 5872 | 23.97 | 3 / 5 |
| context64 | 6 | direct | 99.40% | 0.0178 | 6144 | 44.35 | 0 / 5 |
| context64 | 6 | distilled_logits_only | 99.80% | 0.0076 | 6144 | 43.23 | 0 / 5 |
| context64 | 6 | distilled | 99.67% | 0.0113 | 6144 | 43.80 | 0 / 5 |
| context64 | 8 | dense | 98.83% | 0.0381 | 8160 | 11.36 | 0 / 5 |
| context64 | 8 | dense_teacher | 99.65% | 0.0164 | 8160 | 11.13 | 0 / 5 |
| context64 | 8 | coordinates_teacher | 99.64% | 0.0670 | 8084 | 24.12 | 2 / 5 |
| context64 | 8 | direct | 99.75% | 0.0079 | 8052 | 53.89 | 0 / 5 |
| context64 | 8 | distilled_logits_only | 99.94% | 0.0026 | 8052 | 51.15 | 0 / 5 |
| context64 | 8 | distilled | 99.95% | 0.0025 | 8052 | 51.14 | 0 / 5 |

## Gate comparisons

All gates and the conditional confirmation protocol were saved before training in PROTOCOL.json. Simultaneous paired t intervals use the fixed 40-comparison family, including infeasible planned comparisons, at 95% family confidence. Overlapping digits splits and only five seeds limit inference; these are development results.

A storage claim requires half the deployed bytes with no more than a one-point accuracy loss, and an advantage over the same-cap reference. An equal-cap claim requires at least a three-point gain. Every claim additionally requires <=2x latency, <=1.05x total model-plus-query tensor memory, a positive adjusted gain over the same-teacher logits-only ablation, and no material late validation improvement in the relevant models. These are engineering screening rules, not universal breakthrough definitions.

| Task | Student cap KiB | Reference cap KiB | Accuracy difference pp | Adjusted interval pp | Ablation interval pp | Failed gates in fastest mode |
|---|---:|---:|---:|---|---|---|
| digits | 4 | 4 | -44.57 | [-102.62, +13.49] | [-83.22, +47.35] | accuracy, working_memory, mechanism, training_stability |
| digits | 4 | 6 | -46.20 | [-100.45, +8.06] | [-83.22, +47.35] | accuracy, stored_bytes, working_memory, frontier, mechanism, training_stability |
| digits | 4 | 8 | -46.68 | [-101.55, +8.18] | [-83.22, +47.35] | accuracy, working_memory, latency, frontier, mechanism, training_stability |
| digits | 6 | 6 | -9.89 | [-66.16, +46.38] | [-10.59, +6.35] | accuracy, working_memory, mechanism, training_stability |
| digits | 6 | 8 | -10.38 | [-67.22, +46.46] | [-10.59, +6.35] | accuracy, stored_bytes, working_memory, latency, frontier, mechanism, training_stability |
| digits | 8 | 8 | -0.71 | [-4.69, +3.28] | [-3.06, +3.28] | accuracy, working_memory, latency, mechanism, training_stability |
| context64 | 6 | 6 | +0.90 | [-1.16, +2.96] | [-1.15, +0.89] | accuracy, stored_bytes, working_memory, latency, mechanism |
| context64 | 6 | 8 | +0.02 | [-0.76, +0.81] | [-1.15, +0.89] | stored_bytes, working_memory, latency, frontier, mechanism |
| context64 | 8 | 8 | +0.30 | [-0.95, +1.54] | [-0.09, +0.10] | accuracy, working_memory, latency, mechanism |

## Interpretation boundaries

- The deployed distance function is unchanged. No learned coordinate embeddings are used by the direct or distilled arms. Coordinate embeddings remain a labeled competing control.
- Distilled-logits-only has the identical deployment, teacher logits, initialization, schedule and classification targets, but the pair-distance regression weight is zero. It receives no gradient from that term.
- Digits raw exemplars alone occupy 2,560 bytes; the minimal configured direct generator requires 3,096 bytes. At 64 concepts the exemplars alone occupy 4,096 bytes. No buffers were excluded to manufacture a fit.
- Tables and auxiliary heads are training-only. Latency uses unchanged frozen models and validation inputs; held-out prediction parity is checked. Working-memory measurements count CPU tensor allocations, not total RSS, Python/runtime or allocator reserve.
- The 64-class synthetic task uses 16 training examples per class and disjoint nuisance combinations. The small sample regime stresses both representation and generalization; it does not isolate pure information capacity.
- Three times the prior updates is not a convergence guarantee. The last-quarter validation improvement check flags an unresolved training-budget explanation instead of treating it as a capacity failure.
- Breast-cancer data is reserved solely as an ML confirmation task; it remains unopened if the gate fails. No clinical claim is intended.
