# 32–256-KiB direct-distance capacity test

Completed 480 feasible candidates and evaluated 240 validation-selected checkpoints. Explicitly recorded 0 infeasible configurations across seeds. New seeds, 6,000 updates per candidate, same-teacher ablation. No cloud resources.

**Comparisons passing every predeclared confirmation gate: 0. Confirmation dataset has not been loaded.**

## Development results

| Task | Cap KiB | Arm | Accuracy | CE | Actual tensor bytes | Fast query us | Late-improving seeds |
|---|---:|---|---:|---:|---:|---:|---:|
| digits | 32 | dense | 96.52% | 0.1389 | 32680 | 14.80 | 0 / 5 |
| digits | 32 | dense_teacher | 97.01% | 0.1419 | 32680 | 13.98 | 0 / 5 |
| digits | 32 | coordinates_teacher | 97.12% | 0.1184 | 32468 | 29.58 | 0 / 5 |
| digits | 32 | direct | 95.76% | 0.1875 | 32208 | 40.46 | 0 / 5 |
| digits | 32 | distilled_logits_only | 98.26% | 0.0701 | 32208 | 38.21 | 0 / 5 |
| digits | 32 | distilled | 97.93% | 0.0848 | 32208 | 40.64 | 0 / 5 |
| digits | 64 | dense | 96.74% | 0.1325 | 65164 | 15.16 | 0 / 5 |
| digits | 64 | dense_teacher | 97.55% | 0.1110 | 65164 | 15.52 | 0 / 5 |
| digits | 64 | coordinates_teacher | 96.58% | 0.1510 | 65172 | 30.87 | 0 / 5 |
| digits | 64 | direct | 96.14% | 0.1764 | 64984 | 45.15 | 0 / 5 |
| digits | 64 | distilled_logits_only | 97.88% | 0.0811 | 64984 | 45.23 | 0 / 5 |
| digits | 64 | distilled | 97.83% | 0.0800 | 64984 | 45.30 | 0 / 5 |
| digits | 128 | dense | 96.79% | 0.1257 | 130280 | 16.10 | 0 / 5 |
| digits | 128 | dense_teacher | 97.34% | 0.1156 | 130280 | 16.22 | 0 / 5 |
| digits | 128 | coordinates_teacher | 97.01% | 0.1405 | 130096 | 29.96 | 0 / 5 |
| digits | 128 | direct | 95.98% | 0.1954 | 130296 | 54.28 | 0 / 5 |
| digits | 128 | distilled_logits_only | 97.99% | 0.0793 | 130296 | 54.44 | 0 / 5 |
| digits | 128 | distilled | 97.88% | 0.0977 | 130296 | 52.08 | 0 / 5 |
| digits | 256 | dense | 96.68% | 0.1368 | 261896 | 16.31 | 0 / 5 |
| digits | 256 | dense_teacher | 97.28% | 0.1066 | 261896 | 17.28 | 0 / 5 |
| digits | 256 | coordinates_teacher | 97.55% | 0.1247 | 261424 | 30.84 | 0 / 5 |
| digits | 256 | direct | 96.03% | 0.1663 | 261528 | 62.40 | 0 / 5 |
| digits | 256 | distilled_logits_only | 98.15% | 0.0772 | 261528 | 63.36 | 0 / 5 |
| digits | 256 | distilled | 97.99% | 0.0778 | 261528 | 64.82 | 0 / 5 |
| context64 | 32 | dense | 41.22% | 1.6093 | 32704 | 11.89 | 0 / 5 |
| context64 | 32 | dense_teacher | 40.97% | 1.5395 | 32704 | 11.82 | 0 / 5 |
| context64 | 32 | coordinates_teacher | 47.43% | 1.7485 | 32672 | 26.26 | 0 / 5 |
| context64 | 32 | direct | 60.60% | 1.5467 | 32388 | 84.77 | 0 / 5 |
| context64 | 32 | distilled_logits_only | 61.25% | 1.2089 | 32388 | 87.09 | 0 / 5 |
| context64 | 32 | distilled | 59.59% | 1.2325 | 32388 | 89.08 | 0 / 5 |
| context64 | 64 | dense | 41.74% | 1.7979 | 65536 | 13.85 | 0 / 5 |
| context64 | 64 | dense_teacher | 41.37% | 1.7785 | 65536 | 14.49 | 0 / 5 |
| context64 | 64 | coordinates_teacher | 39.60% | 1.9117 | 65372 | 27.28 | 0 / 5 |
| context64 | 64 | direct | 59.80% | 1.7873 | 65280 | 129.13 | 0 / 5 |
| context64 | 64 | distilled_logits_only | 61.57% | 1.2490 | 65280 | 123.15 | 0 / 5 |
| context64 | 64 | distilled | 61.55% | 1.2676 | 65280 | 131.54 | 0 / 5 |
| context64 | 128 | dense | 43.86% | 1.9654 | 130896 | 16.49 | 0 / 5 |
| context64 | 128 | dense_teacher | 44.38% | 2.2345 | 130896 | 16.48 | 0 / 5 |
| context64 | 128 | coordinates_teacher | 40.52% | 1.8637 | 130288 | 28.83 | 0 / 5 |
| context64 | 128 | direct | 57.98% | 2.0461 | 129768 | 171.05 | 0 / 5 |
| context64 | 128 | distilled_logits_only | 61.70% | 1.3177 | 129768 | 172.69 | 0 / 5 |
| context64 | 128 | distilled | 60.46% | 1.3309 | 129768 | 173.36 | 0 / 5 |
| context64 | 256 | dense | 48.94% | 1.8529 | 262096 | 17.48 | 0 / 5 |
| context64 | 256 | dense_teacher | 49.51% | 2.4297 | 262096 | 17.44 | 4 / 5 |
| context64 | 256 | coordinates_teacher | 39.66% | 1.9309 | 261752 | 30.69 | 0 / 5 |
| context64 | 256 | direct | 54.83% | 1.9727 | 261888 | 238.69 | 0 / 5 |
| context64 | 256 | distilled_logits_only | 62.16% | 1.3717 | 261888 | 240.72 | 0 / 5 |
| context64 | 256 | distilled | 61.82% | 1.3636 | 261888 | 237.18 | 0 / 5 |

## Gate comparisons

All gates and the conditional confirmation protocol were saved before training in PROTOCOL.json. Simultaneous paired t intervals use the fixed 28-comparison family, including infeasible planned comparisons, at 95% family confidence. Overlapping digits splits and only five seeds limit inference; these are development results.

A storage claim requires half the deployed bytes with no more than a one-point accuracy loss, and an advantage over the same-cap reference. An equal-cap claim requires at least a three-point gain. Every claim additionally requires <=2x latency, <=1.05x total model-plus-query tensor memory, a positive adjusted gain over the same-teacher logits-only ablation, and no material late validation improvement in the relevant models. These are engineering screening rules, not universal breakthrough definitions.

| Task | Student cap KiB | Reference cap KiB | Accuracy difference pp | Adjusted interval pp | Ablation interval pp | Failed gates in fastest mode |
|---|---:|---:|---:|---|---|---|
| digits | 32 | 32 | +0.33 | [-1.72, +2.37] | [-1.80, +1.15] | accuracy, working_memory, mechanism |
| digits | 32 | 64 | +0.38 | [-1.12, +1.88] | [-1.80, +1.15] | accuracy, latency, frontier, mechanism |
| digits | 32 | 128 | +0.82 | [-2.23, +3.86] | [-1.80, +1.15] | accuracy, latency, frontier, mechanism |
| digits | 32 | 256 | +0.33 | [-1.91, +2.56] | [-1.80, +1.15] | accuracy, latency, frontier, mechanism |
| digits | 64 | 64 | +0.27 | [-1.41, +1.95] | [-2.00, +1.89] | accuracy, working_memory, latency, mechanism |
| digits | 64 | 128 | +0.71 | [-1.88, +3.29] | [-2.00, +1.89] | accuracy, latency, frontier, mechanism |
| digits | 64 | 256 | +0.22 | [-1.39, +1.82] | [-2.00, +1.89] | accuracy, latency, frontier, mechanism |
| digits | 128 | 128 | +0.76 | [-3.07, +4.59] | [-3.56, +3.35] | accuracy, working_memory, latency, mechanism |
| digits | 128 | 256 | +0.27 | [-3.43, +3.98] | [-3.56, +3.35] | accuracy, latency, frontier, mechanism |
| digits | 256 | 256 | +0.38 | [-0.98, +1.74] | [-2.42, +2.09] | accuracy, working_memory, latency, mechanism |
| context64 | 32 | 32 | +18.41 | [+12.17, +24.65] | [-5.06, +1.74] | working_memory, latency, mechanism |
| context64 | 32 | 64 | +17.98 | [+13.16, +22.81] | [-5.06, +1.74] | working_memory, latency, mechanism |
| context64 | 32 | 128 | +16.27 | [+7.51, +25.03] | [-5.06, +1.74] | working_memory, latency, mechanism |
| context64 | 32 | 256 | +10.66 | [-0.49, +21.81] | [-5.06, +1.74] | latency, mechanism |
| context64 | 64 | 64 | +19.94 | [+15.69, +24.19] | [-6.21, +6.19] | working_memory, latency, mechanism |
| context64 | 64 | 128 | +18.23 | [+9.36, +27.09] | [-6.21, +6.19] | working_memory, latency, mechanism |
| context64 | 64 | 256 | +12.62 | [-2.70, +27.94] | [-6.21, +6.19] | accuracy, latency, mechanism |
| context64 | 128 | 128 | +17.14 | [+5.78, +28.50] | [-4.17, +1.69] | working_memory, latency, mechanism |
| context64 | 128 | 256 | +11.53 | [+2.32, +20.73] | [-4.17, +1.69] | working_memory, latency, mechanism |
| context64 | 256 | 256 | +12.89 | [+1.20, +24.57] | [-3.13, +2.45] | accuracy, working_memory, latency, mechanism |

## Interpretation boundaries

- The deployed distance function is unchanged. No learned coordinate embeddings are used by the direct or distilled arms. Coordinate embeddings remain a labeled competing control.
- Distilled-logits-only has the identical deployment, teacher logits, initialization, schedule and classification targets, but the pair-distance regression weight is zero. It receives no gradient from that term.
- All raw exemplars are counted: 2,560 bytes for digits and 4,096 bytes for context64. Synthetic noise was increased from 0.1 to 0.35 before training; digits remains unchanged for continuity.
- Tables and auxiliary heads are training-only. Latency uses unchanged frozen models and validation inputs; held-out prediction parity is checked. Working-memory measurements count CPU tensor allocations, not total RSS, Python/runtime or allocator reserve.
- The 64-class synthetic task uses 16 training examples per class and disjoint nuisance combinations. The small sample regime stresses both representation and generalization; it does not isolate pure information capacity.
- Twice the preceding training budget is not a convergence guarantee. The last-quarter validation improvement check flags an unresolved training-budget explanation instead of treating it as a capacity failure.
- Breast-cancer data is reserved solely as an ML confirmation task; it remains unopened if the gate fails. No clinical claim is intended.
