"""Below-8-KiB capacity development gate. Prior experiment sources untouched."""
import argparse
import concurrent.futures
import copy
import json
import multiprocessing
from pathlib import Path
import torch
import capacity_sweep as old
from capacity_runtime_followup import predict


def actual_arm(arm):
    return 'distilled' if arm == 'distilled_logits_only' else arm


def kind(arm):
    return 'direct' if actual_arm(arm) in ('distilled', 'direct') else ('coordinates' if arm == 'coordinates_teacher' else 'dense')


def job(c, task, seed, output):
    torch.set_num_threads(c['threads_per_worker'])
    torch.use_deterministic_algorithms(True)
    folder = Path(output)/f'{task}-{seed}'
    folder.mkdir(exist_ok=False)
    old.prepare(c, task, seed, folder)
    payload = torch.load(folder/'training-only.pt', weights_only=True)
    dim, classes = payload['train'][0].shape[-1], len(payload['anchors'])
    records, chosen, infeasible = [], [], []
    for cap in c['scalar_budgets']:
        for arm in c['arms']:
            minimum = old.architecture(c, dim, classes, 1, kind(arm))[0]
            if minimum > cap:
                infeasible.append({'task':task,'seed':seed,'cap':cap,'arm':arm,
                    'minimum_architecture_tensor_bytes':minimum*4,
                    'raw_exemplar_bytes':dim*classes*4 if kind(arm)=='direct' else 0})
                continue
            subdir=folder/arm
            subdir.mkdir(exist_ok=True)
            config=copy.deepcopy(c)
            if arm=='distilled_logits_only':
                config['distill_weight']=0.
            candidates=[]
            for lr in c['learning_rates']:
                row=old.train(config,task,seed,cap,actual_arm(arm),lr,payload,subdir)
                row['arm']=arm
                row['pair_distance_loss_weight']=config['distill_weight'] if arm not in ('dense','direct') else 0.
                candidates.append(row);records.append(row)
                old.write(folder/'CANDIDATES.json',records)
                print(json.dumps({k:row[k] for k in ('task','seed','budget_scalars','arm','lr','validation','training_seconds')}),flush=True)
            chosen.append(min(candidates,key=lambda r:r['validation']['ce']))
    old.write(folder/'SELECTED.json',chosen)
    old.write(folder/'INFEASIBLE.json',infeasible)
    return chosen,infeasible


def assessment(c, selected, output):
    results=[]
    # All comparisons are development evidence: digits has already been used.
    for row in selected:
        r=copy.deepcopy(row)
        (train,valid,test),_=old.data(r['task'],r['seed'],c)
        classes=int(train[1].max())+1
        model=old.Student(c,train[0].shape[-1],classes,r['budget_scalars'],actual_arm(r['arm']),
                          torch.zeros(classes,train[0].shape[-1]))
        path=Path(r['checkpoint'])
        assert old.prior.sha(path)==r['sha256']
        model.load_state_dict(torch.load(path,weights_only=True))
        assert old.evaluate(model,valid)==r['validation']
        r['development_assessment']=old.evaluate(model,test)
        assert old.evaluate(model,test)==r['development_assessment']
        with torch.inference_mode():
            expected=torch.cat([model(x).argmax(-1) for x in test[0].split(128)])
            fast=torch.cat([predict(model,x) for x in test[0].split(128)])
            assert torch.equal(expected,fast)
        query=valid[0][:1]
        r['modes']={'fast':old.profile_call(lambda:predict(model,query),c['benchmark_repeats'])}
        if model.kind=='direct':
            with torch.inference_mode():
                streamed=torch.cat([model.stream(x) for x in test[0].split(128)])
                assert torch.equal(expected,streamed)
            r['modes']['batched']=old.profile_call(lambda:model(query).argmax(-1),c['benchmark_repeats'])
            r['modes']['streaming']=old.profile_call(lambda:model.stream(query),c['benchmark_repeats'])
        early=min(h['ce'] for h in r['history'] if h['step']<=c['steps']*c['late_check_fraction'])
        r['late_validation_ce_improvement']=max(0.,early-r['validation']['ce'])
        r['late_improving']=r['late_validation_ce_improvement']>c['late_ce_tolerance']
        results.append(r)
        old.write(output/'RESULT.json',results)
    old.write(output/'COMPLETION.json',{'models':len(results),'duplicate_assessment_drift':0,
        'frozen_before_assessment':True,'confirmation_dataset_loaded':False,'cloud_resources_created':0})


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',type=Path,default=Path(__file__).with_name('sub8_config.json'))
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    c=json.loads(args.config.read_text())
    torch.set_num_threads(c['threads_per_worker'])
    args.output.mkdir(exist_ok=False,parents=True)
    sources=[Path(__file__),Path(old.__file__),Path(old.prior.__file__),Path(__file__).with_name('capacity_runtime_followup.py')]
    protocol={'config':c,'sources':{str(x.resolve()):old.prior.sha(x) for x in sources},
        'scope':'Development capacity experiment, not independent confirmation. No architecture changes.',
        'storage':'All stored FP32 tensors count, including raw exemplars. Infeasible caps remain infeasible, with no hidden buffers or padding.',
        'ablation':'distilled_logits_only shares architecture, initialization, teacher logits, batches and schedule with distilled, but pair-distance regression weight is zero.',
        'controls':'Dense and coordinate teacher arms receive the same full teacher supervision; dense relational auxiliary head is training-only.',
        'selection':'Validation CE, equal two-LR search. All selections and baseline choices frozen globally before assessment.',
        'convergence':'3x earlier updates; late validation progress audited. No assumption of complete convergence.',
        'confirmation_dataset_loaded':False,'cloud_resources_created':0}
    old.write(args.output/'PROTOCOL.json',protocol)
    for source in sources:
        (args.output/('source-'+source.name)).write_text(source.read_text())
    chosen,infeasible=[],[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=c['workers'],mp_context=multiprocessing.get_context('spawn')) as pool:
        futures=[pool.submit(job,c,t,s,str(args.output.resolve())) for t in c['tasks'] for s in c['seeds']]
        for i,future in enumerate(concurrent.futures.as_completed(futures),1):
            rows,no_fit=future.result();chosen.extend(rows);infeasible.extend(no_fit)
            old.write(args.output/'PROGRESS.json',{'completed_jobs':i,'selected_models':len(chosen)})
    chosen.sort(key=lambda r:(r['task'],r['seed'],r['budget_scalars'],r['arm']))
    baselines=[]
    for task in c['tasks']:
        for seed in c['seeds']:
            for cap in c['scalar_budgets']:
                options=[r for r in chosen if r['task']==task and r['seed']==seed and r['budget_scalars']==cap
                         and r['arm'] in ('dense','dense_teacher','coordinates_teacher')]
                if options:baselines.append(min(options,key=lambda r:r['validation']['ce']))
    old.write(args.output/'FREEZE.json',chosen)
    old.write(args.output/'BASELINE_FREEZE.json',baselines)
    old.write(args.output/'INFEASIBLE.json',infeasible)
    assessment(c,chosen,args.output)


if __name__=='__main__':main()
