"""Parity-gated TorchScript deployment experiment; original trainer untouched."""
import argparse
import copy
import json
import random
import statistics
import time
from pathlib import Path
from typing import Tuple

import torch
from torch import nn
import phase_transition_language as pilot


class PhaseStep(nn.Module):
    __constants__ = ['dynamic', 'width']

    def __init__(self, model):
        super().__init__()
        self.dynamic, self.width = model.dynamic, model.d
        self.embedding = copy.deepcopy(model.embedding)
        self.drive = copy.deepcopy(model.drive)
        self.write = copy.deepcopy(model.write)
        self.norm = copy.deepcopy(model.norm)
        self.retention = nn.Parameter(model.retention.detach().clone(), requires_grad=False)
        self.angle = nn.Parameter(model.angle.detach().clone(), requires_grad=False)
        gain = model.gain.detach().clone() if model.dynamic else torch.zeros_like(model.angle)
        self.gain = nn.Parameter(gain, requires_grad=False)

    def forward(self, token: torch.Tensor, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        embedded = self.embedding(token)
        drive = torch.tanh(self.drive(embedded))
        retention = torch.sigmoid(self.write(embedded) + self.retention)
        pair = state.reshape(token.shape[0], -1, 2)
        theta = self.angle
        if self.dynamic:
            target = drive.reshape(token.shape[0], -1, 2)
            cross = pair[:, :, 0] * target[:, :, 1] - pair[:, :, 1] * target[:, :, 0]
            denominator = torch.sqrt(pair.square().sum(-1) * target.square().sum(-1) + 1e-6)
            theta = theta + self.gain * torch.tanh(cross / denominator)
        cosine, sine = theta.cos(), theta.sin()
        rotated = torch.stack((cosine * pair[:, :, 0] - sine * pair[:, :, 1],
                               sine * pair[:, :, 0] + cosine * pair[:, :, 1]), -1).flatten(1)
        updated = retention * rotated + (1 - retention) * drive
        return self.norm(updated) @ self.embedding.weight.T, updated


def stream(step, tokens, width):
    state = torch.zeros((tokens.shape[0], width), dtype=torch.float32)
    outputs = []
    for index in range(tokens.shape[1]):
        logits, state = step(tokens[:, index], state)
        outputs.append(logits)
    return torch.stack(outputs, 1), state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, required=True)
    parser.add_argument('--warmups', type=int, required=True)
    parser.add_argument('--parity-atol', type=float, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.repeats > 0
    protocol = json.loads((args.source / 'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    frozen = json.loads((args.source / 'FREEZE.json').read_text())
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(config['seeds'][0])
    order_rng = random.Random(config['seeds'][0])
    tokens = torch.randint(256, (1, config['context']))
    args.output.mkdir()
    pilot.shared.write(args.output / 'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source / 'FREEZE.json'),
        'deployment_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'precision': 'FP32', 'repeats': args.repeats, 'warmups': args.warmups,
        'parity_atol': args.parity_atol, 'timing_order': 'Paired eager/scripted trials with seeded shuffled order',
        'scope': 'CPU batch-one streaming adapter, includes Python token loop. Concurrent training contention remains; not a GPU throughput claim. No weight updates or validation selection.',
        'official_test_read': False,
    })
    results = []
    with torch.inference_mode():
        for row in frozen:
            if row['arm'] == 'transformer':
                continue
            path = args.source / Path(row['checkpoint']).name
            assert pilot.shared.prior.sha(path) == row['sha256']
            model = pilot.PhaseLM(config['width'], row['arm'] == 'geometric_rotation')
            model.load_state_dict(torch.load(path, weights_only=True))
            model.float().eval()
            eager = PhaseStep(model).eval()
            scripted = torch.jit.freeze(torch.jit.script(eager))
            full = model(tokens)
            a, state_a = stream(eager, tokens, config['width'])
            b, state_b = stream(scripted, tokens, config['width'])
            assert torch.allclose(full, a, atol=args.parity_atol, rtol=args.parity_atol)
            assert torch.allclose(a, b, atol=args.parity_atol, rtol=args.parity_atol)
            assert torch.allclose(state_a, state_b, atol=args.parity_atol, rtol=args.parity_atol)
            modes = {'eager': eager, 'scripted': scripted}
            for implementation in modes.values():
                for _ in range(args.warmups):
                    stream(implementation, tokens, config['width'])
            timings = {name: [] for name in modes}
            for _ in range(args.repeats):
                order = list(modes)
                order_rng.shuffle(order)
                for name in order:
                    start = time.perf_counter()
                    stream(modes[name], tokens, config['width'])
                    timings[name].append((time.perf_counter()-start) * 1e6 / config['context'])
            results.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                            'eager_vs_full_max_error': (full-a).abs().max().item(),
                            'scripted_vs_eager_max_error': (a-b).abs().max().item(),
                            'median_us_per_token': {name: statistics.median(values) for name, values in timings.items()},
                            'state_bytes': state_b.numel()*state_b.element_size()})
            pilot.shared.write(args.output / 'RESULT.json', results)
            print(json.dumps(results[-1]), flush=True)
    pilot.shared.write(args.output / 'COMPLETION.json', {'checkpoints': len(results), 'official_test_read': False})


if __name__ == '__main__':
    main()
