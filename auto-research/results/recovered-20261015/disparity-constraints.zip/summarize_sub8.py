"""Audit the development sweep and decide whether untouched confirmation opens."""
import argparse
import collections
import json
import math
import os
from pathlib import Path
import statistics
from scipy.stats import t
import torch
import sub8_sweep as run


def average(values):return statistics.mean(values)


def ci(values,alpha):
    m=average(values)
    radius=float(t.ppf(1-alpha/2,len(values)-1))*statistics.stdev(values)/math.sqrt(len(values))
    return [m-radius,m+radius]


def main(out):
    p=json.loads((out/'PROTOCOL.json').read_text());c=p['config'];crit=c['criteria']
    done=json.loads((out/'COMPLETION.json').read_text())
    assert done['confirmation_dataset_loaded'] is False
    for path,digest in p['sources'].items():
        assert run.old.prior.sha(Path(path))==digest
        assert run.old.prior.sha(out/('source-'+Path(path).name))==digest
    rows=json.loads((out/'RESULT.json').read_text())
    frozen=json.loads((out/'FREEZE.json').read_text())
    bases=json.loads((out/'BASELINE_FREEZE.json').read_text())
    no_fit=json.loads((out/'INFEASIBLE.json').read_text())
    candidates=[r for file in out.glob('*/CANDIDATES.json') for r in json.loads(file.read_text())]
    all_combinations=len(c['tasks'])*len(c['seeds'])*len(c['scalar_budgets'])*len(c['arms'])
    assert len(rows)==len(frozen)==done['models']
    assert len(rows)+len(no_fit)==all_combinations
    assert len(candidates)==len(rows)*len(c['learning_rates'])
    for r in candidates:
        path=Path(r['checkpoint']);assert run.old.prior.sha(path)==r['sha256']
        state=torch.load(path,weights_only=True)
        assert sum(v.numel()*v.element_size() for v in state.values())==r['deployed_tensor_bytes']
        assert r['deployed_tensor_bytes']<=r['budget_scalars']*4
        assert not any('auxiliary' in k or 'matrix' in k for k in state)
    for r in no_fit:assert r['minimum_architecture_tensor_bytes']>r['cap']*4
    key=lambda r:(r['task'],r['seed'],r['budget_scalars'],r['arm'])
    idx={key(r):r for r in rows};fidx={key(r):r for r in frozen}
    for r in rows:
        assert r['sha256']==fidx[key(r)]['sha256']
        options=[a for a in candidates if key(a)==key(r)]
        assert r['validation']['ce']==min(a['validation']['ce'] for a in options)
    bidx={}
    for b in bases:
        options=[r for r in frozen if r['task']==b['task'] and r['seed']==b['seed'] and r['budget_scalars']==b['budget_scalars']
                 and r['arm'] in ('dense','dense_teacher','coordinates_teacher')]
        assert b['sha256']==min(options,key=lambda r:r['validation']['ce'])['sha256']
        bidx[(b['task'],b['seed'],b['budget_scalars'])]=idx[key(b)]
    # Keep infeasible comparisons in the fixed planned multiplicity family.
    cap_pairs=[(a,b) for a in c['scalar_budgets'] for b in c['scalar_budgets'] if a<=b]
    family=len(c['tasks'])*(len(cap_pairs)+len(c['scalar_budgets']))
    alpha=(1-crit['confidence_level'])/family
    groups=[];comparisons=[];passers=[]
    for task in c['tasks']:
        for cap in c['scalar_budgets']:
            for arm in c['arms']:
                group=[idx[(task,s,cap,arm)] for s in c['seeds'] if (task,s,cap,arm) in idx]
                if not group:
                    groups.append({'task':task,'cap':cap,'arm':arm,'feasible':False});continue
                groups.append({'task':task,'cap':cap,'arm':arm,'feasible':True,
                    'accuracy':average(r['development_assessment']['accuracy'] for r in group),
                    'ce':average(r['development_assessment']['ce'] for r in group),
                    'deployed_bytes':average(r['deployed_tensor_bytes'] for r in group),
                    'query_us':average(r['modes']['fast']['median_single_query_us'] for r in group),
                    'query_tensor_peak_bytes':average(r['modes']['fast']['incremental_cpu_tensor_peak_bytes'] for r in group),
                    'late_improving_models':sum(r['late_improving'] for r in group),
                    'mean_selected_step':average(r['best_step'] for r in group)})
        for a,b in cap_pairs:
            if not all((task,s,a,'distilled') in idx for s in c['seeds']):continue
            student=[idx[(task,s,a,'distilled')] for s in c['seeds']]
            base=[bidx[(task,s,b)] for s in c['seeds']]
            samecap=[bidx[(task,s,a)] for s in c['seeds']]
            ablation=[idx[(task,s,a,'distilled_logits_only')] for s in c['seeds']]
            diff=[x['development_assessment']['accuracy']-y['development_assessment']['accuracy'] for x,y in zip(student,base)]
            same_diff=[x['development_assessment']['accuracy']-y['development_assessment']['accuracy'] for x,y in zip(student,samecap)]
            ablation_diff=[x['development_assessment']['accuracy']-y['development_assessment']['accuracy'] for x,y in zip(student,ablation)]
            bounds=ci(diff,alpha);same_bounds=ci(same_diff,alpha);ablation_bounds=ci(ablation_diff,alpha)
            weight_ratio=average(x['deployed_tensor_bytes'] for x in student)/average(x['deployed_tensor_bytes'] for x in base)
            stable=not any(r['late_improving'] for r in student+base+samecap+ablation)
            mode_results=[]
            for mode in student[0]['modes']:
                latency=average(x['modes'][mode]['median_single_query_us'] for x in student)/average(x['modes']['fast']['median_single_query_us'] for x in base)
                footprint=average(x['deployed_tensor_bytes']+x['modes'][mode]['incremental_cpu_tensor_peak_bytes'] for x in student)/average(
                    x['deployed_tensor_bytes']+x['modes']['fast']['incremental_cpu_tensor_peak_bytes'] for x in base)
                gates={'accuracy':bounds[0]>=(crit['material_accuracy_gain'] if a==b else -crit['comparable_accuracy_tolerance']),
                    'stored_bytes':weight_ratio<=(crit['maximum_equal_memory_ratio'] if a==b else crit['maximum_memory_ratio_for_savings']),
                    'working_memory':footprint<=crit['maximum_equal_memory_ratio'],
                    'latency':latency<=crit['maximum_latency_ratio'],
                    'frontier':a==b or same_bounds[0]>crit['comparable_accuracy_tolerance'],
                    'mechanism':ablation_bounds[0]>0,'training_stability':stable}
                gates={k:bool(v) for k,v in gates.items()}
                mode_results.append({'mode':mode,'latency_ratio':latency,'total_tensor_ratio':footprint,
                                     'gates':gates,'passes':all(gates.values())})
            row={'task':task,'student_cap':a,'baseline_cap':b,'accuracy_difference':average(diff),
                 'interval':bounds,'same_cap_interval':same_bounds,'ablation_interval':ablation_bounds,
                 'weight_ratio':weight_ratio,'baseline_arms':[r['arm'] for r in base],
                 'student_lrs':[r['lr'] for r in student],'baseline_lrs':[r['lr'] for r in base],
                 'modes':mode_results}
            comparisons.append(row)
            if any(m['passes'] for m in mode_results):passers.append(row)
    passers.sort(key=lambda r:(-r['interval'][0],r['student_cap']))
    summary={'candidate_hashes_verified':len(candidates),'selected':len(rows),'infeasible':len(no_fit),
             'planned_accuracy_comparison_family':family,'groups':groups,'comparisons':comparisons,
             'confirmation_gate_passers':passers,'confirmation_dataset_loaded':False,
             'source_sha256':run.old.prior.sha(Path(__file__)),
             'interpretation':'Exploratory development intervals across five seeds, not proof of novelty or an independent real-world confirmation.'}
    run.old.write(out/'SUMMARY.json',summary)
    decision={'status':'eligible_pending_configuration_freeze' if passers else 'not_opened_gate_not_met',
              'dataset':c['confirmation']['dataset'],'dataset_loaded':False,
              'winning_comparison':passers[0] if passers else None,'planned_protocol':c['confirmation']}
    run.old.write(out/'CONFIRMATION_GATE.json',decision)
    lines=['# Below-8-KiB direct-distance capacity test','',
           f"Completed {len(candidates)} feasible candidates and evaluated {len(rows)} validation-selected checkpoints. Explicitly recorded {len(no_fit)} infeasible configurations across seeds. New seeds, 3,000 updates per candidate, same-teacher ablation. No cloud resources.",'',
           f"**Comparisons passing every predeclared confirmation gate: {len(passers)}. Confirmation dataset has not been loaded.**",'',
           '## Development results','',
           '| Task | Cap KiB | Arm | Accuracy | CE | Actual tensor bytes | Fast query us | Late-improving seeds |',
           '|---|---:|---|---:|---:|---:|---:|---:|']
    for g in groups:
        if not g['feasible']:
            lines.append(f"| {g['task']} | {g['cap']/256:g} | {g['arm']} | Infeasible | — | — | — | — |")
        else:
            lines.append(f"| {g['task']} | {g['cap']/256:g} | {g['arm']} | {g['accuracy']:.2%} | {g['ce']:.4f} | {g['deployed_bytes']:.0f} | {g['query_us']:.2f} | {g['late_improving_models']} / 5 |")
    lines+=['','## Gate comparisons','',
            f"All gates and the conditional confirmation protocol were saved before training in PROTOCOL.json. Simultaneous paired t intervals use the fixed {family}-comparison family, including infeasible planned comparisons, at 95% family confidence. Overlapping digits splits and only five seeds limit inference; these are development results.",'',
            'A storage claim requires half the deployed bytes with no more than a one-point accuracy loss, and an advantage over the same-cap reference. An equal-cap claim requires at least a three-point gain. Every claim additionally requires <=2x latency, <=1.05x total model-plus-query tensor memory, a positive adjusted gain over the same-teacher logits-only ablation, and no material late validation improvement in the relevant models. These are engineering screening rules, not universal breakthrough definitions.','',
            '| Task | Student cap KiB | Reference cap KiB | Accuracy difference pp | Adjusted interval pp | Ablation interval pp | Failed gates in fastest mode |',
            '|---|---:|---:|---:|---|---|---|']
    for r in comparisons:
        mode=r['modes'][0]
        lines.append(f"| {r['task']} | {r['student_cap']/256:g} | {r['baseline_cap']/256:g} | {r['accuracy_difference']*100:+.2f} | [{r['interval'][0]*100:+.2f}, {r['interval'][1]*100:+.2f}] | [{r['ablation_interval'][0]*100:+.2f}, {r['ablation_interval'][1]*100:+.2f}] | {', '.join(k for k,v in mode['gates'].items() if not v) or 'none'} |")
    lines+=['','## Interpretation boundaries','',
            '- The deployed distance function is unchanged. No learned coordinate embeddings are used by the direct or distilled arms. Coordinate embeddings remain a labeled competing control.',
            '- Distilled-logits-only has the identical deployment, teacher logits, initialization, schedule and classification targets, but the pair-distance regression weight is zero. It receives no gradient from that term.',
            '- Digits raw exemplars alone occupy 2,560 bytes; the minimal configured direct generator requires 3,096 bytes. At 64 concepts the exemplars alone occupy 4,096 bytes. No buffers were excluded to manufacture a fit.',
            '- Tables and auxiliary heads are training-only. Latency uses unchanged frozen models and validation inputs; held-out prediction parity is checked. Working-memory measurements count CPU tensor allocations, not total RSS, Python/runtime or allocator reserve.',
            '- The 64-class synthetic task uses 16 training examples per class and disjoint nuisance combinations. The small sample regime stresses both representation and generalization; it does not isolate pure information capacity.',
            '- Three times the prior updates is not a convergence guarantee. The last-quarter validation improvement check flags an unresolved training-budget explanation instead of treating it as a capacity failure.',
            '- Breast-cancer data is reserved solely as an ML confirmation task; it remains unopened if the gate fails. No clinical claim is intended.']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    os.environ.setdefault('MPLCONFIGDIR','/private/tmp/sub8-mpl')
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,len(c['tasks']),figsize=(12,4.5))
    for ax,task in zip(axes,c['tasks']):
        for arm in c['arms']:
            selected=[g for g in groups if g['task']==task and g['arm']==arm and g['feasible']]
            if selected:ax.plot([g['deployed_bytes']/1024 for g in selected],[100*g['accuracy'] for g in selected],'o-',label=arm)
        ax.set_title(task);ax.set_xlabel('Deployed tensors (KiB)');ax.set_ylabel('Development assessment accuracy (%)');ax.grid(alpha=.25)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=3,fontsize=8)
    fig.suptitle('Below-8-KiB capacity: five new seeds, 3,000 updates per candidate')
    fig.tight_layout(rect=(0,.14,1,.94));fig.savefig(out/'capacity.png',dpi=160)
    print(json.dumps({'passers':len(passers),'confirmation':decision['status'],'report':str(out/'REPORT.md')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);main(p.parse_args().output)
