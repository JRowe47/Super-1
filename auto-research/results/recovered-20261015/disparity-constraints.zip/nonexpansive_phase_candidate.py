"""Gate-derived state-sensitivity bound for two generated rotation banks.

For fixed input, each bank has Jacobian norm at most 1+max(abs(gain)).
The normalized oriented-area query satisfies ||state||*||grad(query)||<=1;
tanh cannot increase that bound. Let g=max(retention), and constrain each
gain to (g**(-1/2)-1)*tanh(raw_gain). The complete state transition then has
Jacobian norm bounded by g*(1+cap)**2 = 1. This is only a state-to-state
bound at fixed input, not an output/parameter-gradient or hierarchy bound.
"""
import copy
import json

import torch
import noncommuting_phase_candidate as source


class NonexpansivePhaseLM(source.OverlappingPhaseLM):
    def transition(self, state, drive, retention):
        cap = retention.max(-1, keepdim=True).values.clamp_min(torch.finfo(retention.dtype).tiny).rsqrt()-1
        first_gain = cap*torch.tanh(self.gain)
        second_gain = cap*torch.tanh(self.second_gain)
        theta = self.angle_for(state, drive, self.angle, first_gain, 0)
        transported = source.rotate(state, theta, 0)
        second_theta = self.angle_for(transported, drive, self.second_angle, second_gain, 1)
        transported = source.rotate(transported, second_theta, 1)
        return retention*transported+(1-retention)*drive

    def forward(self, tokens):
        embedded = self.embedding(tokens)
        drive = torch.tanh(self.drive(embedded))
        retention = torch.sigmoid(self.write(embedded)+self.retention)
        state = embedded.new_zeros((len(tokens), self.d))
        history = []
        for index in range(tokens.shape[1]):
            state = self.transition(state, drive[:, index], retention[:, index])
            history.append(state)
        return self.norm(torch.stack(history, 1))@self.embedding.weight.T


def checks():
    torch.manual_seed(41)
    model = NonexpansivePhaseLM(16, True).double()
    fixed = source.OverlappingPhaseLM(16, False).double()
    copied = {name: tensor for name, tensor in model.state_dict().items() if name not in {'gain', 'second_gain'}}
    fixed.load_state_dict(copied)
    tokens = torch.randint(256, (2, 8))
    assert torch.equal(model(tokens), fixed(tokens))
    model(tokens).square().sum().backward()
    assert torch.isfinite(model.gain.grad).all() and model.gain.grad.abs().sum()>0
    assert torch.isfinite(model.second_gain.grad).all() and model.second_gain.grad.abs().sum()>0
    with torch.no_grad():
        model.angle.normal_()
        model.second_angle.normal_()
        model.gain.normal_(std=3)
        model.second_gain.normal_(std=3)
    maxima = []
    for retention_level in [0.01, 0.2, 0.8, 0.9999]:
        state = torch.randn(1, 16, dtype=torch.float64)
        drive = torch.randn_like(state).tanh()
        retention = torch.full_like(state, retention_level)
        jacobian = torch.autograd.functional.jacobian(
            lambda value: model.transition(value.reshape(1, 16), drive, retention).flatten(), state.flatten(), vectorize=True)
        maximum = torch.linalg.svdvals(jacobian).max().item()
        assert maximum<=1+1e-12
        maxima.append({'retention': retention_level, 'max_state_jacobian_singular': maximum})
    original = model(tokens)
    changed = tokens.clone()
    changed[:, 4:] = torch.randint(256, (2, 4))
    assert torch.equal(original[:, :4], model(changed)[:, :4])
    return {'zero_gain_identity': True, 'both_gain_gradients_nonzero': True,
            'sampled_state_sensitivity_bound': maxima, 'causal_prefix': True,
            'trained': False, 'novelty_established': False,
            'scope': 'Fixed-input recurrent-state Jacobian only; no guarantee on output or parameter gradients. This does not apply to the original hierarchy, whose gates depend on state.'}


if __name__ == '__main__':
    torch.set_num_threads(1)
    print(json.dumps(checks()))
