"""Recover an interrupted sealed sweep without retraining completed trials.

Only orchestration is adapted. The sealed runner's optimizer/update/evaluation
loop is executed unchanged, and its original protocol remains immutable.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import run_pair_energy_phase as experiment


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    source = args.source.resolve()
    protocol_path = source / 'PROTOCOL.json'
    protocol = json.loads(protocol_path.read_text())
    config = protocol['config']
    assert not (source / 'COMPLETION.json').exists(), 'Sweep is already terminal'
    runner = experiment.runner
    expected_sources = {
        runner.__file__: protocol['runner_source_sha256'],
        runner.pilot.__file__: protocol['source_sha256'],
        runner.candidate.__file__: protocol['candidate_source_sha256'],
        **protocol['checks']['source_hashes'],
    }
    for path, expected in expected_sources.items():
        assert digest(path) == expected, f'Sealed source drift: {path}'
    for split, expected in protocol['data_sha256'].items():
        assert split in ('train', 'valid')
        assert digest(runner.pilot.DATA / (split + '.txt')) == expected
    rows = json.loads((source / 'CANDIDATES.json').read_text())
    order = [(seed, arm, lr) for seed in config['seeds']
             for arm in config['arms'] for lr in config['lrs']]
    keys = [(row['seed'], row['arm'], row['lr']) for row in rows]
    assert keys == order[:len(rows)], 'Completed trials must be an exact prefix'
    for row in rows:
        checkpoint = source / Path(row['checkpoint']).name
        assert checkpoint.resolve() == Path(row['checkpoint']).resolve()
        assert digest(checkpoint) == row['sha256']
        assert row['parameters'] == protocol['parameters'][row['arm']]
        assert [item['step'] for item in row['history']] == list(
            range(config['validation_interval'], config['steps'] + 1,
                  config['validation_interval']))
        best = min(row['history'], key=lambda item: item['ce'])
        assert row['best_step'] == best['step']
        assert row['validation'] == {key: value for key, value in best.items() if key != 'step'}
    for seed, arm, lr in order[len(rows):]:
        assert not (source / f'{seed}-{arm}-{lr}.pt').exists(), 'Unaccounted checkpoint'
    code = Path(runner.__file__).read_text()
    replacements = {
        '    assert not args.output.exists()\n    args.output.mkdir()':
        '    assert args.output.resolve() == recovery_source\n',
        '    rows, frozen = [], []': '    rows, frozen = list(recovery_rows), []',
        "            for lr in config['lrs']:\n":
        "            for lr in config['lrs']:\n"
        "                cached = recovery_index.get((seed, arm, lr))\n"
        "                if cached is not None:\n"
        "                    trials.append(cached)\n"
        "                    continue\n",
    }
    for old, new in replacements.items():
        assert code.count(old) == 1, 'Runner orchestration shape changed'
        code = code.replace(old, new)
    receipt = {'completed_trials_preserved': len(rows),
               'remaining_trials': len(order) - len(rows),
               'source_protocol_sha256': digest(protocol_path),
               'recovery_script_sha256': digest(__file__),
               'executed_runner_sha256': hashlib.sha256(code.encode()).hexdigest(),
               'interrupted_trial_restarts_from_original_seed': True,
               'training_update_loop_changed': False,
               'official_test_read': False, 'cloud_resources_created': 0}
    print(json.dumps(receipt), flush=True)
    if args.verify_only:
        return
    receipt_path = source / 'RECOVERY.json'
    assert not receipt_path.exists(), 'Recovery already dispatched; inspect its process first'
    runner.pilot.shared.write(receipt_path, receipt)
    original_write = runner.pilot.shared.write

    def preserve_protocol(path, payload):
        if Path(path).resolve() == protocol_path:
            for key in ('config', 'parameters', 'data_sha256', 'source_sha256',
                        'candidate_source_sha256', 'runner_source_sha256',
                        'transformer_width', 'transformer_ff_width', 'contract'):
                assert payload[key] == protocol[key], f'Recovery contract drift: {key}'
            assert payload['checks']['source_hashes'] == protocol['checks']['source_hashes']
            assert digest(protocol_path) == receipt['source_protocol_sha256']
            return
        return original_write(path, payload)

    runner.pilot.shared.write = preserve_protocol
    runner.recovery_source = source
    runner.recovery_rows = rows
    runner.recovery_index = dict(zip(keys, rows))
    exec(compile(code, runner.__file__, 'exec'), runner.__dict__)
    runner.builders = experiment.builders
    runner.candidate.checks = experiment.checks
    sys.argv = [runner.__file__, '--config', str(source.parent / (source.name + '.json')),
                '--output', str(source)]
    runner.main()


if __name__ == '__main__':
    main()
