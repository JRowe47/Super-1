"""One-pass official-split evaluation of previously frozen byte-model winners."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import time
import torch
import nanogpt_compare as pilot


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evaluate_all_targets(model, tokens, context):
    model.eval()
    total, correct, count = 0., 0, 0
    started = time.perf_counter()
    with torch.inference_mode():
        full = (len(tokens)-1)//context*context
        for start in range(0,full,context*16):
            end=min(start+context*16,full)
            x=tokens[start:end].reshape(-1,context)
            y=tokens[start+1:end+1].reshape(-1,context)
            logits,loss=model(x,y)
            total+=float(loss)*y.numel()
            correct+=int((logits.argmax(-1)==y).sum())
            count+=y.numel()
        # Cover the final partial context instead of dropping remaining bytes.
        if full<len(tokens)-1:
            x=tokens[full:-1][None,:]
            y=tokens[full+1:][None,:]
            logits,loss=model(x,y)
            total+=float(loss)*y.numel()
            correct+=int((logits.argmax(-1)==y).sum())
            count+=y.numel()
    assert count==len(tokens)-1
    return dict(ce=total/count,bpc=total/count/math.log(2),accuracy=correct/count,
                targets=count,tail_targets=(len(tokens)-1)%context,seconds=time.perf_counter()-started)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--run",type=Path,required=True)
    args=parser.parse_args()
    root=args.run
    protocol=json.loads((root/"PROTOCOL.json").read_text())
    winners=json.loads((root/"RESULT.json").read_text())
    candidates=json.loads((root/"CANDIDATES.json").read_text())
    c=protocol["config"]
    assert sha(Path(pilot.__file__))==protocol["source_sha256"]
    assert sha(Path(c["nanogpt_source"]))==c["nanogpt_sha256"]
    assert len(winners)==len(c["seeds"])*len(pilot.ARMS)
    assert {(r["seed"],r["arm"]) for r in winners}=={(s,a) for s in c["seeds"] for a in pilot.ARMS}
    for r in winners:
        assert sha(root/r["checkpoint"])==r["sha256"]
        assert r["selection_ce"]==min(v["selection_ce"] for v in candidates if (v["seed"],v["arm"])==(r["seed"],r["arm"]))
    out=root/"official-test-20260912"
    out.mkdir(exist_ok=False)
    freeze={"authorization":"User explicitly requested official test evaluation after explanation of the split",
            "pilot_result_sha256":sha(root/"RESULT.json"),"evaluator_sha256":sha(Path(__file__)),
            "checkpoints":[{k:r[k] for k in ("seed","arm","checkpoint","sha256")} for r in winners],
            "evaluation":"one pass per frozen checkpoint, FP32 CPU, all next-byte targets exactly once, context resets every 32 bytes, final partial context included",
            "selection":"none from official test; all nine validation-selected winners reported"}
    (out/"FREEZE.json").write_text(json.dumps(freeze,indent=2))
    torch.set_num_threads(c["threads"])
    torch.use_deterministic_algorithms(True)
    spec=importlib.util.spec_from_file_location("pinned_nanogpt",c["nanogpt_source"])
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    test_path=Path(c["data_root"])/"test.txt"
    test_bytes=test_path.read_bytes()
    tokens=torch.tensor(list(test_bytes),dtype=torch.long)
    (out/"DATA.json").write_text(json.dumps({"path":str(test_path),"sha256":hashlib.sha256(test_bytes).hexdigest(),
        "bytes":len(test_bytes),"preprocessing":"bytes of word-preprocessed WikiText-2 text; not raw-v1 or word-level evaluation"},indent=2))
    records=[]
    for r in winners:
        model=pilot.make(module,c,r["seed"],r["arm"])
        state=torch.load(root/r["checkpoint"],weights_only=True)
        model.load_state_dict(state)
        assert sum(p.numel() for p in model.parameters())==protocol["parameters"]
        metrics=evaluate_all_targets(model,tokens,c["context"])
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in state.items())
        record={"seed":r["seed"],"arm":r["arm"],"checkpoint_sha256":r["sha256"],**metrics}
        records.append(record)
        (out/"RESULT.json").write_text(json.dumps(records,indent=2,allow_nan=False))
        print(json.dumps(record),flush=True)
    means={arm:{key:sum(r[key] for r in records if r["arm"]==arm)/len(c["seeds"]) for key in ("ce","bpc","accuracy")} for arm in pilot.ARMS}
    lines=["# Official WikiText-2 split: frozen byte-model comparison","",
        f"All nine validation-selected checkpoints evaluated once over {len(tokens)-1:,} next-byte targets each. 70,464 parameters each, context 32, 400 training steps. All models use nanoGPT's causal encoder; distance variants change the tied output head. This is a short pilot using bytes of word-preprocessed WikiText-2, not a published word-level benchmark comparison.","",
        "The final partial context is included. CE is nats per byte. No parameters or checkpoint choices were changed based on test results. Evaluation is FP32 CPU; every saved tensor was verified unchanged afterward.","",
        "| Seed | Model | Test CE | BPC | Byte accuracy |","|---:|---|---:|---:|---:|"]
    for r in records:lines.append(f"| {r['seed']} | {r['arm']} | {r['ce']:.6f} | {r['bpc']:.6f} | {100*r['accuracy']:.2f}% |")
    lines += ["","| Model | Mean test CE | Mean BPC | Mean byte accuracy |","|---|---:|---:|---:|"]
    for arm,m in means.items():lines.append(f"| {arm} | {m['ce']:.6f} | {m['bpc']:.6f} | {100*m['accuracy']:.2f}% |")
    (out/"REPORT.md").write_text('\n'.join(lines)+'\n')
    (out/"COMPLETION.json").write_text(json.dumps({"evaluated":len(records),"all_targets_covered":True,"model_tensors_unchanged":True,
        "official_test_opened":True,"means":means,"cloud_resources_created":0},indent=2))


if __name__=="__main__":main()
