# Direct-distance inference capacity sweep

Completed 450 training candidates; 225 validation-selected checkpoints; 5 seeds, 3 storage caps and 3 task conditions. No cloud resources.

**Predeclared joint accuracy/storage/latency screening passes: 3 deployment comparisons; distinct frontier-qualified passes: 0.** A screening pass is not a breakthrough claim. See every comparison in SUMMARY.json.

## Protocol and controls

Teacher arms all receive the same label-trained table, class-logit targets and sampled pair-distance targets. Dense-teacher uses a training-only auxiliary relational head discarded before deployment. Coordinates-teacher compresses relationships into embeddings. Direct and distilled share an identical scalar pair-function architecture; distilled gets additional teacher supervision. Dense and dense-teacher share identical deployed architecture and initialization. All dense models also learn logit scale.

Storage caps are 8, 16 and 32 KiB of deployed FP32 tensors, including exemplars/prototypes and scale. Actual sizes differ slightly because architectures are selected without dummy padding. Every arm uses the same 1,000-update schedule, input batches, two-LR search and validation checkpoints. Training FLOPs differ; this is a fixed-budget comparison, not convergence proof.

The reference baseline for each task/seed/cap is selected by validation CE among dense, dense-teacher and coordinates-teacher, before test access. No reference selection uses test results. All candidates and baselines are globally frozen before evaluation.

## Held-out quality and deployment costs

| Task | Cap KiB | Arm | Accuracy | CE | Actual tensor bytes | Query us | Incremental tensor peak bytes |
|---|---:|---|---:|---:|---:|---:|---:|
| context8 | 8 | dense | 99.88% | 0.0064 | 7856 | 13.10 | 476 |
| context8 | 8 | dense_teacher | 99.79% | 0.0065 | 7856 | 13.45 | 476 |
| context8 | 8 | coordinates_teacher | 99.94% | 0.0015 | 8112 | 26.89 | 544 |
| context8 | 8 | direct | 99.98% | 0.0005 | 7996 | 47.60 | 3808 |
| context8 | 8 | distilled | 100.00% | 0.0001 | 7996 | 46.57 | 3808 |
| context8 | 16 | dense | 99.94% | 0.0029 | 16064 | 13.53 | 764 |
| context8 | 16 | dense_teacher | 99.92% | 0.0018 | 16064 | 13.55 | 764 |
| context8 | 16 | coordinates_teacher | 100.00% | 0.0002 | 16320 | 26.76 | 760 |
| context8 | 16 | direct | 99.98% | 0.0003 | 15964 | 51.20 | 5856 |
| context8 | 16 | distilled | 100.00% | 0.0002 | 15964 | 50.58 | 5856 |
| context8 | 32 | dense | 99.96% | 0.0019 | 32496 | 16.67 | 1180 |
| context8 | 32 | dense_teacher | 99.98% | 0.0018 | 32496 | 16.26 | 1180 |
| context8 | 32 | coordinates_teacher | 100.00% | 0.0001 | 32752 | 30.12 | 1176 |
| context8 | 32 | direct | 100.00% | 0.0003 | 32768 | 63.68 | 9056 |
| context8 | 32 | distilled | 100.00% | 0.0001 | 32768 | 61.75 | 9056 |
| context32 | 8 | dense | 99.64% | 0.0129 | 8088 | 13.22 | 420 |
| context32 | 8 | dense_teacher | 99.89% | 0.0048 | 8088 | 13.19 | 420 |
| context32 | 8 | coordinates_teacher | 99.84% | 0.0150 | 8128 | 26.62 | 2080 |
| context32 | 8 | direct | 99.87% | 0.0045 | 8176 | 64.87 | 13440 |
| context32 | 8 | distilled | 99.99% | 0.0006 | 8176 | 60.29 | 13440 |
| context32 | 16 | dense | 99.78% | 0.0076 | 16128 | 13.47 | 700 |
| context32 | 16 | dense_teacher | 99.91% | 0.0034 | 16128 | 13.09 | 700 |
| context32 | 16 | coordinates_teacher | 99.88% | 0.0121 | 16048 | 27.48 | 2080 |
| context32 | 16 | direct | 99.87% | 0.0034 | 16192 | 71.25 | 22144 |
| context32 | 16 | distilled | 99.99% | 0.0004 | 16192 | 67.78 | 22144 |
| context32 | 32 | dense | 99.85% | 0.0052 | 32568 | 15.08 | 1100 |
| context32 | 32 | dense_teacher | 99.96% | 0.0019 | 32568 | 14.90 | 1100 |
| context32 | 32 | coordinates_teacher | 99.83% | 0.0119 | 32064 | 30.35 | 2080 |
| context32 | 32 | direct | 99.92% | 0.0027 | 32536 | 81.37 | 34944 |
| context32 | 32 | distilled | 99.99% | 0.0006 | 32536 | 79.57 | 34944 |
| digits | 8 | dense | 94.89% | 0.1880 | 7976 | 13.27 | 220 |
| digits | 8 | dense_teacher | 96.30% | 0.1553 | 7976 | 13.01 | 220 |
| digits | 8 | coordinates_teacher | 97.50% | 0.1076 | 7956 | 26.24 | 672 |
| digits | 8 | direct | 93.91% | 0.2000 | 7824 | 46.65 | 5960 |
| digits | 8 | distilled | 96.03% | 0.1671 | 7824 | 47.15 | 5960 |
| digits | 16 | dense | 95.71% | 0.1627 | 16280 | 13.19 | 412 |
| digits | 16 | dense_teacher | 96.68% | 0.1335 | 16280 | 13.39 | 412 |
| digits | 16 | coordinates_teacher | 95.92% | 0.1272 | 16188 | 26.59 | 672 |
| digits | 16 | direct | 95.82% | 0.1807 | 16116 | 51.13 | 7160 |
| digits | 16 | distilled | 97.72% | 0.0938 | 16116 | 52.06 | 7160 |
| digits | 32 | dense | 96.30% | 0.1491 | 32680 | 16.39 | 732 |
| digits | 32 | dense_teacher | 97.55% | 0.0977 | 32680 | 16.49 | 732 |
| digits | 32 | coordinates_teacher | 97.45% | 0.1052 | 32468 | 31.93 | 720 |
| digits | 32 | direct | 96.63% | 0.1475 | 32208 | 62.58 | 9320 |
| digits | 32 | distilled | 97.77% | 0.0848 | 32208 | 62.53 | 9320 |

## Predeclared claim checks

Comparable accuracy: simultaneous lower bound no worse than -1 percentage point, at most half the actual deployed tensor bytes. Material accuracy gain: simultaneous lower bound at least +3 percentage points at the same storage cap. Both require mean latency at most 2x baseline and total model-plus-query tensor memory at most 1.05x baseline. These are proposed engineering thresholds, not universal scientific definitions.

The 18 accuracy comparisons use paired t intervals across five seeds, Bonferroni-adjusted for a 95% family confidence level. Timing/working-memory comparisons are engineering measurements, not confidence bounds. Two deployment modes share the same accuracy comparison.

A secondary frontier guard avoids calling half-storage matches against oversized baselines distinct advantages when a same-cap baseline already matches accuracy. It requires the existing simultaneous same-cap interval to show the student ahead by more than the one-point equivalence tolerance. Audit correction: ANALYSIS_PROTOCOL.json was created nine seconds after global checkpoint freeze, so this guard is post hoc, not preregistered. It was added before inspecting held-out scores, but assessment had started. The original predeclared screen is reported unchanged.

| Task | Student cap KiB | Baseline cap KiB | Mean accuracy difference pp | Adjusted interval pp | Tensor storage ratio | Vectorized latency ratio | Vectorized total tensor ratio | Pass in any mode |
|---|---:|---:|---:|---|---:|---:|---:|---|
| context8 | 8 | 8 | +0.06 | [-0.33, +0.44] | 0.986 | 1.73 | 1.36 | False |
| context8 | 8 | 16 | +0.00 | [+0.00, +0.00] | 0.491 | 1.93 | 0.69 | True |
| context8 | 8 | 32 | +0.00 | [+0.00, +0.00] | 0.244 | 1.55 | 0.35 | True |
| context8 | 16 | 16 | +0.00 | [+0.00, +0.00] | 0.981 | 2.09 | 1.28 | False |
| context8 | 16 | 32 | +0.00 | [+0.00, +0.00] | 0.487 | 1.68 | 0.64 | True |
| context8 | 32 | 32 | +0.00 | [+0.00, +0.00] | 1.000 | 2.05 | 1.23 | False |
| context32 | 8 | 8 | +0.10 | [-0.16, +0.36] | 1.011 | 4.57 | 2.54 | False |
| context32 | 8 | 16 | +0.08 | [-0.17, +0.32] | 0.507 | 4.61 | 1.28 | False |
| context32 | 8 | 32 | +0.03 | [-0.21, +0.26] | 0.251 | 4.05 | 0.64 | False |
| context32 | 16 | 16 | +0.08 | [-0.16, +0.33] | 1.004 | 5.18 | 2.28 | False |
| context32 | 16 | 32 | +0.03 | [-0.19, +0.26] | 0.497 | 4.55 | 1.14 | False |
| context32 | 32 | 32 | +0.03 | [-0.18, +0.24] | 0.999 | 5.34 | 2.00 | False |
| digits | 8 | 8 | -0.87 | [-3.29, +1.55] | 0.982 | 2.24 | 1.63 | False |
| digits | 8 | 16 | -0.82 | [-3.86, +2.22] | 0.482 | 2.22 | 0.82 | False |
| digits | 8 | 32 | -1.58 | [-4.00, +0.85] | 0.240 | 2.05 | 0.41 | False |
| digits | 16 | 16 | +0.87 | [-2.72, +4.46] | 0.993 | 2.45 | 1.39 | False |
| digits | 16 | 32 | +0.11 | [-0.80, +1.02] | 0.494 | 2.27 | 0.70 | False |
| digits | 32 | 32 | +0.16 | [-1.84, +2.17] | 0.988 | 2.72 | 1.25 | False |

## Boundaries

- Context8 and context32 are related synthetic conditions, not independent task families; context8 extends the earlier pilot. Digits is a small real handwritten-digit task, not MNIST or a language-model benchmark.
- Digits is deduplicated before stratified splitting. Train/validation/test input hashes are checked for overlap. Different seeds reuse the same underlying digits dataset, so uncertainty describes split/seed variation and is exploratory.
- Test inference has no teacher or auxiliary head in the model state. Runtime profiling measures actual CPU tensor allocation/free events; it excludes Python/runtime memory, allocator reserve and total RSS. Checkpoint serialization overhead is reported separately in RESULT.json.
- Current implementations are CPU PyTorch canaries, not optimized deployment kernels. Both throughput and batching can alter latency; these are single-query measurements.
- Direct distances do not imply a globally valid metric. Compression does not add independent information bits. Richer supervision and ordinary distillation are controlled but finite tuning budgets cannot establish optimality.
- All selected validation scores are reproduced, held-out scores duplicate-confirmed, and checkpoint bytes verified. There is no post-test training or hyperparameter adjustment.

## Runtime-only follow-up: promising digits compression, not a unique advantage

After the sealed sweep, the unchanged direct generator was optimized by batching
both query orientations into one pair-network call. A common positive logit
scale was omitted for argmax in **all** arms. No weights, checkpoint selections,
training losses or datasets changed. All tested predictions matched. This is a
post hoc runtime follow-up, not an original predeclared screening result.

The most promising comparison is the 16-KiB-cap distilled digits model against
the validation-selected 32-KiB-cap conventional reference:

| Measurement | Distilled direct distances | Conventional reference |
|---|---:|---:|
| Five-seed mean held-out accuracy | 97.72% | 97.61% |
| Actual deployed FP32 tensor bytes | 16,116 | 32,595.2 mean |
| Incremental query tensor peak bytes, optimized | 14,240 | 724.8 mean |
| Total model plus incremental query tensor bytes | 30,356 | 33,320 mean |

The same predeclared, multiplicity-adjusted accuracy difference interval is
[-0.80, +1.02] percentage points, within the -1-point noninferiority threshold.
Deployed tensor storage is 49.44% of reference, but total inference tensor memory
is approximately 91.1% of reference—not half. The reference consists of three
dense-teacher and two coordinate-teacher checkpoints, selected before test.

An initial optimized timing pass gave a 1.98x latency ratio. Five subsequent
interleaved blocks of 500 timings per seed gave mean-seed ratios of 1.781, 1.792,
1.788, 1.751 and 1.753 (median 1.781). These are repeated CPU measurements, not
independent hardware replications or GPU performance. Raw measurements are in
`RUNTIME_FOLLOWUP.json` and `LATENCY_REPEATS.json`.

**This is not a distinct memory-efficiency breakthrough:** the separately
reported coordinate-teacher model at the *8-KiB cap* already reaches 97.50% mean
accuracy with 7,956 deployed bytes. Its accuracy is close to the 16-KiB direct
generator while using less storage. The synthetic conditions remain nearly
saturated even at the smallest tested cap. The sweep therefore establishes a
promising distillation/compression result versus a larger reference, but not a
consistent new quality-memory-latency advantage across scales and domains.

Reproduction instructions: `../CAPACITY_README.md`. The chart shows the original
sealed inference implementation; optimized follow-up timings are separate above.
