# Preliminary prior-art boundary

This is a limited primary-source check, not exhaustive novelty clearance. The active experiment was designed before this check; no training mechanism was changed in response.

- Complex Gated Recurrent Neural Networks (NeurIPS 2018), https://papers.nips.cc/paper_files/paper/2018/hash/652cf38361a209088302ba2b8b7f51e0-Abstract.html : the authors describe combining complex-valued, norm-preserving state transitions with gating. Generic phase-aware gated recurrence cannot be claimed new.
- Neural Phase Correlation (arXiv:2606.18496v1, submitted June 2026), https://arxiv.org/html/2606.18496v1 : learns paired bases for relational planar rotations, builds bilinear interactions, and connects the construction to earlier multiplicative transformation models. This is related algebra, not evidence that the present recurrent language-model mechanism is identical.
- Rotation Plane Doubly Orthogonal Recurrent Neural Networks, OpenReview https://openreview.net/pdf?id=ry_4vpixl : search identified a potentially relevant work, but direct retrieval hit a browser challenge. No conclusion drawn from unverified full text.

Current safe claim: a controlled local ablation of learned reference-phase keys added to an existing overlapping geometric recurrence. The keys shift a relative-angle query using normalized cross and dot products. Exact identity initialization and expressive distinction do not establish research novelty, extra independent information storage, SOTA, or superiority. A stronger contribution would need reliable benchmark gains, deployment evidence, and a more complete technical comparison with related operators.
