# Disjoint WikiText validation confirmation

Frozen local byte-model pilot, three seeds. Every checkpoint scored twice in FP32 on 65,536 target bytes from a validation region disjoint from selection. No official test read. Models saw only 153,600 training target bytes per trial, so convergence is unproven.

| Arm | CE | BPC |
|---|---:|---:|
| fixed_rotation | 2.322434 | 3.350565 |
| geometric_rotation | 2.316014 | 3.341302 |
| transformer | 2.597911 | 3.747994 |

Per-seed geometry minus fixed-rotation CE (negative favors geometry): [-0.008658872917294502, -0.00570034421980381, -0.004901275970041752]

These are byte-level CE/BPC values, not word-level perplexity or evidence of SOTA. The recurrent architecture is an experimental successor, not the original hierarchy. Parameter counts are matched; FLOPs and effective optimization are not.
