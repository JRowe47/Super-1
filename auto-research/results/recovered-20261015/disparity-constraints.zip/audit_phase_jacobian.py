"""Measure sampled local sensitivity of trained state-conditioned rotations.

State norm preservation does not imply an orthogonal Jacobian when angles
depend on state. Samples here are diagnostics, not a global stability proof.
"""
import argparse
import hashlib
import json
from pathlib import Path

import torch
import noncommuting_phase_candidate as candidate
import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--samples', type=int, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.samples > 0
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(candidate.__file__)) == protocol['candidate_source_sha256']
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    raw = (pilot.DATA/'train.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['train']
    train = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    pilot.shared.write(args.output/'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source/'FREEZE.json'),
        'audit_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'samples_per_seed': args.samples, 'precision': 'FP64',
        'scope': 'Frozen overlapping-geometric checkpoints, actual states from one sampled training window per seed. Jacobians hold the next-token drive fixed. Static-angle counterfactual is not retrained. Sampled bounds are not global bounds.',
        'official_test_read': False, 'validation_read': False,
    })
    rows = []
    frozen = json.loads((args.source/'FREEZE.json').read_text())
    for row in frozen:
        if row['arm'] != 'geometric_overlapping':
            continue
        checkpoint = args.source/Path(row['checkpoint']).name
        assert pilot.shared.prior.sha(checkpoint) == row['sha256']
        model = candidate.OverlappingPhaseLM(config['width'], True).double().eval()
        model.load_state_dict(torch.load(checkpoint, weights_only=True))
        generator = torch.Generator().manual_seed(row['seed'])
        start = torch.randint(len(train)-config['context'], (1,), generator=generator).item()
        tokens = train[start:start+config['context']].unsqueeze(0)
        captured = []
        hook = model.norm.register_forward_pre_hook(lambda module, values: captured.append(values[0].detach()))
        with torch.no_grad():
            model(tokens)
            embedded = model.embedding(tokens)
            drives = torch.tanh(model.drive(embedded))
            gates = torch.sigmoid(model.write(embedded)+model.retention)
        hook.remove()
        states = captured[0]
        positions = torch.linspace(0, config['context']-2, args.samples).long().unique().tolist()
        for index in positions:
            state = states[:, index].clone().requires_grad_(True)
            drive = drives[:, index+1]
            gate = gates[:, index+1]
            def rotation(value, dynamic):
                value = value.reshape(1, config['width'])
                theta = model.angle_for(value, drive, model.angle, model.gain if dynamic else None, 0)
                first = candidate.rotate(value, theta, 0)
                second_theta = model.angle_for(first, drive, model.second_angle, model.second_gain if dynamic else None, 1)
                return candidate.rotate(first, second_theta, 1).flatten()
            x = state.flatten()
            moved = rotation(x, True)
            norm_error = abs(moved.square().sum().item()-x.square().sum().item())
            dynamic_j = torch.autograd.functional.jacobian(lambda value: rotation(value, True), x, vectorize=True)
            static_j = torch.autograd.functional.jacobian(lambda value: rotation(value, False), x, vectorize=True)
            transition_j = gate.flatten()[:, None]*dynamic_j
            static_transition_j = gate.flatten()[:, None]*static_j
            static_singular = torch.linalg.svdvals(static_j)
            assert torch.allclose(static_singular, torch.ones_like(static_singular), atol=1e-12, rtol=1e-12)
            rows.append({'seed': row['seed'], 'checkpoint_sha256': row['sha256'], 'token_index': index,
                         'state_norm_squared_error': norm_error,
                         'dynamic_rotation_jacobian_max_singular': torch.linalg.svdvals(dynamic_j).max().item(),
                         'dynamic_transition_jacobian_max_singular': torch.linalg.svdvals(transition_j).max().item(),
                         'static_transition_jacobian_max_singular': torch.linalg.svdvals(static_transition_j).max().item(),
                         'maximum_retention': gate.max().item()})
        pilot.shared.write(args.output/'RESULT.json', rows)
    assert len(rows) > 0
    summary = {
        'samples': len(rows), 'max_state_norm_squared_error': max(r['state_norm_squared_error'] for r in rows),
        'max_dynamic_rotation_jacobian_singular': max(r['dynamic_rotation_jacobian_max_singular'] for r in rows),
        'max_dynamic_transition_jacobian_singular': max(r['dynamic_transition_jacobian_max_singular'] for r in rows),
        'sampled_transitions_above_unit_gain': sum(r['dynamic_transition_jacobian_max_singular']>1 for r in rows),
        'official_test_read': False, 'validation_read': False,
    }
    pilot.shared.write(args.output/'SUMMARY.json', summary)
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
