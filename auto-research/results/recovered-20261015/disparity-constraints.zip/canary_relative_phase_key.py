"""Actual full-width candidate training canary on synthetic tokens only."""
import argparse
import importlib
import json
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import run_relative_phase_key as factory


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--factory-module', choices=['run_relative_phase_key', 'run_relative_phase_key_scale', 'run_pair_energy_phase'], default='run_relative_phase_key')
    parser.add_argument('--candidate-arm', default='relative_phase_key')
    args = parser.parse_args()
    factory = importlib.import_module(args.factory_module)
    config = json.loads(args.config.read_text())
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    checks = factory.checks()
    factory.runner.pilot.C.update(config)
    makes, width, ff = factory.builders(config)
    counts = {name: factory.runner.pilot.count(make()) for name, make in makes.items()}
    assert max(counts.values())/min(counts.values()) < 1.02
    torch.manual_seed(config['seeds'][0])
    model = makes[args.candidate_arm]()
    optimizer = torch.optim.AdamW(model.parameters(), lr=config['lrs'][0], weight_decay=config['weight_decay'])
    tokens = torch.randint(256, (config['batch'], config['context']+1))
    start = time.perf_counter()
    for _ in range(config['canary_steps']):
        optimizer.zero_grad()
        loss = F.cross_entropy(model(tokens[:, :-1]).reshape(-1, 256), tokens[:, 1:].flatten())
        assert torch.isfinite(loss)
        loss.backward()
        assert all(parameter.grad is None or torch.isfinite(parameter.grad).all() for parameter in model.parameters())
        torch.nn.utils.clip_grad_norm_(model.parameters(), config['gradient_clip'])
        optimizer.step()
    elapsed = time.perf_counter()-start
    print(json.dumps({'checks': checks, 'parameters': counts, 'transformer_width': width,
                      'candidate_arm': args.candidate_arm,
                      'transformer_ff_width': ff, 'synthetic_steps': config['canary_steps'],
                      'elapsed_seconds': elapsed, 'candidate_trial_seconds_estimate': elapsed*config['steps']/config['canary_steps'],
                      'loss_finite': True, 'gradients_finite': True, 'official_test_read': False}))


if __name__ == '__main__':
    main()
