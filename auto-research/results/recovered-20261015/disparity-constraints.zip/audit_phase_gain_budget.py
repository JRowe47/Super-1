"""Training-input diagnostic of the new bound on prior frozen checkpoints.

This does not convert or evaluate checkpoint accuracy. It quantifies how much
of the prior learned gain lies outside a conservative sufficient bound.
"""
import argparse
import hashlib
import json
from pathlib import Path

import torch
import noncommuting_phase_candidate as candidate
import phase_transition_language as pilot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    protocol = json.loads((args.source / 'PROTOCOL.json').read_text())
    frozen = json.loads((args.source / 'FREEZE.json').read_text())
    config = protocol['config']
    torch.set_num_threads(config['threads'])
    assert pilot.shared.prior.sha(Path(candidate.__file__)) == protocol['candidate_source_sha256']
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    raw = (pilot.DATA / 'train.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['train']
    data = torch.tensor(list(raw), dtype=torch.long)
    rows = []
    for row in frozen:
        if row['arm'] != 'geometric_overlapping':
            continue
        path = args.source / Path(row['checkpoint']).name
        assert pilot.shared.prior.sha(path) == row['sha256']
        model = candidate.OverlappingPhaseLM(config['width'], True).double().eval()
        model.load_state_dict(torch.load(path, weights_only=True))
        generator = torch.Generator().manual_seed(row['seed'] + config['window_seed_offset'])
        starts = torch.randint(len(data)-config['context']-1, (config['batch'],), generator=generator)
        tokens = torch.stack([data[start:start+config['context']] for start in starts])
        with torch.no_grad():
            embedded = model.embedding(tokens)
            maximum_retention = torch.sigmoid(model.write(embedded)+model.retention).max(-1).values
            cap = maximum_retention.rsqrt()-1
            gains = torch.cat([model.gain, model.second_gain]).abs()
            outside = (gains[None, None, :] > cap[:, :, None]).double().mean()
        rows.append({'seed': row['seed'], 'checkpoint_sha256': row['sha256'],
                     'sampled_input_bytes': tokens.numel(),
                     'maximum_retention_mean': maximum_retention.mean().item(),
                     'gain_cap_min': cap.min().item(), 'gain_cap_mean': cap.mean().item(),
                     'gain_cap_max': cap.max().item(),
                     'prior_gain_abs_mean': gains.mean().item(), 'prior_gain_abs_max': gains.max().item(),
                     'prior_gains_outside_sufficient_bound_fraction': outside.item()})
    assert len(rows) == len(config['seeds'])
    args.output.mkdir()
    result = {'rows': rows, 'validation_read': False, 'official_test_read': False,
              'accuracy_evaluated': False, 'source_sha256': pilot.shared.prior.sha(Path(__file__)),
              'interpretation': 'The sufficient bound may exclude useful learned transport. Exceeding this conservative bound does not itself prove expansion, instability or poor accuracy. The new model is trained from scratch rather than clamping these checkpoints.'}
    (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
