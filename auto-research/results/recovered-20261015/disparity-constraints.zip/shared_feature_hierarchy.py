"""Shared input-generated feature transport around the authoritative hierarchy.

Unlike the earlier cross-scale rotations, this does not mix timescale slots.
All scales use the same orthogonal feature operator, so averaging states
commutes with the transport. Original learned gates and coupling are untouched.
This prototype does not establish novelty or accuracy.
"""
import copy
import json

import torch
from torch import nn
import original_hierarchy_transport as original


SOURCE = original.SOURCE
authoritative = original.authoritative


class SharedFeatureHierarchy(original.GeometricHierarchy):
    def __init__(self, base, dynamic):
        nn.Module.__init__(self)
        assert base.width >= 2
        self.base = base
        self.dynamic = dynamic
        self.angle = nn.Parameter(torch.zeros(base.width//2))
        self.gain = nn.Parameter(torch.zeros_like(self.angle)) if dynamic else None

    def transport(self, state, current):
        count = 2*len(self.angle)
        pairs = state[..., :count].reshape(len(state), self.base.state_scales, -1, 2)
        theta = self.angle
        if self.dynamic:
            query = current[:, :count].reshape(len(current), -1, 2)
            cross = query[..., 0]*self.angle.sin()-query[..., 1]*self.angle.cos()
            theta = theta+self.gain*torch.tanh(cross/torch.sqrt(query.square().sum(-1)+1e-6))
        cosine, sine = theta.cos(), theta.sin()
        if theta.ndim == 2:
            cosine, sine = cosine[:, None], sine[:, None]
        moved = torch.stack((cosine*pairs[..., 0]-sine*pairs[..., 1],
                             sine*pairs[..., 0]+cosine*pairs[..., 1]), -1).flatten(-2)
        return torch.cat((moved, state[..., count:]), dim=-1)


def checks():
    torch.set_num_threads(1)
    torch.manual_seed(9017)
    base = authoritative.PersistentMultiScaleLM(256, 15, state_scales=4).double()
    wrapped = SharedFeatureHierarchy(copy.deepcopy(base), True).double()
    tokens = torch.randint(256, (2, 8))
    expected, expected_state = base(tokens, return_state=True)
    actual, actual_state = wrapped(tokens, return_state=True)
    assert torch.allclose(expected, actual, atol=1e-12, rtol=1e-12)
    assert torch.allclose(expected_state, actual_state, atol=1e-12, rtol=1e-12)
    expected.square().sum().backward()
    actual.square().sum().backward()
    gradient_error = 0.0
    for (name, left), (other, right) in zip(base.named_parameters(), wrapped.base.named_parameters()):
        assert name == other
        assert torch.allclose(left.grad, right.grad, atol=1e-12, rtol=1e-10), name
        gradient_error = max(gradient_error, (left.grad-right.grad).abs().max().item())
    assert torch.isfinite(wrapped.gain.grad).all() and wrapped.gain.grad.abs().sum()>0
    with torch.no_grad():
        wrapped.angle.normal_()
        wrapped.gain.normal_()
    state = torch.randn(2, 4, 15, dtype=torch.float64)
    current = torch.randn(2, 15, dtype=torch.float64)
    moved = wrapped.transport(state, current)
    norm_error = (state.square().sum(-1)-moved.square().sum(-1)).abs().max().item()
    assert torch.allclose(state.square().sum(-1), moved.square().sum(-1), atol=1e-12, rtol=1e-12)
    assert torch.equal(state[..., -1], moved[..., -1]), 'Unpaired feature must remain untouched'
    mean_input = state.mean(1, keepdim=True).expand_as(state)
    mean_error = (wrapped.transport(mean_input, current)[:, 0]-moved.mean(1)).abs().max().item()
    assert mean_error < 1e-12, 'Transport must commute with mean-state coupling'
    whole, final = wrapped(tokens, return_state=True)
    prefix, intermediate = wrapped(tokens[:, :4], return_state=True)
    suffix, continued = wrapped(tokens[:, 4:], intermediate, return_state=True)
    assert torch.equal(whole, torch.cat((prefix, suffix), 1)) and torch.equal(final, continued)
    changed = tokens.clone()
    changed[:, 4:] = torch.randint(256, (2, 4))
    assert torch.equal(whole[:, :4], wrapped(changed)[:, :4])
    return {'original_gates_and_coupling_owned': True, 'identity_logits_max_error': (expected-actual).abs().max().item(),
            'identity_native_gradient_max_error': gradient_error, 'gain_gradient_nonzero': True,
            'per_scale_norm_max_error': norm_error, 'mean_coupling_commutation_max_error': mean_error,
            'unpaired_feature_untouched': True, 'contiguous_state_parity': True, 'causal_prefix': True,
            'trained': False, 'novelty_established': False,
            'limitation': 'Transport itself is orthogonal at fixed input; the original state-dependent gates do not inherit a global nonexpansive bound.'}


if __name__ == '__main__':
    print(json.dumps(checks()))
