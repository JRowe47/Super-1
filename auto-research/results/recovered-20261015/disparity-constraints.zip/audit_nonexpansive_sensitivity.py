"""Adversarial sampled checks, not an empirical accuracy or global proof claim."""
import argparse
import hashlib
import json
from pathlib import Path

import torch
import nonexpansive_phase_candidate as candidate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--samples', type=int, required=True)
    parser.add_argument('--seed', type=int, required=True)
    args = parser.parse_args()
    assert args.samples > 0 and not args.output.exists()
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    model = candidate.NonexpansivePhaseLM(16, True).double()
    rows = []
    # Exercise unequal gates, endpoints and states around the normalization's
    # epsilon transition. These are explicit audit cases, not training rules.
    for index in range(args.samples):
        with torch.no_grad():
            for parameter in [model.angle, model.second_angle, model.gain, model.second_gain]:
                parameter.normal_(std=10)
        state_scale = 10.0 ** (-8 + 12 * index / max(args.samples - 1, 1))
        state = torch.randn(1, model.d, dtype=torch.float64) * state_scale
        drive = torch.randn_like(state).tanh()
        retention = torch.sigmoid(torch.randn_like(state) * 12)
        if index % 5 == 0:
            state.zero_()
        if index % 7 == 0:
            drive.zero_()
        if index % 11 == 0:
            retention[:, 0] = 1
        if index % 13 == 0:
            retention.zero_()
        transition = lambda value: model.transition(value.reshape(1, model.d), drive, retention).flatten()
        jacobian = torch.autograd.functional.jacobian(transition, state.flatten(), vectorize=True)
        assert torch.isfinite(jacobian).all(), f'Nonfinite Jacobian in case {index}'
        singular = torch.linalg.svdvals(jacobian).max().item()
        assert singular <= 1 + 1e-10, f'Bound violated in case {index}: {singular}'
        # Compare two finite, distant states too, not only one local derivative.
        other = torch.randn_like(state) * max(state_scale, 1e-4)
        ratio = ((transition(state.flatten()) - transition(other.flatten())).norm()
                 / (state - other).norm()).item()
        assert ratio <= 1 + 1e-10, f'Finite-difference expansion in case {index}: {ratio}'
        rows.append({'case': index, 'state_scale': state_scale,
                     'retention_min': retention.min().item(), 'retention_max': retention.max().item(),
                     'jacobian_max_singular': singular, 'finite_difference_ratio': ratio})
    args.output.mkdir()
    result = {
        'seed': args.seed, 'samples': args.samples, 'precision': 'FP64',
        'max_jacobian_singular': max(row['jacobian_max_singular'] for row in rows),
        'max_finite_difference_ratio': max(row['finite_difference_ratio'] for row in rows),
        'cases': rows, 'accuracy_tested': False, 'novelty_established': False,
        'scope': 'Sampled fixed-input state-to-state sensitivity only. Not output, input or parameter sensitivity; not an original-hierarchy result.',
        'source_sha256': {str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
                          for path in [__file__, candidate.__file__, candidate.source.__file__]},
        'official_test_read': False, 'cloud_resources_created': 0,
    }
    (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'cases'}))


if __name__ == '__main__':
    main()
