"""Build a portable replication archive and a four-page evidence report."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

ROOT=Path(__file__).resolve().parents[2]
EXP=ROOT/'experiments/disparity_constraints'
RUN=EXP/'nanogpt-20260912-v1'
OUT=ROOT/'output/pdf'
OUT.mkdir(parents=True,exist_ok=True)
PKG=ROOT/'output/disparity_nanogpt_replication_20260912'
PKG.mkdir(exist_ok=True)
code=PKG/'code';code.mkdir(exist_ok=True)
for name in ('nanogpt_compare.py','official_test.py','nanogpt_config.json'):
    shutil.copy2(EXP/name,code/name)
vendor=ROOT/'funcweights/aug8_official_nanogpt_comparator_20260815_v1/third_party/nanogpt'
shutil.copytree(vendor,PKG/'vendor/nanogpt',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(RUN,PKG/'evidence',dirs_exist_ok=True,ignore=shutil.ignore_patterns('matplotlib','__pycache__'))
data=Path(json.loads((RUN/'PROTOCOL.json').read_text())['config']['data_root'])
(PKG/'data').mkdir(exist_ok=True)
for name in ('train.txt','valid.txt','test.txt','MANIFEST.json'):
    shutil.copy2(data/name,PKG/'data'/name)
# Only path settings change in the portable config; historical config remains in evidence.
c=json.loads((code/'nanogpt_config.json').read_text())
c['data_root']='data';c['nanogpt_source']='vendor/nanogpt/model.py'
(code/'nanogpt_config.json').write_text(json.dumps(c,indent=2)+'\n')
(PKG/'requirements.txt').write_text('torch==2.8.0\nmatplotlib==3.9.4\n')
(PKG/'README.md').write_text('''# Replicate the nanoGPT / distance-head pilot

Run from this extracted directory. Python 3.10+ is recommended for installing
PyTorch 2.8.0. CPU is sufficient; no credentials, network datasets, or GPU are
needed after installing dependencies.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python verify_bundle.py
python code/nanogpt_compare.py --output reproduced
python code/official_test.py --run reproduced
```

The last command opens the official test after freezing the validation-selected
models. Output paths must be fresh. Do not rerun into an existing directory.
Training executes 18 candidates (3 arms x 3 seeds x 2 learning rates), selecting
one checkpoint per arm and seed using validation only. Official evaluation
covers every next-byte target once, including the five-byte partial tail.

To evaluate the PROVIDED checkpoints without retraining:

```bash
python evaluate_supplied.py
```

This creates a fresh supplied-evaluation folder and evaluates the nine frozen
winners. It does not change the historical evidence. Expected scores are in
evidence/official-test-20260912/RESULT.json. Floating-point results may differ
across operating systems, hardware and PyTorch builds; the original used CPU,
one thread, deterministic algorithms, PyTorch 2.8.0. Hashes verify artifact
identity, not cross-platform numerical equivalence.

All three arms share nanoGPT's causal encoder. The two distance heads preserve
weight tying and use normalized squared-distance logits (equivalent to scaled
cosine similarity). The constrained arm adds batchwise label-pair penalties.
This is an adaptation of the distance mechanism, not a standalone MLP versus
Transformer test. Training size and steps are matched; FLOPs are not.

Data are bundled for exact replication: bytes of the word-preprocessed
Salesforce WikiText-2-v1 reconstruction at revision
b08601e04326c79dfdd32d625aee71d232d685c3. See data/MANIFEST.json for source
and reconstructed hashes. Dataset source:
https://huggingface.co/datasets/Salesforce/wikitext
Retain original dataset attribution and applicable licensing when redistributing.
The bundled data carry their original rights; no new license is asserted here.

nanoGPT is vendored at commit 3adf61e154c3fe3fca428ad6bc3818b27a3b8291.
Its MIT license is retained at vendor/nanogpt/LICENSE. Upstream:
https://github.com/karpathy/nanoGPT

SHA256SUMS.json covers every packaged file except itself. The code's only
portability change is replacing two machine-specific configuration paths with
relative paths. Historical configuration, source hashes and all 18 candidate
checkpoints are preserved under evidence/.
''')
(PKG/'verify_bundle.py').write_text('''from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
m=json.loads((p/'SHA256SUMS.json').read_text())
for name,expected in m.items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==expected,name
print(f'PASS: {len(m)} packaged files verified')
''')
(PKG/'evaluate_supplied.py').write_text('''from pathlib import Path
import json,shutil,subprocess,sys
p=Path(__file__).resolve().parent
out=p/'supplied-evaluation'
out.mkdir(exist_ok=False)
e=p/'evidence'
for name in ('RESULT.json','CANDIDATES.json'):
    shutil.copy2(e/name,out/name)
for row in json.loads((e/'RESULT.json').read_text()):
    shutil.copy2(e/row['checkpoint'],out/row['checkpoint'])
protocol=json.loads((e/'PROTOCOL.json').read_text())
protocol['config']['data_root']=str(p/'data')
protocol['config']['nanogpt_source']=str(p/'vendor/nanogpt/model.py')
(out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2))
subprocess.run([sys.executable,str(p/'code/official_test.py'),'--run',str(out)],cwd=p,check=True)
''')

results=json.loads((RUN/'official-test-20260912/RESULT.json').read_text())
means=json.loads((RUN/'official-test-20260912/COMPLETION.json').read_text())['means']
styles=getSampleStyleSheet()
styles['Title'].fontSize=25;styles['Title'].leading=30
styles['BodyText'].fontSize=10;styles['BodyText'].leading=14
story=[]
def p(text,style='BodyText'):
    story.append(Paragraph(text,styles[style]));story.append(Spacer(1,6))
def table(rows,widths=None):
    t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#15364a')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#eef3f5'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP')]))
    story.append(t);story.append(Spacer(1,14))
names={'nanogpt':'Standard nanoGPT','distance':'Distance head','constrained_distance':'Constrained distance head'}
p('Distance-based output heads\nversus nanoGPT'.replace('\n','<br/>'),'Title')
p('Official WikiText-2 test split | Local CPU pilot | 12 September 2026')
p('Finding','Heading2')
p('At exactly 70,464 parameters, the distance head reduced mean test cross-entropy by 2.25% relative to standard nanoGPT. The constrained version reduced it by 0.92%. However, adding the constraints worsened CE relative to the unconstrained distance head in all three seeds.')
table([['Model','Mean CE','BPC','Byte accuracy']]+[[names[a],f"{m['ce']:.6f}",f"{m['bpc']:.6f}",f"{100*m['accuracy']:.2f}%"] for a,m in means.items()],[200,80,75,95])
p('What this establishes','Heading2')
p('A short, matched-size language experiment shows a CE benefit from modifying the output head. The constrained model beats standard nanoGPT in two of three seeds; the distance-only model wins in all three. Both modified heads have lower mean top-1 byte accuracy than the standard head, despite better CE.')
p('What it does not establish','Heading2')
p('This is not a converged benchmark, a state-of-the-art result, proof of extra independent storage capacity, or proof that constraints improve language modeling. Every model uses nanoGPT as its encoder. The tested modifications are output heads and an auxiliary training penalty.')
story.append(PageBreak())
p('Experimental protocol','Title')
table([['Setting','Value'],['Architecture','2 causal Transformer blocks; width 48; 2 heads'],['Vocabulary / context','256 byte values / 32 bytes'],['Unique learned parameters','70,464 in every arm, including position embeddings'],['Training per candidate','400 updates x 4 windows x 32 targets = 51,200 bytes'],['Seeds / learning rates','17, 43, 89 / 0.001 and 0.003'],['Optimizer','AdamW; weight decay 0.01; gradient clip 1.0'],['Selection','Lowest validation-prefix CE across checkpoints and LRs'],['Official test','1,254,981 next-byte targets per frozen checkpoint']],[150,300])
p('Model and constraint definitions','Heading2')
p('The standard arm uses the vendored nanoGPT tied linear head. Distance variants normalize the final hidden vector and tied token embedding, then use negative squared distance times a fixed temperature of 10. Dropping a shared constant yields 20 times cosine similarity. This adds no learned parameters.')
p('The constrained arm attracts hidden vectors with the same next-byte target within radius 0.35 and repels vectors with different targets beyond radius 1.0. A squared-hinge penalty of weight 5 balances positive and negative pair groups. All 8,128 unordered pairs in each batch are considered. Unlike the earlier toy experiment, this pilot uses a fixed penalty, without persistent per-pair multipliers. It is not whole-corpus all-pairs optimization.')
p('Data and evaluation','Heading2')
p('Inputs are bytes of the word-preprocessed WikiText-2 text reconstruction, not the raw-v1 dataset and not word-level tokens. An 8,192-byte validation prefix selects candidates; a disjoint 32,768-byte suffix was assessed before the user authorized official testing. All nine previously selected checkpoints were frozen before opening test.txt. Test contexts reset every 32 bytes; the final five targets are included.')
story.append(PageBreak())
p('Per-seed official results','Title')
table([['Seed','Model','CE','BPC','Accuracy']]+[[str(r['seed']),names[r['arm']],f"{r['ce']:.6f}",f"{r['bpc']:.6f}",f"{100*r['accuracy']:.2f}%"] for r in results],[35,185,80,75,75])
p('Interpretation and limitations','Heading2')
p('The distance-only improvement is consistent across these three seeds. The constraint-specific hypothesis is unsupported here: every seed scores worse with the penalty than without it. Next-byte equality is not semantic equivalence; contexts sharing a next byte can have different future distributions, and the same context can admit several legitimate continuations.')
p('All candidates received identical minibatch schedules within a seed, equal steps, and two learning-rate candidates. Parameter counts match exactly. Computation does not: the constrained arm adds pairwise training operations. The standard and modified heads also have different logit scales. No temperature sweep or longer training was run after assessment.')
p('Only 51,200 target bytes were processed per candidate from a 10,784,197-byte training file. Models were still improving at the training boundary. Results describe this short budget and cannot establish final attainable quality. Three seeds do not establish statistical significance.')
p('Verification','Heading2')
p('Checks covered pinned nanoGPT source hash, identical initial parameter tensors, unique parameter counts, causality, distance-head equivalence, all 18 candidate checkpoint hashes, validation-only winner selection and duplicate validation assessment. Official evaluation ran once per selected checkpoint and covered every target; all model tensors were verified unchanged afterward. No cloud resources were created.')
story.append(PageBreak())
p('Replication and provenance','Title')
p('The accompanying ZIP includes executable experiment code, portable configuration, dependencies, the pinned nanoGPT source and license, exact data files, all 18 candidate checkpoints, per-seed JSON results and SHA-256 manifests. Historical evidence is retained unchanged; only the portable configuration has machine-specific paths replaced.')
p('Run from the extracted archive root','Heading2')
for line in ['python3 -m venv .venv','source .venv/bin/activate','python -m pip install -r requirements.txt','python verify_bundle.py','python code/nanogpt_compare.py --output reproduced','python code/official_test.py --run reproduced']:
    p(line,'Code')
p('To evaluate the supplied frozen checkpoints without training, run python evaluate_supplied.py. It writes a separate supplied-evaluation directory. Every output directory must be fresh. PyTorch builds and hardware may introduce numerical differences; compare metric tolerances as well as hashes.')
p('Source provenance','Heading2')
p('nanoGPT commit: 3adf61e154c3fe3fca428ad6bc3818b27a3b8291<br/>Source: https://github.com/karpathy/nanoGPT<br/>The upstream MIT license is bundled.')
p('Dataset: Salesforce WikiText-2-v1 reconstruction<br/>Revision: b08601e04326c79dfdd32d625aee71d232d685c3<br/>Source: https://huggingface.co/datasets/Salesforce/wikitext<br/>Original dataset rights and attribution apply. data/MANIFEST.json records original and reconstructed split hashes.')
p('The complete checkpoint identities, test-data hash and evaluator hash are in evidence/official-test-20260912/FREEZE.json and DATA.json. This report was generated from the saved results, without retraining or choosing checkpoints from test scores.')
pdf=OUT/'disparity_nanogpt_report_20260912.pdf'
def footer(canvas,doc):
    canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#526574'))
    canvas.drawString(48,28,'Distance-head pilot | 12 September 2026')
    canvas.drawRightString(564,28,str(doc.page))
SimpleDocTemplate(str(pdf),pagesize=(612,792),rightMargin=48,leftMargin=48,topMargin=44,bottomMargin=48).build(story,onFirstPage=footer,onLaterPages=footer)
shutil.copy2(pdf,PKG/pdf.name)
files=[p for p in sorted(PKG.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json' and 'supplied-evaluation' not in p.parts and '__pycache__' not in p.parts]
manifest={str(p.relative_to(PKG)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(PKG/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'output/disparity_nanogpt_replication_20260912.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[PKG/'SHA256SUMS.json']:
        z.write(p,Path(PKG.name)/p.relative_to(PKG))
print(pdf);print(archive)
