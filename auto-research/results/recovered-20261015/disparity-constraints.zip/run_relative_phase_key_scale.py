"""Larger-scale replication with parameter-derived Transformer matching."""
import hashlib
from pathlib import Path

import run_relative_phase_key as source

runner = source.runner


def builders(config):
    width = config['width']
    target = runner.pilot.count(source.keyed.RelativePhaseKeyLM(width))
    # Grow the search until the standard two-times-width feedforward model
    # brackets the target; no inherited small-width search ceiling.
    upper = 2
    while runner.pilot.count(runner.pilot.TinyTransformer(upper)) < target:
        upper *= 2
    d = min(range(2, upper + 1, 2),
            key=lambda v: abs(runner.pilot.count(runner.pilot.TinyTransformer(v)) - target))
    ff = min(range(d, 4 * d + 1),
             key=lambda v: abs(runner.pilot.count(runner.pilot.TinyTransformer(d, v)) - target))
    makes = {
        'relative_phase_key': lambda: source.keyed.RelativePhaseKeyLM(width),
        'geometric_overlapping': lambda: runner.candidate.OverlappingPhaseLM(width, True),
        'fixed_overlapping': lambda: runner.candidate.OverlappingPhaseLM(width, False),
        'transformer': lambda: runner.pilot.TinyTransformer(d, ff),
    }
    return {name: makes[name] for name in config['arms']}, d, ff


def checks():
    result = source.checks()
    result['source_hashes'][str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['source_hashes'][str(Path(source.__file__).resolve())] = hashlib.sha256(Path(source.__file__).read_bytes()).hexdigest()
    return result


if __name__ == '__main__':
    runner.builders = builders
    runner.candidate.checks = checks
    runner.main()
