# Learned relative-phase keys: confirmed small local improvement

Three seeds, two learning rates per arm, fresh initialization, 3,000 steps, batch four, context 128, and 1,536,000 training target-byte exposures per trial. Parameters: phase keys 66,560; existing geometry 66,432; fixed rotations 66,304; Transformer 66,426. Equal token exposure and learning-rate tuning, closely matched parameters, not matched FLOPs. State resets every 128-byte window; this is not the original hierarchy or word-level WikiText benchmark.

All 24 trials finished successfully. All 18 unchanged controls exactly replayed previous checkpoint hashes, selection histories, and scores; these are reused control training evidence, not new independent-seed replication. Selection steps and learning rates were frozen before confirmation.

Each of 12 frozen checkpoints was evaluated twice in FP32 on the predeclared validation region starting at byte 655,360, scoring 65,536 bytes. Duplicate drift was zero. Source, data, checkpoint, and selection checks passed. Official test was not read; no cloud resources were created.

| Arm | Mean byte CE | Mean BPC |
|---|---:|---:|
| Learned phase keys | 1.793440726 | 2.587388041 |
| Existing geometry | 1.796634744 | 2.591996036 |
| Fixed rotations | 1.858464714 | 2.681197827 |
| Transformer | 1.968305057 | 2.839663944 |

Keys improve mean CE by approximately 0.178% versus existing geometry, 3.499% versus fixed rotations, and 8.884% versus Transformer. The incremental contribution is small, despite the larger baseline comparison.

| Seed | Keys CE | Geometry CE | Fixed CE | Transformer CE |
|---|---:|---:|---:|---:|
| 2503 | 1.788237764 | 1.795126109 | 1.858416980 | 2.020494975 |
| 2551 | 1.790205735 | 1.791692487 | 1.857398518 | 1.937724235 |
| 2609 | 1.801878680 | 1.803085636 | 1.859578645 | 1.946695960 |

Keys beat every control in each seed on this region, satisfying the predeclared local advancement criterion. Selection-region results were mixed; this confirmation does not erase them or establish significance across datasets. Advance the mechanism for further independent tasks/scales/seeds; do not claim SOTA, established novelty, global contraction, extra independent information, or a deployment latency win. Generic geometric/phase recurrence has prior art. The earlier geometry timing audit showed slower inference than equally compiled Transformer adapters; keyed latency is not measured here.

Frozen keyed checkpoint SHA256:

- 2503: `ac21693889ff7d4dc19a2aa6180db471ca34c658601310915f934574a62aba36`
- 2551: `5b8d529e1dfd963254db1fdff9320966d1d2bf97a170100f8fe7164611d645e7`
- 2609: `1beda739ed3073ffaf6994ea118f22d8bad5b2173d5c2a2fb7461c93319b47cf`

Reproduction: training configuration `relative-phase-key-20261001-v1.json`, runner `run_relative_phase_key.py`; confirmation `confirm_nonexpansive_phase.py --source experiments/disparity_constraints/relative-phase-key-20261001-v1 --output <fresh-directory> --windows 512 --experiment-module run_relative_phase_key --candidate-arm relative_phase_key`. See PROTOCOL.json, RESULT.json, SUMMARY.json, COMPLETION.json and the final control-replay audit for authoritative evidence.
