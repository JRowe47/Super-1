"""Post-sweep runtime-only follow-up, unchanged frozen weights and selections."""
import argparse
import json
from pathlib import Path
import statistics
import torch
from torch.nn import functional as F
import capacity_sweep as s


def predict(model, x):
    # Positive common logit scale cannot change argmax in any arm.
    if model.kind == 'dense':
        return model.output(model.encoder(x)).argmax(-1)
    if model.kind == 'coordinates':
        d = (model.coordinates(x)[:, None, :]-F.normalize(model.prototypes, dim=-1)[None, :, :]).square().sum(-1)
        return d.argmin(-1)
    b, classes, dim = len(x), len(model.anchors), x.shape[-1]
    left = x[:, None, :].expand(b, classes, dim)
    right = model.anchors[None, :, :].expand(b, classes, dim)
    # One allocation and one MLP call for both orientations; no latent vectors.
    pairs = torch.cat((left, right, right, left), dim=-1).reshape(b, classes, 2, 2*dim)
    outputs = model.pair(pairs).squeeze(-1)
    d = F.softplus((outputs[...,0]+outputs[...,1])*.5)
    d = torch.where((left == right).all(-1), torch.zeros_like(d), d)
    return d.argmin(-1)


def main(out):
    c = json.loads((out/'PROTOCOL.json').read_text())['config']
    torch.set_num_threads(c['threads_per_worker'])
    rows = json.loads((out/'FREEZE.json').read_text())
    bases = json.loads((out/'BASELINE_FREEZE.json').read_text())
    chosen = [r for r in rows if r['arm']=='distilled']+bases
    records = []
    for row in chosen:
        path = Path(row['checkpoint'])
        assert s.prior.sha(path) == row['sha256']
        (_, valid, test), _ = s.data(row['task'],row['seed'],c)
        classes = int(valid[1].max())+1
        model = s.Student(c,valid[0].shape[-1],classes,row['budget_scalars'],row['arm'],torch.zeros(classes,valid[0].shape[-1]))
        model.load_state_dict(torch.load(path,weights_only=True))
        with torch.inference_mode():
            ref = torch.cat([model(x).argmax(-1) for x in test[0].split(128)])
            new = torch.cat([predict(model,x) for x in test[0].split(128)])
            assert torch.equal(ref,new)
        # Timing uses validation input; no quality tuning and no model changes.
        query=valid[0][:1]
        before=s.profile_call(lambda:model(query).argmax(-1),c['benchmark_repeats'])
        after=s.profile_call(lambda:predict(model,query),c['benchmark_repeats'])
        assert s.prior.sha(path)==row['sha256']
        records.append({'task':row['task'],'seed':row['seed'],'budget_scalars':row['budget_scalars'],
                        'arm':row['arm'],'role':'student' if row['arm']=='distilled' else 'baseline',
                        'deployed_tensor_bytes':row['deployed_tensor_bytes'],'sha256':row['sha256'],
                        'before':before,'after':after,'heldout_prediction_mismatches':0})
    result={'status':'Post hoc runtime follow-up, not part of original preregistered screen',
            'changes':'Batch both pair orders into one network call; omit positive common scale for argmax in every arm.',
            'weights_and_selections_unchanged':True,'source_sha256':s.prior.sha(Path(__file__)),
            'records':records,'cloud_resources_created':0}
    s.write(out/'RUNTIME_FOLLOWUP.json',result)
    for task in c['tasks']:
        for cap in c['scalar_budgets']:
            a=[r for r in records if r['task']==task and r['budget_scalars']==cap and r['role']=='student']
            print(json.dumps({'task':task,'cap':cap,'before_us':statistics.mean(r['before']['median_single_query_us'] for r in a),
                              'after_us':statistics.mean(r['after']['median_single_query_us'] for r in a),
                              'working_bytes':statistics.mean(r['after']['incremental_cpu_tensor_peak_bytes'] for r in a)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);main(p.parse_args().output)
