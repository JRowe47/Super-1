"""Identity-centered geometric transport around the authoritative hierarchy.

The original learned gates, nonlinear update, mean-state coupling, scale
parameters, normalization, and output head are owned by the existing model.
This wrapper inserts only a norm-preserving cross-scale rotation before each
native token transition. It is exploratory and has not established novelty.
"""
import copy
import importlib.util
import json
import sys
from pathlib import Path

import torch
from torch import nn

SOURCE = Path(__file__).resolve().parents[1] / 'function_weight_wt2_original_multiscale_decisive' / 'models.py'
spec = importlib.util.spec_from_file_location('_phase_authoritative_hierarchy', SOURCE)
assert spec is not None and spec.loader is not None
authoritative = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = authoritative
spec.loader.exec_module(authoritative)


class GeometricHierarchy(nn.Module):
    def __init__(self, base, dynamic):
        super().__init__()
        assert base.state_scales % 2 == 0
        self.base = base
        self.dynamic = dynamic
        self.angle = nn.Parameter(torch.zeros(base.width, base.state_scales // 2))
        self.gain = nn.Parameter(torch.zeros_like(self.angle)) if dynamic else None

    def transport(self, state, current):
        pairs = state.transpose(1, 2).reshape(len(state), self.base.width, -1, 2)
        theta = self.angle
        if self.dynamic:
            value = current[:, :, None]
            cross = (pairs[..., 0]-pairs[..., 1]) * value
            denominator = torch.sqrt(pairs.square().sum(-1) * (2*value.square()) + 1e-6)
            theta = theta + self.gain * torch.tanh(cross / denominator)
        cosine, sine = theta.cos(), theta.sin()
        rotated = torch.stack((cosine*pairs[..., 0]-sine*pairs[..., 1],
                               sine*pairs[..., 0]+cosine*pairs[..., 1]), -1)
        return rotated.reshape(len(state), self.base.width, self.base.state_scales).transpose(1, 2)

    def forward(self, tokens, state=None, *, return_state=False):
        embedded = self.base.core.embedding(tokens)
        if state is None:
            state = self.base.initial_state(len(tokens), dtype=embedded.dtype, device=embedded.device)
        self.base._validate_state(state, embedded)
        history = []
        for index in range(tokens.shape[1]):
            state = self.transport(state, embedded[:, index])
            # Invoke the existing transition; do not copy or replace its gates.
            hidden, state, _ = self.base._scan_hidden_tensor(embedded[:, index:index+1], state)
            history.append(hidden[:, 0])
        logits = self.base.output(torch.stack(history, 1))
        return (logits, state) if return_state else logits


def checks():
    torch.manual_seed(41)
    base = authoritative.PersistentMultiScaleLM(256, 16, state_scales=4).double()
    model = GeometricHierarchy(copy.deepcopy(base), True).double()
    tokens = torch.randint(256, (2, 8))
    expected, expected_state = base(tokens, return_state=True)
    actual, state = model(tokens, return_state=True)
    assert torch.allclose(expected, actual, atol=1e-12, rtol=1e-12)
    assert torch.allclose(expected_state, state, atol=1e-12, rtol=1e-12)
    actual.square().sum().backward()
    expected.square().sum().backward()
    native_parameters = dict(base.named_parameters())
    wrapped_parameters = dict(model.base.named_parameters())
    assert set(native_parameters) == set(wrapped_parameters)
    gradient_error = 0.0
    for name in native_parameters:
        reference_gradient = native_parameters[name].grad
        wrapped_gradient = wrapped_parameters[name].grad
        assert torch.allclose(reference_gradient, wrapped_gradient, atol=1e-12, rtol=1e-10), name
        gradient_error = max(gradient_error, (reference_gradient-wrapped_gradient).abs().max().item())
    assert torch.isfinite(model.gain.grad).all() and model.gain.grad.abs().sum() > 0
    with torch.no_grad():
        model.angle.fill_(0.3)
        model.gain.fill_(0.5)
    random_state = torch.randn(2, 4, 16, dtype=torch.float64)
    current = torch.randn(2, 16, dtype=torch.float64)
    moved = model.transport(random_state, current)
    assert torch.allclose(random_state.square().sum((1, 2)), moved.square().sum((1, 2)), atol=1e-12)
    whole, final = model(tokens, return_state=True)
    prefix, intermediate = model(tokens[:, :4], return_state=True)
    suffix, continued = model(tokens[:, 4:], intermediate, return_state=True)
    assert torch.equal(whole, torch.cat((prefix, suffix), 1))
    assert torch.equal(final, continued)
    changed = tokens.clone()
    changed[:, 4:] = torch.randint(256, (2, 4))
    assert torch.equal(whole[:, :4], model(changed)[:, :4])
    return {'original_core_owned': True, 'identity_logits_max_error': (expected-actual).abs().max().item(),
            'identity_state_max_error': (expected_state-state).abs().max().item(),
            'identity_native_gradient_max_error': gradient_error,
            'geometry_gradient_nonzero': True, 'transport_norm_preserved': True,
            'contiguous_state_parity': True, 'causal_prefix': True, 'trained': False,
            'novelty_established': False}


if __name__ == '__main__':
    torch.set_num_threads(1)
    print(json.dumps(checks()))
