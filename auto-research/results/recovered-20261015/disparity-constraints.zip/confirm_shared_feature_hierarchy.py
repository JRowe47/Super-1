"""Frozen duplicate-FP32 confirmation for shared-feature native hierarchy."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

import torch
import run_shared_feature_hierarchy as factory
import confirm_original_transport_stream as prior_confirmation


def inspect(source):
    protocol = json.loads((source/'PROTOCOL.json').read_text())
    completed = json.loads((source/'COMPLETION.json').read_text())
    frozen = json.loads((source/'FREEZE.json').read_text())
    assert completed['official_test_read'] is False
    prior_confirmation.inspect_selection(source, protocol, completed, frozen)
    runner = factory.runner
    sha = runner.shared.shared.prior.sha
    files = {
        'runner_sha256': Path(runner.__file__),
        'transport_sha256': Path(factory.feature.__file__),
        'authoritative_wrapper_sha256': factory.feature.SOURCE,
        'authoritative_core_sha256': factory.feature.authoritative.AUTHORITATIVE_MULTISCALE_PATH,
        'authoritative_transformer_sha256': factory.feature.authoritative.AUTHORITATIVE_TRANSFORMER_PATH,
    }
    for field, path in files.items():
        assert sha(path) == protocol[field], field
    for path, digest in protocol['checks']['source_hashes'].items():
        assert sha(Path(path)) == digest, path
    assert str(Path(factory.__file__).resolve()) in protocol['checks']['source_hashes']
    assert set(protocol['arms']) == {'original', 'fixed_feature', 'input_feature', 'transformer'}
    return protocol, frozen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bytes', type=int, required=True)
    args = parser.parse_args()
    assert args.bytes > 0 and not args.output.exists()
    protocol, frozen = inspect(args.source)
    config = protocol['config']
    factory.configure()
    runner = factory.runner
    sha = runner.shared.shared.prior.sha
    assert args.bytes % config['context'] == 0
    start = config['reserved_confirmation_start']
    assert start > config['selection_start']+config['selection_bytes']
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    assert {arm: runner.shared.count(factory.make_model(arm, config)) for arm in protocol['arms']} == protocol['parameters']
    raw = (runner.shared.DATA/'valid.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['valid']
    assert start+args.bytes < len(raw)
    data = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    runner.shared.shared.write(args.output/'PROTOCOL.json', {
        'source_protocol_sha256': sha(args.source/'PROTOCOL.json'),
        'freeze_sha256': sha(args.source/'FREEZE.json'),
        'confirmation_source_sha256': sha(Path(__file__)),
        'selection_verifier_sha256': sha(Path(prior_confirmation.__file__)),
        'validation_start': start, 'scored_bytes': args.bytes, 'precision': 'FP32', 'duplicates': 2,
        'state_contract': 'Fresh state at region start, carry across contiguous chunks; Transformer prefix stays inside this region.',
        'official_test_read': False, 'official_test_eligible': False})
    rows = []
    for row in frozen:
        model = factory.make_model(row['arm'], config).float().eval()
        model.load_state_dict(torch.load(args.source/Path(row['checkpoint']).name, weights_only=True))
        assert all(parameter.dtype == torch.float32 for parameter in model.parameters())
        first = runner.evaluate(model, row['arm'], data, config, start, args.bytes)
        second = runner.evaluate(model, row['arm'], data, config, start, args.bytes)
        assert first == second, 'Duplicate drift forbids promotion'
        rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'], 'validation': first, 'duplicate_drift': 0})
        runner.shared.shared.write(args.output/'RESULT.json', rows)
        print(json.dumps({'confirmed': len(rows), 'total': len(frozen), **rows[-1]}), flush=True)
    groups = [{'arm': arm, 'ce': statistics.mean(row['validation']['ce'] for row in rows if row['arm']==arm),
               'bpc': statistics.mean(row['validation']['bpc'] for row in rows if row['arm']==arm)} for arm in protocol['arms']]
    pairs = []
    for seed in config['seeds']:
        scores = {row['arm']: row['validation']['ce'] for row in rows if row['seed']==seed}
        pairs.append({'seed': seed, 'input_feature_minus_controls_ce': {
            arm: scores['input_feature']-score for arm, score in scores.items() if arm != 'input_feature'}})
    runner.shared.shared.write(args.output/'SUMMARY.json', {'groups': groups, 'pairs': pairs, 'duplicate_drift': 0,
        'input_feature_beats_all_controls_all_seeds': all(delta < 0 for pair in pairs for delta in pair['input_feature_minus_controls_ce'].values()),
        'official_test_read': False, 'official_test_eligible': False, 'novelty_established': False})
    runner.shared.shared.write(args.output/'COMPLETION.json', {'checkpoints': len(rows), 'duplicate_drift': 0,
        'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
