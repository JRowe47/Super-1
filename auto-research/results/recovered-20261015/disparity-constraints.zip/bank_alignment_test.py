"""Two directed alignment banks: learned input routing versus constant mixing."""
import argparse,copy,json,math,time,statistics
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
import dot_weight_test as base
S=base.shared
C={**base.C,'caps_bytes':[8192],'seeds':[1901,1951,2003,2053,2111],
   'arms':['dense','factorized','constant_banks','dynamic_banks'],'banks':2,'ranks':[8,16],'bank_ranks':[4,8]}

class Model(nn.Module):
    def __init__(self,h,rank,arm):
        super().__init__();self.arm=arm;self.rank=rank
        if arm in ('dense','factorized'):self.single=base.Model(h,rank)
        else:
            self.q=nn.Parameter(torch.randn(C['banks'],h,rank)/math.sqrt(rank))
            self.k=nn.Parameter(torch.randn(C['banks'],64,rank)/8)
            self.bias=nn.Parameter(torch.zeros(h));self.output=nn.Linear(h,10)
            if arm=='dynamic_banks':
                self.router=nn.Linear(64,C['banks']);nn.init.zeros_(self.router.weight);nn.init.zeros_(self.router.bias)
            else:self.logits=nn.Parameter(torch.zeros(C['banks']))
    def routes(self,x):
        return torch.softmax(self.router(x) if self.arm=='dynamic_banks' else self.logits.expand(len(x),-1),-1)
    def forward(self,x,materialized=False):
        if self.arm in ('dense','factorized'):return self.single(x,materialized)
        a=self.routes(x)
        if materialized:
            w=torch.einsum('be,ehr,eir->bhi',a,self.q,self.k)
            hidden=torch.bmm(w,x[:,:,None]).squeeze(-1)
        else:
            hidden=sum(a[:,e,None]*((x@self.k[e])@self.q[e].T) for e in range(C['banks']))
        return self.output(torch.tanh(hidden+self.bias))

def size(h,rank,arm):
    if arm in ('dense','factorized'):return base.size(h,rank)
    router=65*C['banks'] if arm=='dynamic_banks' else C['banks']
    return 4*(C['banks']*(h+64)*rank+11*h+10+router)
def score(m,split):
    with torch.inference_mode():
        a=torch.cat([m(x) for x in split[0].split(C['batch'])]);return {'ce':F.cross_entropy(a,split[1]).item(),'accuracy':(a.argmax(-1)==split[1]).float().mean().item()}
def coefficient_stats(m,x):
    if m.arm in ('dense','factorized'):return None
    with torch.inference_mode():
        a=m.routes(x)
        return {'bank_mean_mass':a.mean(0).tolist(),'mean_input_std':a.std(0).mean().item(),'entropy':(-(a*a.clamp_min(1e-12).log()).sum(-1)).mean().item()}
def checks():
    torch.set_num_threads(1);torch.manual_seed(0);m=Model(31,4,'dynamic_banks').double();x=torch.randn(5,64,dtype=torch.float64)
    assert torch.allclose(m.routes(x),torch.full((5,2),.5,dtype=torch.float64))
    with torch.no_grad():m.router.weight.normal_()
    a=m(x);b=m(x,True);assert torch.allclose(a,b,atol=1e-12,rtol=1e-10)
    g=torch.autograd.grad(a.square().sum(),tuple(m.parameters()));h=torch.autograd.grad(b.square().sum(),tuple(m.parameters()))
    assert all(torch.allclose(u,v,atol=1e-10,rtol=1e-9) for u,v in zip(g,h))
    assert coefficient_stats(m,x)['mean_input_std']>0
    return {'uniform_initial_routes':True,'materialized_forward_gradient_parity':True,'input_routing':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);p.add_argument('--canary',action='store_true');a=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);proof=checks()
    if a.canary:
        m=Model(40,4,'dynamic_banks');x=torch.randn(C['batch'],64);y=torch.arange(C['batch'])%10;opt=torch.optim.Adam(m.parameters());start=time.perf_counter()
        for _ in range(100):opt.zero_grad();F.cross_entropy(m(x),y).backward();opt.step()
        print({'checks':proof,'estimated_seconds_per_2000_updates':(time.perf_counter()-start)*20});return
    out=a.output;out.mkdir(parents=True,exist_ok=False)
    S.write(out/'PROTOCOL.json',{'config':C,'checks':proof,'sources':{str(Path(f).resolve()):S.prior.sha(Path(f)) for f in [__file__,base.__file__,S.__file__]},
        'equation':'hidden=sum_e softmax(router(x))_e * ((x K_e) Q_e^T) + bias; two independent banks. Constant mixing uses learned logits independent of x.',
        'scope':'Two-bank directed function-generated weights. All factors, router and output parameters counted. No novelty or SOTA claim; constant-bank mixture is a rank-capacity control.',
        'selection':'Validation CE only, global freeze before assessment. Digits is development data. Same input batches, updates and tuning count, not equal FLOPs. No cloud or confirmation dataset.'})
    rows=[];selected=[]
    for seed in C['seeds']:
        (train,valid,_),meta=S.data('digits',seed,C);S.write(out/f'data-{seed}.json',meta)
        for cap in C['caps_bytes']:
            for arm in C['arms']:
                if arm=='dense':shapes=[(max(1,int(((cap//4-10)//75)*f)),None) for f in C['dense_width_fractions']]
                else:shapes=[(max(h for h in range(1,cap//4) if size(h,r,arm)<=cap),r) for r in (C['ranks'] if arm=='factorized' else C['bank_ranks'])]
                candidates=[]
                for width,rank in shapes:
                    for lr in C['lrs']:
                        torch.manual_seed(seed);m=Model(width,rank,arm);opt=torch.optim.Adam(m.parameters(),lr=lr);rng=torch.Generator().manual_seed(seed+30000);history=[];best=float('inf');start=time.perf_counter()
                        for step in range(1,C['steps']+1):
                            ids=torch.randint(len(train[0]),(C['batch'],),generator=rng)
                            for group in opt.param_groups:group['lr']=lr*(.1+.9*.5*(1+math.cos(math.pi*step/C['steps'])))
                            opt.zero_grad();loss=F.cross_entropy(m(train[0][ids]),train[1][ids]);assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5);opt.step()
                            if step%C['validation_interval']==0:
                                val=score(m,valid);history.append({'step':step,**val})
                                if val['ce']<best:best=val['ce'];state=copy.deepcopy(m.state_dict());best_step=step
                        m.load_state_dict(state);path=out/f'{seed}-{arm}-{width}-{rank}-{lr}.pt';torch.save(state,path);n=sum(v.numel()*v.element_size() for v in state.values());assert n==size(width,rank,arm) and n<=cap
                        r={'seed':seed,'arm':arm,'cap':cap,'width':width,'rank':rank,'lr':lr,'bytes':n,'validation':score(m,valid),'best_step':best_step,'history':history,'checkpoint':str(path.resolve()),'sha256':S.prior.sha(path),'seconds':time.perf_counter()-start}
                        rows.append(r);candidates.append(r);S.write(out/'CANDIDATES.json',rows)
                selected.append(min(candidates,key=lambda r:r['validation']['ce']));print('completed',len(rows),'of',80,flush=True)
    S.write(out/'FREEZE.json',selected);result=[]
    for r in selected:
        (_,valid,test),_=S.data('digits',r['seed'],C);m=Model(r['width'],r['rank'],r['arm']);path=Path(r['checkpoint']);assert S.prior.sha(path)==r['sha256'];m.load_state_dict(torch.load(path,weights_only=True));assert score(m,valid)==r['validation'];r=copy.deepcopy(r);r['heldout']=score(m,test);assert score(m,test)==r['heldout']
        with torch.inference_mode():
            original=torch.cat([m(x).argmax(-1) for x in test[0].split(C['batch'])]);tiled=torch.cat([m(x,materialized=True).argmax(-1) for x in test[0].split(C['batch'])]);assert torch.equal(original,tiled)
        r['runtime']=S.profile_call(lambda:m(valid[0][:1]),C['repeats']);r['coefficient_stats']=coefficient_stats(m,valid[0]);result.append(r)
    S.write(out/'RESULT.json',result)
    lines=['# Two-bank alignment pilot','','Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.','','| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |','|---|---:|---:|---:|---:|---:|']
    summary=[]
    for arm in C['arms']:
        rs=[r for r in result if r['arm']==arm];avg=lambda f:statistics.mean(f(r) for r in rs)
        g={'arm':arm,'bytes':avg(lambda r:r['bytes']),'ce':avg(lambda r:r['heldout']['ce']),'accuracy':avg(lambda r:r['heldout']['accuracy']),'us':avg(lambda r:r['runtime']['median_single_query_us']),'query_tensor_bytes':avg(lambda r:r['runtime']['incremental_cpu_tensor_peak_bytes'])};summary.append(g)
        lines.append(f"| {arm} | {g['bytes']:.0f} | {g['ce']:.5f} | {g['accuracy']:.2%} | {g['us']:.2f} | {g['query_tensor_bytes']:.0f} |")
    lines+=['','All bank and router parameters count toward storage. Actual inference never materializes a full weight matrix. Materialization is verification only. Constant mixing controls for increased bank count and changes in rank. The input router initially mixes both banks equally. CPU tensor allocations are not RSS. Equal training updates do not prove convergence. Previously used digits is development evidence, not independent confirmation. No novelty or SOTA claim.','', 'Reproduce: python3 experiments/disparity_constraints/bank_alignment_test.py --output NEW_DIRECTORY']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');S.write(out/'SUMMARY.json',summary);S.write(out/'COMPLETION.json',{'candidates':len(rows),'selected':len(result),'materialization_prediction_mismatches':0,'cloud_resources_created':0});print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
