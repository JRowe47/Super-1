"""Run a sealed local capacity sweep followed by its audit and chart."""
import argparse
import json
import platform
from pathlib import Path
import subprocess
import sys
import traceback
import torch
import numpy
import scipy
import sklearn
import sub8_sweep as sweep

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    here=Path(__file__).resolve().parent
    assert not args.output.exists(), 'Use a fresh output directory'
    try:
        subprocess.run([sys.executable,str(here/'sub8_sweep.py'),'--config',str(here/'large_capacity_config.json'),'--output',str(args.output)],check=True)
        subprocess.run([sys.executable,str(here/'summarize_large_capacity.py'),str(args.output)],check=True)
        sweep.old.write(args.output/'ENVIRONMENT.json',{'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':numpy.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__})
        sweep.old.write(args.output/'PIPELINE_COMPLETE.json',{'training_assessment_audit_chart_complete':True,'confirmation_dataset_loaded':False,'cloud_resources_created':0})
    except Exception:
        if args.output.exists():sweep.old.write(args.output/'PIPELINE_FAILURE.json',{'traceback':traceback.format_exc()})
        raise

if __name__=='__main__':main()
