"""Audit matching control trials without reading test or confirmation data."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prior', type=Path, required=True)
    parser.add_argument('--current', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    previous = json.loads((args.prior / 'CANDIDATES.json').read_text())
    current = json.loads((args.current / 'CANDIDATES.json').read_text())
    key = lambda row: (row['seed'], row['arm'], row['lr'])
    indexed = {key(row): row for row in previous}
    assert len(indexed) == len(previous)
    rows = []
    for row in current:
        if key(row) not in indexed:
            continue
        prior = indexed[key(row)]
        equality = {name: row[name] == prior[name]
                    for name in ['history', 'validation', 'sha256', 'best_step', 'parameters']}
        assert all(equality.values()), f'Control replay drift: {key(row)}, {equality}'
        for root, entry in [(args.prior, prior), (args.current, row)]:
            path = root / Path(entry['checkpoint']).name
            assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
        rows.append({'seed': row['seed'], 'arm': row['arm'], 'lr': row['lr'],
                     'checkpoint_sha256': row['sha256'], 'exact_fields': equality})
    assert rows, 'No matching completed trials'
    result = {'matching_trials': len(rows), 'current_completed_trials': len(current),
              'all_controls_exact': True, 'rows': rows,
              'accuracy_improvement_established': False, 'official_test_read': False,
              'scope': 'Completed matching trials only; runtime intentionally excluded.',
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.mkdir()
    (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))


if __name__ == '__main__':
    main()
