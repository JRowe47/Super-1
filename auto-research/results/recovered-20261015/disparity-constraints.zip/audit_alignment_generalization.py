"""Read frozen checkpoints and score training/validation only; never test."""
import argparse,json,statistics
from pathlib import Path
import torch
import conditioned_alignment_test as model

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    assert not a.output.exists()
    protocol=json.loads((a.source/'PROTOCOL.json').read_text());config=protocol['config']
    for filename,digest in protocol['sources'].items():
        assert model.S.prior.sha(Path(filename))==digest,filename
    frozen=json.loads((a.source/'FREEZE.json').read_text());rows=[]
    for r in frozen:
        path=a.source/Path(r['checkpoint']).name
        assert model.S.prior.sha(path)==r['sha256']
        # Existing splitter constructs all partitions; only train/valid are scored.
        (train,valid,_),_=model.S.data('digits',r['seed'],config)
        m=model.Model(r['width'],r['rank'],r['arm']);m.load_state_dict(torch.load(path,weights_only=True));m.eval()
        v=model.score(m,valid);assert abs(v['ce']-r['validation']['ce'])<1e-6
        t=model.score(m,train)
        rows.append({'seed':r['seed'],'arm':r['arm'],'checkpoint_sha256':r['sha256'],'best_step':r['best_step'],'train':t,'validation':v,'gap':v['ce']-t['ce']})
    groups=[]
    for arm in config['arms']:
        rs=[r for r in rows if r['arm']==arm]
        groups.append({'arm':arm,'train_ce':statistics.mean(r['train']['ce'] for r in rs),'validation_ce':statistics.mean(r['validation']['ce'] for r in rs),'train_accuracy':statistics.mean(r['train']['accuracy'] for r in rs),'validation_accuracy':statistics.mean(r['validation']['accuracy'] for r in rs),'gap':statistics.mean(r['gap'] for r in rs)})
    model.S.write(a.output,{'scope':'Post hoc diagnosis, not new held-out evidence. No test split scored. No training or source checkpoint modifications.','checkpoint_count':len(rows),'rows':rows,'groups':groups})
    print(json.dumps(groups,indent=2))

if __name__=='__main__':main()
