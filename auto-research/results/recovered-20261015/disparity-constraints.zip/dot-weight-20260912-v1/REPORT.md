# Directed dot-product weight pilot

The input-to-hidden matrix is generated as W = Q K^T. Inference computes (x K) Q^T without materializing W. Entries can be positive or negative and contributions can cancel. The output layer remains dense. This is a low-rank factorization, not an input-distance model or a new attention mechanism.

Five seeds on previously used digits development data; 2,000 updates each. Each arm receives two architecture candidates and two learning rates. Validation CE selects checkpoints and configurations before any held-out scoring. Same-width controls deliberately exceed the storage cap.

| Cap KiB | Model | Stored bytes | Held-out CE | Accuracy | Query us | Query tensor peak bytes |
|---|---|---:|---:|---:|---:|---:|
| 8 | factorized | 8132 | 0.11166 | 96.96% | 7.38 | 336 |
| 8 | dense_same_bytes | 7720 | 0.08776 | 97.55% | 6.23 | 245 |
| 8 | dense_same_width | 20860 | 0.10109 | 97.28% | 7.29 | 595 |
| 32 | factorized | 32756 | 0.12437 | 96.63% | 10.85 | 2160 |
| 32 | dense_same_bytes | 26020 | 0.09727 | 97.39% | 8.49 | 733 |
| 32 | dense_same_width | 126880 | 0.10169 | 97.07% | 10.35 | 3422 |

## Per-seed comparisons

CE difference is factorized minus dense; negative favors factorized. Intervals are exploratory, unadjusted, and based on only five overlapping dataset splits. They are not independent confirmation.

- 8 KiB vs dense_same_bytes: +0.02390, interval [0.007260195385410218, 0.04053149722914515].
- 8 KiB vs dense_same_width: +0.01057, interval [-0.0012120734900801355, 0.022358880564626947].
- 32 KiB vs dense_same_bytes: +0.02710, interval [0.0163863103332905, 0.03782134247394522].
- 32 KiB vs dense_same_width: +0.02269, interval [0.002859823104955972, 0.04251210272588509].

## Boundaries

- Every stored tensor counts. Query allocations exclude parameters and are reported separately; neither metric is process RSS or serialized checkpoint size.
- The primary inference path never constructs Q K^T. Materialization is used only as a separate verification/reference measurement after model freezing.
- Rank is bounded by the factor dimension. Many connections are generated, but they are coupled rather than independently stored.
- No input-distance teacher, raw exemplars, normalization vectors, learned gates, or attention were used.
- Equal updates and tuning counts do not mean equal training FLOPs or convergence. Results may depend on initialization, chosen ranks, and optimizer.
- This small pilot tests usefulness, not novelty, a general capacity theorem, or a breakthrough. No cloud resources or reserved confirmation dataset were used.

## Reproduce

Run dot_weight_test.py --output NEW_DIRECTORY, then report_dot_weights.py NEW_DIRECTORY. Dependencies: Python, PyTorch, scikit-learn, NumPy, SciPy. Configuration and source hash are in PROTOCOL.json.
