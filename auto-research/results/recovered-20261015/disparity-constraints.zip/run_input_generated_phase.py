"""Larger-scale controlled test of source-generated versus state-generated angles."""
from pathlib import Path
import hashlib

import run_overlapping_phase as runner
import input_generated_phase_candidate as generated


original_builders = runner.builders
original_checks = runner.candidate.checks


def builders(config):
    makes, width, ff = original_builders(config)
    makes['input_generated_overlapping'] = lambda: generated.InputGeneratedPhaseLM(config['width'], True)
    return {name: makes[name] for name in config['arms']}, width, ff


def checks():
    return {'overlapping_checks': original_checks(), 'input_generated_checks': generated.checks(),
            'source_hashes': {str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
                              for path in [__file__, generated.__file__]},
            'hypothesis': 'Input-generated angles retain dynamic transport without state-query expansion or a restrictive gain cap.',
            'limitation': 'Not the original hierarchy; accuracy, FLOP parity, novelty and SOTA remain unproven.'}


if __name__ == '__main__':
    runner.builders = builders
    runner.candidate.checks = checks
    runner.main()
