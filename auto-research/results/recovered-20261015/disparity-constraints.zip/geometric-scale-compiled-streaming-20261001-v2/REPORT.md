# Equal-compiler deployment check

Frozen TorchScript adapters preserve the tested eager outputs exactly for both overlapping geometric recurrence and the projected-KV Transformer: scripted-versus-eager maximum logit error is zero in all three seeds. Each seed was probed at batch sizes one and three and sequence lengths one, seventeen and 128. Full-forward-versus-incremental FP32 differences remained within configured tolerance. Checkpoint hashes were verified before and after; no training weights changed and no validation or official test was evaluated.

| Seed | Eager geometry us/token | Compiled geometry | Eager KV Transformer | Compiled KV Transformer |
| --- | ---: | ---: | ---: | ---: |
| 2503 | 90.58 | 52.58 | 59.79 | 32.81 |
| 2551 | 92.21 | 54.12 | 60.77 | 33.90 |
| 2609 | 98.84 | 56.52 | 63.66 | 35.87 |

Compilation reduces the mean of per-seed geometry medians by approximately 42%. But after compiling both adapters, geometry averages 54.40 us/token versus Transformer 34.19 us/token: geometry is approximately 59% slower. The earlier geometry-only compiler comparison against an eager Transformer is not a fair architecture-latency comparison and is superseded by this check.

Both models use the same compiler approach, but this is not proof of equally mature or optimally fused implementations. Timing uses 30 seeded shuffled paired repeats per checkpoint after three warmups, FP32, CPU, batch one, 128 synthetic tokens, with another local training process running. It includes the Python token loop and excludes compiler setup. No GPU, production-latency, FLOP-parity, or peak-memory claim is supported.

The geometric state remains 512 tensor bytes versus 71,680 projected KV bytes; weights plus state remain 266,240 versus 337,384 bytes. That is 140 times smaller persistent state but only 21.1% smaller measured weights-plus-state storage. Allocator overhead, runtime libraries and temporary activations are excluded. Compiled serialized files also contain graph/format overhead and are not those tensor-storage measures. Scripted artifacts and their hashes are preserved in this directory.

Decision: the confirmed accuracy/state-storage result is promising, but there is no inference-speed win here. Keep the active relative-phase-key training unchanged. Further deployment claims require isolated timing, broader context/batch tests and an implementation that improves the actual recurring workload; do not compare a compiled candidate against an uncompiled baseline without disclosure.
