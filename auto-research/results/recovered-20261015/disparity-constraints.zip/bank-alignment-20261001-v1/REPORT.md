# Two-bank alignment pilot

Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.

| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |
|---|---:|---:|---:|---:|---:|
| dense | 8140 | 0.10977 | 97.12% | 7.28 | 256 |
| factorized | 8132 | 0.13442 | 96.41% | 8.78 | 336 |
| constant_banks | 8154 | 0.15931 | 96.20% | 19.70 | 658 |
| dynamic_banks | 8121 | 0.14214 | 96.03% | 20.77 | 490 |

All bank and router parameters count toward storage. Actual inference never materializes a full weight matrix. Materialization is verification only. Constant mixing controls for increased bank count and changes in rank. The input router initially mixes both banks equally. CPU tensor allocations are not RSS. Equal training updates do not prove convergence. Previously used digits is development evidence, not independent confirmation. No novelty or SOTA claim.

Reproduce: python3 experiments/disparity_constraints/bank_alignment_test.py --output NEW_DIRECTORY
