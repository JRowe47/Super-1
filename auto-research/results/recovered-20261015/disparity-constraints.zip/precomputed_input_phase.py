"""Precompute source-generated rotation functions; keep the recurrence exact.

This does not make the recurrent state update parallel. Only angle queries and
trigonometry are block-vectorized. Active training implementations are untouched.
"""
import argparse
import copy
import hashlib
import json
import statistics
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import input_generated_phase_candidate as source


def rotate_precomputed(state, cosine, sine, offset):
    pairs = torch.roll(state, shifts=offset, dims=-1).reshape(len(state), -1, 2)
    moved = torch.stack((cosine*pairs[..., 0]-sine*pairs[..., 1],
                         sine*pairs[..., 0]+cosine*pairs[..., 1]), -1).flatten(1)
    return torch.roll(moved, shifts=-offset, dims=-1)


class PrecomputedInputPhaseLM(source.InputGeneratedPhaseLM):
    def forward(self, tokens):
        embedded = self.embedding(tokens)
        drive = torch.tanh(self.drive(embedded))
        retention = torch.sigmoid(self.write(embedded)+self.retention)
        angles = [self.angle_for(None, drive.flatten(0, 1), angle, gain, offset).reshape(
                    tokens.shape[0], tokens.shape[1], self.d//2)
                  for angle, gain, offset in [(self.angle, self.gain, 0), (self.second_angle, self.second_gain, 1)]]
        trig = [(angle.cos(), angle.sin()) for angle in angles]
        state = embedded.new_zeros((len(tokens), self.d))
        history = []
        for index in range(tokens.shape[1]):
            for offset, (cosine, sine) in enumerate(trig):
                state = rotate_precomputed(state, cosine[:, index], sine[:, index], offset)
            state = retention[:, index]*state+(1-retention[:, index])*drive[:, index]
            history.append(state)
        return self.norm(torch.stack(history, 1))@self.embedding.weight.T


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    torch.set_num_threads(1)
    torch.manual_seed(9017)
    base = source.InputGeneratedPhaseLM(128, True).double()
    with torch.no_grad():
        base.gain.normal_()
        base.second_gain.normal_()
        base.angle.normal_()
        base.second_angle.normal_()
    fast = PrecomputedInputPhaseLM(128, True).double()
    fast.load_state_dict(base.state_dict())
    tokens = torch.randint(256, (4, 128))
    target = torch.randint(256, tokens.shape)
    reference, actual = base(tokens), fast(tokens)
    output_error = (reference-actual).abs().max().item()
    assert torch.allclose(reference, actual, atol=1e-11, rtol=1e-11)
    F.cross_entropy(reference.flatten(0, 1), target.flatten()).backward()
    F.cross_entropy(actual.flatten(0, 1), target.flatten()).backward()
    gradient_errors = {}
    for (name, left), (other, right) in zip(base.named_parameters(), fast.named_parameters()):
        assert name == other
        assert torch.allclose(left.grad, right.grad, atol=1e-11, rtol=1e-10), name
        gradient_errors[name] = (left.grad-right.grad).abs().max().item()
    # Paired CPU timing at this synthetic shape, not a GPU/deployment claim.
    models = [base.float().eval(), fast.float().eval()]
    timings = [[], []]
    with torch.no_grad():
        for model in models:
            model(tokens)
        generator = torch.Generator().manual_seed(9017)
        for _ in range(10):
            for which in torch.randperm(2, generator=generator).tolist():
                begin = time.perf_counter()
                models[which](tokens)
                timings[which].append(time.perf_counter()-begin)
    medians = [statistics.median(values) for values in timings]
    args.output.mkdir()
    result = {'synthetic_nonzero_gain_fp64_output_max_error': output_error,
              'synthetic_fp64_gradient_max_errors': gradient_errors,
              'cpu_fp32_forward_median_seconds': {'eager': medians[0], 'precomputed': medians[1]},
              'cpu_forward_speedup': medians[0]/medians[1],
              'timing_scope': 'Paired synthetic batch4/context128/width128 CPU forward; concurrent training contention. Not streaming latency, trained-checkpoint parity, training trajectory or GPU benchmark.',
              'active_training_changed': False, 'official_test_read': False,
              'source_sha256': {str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
                                for path in [__file__, source.__file__]}}
    (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
