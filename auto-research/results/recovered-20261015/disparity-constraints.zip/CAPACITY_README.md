# Direct-distance inference capacity sweep

This is the agreed compact-inference relational design, with large training-only
distance tables. It does not replace it with an embedding-distance head: that
head is a **separate, explicitly labeled control**.

## Reproduce locally

Tested with Python 3.9, PyTorch 2.8.0 and scikit-learn 1.6.1. NumPy, SciPy and
Matplotlib are used by the reporting script. The digits dataset is bundled with
scikit-learn; no cloud service or credential is used.

From `/Users/rohanarun/Documents/trin`:

```bash
python3 experiments/disparity_constraints/test_capacity_sweep.py
python3 experiments/disparity_constraints/capacity_sweep.py --canary --output experiments/disparity_constraints/capacity-replication-canary
python3 experiments/disparity_constraints/capacity_sweep.py --output experiments/disparity_constraints/capacity-replication
python3 experiments/disparity_constraints/summarize_capacity.py experiments/disparity_constraints/capacity-replication
python3 experiments/disparity_constraints/capacity_runtime_followup.py experiments/disparity_constraints/capacity-replication
python3 experiments/disparity_constraints/capacity_latency_repeat.py experiments/disparity_constraints/capacity-replication
```

Training output directories must be new. The reporting script can be rerun
without training. The canary measures runtime only and makes no quality-driven
hyperparameter choices. Configurable values live in `capacity_config.json`.
`direct_distance.py` supplies the original independently parameterized table.

## Frozen sweep

- Tasks: context-dependent 8-class and 32-class synthetic tasks; real optical
  handwritten-digit classification. The synthetic tasks are related conditions,
  not two independent domains.
- Caps: 8, 16, 32 KiB of **actual deployed FP32 tensors**, including anchors,
  prototypes, and scale. Architectures maximize storage under each cap without
  padding; actual sizes are reported.
- Seeds: 17, 43, 89, 127, 191. Two learning rates per arm; 1,000 training updates
  per candidate; 450 candidates and 225 validation-selected models.
- Arms: ordinary dense classifier; dense with teacher; coordinate embeddings
  with teacher; direct distance generator; direct generator with teacher.
- All teacher arms receive both class-logit and pair-distance supervision from
  the same table. Dense-teacher gets a larger **training-only** pair head; it is
  not present in its deployment state. All dense models also learn logit scale.
- Validation selects checkpoints and conventional reference arms before any
  test assessment. `FREEZE.json` and `BASELINE_FREEZE.json` record the choices.
  Evaluation duplicates each selected score and verifies checkpoint hashes.
- Digits duplicates are removed before stratified splitting, and exact input
  overlap is checked. Digits seeds share the underlying dataset; confidence
  intervals are exploratory split/seed variation, not independent-population
  proof.

The official language-model test is not used. These runs are fixed-budget, not
proof that every model is fully converged or optimally tuned. Training FLOPs and
auxiliary parameter counts differ intentionally and are reported separately.

## Inference

Deployment checkpoints contain only `Student.state_dict()`. Training tables and
the dense auxiliary head are excluded. Raw query inputs are ordinary input
data, not part of stored model parameters. Instantiate the configured `Student`
with zero placeholder anchors, then load its checkpoint; actual anchors are in
the checkpoint for the direct-distance models.

The direct model produces scalar pair distances by a symmetric pair-conditioned
MLP. It does not learn separate endpoint coordinate embeddings. Its standard
inference batches classes; its streaming path trades lower temporary storage
for additional dispatches. `capacity_runtime_followup.predict` additionally
batches both pair orders into one network call. All prediction comparisons use
unchanged frozen weights; no runtime follow-up retraining occurs.

Memory figures count deployed tensors plus incremental CPU tensor allocations.
They exclude Python/runtime overhead, allocator reserve, input pipelines and
total RSS. PyTorch checkpoint file sizes include separate serialization overhead.
Latency is CPU single-query latency, not optimized GPU throughput.

## Interpretation and audit correction

The original engineering screen asks for half the deployed tensor storage with
accuracy within one percentage point, or a three-point gain at comparable memory,
with no more than twice baseline latency. Small-sample paired intervals are
Bonferroni-adjusted across the 18 predeclared accuracy comparisons.

A secondary guard rejects apparent storage advantages against an unnecessarily
oversized baseline if a same-cap baseline already matches performance. In the
first run, the guard was written nine seconds **after** checkpoint freeze, despite
initially being described as earlier. `ANALYSIS_PROTOCOL.json` records the timing
correction. It is post hoc; original screen results are reported unchanged.
The guard is not a new experiment or a training change.

The runtime follow-up is also explicitly post hoc and reports its results
separately from the original screening results. No claim of novelty, extra
independent information storage, or breakthrough follows automatically from
matching an oversized baseline.
