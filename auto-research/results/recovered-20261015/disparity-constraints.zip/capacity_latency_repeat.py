"""Repeated interleaved timing of the borderline digits half-storage result."""
import argparse
import json
from pathlib import Path
import statistics
import time
import torch
import capacity_sweep as s
from capacity_runtime_followup import predict


def main(out, blocks, repeats):
    c=json.loads((out/'PROTOCOL.json').read_text())['config']
    torch.set_num_threads(c['threads_per_worker'])
    frozen=json.loads((out/'FREEZE.json').read_text())
    baseline=json.loads((out/'BASELINE_FREEZE.json').read_text())
    rows=[]
    for seed in c['seeds']:
        specs=[next(r for r in frozen if r['task']=='digits' and r['seed']==seed and r['arm']=='distilled' and r['budget_scalars']==4096),
               next(r for r in baseline if r['task']=='digits' and r['seed']==seed and r['budget_scalars']==8192)]
        (_,valid,_),_=s.data('digits',seed,c)
        query=valid[0][:1]
        models=[]
        for spec in specs:
            state=torch.load(spec['checkpoint'],weights_only=True)
            model=s.Student(c,valid[0].shape[-1],int(valid[1].max())+1,spec['budget_scalars'],spec['arm'],torch.zeros(10,valid[0].shape[-1]))
            model.load_state_dict(state)
            models.append(model)
        with torch.inference_mode():
            for model in models:
                for _ in range(50):predict(model,query)
            for block in range(blocks):
                samples=[[],[]]
                for iteration in range(repeats):
                    order=(0,1) if (iteration+block)%2==0 else (1,0)
                    for index in order:
                        start=time.perf_counter_ns()
                        predict(models[index],query)
                        samples[index].append((time.perf_counter_ns()-start)/1000)
                rows.append({'seed':seed,'block':block,'student_us':statistics.median(samples[0]),
                             'baseline_us':statistics.median(samples[1]),'baseline_arm':specs[1]['arm']})
    ratios=[]
    for block in range(blocks):
        subset=[r for r in rows if r['block']==block]
        ratios.append(statistics.mean(r['student_us'] for r in subset)/statistics.mean(r['baseline_us'] for r in subset))
    result={'timing_only_posthoc':True,'blocks':blocks,'interleaved_repeats_per_block':repeats,
            'mean_seed_latency_ratios_per_block':ratios,'median_block_ratio':statistics.median(ratios),
            'source_sha256':s.prior.sha(Path(__file__)),'records':rows}
    s.write(out/'LATENCY_REPEATS.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path)
    p.add_argument('--blocks',type=int,default=5);p.add_argument('--repeats',type=int,default=500)
    a=p.parse_args();main(a.output,a.blocks,a.repeats)
