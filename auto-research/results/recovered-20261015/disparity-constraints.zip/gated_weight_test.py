"""Shared learned per-connection gates on directed dot-product weights."""
import argparse,copy,json,math,time,statistics
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
import dot_weight_test as base
S=base.shared
C={**base.C,'caps_bytes':[8192],'seeds':[1301,1361,1423,1481,1543],
   'arms':['dense','factorized','static_gate','input_gate'],'tile_rows':16}

class Model(base.Model):
    def __init__(self,h,rank,arm):
        super().__init__(h,rank);self.arm=arm
        if arm.endswith('gate'):self.gate=nn.Parameter(torch.zeros(4 if arm=='input_gate' else 2))
    def forward(self,x,tiled=False):
        if not self.arm.endswith('gate'):return super().forward(x)
        chunks=[]
        for q in self.q.split(C['tile_rows'] if tiled else len(self.q)):
            w=q@self.k.T
            logits=self.gate[0]*w+self.gate[1]
            if self.arm=='input_gate':
                context=(x@self.k)@q.T
                logits=logits[None]+self.gate[2]*x[:,None,:]+self.gate[3]*context[:,:,None]
                z=(x[:,None,:]*w[None]*(2*torch.sigmoid(logits))).sum(-1)
            else:z=x@(w*(2*torch.sigmoid(logits))).T
            chunks.append(z)
        return self.output(torch.tanh(torch.cat(chunks,-1)+self.bias))

def size(h,rank,arm):return base.size(h,rank)+(16 if arm=='input_gate' else 8 if arm=='static_gate' else 0)
def score(m,split):
    with torch.inference_mode():
        a=torch.cat([m(x) for x in split[0].split(C['batch'])]);return {'ce':F.cross_entropy(a,split[1]).item(),'accuracy':(a.argmax(-1)==split[1]).float().mean().item()}
def checks():
    torch.set_num_threads(1);torch.manual_seed(0);m=Model(37,4,'input_gate').double();x=torch.randn(5,64,dtype=torch.float64)
    ref=base.Model(37,4).double();ref.load_state_dict({k:v for k,v in m.state_dict().items() if k!='gate'})
    assert torch.allclose(m(x),ref(x),atol=1e-12,rtol=1e-10)
    with torch.no_grad():m.gate.copy_(torch.tensor([.3,-.2,.4,.1]))
    a=m(x);b=m(x,True);assert torch.allclose(a,b,atol=1e-12,rtol=1e-10)
    g=torch.autograd.grad(a.square().sum(),tuple(m.parameters()));h=torch.autograd.grad(b.square().sum(),tuple(m.parameters()))
    assert all(torch.allclose(u,v,atol=1e-10,rtol=1e-9) for u,v in zip(g,h))
    assert g[-1] is not None
    return {'identity_initialization':True,'tiled_forward_gradient_parity':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);p.add_argument('--canary',action='store_true');a=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);proof=checks()
    if a.canary:
        m=Model(102,4,'input_gate');x=torch.randn(C['batch'],64);y=torch.arange(C['batch'])%10;opt=torch.optim.Adam(m.parameters());start=time.perf_counter()
        for _ in range(100):opt.zero_grad();F.cross_entropy(m(x),y).backward();opt.step()
        print({'checks':proof,'estimated_seconds_per_2000_updates':(time.perf_counter()-start)*20});return
    out=a.output;out.mkdir(parents=True,exist_ok=False)
    S.write(out/'PROTOCOL.json',{'config':C,'checks':proof,'sources':{str(Path(f).resolve()):S.prior.sha(Path(f)) for f in [__file__,base.__file__,S.__file__]},
        'equation':'W_ij = q_i dot k_j; a_ij(x)=2 sigmoid(alpha W_ij + beta + gamma x_j + delta (W x)_i); effective weight=a_ij(x) W_ij. Static gate omits gamma and delta.',
        'scope':'Shared sigmoid attention-style gate, not conventional softmax self-attention. Zero coefficients initialize exact ungated behavior. No per-pair stored gates. Gate cannot reverse the sign of W but can suppress/amplify contributions.',
        'selection':'Validation CE only, global freeze before assessment. Digits is development data. Same input batches, updates and tuning count, not equal FLOPs. No cloud or confirmation dataset.'})
    rows=[];selected=[]
    for seed in C['seeds']:
        (train,valid,_),meta=S.data('digits',seed,C);S.write(out/f'data-{seed}.json',meta)
        for cap in C['caps_bytes']:
            for arm in C['arms']:
                if arm=='dense':shapes=[(max(1,int(((cap//4-10)//75)*f)),None) for f in C['dense_width_fractions']]
                else:shapes=[(max(h for h in range(1,cap//4) if size(h,r,arm)<=cap),r) for r in C['ranks']]
                candidates=[]
                for width,rank in shapes:
                    for lr in C['lrs']:
                        torch.manual_seed(seed);m=Model(width,rank,arm);opt=torch.optim.Adam(m.parameters(),lr=lr);rng=torch.Generator().manual_seed(seed+30000);history=[];best=float('inf');start=time.perf_counter()
                        for step in range(1,C['steps']+1):
                            ids=torch.randint(len(train[0]),(C['batch'],),generator=rng)
                            for group in opt.param_groups:group['lr']=lr*(.1+.9*.5*(1+math.cos(math.pi*step/C['steps'])))
                            opt.zero_grad();loss=F.cross_entropy(m(train[0][ids]),train[1][ids]);assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5);opt.step()
                            if step%C['validation_interval']==0:
                                val=score(m,valid);history.append({'step':step,**val})
                                if val['ce']<best:best=val['ce'];state=copy.deepcopy(m.state_dict());best_step=step
                        m.load_state_dict(state);path=out/f'{seed}-{arm}-{width}-{rank}-{lr}.pt';torch.save(state,path);n=sum(v.numel()*v.element_size() for v in state.values());assert n==size(width,rank,arm) and n<=cap
                        r={'seed':seed,'arm':arm,'cap':cap,'width':width,'rank':rank,'lr':lr,'bytes':n,'validation':score(m,valid),'best_step':best_step,'history':history,'checkpoint':str(path.resolve()),'sha256':S.prior.sha(path),'seconds':time.perf_counter()-start}
                        rows.append(r);candidates.append(r);S.write(out/'CANDIDATES.json',rows)
                selected.append(min(candidates,key=lambda r:r['validation']['ce']));print('completed',len(rows),'of',80,flush=True)
    S.write(out/'FREEZE.json',selected);result=[]
    for r in selected:
        (_,valid,test),_=S.data('digits',r['seed'],C);m=Model(r['width'],r['rank'],r['arm']);path=Path(r['checkpoint']);assert S.prior.sha(path)==r['sha256'];m.load_state_dict(torch.load(path,weights_only=True));assert score(m,valid)==r['validation'];r=copy.deepcopy(r);r['heldout']=score(m,test);assert score(m,test)==r['heldout']
        with torch.inference_mode():
            original=torch.cat([m(x).argmax(-1) for x in test[0].split(C['batch'])]);tiled=torch.cat([m(x,True).argmax(-1) for x in test[0].split(C['batch'])]);assert torch.equal(original,tiled)
        r['runtime']=S.profile_call(lambda:m(valid[0][:1],True),C['repeats']);r['gate_values']=m.gate.tolist() if hasattr(m,'gate') else None;result.append(r)
    S.write(out/'RESULT.json',result)
    lines=['# Learned weight-gate pilot','','Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.','','| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |','|---|---:|---:|---:|---:|---:|']
    summary=[]
    for arm in C['arms']:
        rs=[r for r in result if r['arm']==arm];avg=lambda f:statistics.mean(f(r) for r in rs)
        g={'arm':arm,'bytes':avg(lambda r:r['bytes']),'ce':avg(lambda r:r['heldout']['ce']),'accuracy':avg(lambda r:r['heldout']['accuracy']),'us':avg(lambda r:r['runtime']['median_single_query_us']),'query_tensor_bytes':avg(lambda r:r['runtime']['incremental_cpu_tensor_peak_bytes'])};summary.append(g)
        lines.append(f"| {arm} | {g['bytes']:.0f} | {g['ce']:.5f} | {g['accuracy']:.2%} | {g['us']:.2f} | {g['query_tensor_bytes']:.0f} |")
    lines+=['','Gate parameters count toward storage. Inference generates connection tiles, not a full matrix; temporary allocations exclude model weights, allocator reserve and process RSS. Training can materialize all connections. The input gate is a four-scalar shared rule, not a general attention architecture. The static gate isolates a nonlinear reweighting without input conditioning. The ungated model uses efficient factored inference. Equal updates do not guarantee convergence or equal compute. No breakthrough or novelty claim.','', 'Reproduce: python3 experiments/disparity_constraints/gated_weight_test.py --output NEW_DIRECTORY']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');S.write(out/'SUMMARY.json',summary);S.write(out/'COMPLETION.json',{'candidates':len(rows),'selected':len(result),'tiled_prediction_mismatches':0,'cloud_resources_created':0});print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
