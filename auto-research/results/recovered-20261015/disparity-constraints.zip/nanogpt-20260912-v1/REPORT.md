# nanoGPT versus constrained distance: byte-language pilot

All models have 70,464 parameters. Two layers, width 48, context 32, 400 updates, 51,200 target bytes per candidate; three seeds and two learning rates per arm. Full configuration and hashes are in PROTOCOL.json.

All arms use the unchanged pinned nanoGPT causal encoder. Distance arms replace its tied output head with normalized distance-to-token-prototype logits. The constrained arm adds same-next-byte attraction and different-next-byte repulsion for all 8,128 unordered pairs per batch. The distance model is an adaptation to language, not the earlier fixed-input MLP. Equal bytes, steps, initialization and parameters; extra constraint compute is not matched.

Data: bytes from the local WikiText-2 word-preprocessed train.txt and valid.txt. This is not raw-v1 or word-level PPL. A fixed 8,192-byte validation prefix selects checkpoints and learning rates. Frozen winners are assessed on a disjoint 32,768-byte validation suffix. The official test is unopened. This is a short learning pilot, not a converged benchmark.

| Seed | Model | Selected LR | Assessment CE | BPC |
|---:|---|---:|---:|---:|
| 17 | nanogpt | 0.001 | 2.446040 | 3.528890 |
| 17 | distance | 0.003 | 2.414370 | 3.483199 |
| 17 | constrained_distance | 0.003 | 2.471323 | 3.565365 |
| 43 | nanogpt | 0.001 | 2.468204 | 3.560866 |
| 43 | distance | 0.001 | 2.427254 | 3.501787 |
| 43 | constrained_distance | 0.001 | 2.449336 | 3.533644 |
| 89 | nanogpt | 0.001 | 2.464381 | 3.555350 |
| 89 | distance | 0.003 | 2.402327 | 3.465825 |
| 89 | constrained_distance | 0.003 | 2.418588 | 3.489285 |

| Model | Mean CE | Mean BPC |
|---|---:|---:|
| nanogpt | 2.459542 | 3.548369 |
| distance | 2.414650 | 3.483604 |
| constrained_distance | 2.446416 | 3.529432 |

Verified identical initial tensors, unique parameter counts, causal outputs, distance-head equivalence, checkpoint hashes, exact selection-score reproduction and zero drift on duplicate assessment. Byte-label constraints may conflict with the fact that the same context can legitimately have several next tokens. They should not be interpreted as learned semantic compatibility.

## Interpretation

Constrained distance lowers mean assessment CE by approximately 0.53% relative to ordinary nanoGPT, winning two of three seeds. Unconstrained distance lowers mean CE by approximately 1.83%, wins all three seeds against nanoGPT, and also beats constrained distance in all three seeds. Thus this run supports a promising distance-head modification at a short training budget, but supplies no evidence that the added constraints caused the improvement. The normalized squared-distance head is equivalent to scaled cosine logits; this is not a new storage-capacity result.

This language pilot uses a fixed squared-hinge penalty, whereas the earlier full-batch toy experiment additionally maintained persistent per-example-pair multipliers. The earlier constrained model was an MLP; this pilot uses a shared nanoGPT encoder for a controlled causal-language adaptation. Results cannot establish that the original standalone MLP beats a transformer. Same-next-byte attraction is only a provisional label-based constraint and may collapse contexts with different future distributions.

All 18 saved candidate checkpoint hashes and all nine validation-based winner choices were also checked after completion. The official test remains unopened, no cloud resources were started, and no hyperparameters were retuned after assessment results were obtained. More training and a larger held-out assessment are required before calling this a benchmark win.
