# Official WikiText-2 split: frozen byte-model comparison

All nine validation-selected checkpoints evaluated once over 1,254,981 next-byte targets each. 70,464 parameters each, context 32, 400 training steps. All models use nanoGPT's causal encoder; distance variants change the tied output head. This is a short pilot using bytes of word-preprocessed WikiText-2, not a published word-level benchmark comparison.

The final partial context is included. CE is nats per byte. No parameters or checkpoint choices were changed based on test results. Evaluation is FP32 CPU; every saved tensor was verified unchanged afterward.

| Seed | Model | Test CE | BPC | Byte accuracy |
|---:|---|---:|---:|---:|
| 17 | nanogpt | 2.444643 | 3.526874 | 32.87% |
| 17 | distance | 2.402846 | 3.466574 | 31.30% |
| 17 | constrained_distance | 2.462200 | 3.552204 | 30.24% |
| 43 | nanogpt | 2.457651 | 3.545641 | 32.77% |
| 43 | distance | 2.408876 | 3.475274 | 31.17% |
| 43 | constrained_distance | 2.427457 | 3.502081 | 31.82% |
| 89 | nanogpt | 2.464724 | 3.555845 | 32.85% |
| 89 | distance | 2.389227 | 3.446926 | 33.10% |
| 89 | constrained_distance | 2.409871 | 3.476709 | 33.08% |

| Model | Mean test CE | Mean BPC | Mean byte accuracy |
|---|---:|---:|---:|
| nanogpt | 2.455673 | 3.542787 | 32.83% |
| distance | 2.400316 | 3.462925 | 31.86% |
| constrained_distance | 2.433176 | 3.510331 | 31.71% |
