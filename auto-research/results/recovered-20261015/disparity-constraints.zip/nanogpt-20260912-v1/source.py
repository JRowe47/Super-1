"""Matched-size byte-language pilot. Official test is never opened."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time
import torch
from torch import nn
from torch.nn import functional as F

ARMS = ("nanogpt", "distance", "constrained_distance")


class DistanceHead(nn.Module):
    def __init__(self, weight, temperature):
        super().__init__()
        self.weight = weight
        self.temperature = temperature
        self.hidden = None

    def forward(self, x):
        self.hidden = F.normalize(x, dim=-1)
        prototypes = F.normalize(self.weight, dim=-1)
        # -temperature * squared unit distance, dropping the common -2T term.
        return 2*self.temperature*(self.hidden @ prototypes.T)


def make(module, c, seed, arm):
    torch.manual_seed(seed)
    model = module.GPT(module.GPTConfig(vocab_size=256, block_size=c["context"],
                       n_layer=c["layers"], n_head=c["heads"], n_embd=c["width"], dropout=0., bias=True))
    if arm != "nanogpt":
        model.lm_head = DistanceHead(model.lm_head.weight, c["temperature"])
    return model


def pairs(z, y, c):
    z, y = z.reshape(-1,z.shape[-1]), y.flatten()
    i,j = torch.triu_indices(len(y),len(y),offset=1)
    same = y[i]==y[j]
    d = (z[i]-z[j]).square().sum(-1)
    v = torch.where(same, d-c["close_radius"]**2, c["separate_radius"]**2-d).relu()
    loss = torch.stack([v[m].square().mean() for m in (same,~same) if m.any()]).mean()
    return loss, {"pairs":len(i), "satisfied_fraction":float((v.detach()<=1e-4).float().mean()),
                  "max_violation":float(v.detach().max())}


def evaluation(model, tokens, context):
    model.eval()
    total, n = 0.,0
    with torch.no_grad():
        for start in range(0,len(tokens)-1,context*16):
            chunk=tokens[start:min(start+context*16+1,len(tokens))]
            windows=(len(chunk)-1)//context
            if not windows:
                continue
            x=chunk[:windows*context].reshape(windows,context)
            y=chunk[1:windows*context+1].reshape(windows,context)
            _,loss=model(x,y)
            total+=float(loss)*y.numel()
            n+=y.numel()
    return {"ce":total/n,"bpc":total/n/math.log(2),"targets":n}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    source=Path(__file__)
    c=json.loads(source.with_name("nanogpt_config.json").read_text())
    torch.set_num_threads(c["threads"])
    torch.use_deterministic_algorithms(True)
    vendor=Path(c["nanogpt_source"])
    assert hashlib.sha256(vendor.read_bytes()).hexdigest()==c["nanogpt_sha256"]
    spec=importlib.util.spec_from_file_location("pinned_nanogpt",vendor)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    root=Path(c["data_root"])
    train_bytes=(root/"train.txt").read_bytes()
    valid_bytes=(root/"valid.txt").read_bytes()
    train=torch.tensor(list(train_bytes),dtype=torch.long)
    # Fixed disjoint validation regions: tuning prefix and assessment suffix.
    cut=c["selection_bytes"]
    assert len(valid_bytes)>cut+c["assessment_bytes"]+2*c["context"]
    selection=torch.tensor(list(valid_bytes[:cut+1]),dtype=torch.long)
    assessment=torch.tensor(list(valid_bytes[-c["assessment_bytes"]-1:]),dtype=torch.long)
    out=args.output
    out.mkdir(parents=True,exist_ok=False)
    models=[make(module,c,17,arm) for arm in ARMS]
    counts=[sum(p.numel() for p in m.parameters()) for m in models]
    assert len(set(counts))==1
    for model in models[1:]:
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in models[0].state_dict().items())
    # Causality and direct distance-head equivalence checks before training.
    x=train[:c["context"]].reshape(1,-1)
    for model in models:
        with torch.no_grad():
            a,_=model(x,x)
            changed=x.clone(); changed[:,-1]=(changed[:,-1]+1)%256
            b,_=model(changed,x)
            assert torch.equal(a[:,:-1],b[:,:-1])
            if isinstance(model.lm_head,DistanceHead):
                h=model.lm_head.hidden
                p=F.normalize(model.lm_head.weight,dim=-1)
                explicit=-c["temperature"]*(h[:,:,None,:]-p[None,None,:,:]).square().sum(-1)
                assert torch.allclose(b.softmax(-1),explicit.softmax(-1),atol=2e-6,rtol=2e-5)
    protocol={"config":c,"parameters":counts[0],"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
              "train_sha256":hashlib.sha256(train_bytes).hexdigest(),"valid_sha256":hashlib.sha256(valid_bytes).hexdigest(),
              "train_bytes":len(train_bytes),"validation_bytes":len(valid_bytes),"torch":torch.__version__,
              "device":"cpu","official_test_opened":False,"initialization_equal":True,"causality_verified":True,
              "scope":"nanoGPT shared causal encoder; replace tied head with normalized distance prototypes. Same/different NEXT BYTE labels define compatibility. This is not semantic concept supervision.",
              "constraints":"all pairs within each batch, fixed balanced squared hinge penalty; no corpus-wide multipliers, no guaranteed feasibility",
              "selection":"lowest prefix-validation CE across checkpoints and two learning rates; assess frozen winners on disjoint validation suffix",
              "budget":"equal steps, training bytes and parameter counts; not equal FLOPs; 51200 target bytes per candidate"}
    (out/"PROTOCOL.json").write_text(json.dumps(protocol,indent=2))
    (out/"source.py").write_text(source.read_text())
    del models
    candidates=[]
    for seed in c["seeds"]:
        for arm in ARMS:
            for lr in c["learning_rates"]:
                model=make(module,c,seed,arm)
                opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=c["weight_decay"])
                rng=torch.Generator().manual_seed(seed+10000)
                history=[]; best_ce=float("inf"); best=None
                started=time.perf_counter()
                for step in range(1,c["steps"]+1):
                    model.train()
                    indices=torch.randint(len(train)-c["context"]-1,(c["batch_size"],),generator=rng)
                    positions=indices[:,None]+torch.arange(c["context"])[None,:]
                    x,y=train[positions],train[positions+1]
                    opt.zero_grad(set_to_none=True)
                    _,ce=model(x,y)
                    loss=ce
                    if arm=="constrained_distance":
                        penalty,geometry=pairs(model.lm_head.hidden,y,c)
                        loss=loss+c["penalty"]*penalty
                    assert torch.isfinite(loss)
                    loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(),c["clip"])
                    opt.step()
                    if step%c["validation_interval"]==0:
                        measured=evaluation(model,selection,c["context"])
                        row={"step":step,"selection_ce":measured["ce"],"train_ce":float(ce.detach())}
                        if arm=="constrained_distance": row["last_batch_geometry"]=geometry
                        history.append(row)
                        if measured["ce"]<best_ce:
                            best_ce=measured["ce"]; best=copy.deepcopy(model.state_dict()); best_step=step
                record={"seed":seed,"arm":arm,"lr":lr,"selection_ce":best_ce,"best_step":best_step,
                        "history":history,"training_seconds":time.perf_counter()-started}
                path=out/f"{seed}-{arm}-{lr}.pt"
                torch.save(best,path)
                record.update(checkpoint=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                candidates.append(record)
                (out/"CANDIDATES.json").write_text(json.dumps(candidates,indent=2))
                print(json.dumps({k:v for k,v in record.items() if k!="history"}),flush=True)
    # No assessment scores computed until every candidate finishes.
    results=[]
    for seed in c["seeds"]:
        for arm in ARMS:
            winner=min((r for r in candidates if r["seed"]==seed and r["arm"]==arm),key=lambda r:r["selection_ce"])
            model=make(module,c,seed,arm)
            path=out/winner["checkpoint"]
            assert hashlib.sha256(path.read_bytes()).hexdigest()==winner["sha256"]
            model.load_state_dict(torch.load(path,weights_only=True))
            assert evaluation(model,selection,c["context"])["ce"]==winner["selection_ce"]
            measured=evaluation(model,assessment,c["context"])
            assert evaluation(model,assessment,c["context"])==measured
            results.append({**winner,"assessment":measured})
    (out/"RESULT.json").write_text(json.dumps(results,indent=2))
    lines=["# nanoGPT versus constrained distance: byte-language pilot","",
           f"All models have {counts[0]:,} parameters. Two layers, width 48, context 32, 400 updates, 51,200 target bytes per candidate; three seeds and two learning rates per arm. Full configuration and hashes are in PROTOCOL.json.","",
           "All arms use the unchanged pinned nanoGPT causal encoder. Distance arms replace its tied output head with normalized distance-to-token-prototype logits. The constrained arm adds same-next-byte attraction and different-next-byte repulsion for all 8,128 unordered pairs per batch. The distance model is an adaptation to language, not the earlier fixed-input MLP. Equal bytes, steps, initialization and parameters; extra constraint compute is not matched.","",
           "Data: bytes from the local WikiText-2 word-preprocessed train.txt and valid.txt. This is not raw-v1 or word-level PPL. A fixed 8,192-byte validation prefix selects checkpoints and learning rates. Frozen winners are assessed on a disjoint 32,768-byte validation suffix. The official test is unopened. This is a short learning pilot, not a converged benchmark.","",
           "| Seed | Model | Selected LR | Assessment CE | BPC |","|---:|---|---:|---:|---:|"]
    for r in results:
        lines.append(f"| {r['seed']} | {r['arm']} | {r['lr']} | {r['assessment']['ce']:.6f} | {r['assessment']['bpc']:.6f} |")
    lines += ["","| Model | Mean CE | Mean BPC |","|---|---:|---:|"]
    for arm in ARMS:
        rows=[r for r in results if r["arm"]==arm]
        lines.append(f"| {arm} | {sum(r['assessment']['ce'] for r in rows)/len(rows):.6f} | {sum(r['assessment']['bpc'] for r in rows)/len(rows):.6f} |")
    lines += ["","Verified identical initial tensors, unique parameter counts, causal outputs, distance-head equivalence, checkpoint hashes, exact selection-score reproduction and zero drift on duplicate assessment. Byte-label constraints may conflict with the fact that the same context can legitimately have several next tokens. They should not be interpreted as learned semantic compatibility."]
    (out/"REPORT.md").write_text('\n'.join(lines)+'\n')
    os.environ.setdefault("MPLCONFIGDIR",str(out/"matplotlib"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(7,4))
    for arm in ARMS:
        rows=[r for r in results if r["arm"]==arm]
        ax.plot([h["step"] for h in rows[0]["history"]],
                [sum(r["history"][i]["selection_ce"] for r in rows)/len(rows) for i in range(len(rows[0]["history"]))],label=arm)
    ax.set(xlabel="Training steps",ylabel="Selection validation CE (nats/byte)",title="Matched-size nanoGPT pilot: selected learning rates")
    ax.legend(); ax.grid(alpha=.2); fig.tight_layout(); fig.savefig(out/"progress.png",dpi=160)
    print(str(out/"REPORT.md"),flush=True)


if __name__=="__main__":main()
