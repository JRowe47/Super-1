# Deployment audit of the confirmed geometric winners

All three frozen geometric checkpoints and their corresponding frozen Transformer controls passed FP32 full-forward/incremental decoding parity on synthetic 128-token sequences. Maximum logit discrepancy across the six checkpoints was 0.000006914. All checkpoint hashes matched; no validation or official test data was read and no accuracy scoring was repeated.

| Quantity, FP32 batch one at 128 tokens | Geometry | Transformer |
| --- | ---: | ---: |
| Weight tensor bytes | 265,728 | 265,704 |
| Persistent state tensor bytes | 512 | 71,680 |
| Weights plus persistent state bytes | 266,240 | 337,384 |
| Seed 2503 CPU microseconds/token | 86.14 | 55.10 |
| Seed 2551 CPU microseconds/token | 86.56 | 54.89 |
| Seed 2609 CPU microseconds/token | 85.59 | 55.76 |

The geometry retains 140 times less sequence state, but measured weights-plus-state storage is only 21.1% smaller. Temporary activations, allocator overhead and runtime libraries are excluded. The exact Transformer adapter caches projected keys and values rather than recomputing the whole prefix.

This eager Python geometric adapter is approximately 56% slower based on the mean of the per-seed CPU median token times. Each checkpoint used 30 repeats after three warmups. A separate training experiment was running concurrently. These are batch-one synthetic CPU decoding measurements, not isolated production latency, GPU throughput, peak memory or a claim that compression improves speed.

These are the actual frozen winners from the completed larger reserved-validation study, unlike the earlier first-checkpoint input-only deployment audit. The confirmed 8.45% lower mean byte CE versus this Transformer is recorded separately under input-generated-scale-validation-20261001-v1; this audit does not add independent accuracy evidence. Norm-preserving geometric recurrence is still not a validated SOTA or novelty result.

Decision: retain the promising accuracy and state-memory findings, but do not claim an overall inference-performance win yet. Improve and independently validate the incremental implementation before scaling deployment claims. Do not alter the active relative-phase-key training implementation.
