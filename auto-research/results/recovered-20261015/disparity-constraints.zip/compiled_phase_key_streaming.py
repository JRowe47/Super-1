"""Exact incremental phase-key adapter, with no dense transition storage."""
import torch
from torch import nn
from compiled_overlapping_streaming import OverlappingStep


class PhaseKeyStep(OverlappingStep):
    def __init__(self, model):
        super().__init__(model)
        self.phase_key = nn.Parameter(model.phase_key.detach().clone(), requires_grad=False)
        self.second_phase_key = nn.Parameter(model.second_phase_key.detach().clone(), requires_grad=False)

    def bank(self, state: torch.Tensor, drive: torch.Tensor, angle: torch.Tensor,
             gain: torch.Tensor, offset: int) -> torch.Tensor:
        pair = torch.roll(state, shifts=offset, dims=-1).reshape(state.shape[0], -1, 2)
        target = torch.roll(drive, shifts=offset, dims=-1).reshape(state.shape[0], -1, 2)
        cross = pair[:, :, 0]*target[:, :, 1]-pair[:, :, 1]*target[:, :, 0]
        dot = (pair*target).sum(-1)
        denominator = torch.sqrt(pair.square().sum(-1)*target.square().sum(-1)+1e-6)
        key = self.phase_key if offset == 0 else self.second_phase_key
        query = (cross*key.cos()+dot*key.sin())/denominator
        theta = angle+gain*query.tanh()
        cosine, sine = theta.cos(), theta.sin()
        rotated = torch.stack((cosine*pair[:, :, 0]-sine*pair[:, :, 1],
                               sine*pair[:, :, 0]+cosine*pair[:, :, 1]), -1).flatten(1)
        return torch.roll(rotated, shifts=-offset, dims=-1)
