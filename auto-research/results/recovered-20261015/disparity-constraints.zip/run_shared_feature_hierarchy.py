"""Native-hierarchy test preserving scale slots and shared feature alignment."""
from pathlib import Path
import hashlib

import run_original_transport_stream as runner
import shared_feature_hierarchy as feature


native_make_model = runner.make_model
native_checks = feature.checks


def make_model(arm, config):
    if arm in {'original', 'transformer'}:
        return native_make_model(arm, config)
    assert arm in {'fixed_feature', 'input_feature'}
    base = feature.authoritative.PersistentMultiScaleLM(config['vocab'], config['hierarchy_width'], config['state_scales'])
    return feature.SharedFeatureHierarchy(base, arm == 'input_feature')


def checks():
    result = native_checks()
    result['source_hashes'] = {str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
                               for path in [__file__, feature.original.__file__]}
    result['hypothesis'] = 'Input-generated shared feature transport can improve the original hierarchy without rotating fast and slow scale slots into each other.'
    return result


def configure():
    runner.transport = feature
    runner.ARMS = ('original', 'fixed_feature', 'input_feature', 'transformer')
    runner.make_model = make_model
    feature.checks = checks


if __name__ == '__main__':
    configure()
    runner.main()
