"""Actual CPU streaming-state and latency audit of frozen byte checkpoints.

Recurrent adapter retains only the hidden vector. Transformer adapter caches
the exact layer's projected keys/values rather than recomputing full prefixes.
No training, new validation scoring, or official-test access occurs here.
"""
import argparse
import json
import statistics
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import phase_transition_language as pilot


def phase_step(model, token, state):
    embedded = model.embedding(token)
    drive = torch.tanh(model.drive(embedded))
    retention = torch.sigmoid(model.write(embedded) + model.retention)
    if state is None:
        state = torch.zeros_like(drive)
    pair, target = state.reshape(len(token), -1, 2), drive.reshape(len(token), -1, 2)
    theta = model.angle
    if model.dynamic:
        cross = pair[..., 0] * target[..., 1] - pair[..., 1] * target[..., 0]
        denominator = torch.sqrt(pair.square().sum(-1) * target.square().sum(-1) + 1e-6)
        theta = theta + model.gain * torch.tanh(cross / denominator)
    cosine, sine = theta.cos(), theta.sin()
    rotated = torch.stack((cosine * pair[..., 0] - sine * pair[..., 1],
                           sine * pair[..., 0] + cosine * pair[..., 1]), -1).flatten(1)
    updated = retention * rotated + (1 - retention) * drive
    return model.norm(updated) @ model.embedding.weight.T, updated


def transformer_step(model, token, state):
    layer = model.block
    position = 0 if state is None else state[0].shape[-2]
    embedded = model.embedding(token) + model.position[position]
    normalized = layer.norm1(embedded)
    q, k, v = F.linear(normalized, layer.self_attn.in_proj_weight, layer.self_attn.in_proj_bias).chunk(3, -1)
    heads = layer.self_attn.num_heads
    def split(tensor):
        return tensor.reshape(len(token), heads, 1, -1)
    q, k, v = split(q), split(k), split(v)
    if state is not None:
        k, v = torch.cat((state[0], k), -2), torch.cat((state[1], v), -2)
    attended = F.scaled_dot_product_attention(q, k, v).reshape(len(token), -1)
    hidden = embedded + layer.self_attn.out_proj(attended)
    hidden = hidden + layer.linear2(layer.activation(layer.linear1(layer.norm2(hidden))))
    return model.norm(hidden) @ model.embedding.weight.T, (k, v)


def bytes_of(state):
    if isinstance(state, tuple):
        return sum(bytes_of(item) for item in state)
    return state.numel() * state.element_size()


def stream(model, tokens, step):
    state, outputs = None, []
    for index in range(tokens.shape[1]):
        logits, state = step(model, tokens[:, index], state)
        outputs.append(logits)
    return torch.stack(outputs, 1), state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, required=True)
    parser.add_argument('--warmups', type=int, required=True)
    parser.add_argument('--parity-atol', type=float, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.repeats > 0 and args.warmups >= 0
    protocol = json.loads((args.source / 'PROTOCOL.json').read_text())
    assert pilot.shared.prior.sha(Path(pilot.__file__)) == protocol['source_sha256']
    pilot.C.update(protocol['config'])
    torch.set_num_threads(protocol['config']['threads'])
    frozen = json.loads((args.source / 'FREEZE.json').read_text())
    args.output.mkdir()
    pilot.shared.write(args.output / 'PROTOCOL.json', {
        'source_freeze_sha256': pilot.shared.prior.sha(args.source / 'FREEZE.json'),
        'adapter_source_sha256': pilot.shared.prior.sha(Path(__file__)),
        'repeats': args.repeats, 'warmups': args.warmups, 'parity_atol': args.parity_atol,
        'scope': 'Batch-one CPU incremental decoding; actual persistent tensor bytes exclude temporary activations, allocator overhead, and runtime libraries. Timings may face contention from concurrent training. Not GPU speed or peak-memory evidence.',
        'official_test_read': False,
    })
    torch.manual_seed(protocol['config']['seeds'][0])
    tokens = torch.randint(256, (1, protocol['config']['context']))
    rows = []
    with torch.inference_mode():
        for row in frozen:
            path = args.source / Path(row['checkpoint']).name
            assert pilot.shared.prior.sha(path) == row['sha256']
            if row['arm'] == 'transformer':
                model = pilot.TinyTransformer(protocol['transformer_width'], protocol['transformer_ff_width'])
                step = transformer_step
            else:
                assert row['arm'] in {'fixed_rotation', 'geometric_rotation'}
                model = pilot.PhaseLM(protocol['config']['width'], row['arm'] == 'geometric_rotation')
                step = phase_step
            model.load_state_dict(torch.load(path, weights_only=True))
            model.float().eval()
            full = model(tokens)
            incremental, state = stream(model, tokens, step)
            maximum_error = (full - incremental).abs().max().item()
            assert torch.allclose(full, incremental, atol=args.parity_atol, rtol=args.parity_atol), maximum_error
            for _ in range(args.warmups):
                stream(model, tokens, step)
            timings = []
            for _ in range(args.repeats):
                start = time.perf_counter()
                stream(model, tokens, step)
                timings.append(time.perf_counter() - start)
            rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                         'streaming_parity_max_error': maximum_error,
                         'weight_tensor_bytes': sum(p.numel() * p.element_size() for p in model.parameters()),
                         'persistent_state_bytes': bytes_of(state), 'context': tokens.shape[1],
                         'median_microseconds_per_token': statistics.median(timings) * 1e6 / tokens.shape[1]})
            pilot.shared.write(args.output / 'RESULT.json', rows)
            print(json.dumps(rows[-1]), flush=True)
    pilot.shared.write(args.output / 'COMPLETION.json', {'checkpoints': len(rows), 'official_test_read': False})


if __name__ == '__main__':
    main()
