"""Input-generated overlapping rotations with no state-dependent angle query.

At fixed input the transport Jacobian is orthogonal regardless of gain size.
The existing input-conditioned retention then contracts its state Jacobian.
This is a mechanism ablation, not a claim that input-generated RNNs are new.
"""
import json

import torch
import noncommuting_phase_candidate as source


class InputGeneratedPhaseLM(source.OverlappingPhaseLM):
    def angle_for(self, state, drive, angle, gain, offset):
        if gain is None:
            return angle
        pair = torch.roll(drive, shifts=offset, dims=-1).reshape(len(drive), -1, 2)
        # The learned base angle also supplies a query direction, avoiding an
        # extra stored direction vector or a larger parameter budget.
        oriented = pair[..., 0] * angle.sin() - pair[..., 1] * angle.cos()
        normalized = oriented / torch.sqrt(pair.square().sum(-1) + 1e-6)
        return angle + gain * normalized.tanh()


def checks():
    torch.set_num_threads(1)
    torch.manual_seed(9017)
    model = InputGeneratedPhaseLM(16, True).double()
    fixed = source.OverlappingPhaseLM(16, False).double()
    fixed.load_state_dict({name: value for name, value in model.state_dict().items()
                          if name not in {'gain', 'second_gain'}})
    tokens = torch.randint(256, (2, 8))
    assert torch.equal(model(tokens), fixed(tokens)), 'Zero-gain baseline drift'
    model(tokens).square().sum().backward()
    for parameter in [model.gain, model.second_gain]:
        assert torch.isfinite(parameter.grad).all() and parameter.grad.abs().sum() > 0
    with torch.no_grad():
        model.angle.normal_()
        model.second_angle.normal_()
        model.gain.normal_(std=10)
        model.second_gain.normal_(std=10)
    rows = []
    for _ in range(20):
        state = torch.randn(1, model.d, dtype=torch.float64)
        drive = torch.randn_like(state).tanh()
        retention = torch.sigmoid(torch.randn_like(state)*4)
        def rotate(value):
            value = value.reshape(1, model.d)
            first = source.rotate(value, model.angle_for(value, drive, model.angle, model.gain, 0), 0)
            return source.rotate(first, model.angle_for(first, drive, model.second_angle, model.second_gain, 1), 1).flatten()
        jacobian = torch.autograd.functional.jacobian(rotate, state.flatten(), vectorize=True)
        singular = torch.linalg.svdvals(jacobian)
        assert torch.allclose(singular, torch.ones_like(singular), atol=1e-12, rtol=1e-12)
        transition_singular = torch.linalg.svdvals(retention.flatten()[:, None]*jacobian).max().item()
        assert abs(transition_singular-retention.max().item()) < 1e-12
        rows.append({'rotation_jacobian_max_singular': singular.max().item(),
                     'transition_jacobian_max_singular': transition_singular,
                     'maximum_retention': retention.max().item()})
    changed = tokens.clone()
    changed[:, 4:] = torch.randint(256, (2, 4))
    assert torch.equal(model(tokens)[:, :4], model(changed)[:, :4])
    return {'zero_gain_identity_exact': True, 'both_gain_gradients_nonzero': True,
            'causal_prefix': True, 'large_gain_sensitivity_cases': rows,
            'trained': False, 'novelty_established': False,
            'scope': 'Fixed-input recurrent-state Jacobian only. No output/input/parameter sensitivity guarantee; not the original hierarchy.'}


if __name__ == '__main__':
    print(json.dumps(checks()))
