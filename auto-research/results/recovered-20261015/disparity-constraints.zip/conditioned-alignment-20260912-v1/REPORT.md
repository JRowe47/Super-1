# Input-conditioned alignment pilot

Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.

| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |
|---|---:|---:|---:|---:|---:|
| dense | 7300 | 0.11040 | 97.23% | 6.43 | 234 |
| factorized | 8132 | 0.13178 | 96.09% | 7.70 | 336 |
| constant | 8088 | 0.12789 | 96.30% | 8.82 | 496 |
| conditioned | 8140 | 0.14252 | 96.09% | 12.80 | 452 |

All conditioner parameters count toward storage. Actual inference uses rank-sized channels and never materializes the weight matrix. Full matrices are formed only for an independent equivalence check after freezing. Temporary allocations exclude model weights, allocator reserve and process RSS. Constant coefficients can be absorbed into Q: this control changes optimization, not the representable linear layer. Signed input-conditioned coefficients need not be probabilities. Equal updates do not guarantee convergence or equal compute. No breakthrough or novelty claim.

Reproduce: python3 experiments/disparity_constraints/conditioned_alignment_test.py --output NEW_DIRECTORY
