# Shared-feature hierarchy: reserved validation decision

The input-generated within-scale rotation extension is not promoted as a reliable improvement over the original hierarchy. It beats the Transformer in all three seeds, but its small average improvement over the original is inconsistent across seeds and its improvement over fixed rotations is also inconsistent.

All 24 declared training trials completed. The twelve selected checkpoints were frozen by selection-region CE over the same two learning rates per arm and seed. Source and checkpoint hashes, complete trial coverage, selected steps and canonical learning-rate selection passed inspection. All twelve checkpoints were evaluated twice in FP32 on 65,536 reserved validation bytes beginning at byte 393,216, with zero duplicate drift. The twelve original/Transformer control trials exactly replayed earlier training scores, histories and checkpoint hashes.

| Arm | Mean byte CE | Mean BPC | Parameters |
| --- | ---: | ---: | ---: |
| Original hierarchy | 1.713308 | 2.471780 | 52,861 |
| Fixed feature rotations | 1.713941 | 2.472694 | 52,892 |
| Input-generated feature rotations | 1.710469 | 2.467686 | 52,923 |
| Transformer | 1.774943 | 2.560702 | 52,768 |

| Seed | Input-generated minus original CE | Minus fixed feature CE | Minus Transformer CE |
| --- | ---: | ---: | ---: |
| 2503 | -0.008936 | -0.004147 | -0.046921 |
| 2551 | -0.000149 | +0.001171 | -0.065917 |
| 2609 | +0.000570 | -0.007437 | -0.080583 |

Lower is better. Input-generated rotations improve mean CE by approximately 0.166% over original, 0.203% over fixed rotations, and 3.63% over Transformer. The original hierarchy already beats this Transformer; that comparison alone cannot attribute the advantage to the added rotations. No statistical significance or universal mechanism claim is established.

The extension preserves the original learned gates, nonlinear state update, cross-scale mean coupling, timescales and head. It applies one shared orthogonal feature rotation inside each scale, preserving scale slots. This tests a different extension from earlier cross-scale rotations; it does not prove why those earlier rotations underperformed.

Training uses three seeds, 3,000 updates, batch eight, 64-token contiguous BPTT, 1,536,000 target-byte exposures per trial, and equal learning-rate tuning budgets. Hierarchy state is carried and detached across chunks. Transformer uses a recomputed 64-token prefix and scores the next 64 tokens. Parameters and tokens are closely matched, but FLOPs and effective history are not matched. This is a small byte-level local study, not word-level perplexity, official-test evidence, SOTA, or established novelty. Zero cloud resources were created. The official test remains sealed.

Decision: preserve the original hierarchy as the stronger established baseline. Do not scale the shared-feature extension solely on this mixed, tiny incremental gain. Await the separate larger input-generated/state-dependent rotation comparison before choosing a new mechanism experiment.
