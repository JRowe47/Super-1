"""Independent checkpoint/data audit and disclosed full-replay supplement."""
import argparse
import hashlib
import json
from pathlib import Path
import torch
import run as experiment


def verify_checkpoint(root, receipt):
    path = root/receipt["file"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == receipt["sha256"]
    return torch.load(path, weights_only=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args()
    root = args.results
    protocol = json.loads((root/"PROTOCOL.json").read_text())
    results = json.loads((root/"RESULT.json").read_text())
    c = protocol["config"]
    torch.set_num_threads(c["threads"])
    torch.use_deterministic_algorithms(True)
    assert hashlib.sha256(Path(experiment.__file__).read_bytes()).hexdigest() == protocol["source_sha256"]
    assert hashlib.sha256((root/"run_source.py").read_bytes()).hexdigest() == protocol["source_sha256"]
    prepared = {seed:experiment.datasets(seed, c) for seed in c["seeds"]}
    for seed, (_, evidence) in prepared.items():
        assert evidence == protocol["data"][str(seed)]
    expected = len(c["seeds"])*len(experiment.ARMS)
    assert len(results["joint"]) == len(results["pretrain"]) == expected
    assert len(results["adaptation"]) == expected*len(c["rehearsal_per_old_class"])
    checked = 0
    for stage, records in results.items():
        for r in records:
            (train, valid, test), _ = prepared[r["seed"]]
            model = experiment.make_model(r["arm"], r["seed"], c)
            model.load_state_dict(verify_checkpoint(root, r["checkpoint"]))
            checked += 1
            assert experiment.count(model) == r["parameters"]
            old_argument = None if stage == "joint" else c["old_classes"]
            assert experiment.metrics(model, test, old_argument) == r["test"]
            if stage == "pretrain":
                valid = experiment.subset(valid, valid[1] < c["old_classes"])
                train = experiment.subset(train, train[1] < c["old_classes"])
            elif stage == "adaptation":
                rehearsal = r["rehearsal_per_old_class"]
                others = [v for v in records if v["seed"]==r["seed"] and v["rehearsal_per_old_class"]==rehearsal]
                assert all(v["training_indices"]==r["training_indices"] for v in others)
                train = experiment.subset(train, torch.tensor(r["training_indices"]))
            assert experiment.metrics(model, valid) == r["validation"]
            assert r["validation"]["ce"] == min(h["validation_ce"] for h in r["history"])
            if "candidate_validation_results" in r:
                assert r["validation"]["ce"] == min(v["validation"]["ce"] for v in r["candidate_validation_results"])
                assert len(r["candidate_validation_results"]) == len(c["learning_rates"])
            if r["arm"] != "dense":
                relation = experiment.Constraints(train[1], c)
                assert len(relation.i) == len(train[1])*(len(train[1])-1)//2
                with torch.no_grad():
                    z = model(train[0])[1]
                    assert relation.measure(z) == r["train_geometry"]
                    assert z.norm(dim=1).max() <= 1.000001
                    # Independent direct matrix calculation of every pair violation.
                    d = (z[:, None, :]-z[None, :, :]).square().sum(-1)
                    same = train[1][:, None] == train[1][None, :]
                    residuals = torch.where(same, d-c["close_radius"]**2, c["separate_radius"]**2-d)
                    assert torch.equal(relation.violations(z), residuals[relation.i, relation.j])
            if stage == "adaptation":
                model.load_state_dict(verify_checkpoint(root, r["final_checkpoint"]))
                checked += 1
                assert experiment.metrics(model, test, c["old_classes"]) == r["final_test"]
    # Verify constraints have finite, nonzero gradients on an unsatisfied example.
    z = torch.tensor([[1.,0.,0.],[0.,1.,0.],[1.,0.,0.]], requires_grad=True)
    relation = experiment.Constraints(torch.tensor([0,0,1]), c)
    relation.penalty(relation.violations(z)).backward()
    assert torch.isfinite(z.grad).all() and z.grad.norm() > 0
    supplement = root/"full-replay"
    supplement.mkdir(exist_ok=False)
    (supplement/"PROTOCOL.json").write_text(json.dumps({
        "timing": "Added after primary results; no changes to training settings or checkpoint-selection rules",
        "purpose": "Adapt with all old and new training examples and all their pairwise constraints present",
        "config": c, "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    }, indent=2))
    extra = []
    for initial in results["pretrain"]:
        seed, arm = initial["seed"], initial["arm"]
        (train, valid, test), _ = prepared[seed]
        model, best, final, row = experiment.fit(arm, seed, initial["learning_rate"], c,
                                               train, valid, c["adapt_steps"], verify_checkpoint(root, initial["checkpoint"]))
        row["test"] = experiment.metrics(model, test, c["old_classes"])
        row["before_test"] = initial["test"]
        row["forgetting"] = initial["test"]["old_accuracy"]-row["test"]["old_accuracy"]
        row["checkpoint"] = experiment.save_checkpoint(supplement, f"full-replay-{seed}-{arm}", best)
        model.load_state_dict(final)
        row["final_test"] = experiment.metrics(model, test, c["old_classes"])
        row["final_checkpoint"] = experiment.save_checkpoint(supplement, f"full-replay-final-{seed}-{arm}", final)
        row["rehearsal_per_old_class"] = c["train_per_class"]
        for receipt, expected_metrics in ((row["checkpoint"], row["test"]), (row["final_checkpoint"], row["final_test"])):
            restored = experiment.make_model(arm, seed, c)
            restored.load_state_dict(verify_checkpoint(supplement, receipt))
            assert experiment.metrics(restored, test, c["old_classes"]) == expected_metrics
        extra.append(row)
        print(json.dumps({"stage":"full_replay", "seed":seed, "arm":arm, "test":row["test"]}), flush=True)
    (supplement/"RESULT.json").write_text(json.dumps(extra, indent=2, allow_nan=False))
    audit = {"primary_checkpoints_verified":checked, "full_replay_checkpoints_verified":2*len(extra),
             "source_and_data_hashes_verified":True, "exact_validation_and_test_reproduction":True,
             "equal_rehearsal_verified":True, "all_pairs_verified":True, "unit_norm_verified":True,
             "constraint_gradient_verified":True, "selection_uses_validation_only":True}
    (root/"VERIFICATION.json").write_text(json.dumps(audit, indent=2))
    print(json.dumps(audit), flush=True)


if __name__ == "__main__":
    main()
