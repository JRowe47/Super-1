# Larger geometric function-weight comparison

State-dependent overlapping rotations remain the strongest tested mechanism in this 66K-parameter pilot. They beat fixed rotations, input-only generated rotations and the matched-parameter Transformer in all three seeds on the predeclared reserved validation region. Input-only rotations also beat fixed rotations and Transformer in all seeds, but do not improve on state-dependent geometry.

| Arm | Parameters | Mean byte CE | Mean BPC |
| --- | ---: | ---: | ---: |
| State-dependent geometric rotations | 66,432 | 1.804931 | 2.603965 |
| Input-only generated rotations | 66,432 | 1.814243 | 2.617400 |
| Fixed overlapping rotations | 66,304 | 1.864358 | 2.689699 |
| Transformer | 66,426 | 1.971527 | 2.844312 |

Geometry improves mean CE by approximately 8.45% versus Transformer, 3.19% versus fixed rotations, and 0.51% versus input-only generation. These are relative differences of means, not statistical significance estimates or evidence of SOTA.

| Seed | Geometry CE | Input-only CE | Fixed CE | Transformer CE |
| --- | ---: | ---: | ---: | ---: |
| 2503 | 1.800252 | 1.818740 | 1.861855 | 2.027508 |
| 2551 | 1.805222 | 1.812736 | 1.868904 | 1.942942 |
| 2609 | 1.809318 | 1.811254 | 1.862314 | 1.944130 |

## Verification and fairness

All 24 trials completed successfully: three seeds, four arms, and the same two learning rates per arm. Each trial trained for 3,000 steps, batch four, context 128, and 1,536,000 target-byte exposures. Training windows are identical per seed across arms. Selection uses only the initial 16,384-byte validation region; best training step and learning rate were frozen before confirmation.

The verifier checked complete trial coverage, training-source hashes, every candidate checkpoint hash, history-based best-step scores, frozen canonical learning-rate selection and model parameter counts. All twelve frozen checkpoints were evaluated twice in FP32 on 65,536 validation bytes starting at 917,504. Duplicate drift was zero. Detailed hashes and scores are in RESULT.json; sealed data/source hashes are in the training PROTOCOL.json and confirmation hashes are in the confirmation PROTOCOL.json. Both training and confirmation exited successfully.

Parameters, training targets and learning-rate tuning budgets are matched closely. FLOPs are not matched. State resets at each 128-token window, unlike the separate contiguous original-hierarchy experiment. This candidate is not the original learned-gate cross-scale hierarchy. Do not compare absolute CE against results from other validation regions or convert byte BPC into word-level perplexity.

## Deployment evidence limits

A separate streaming adapter audit used the first completed low-learning-rate input-only checkpoint, not these frozen winners. It verified numerical full-forward/incremental parity and measured 512 persistent state bytes versus 71,680 projected KV bytes at context 128: 140 times less state, but only 21.1% less weights-plus-state tensor storage. It measured slower Python CPU decoding for input-only rotations under concurrent training. That is not a latency measurement for the selected geometric winner and is not a GPU or peak-memory result. Temporary activations and allocator/runtime overhead were excluded.

## Decision

Preserve state-dependent geometry as the leading phase-mechanism candidate for the next larger and better-matched evaluation. Do not replace it with the input-only variant solely for its fixed-input contraction property: this test shows an accuracy cost in every seed. The bound does not itself prove deployable robustness, and this experiment does not prove why the variant loses.

This extends the promising smaller geometric pilot to newly trained, larger models on a distinct reserved region. It is still a small local byte-level study, not an official benchmark win, established research novelty, or a publication-grade SOTA claim. The original hierarchy remains a separate promising baseline. Official test data was not read. Zero cloud resources were created.
