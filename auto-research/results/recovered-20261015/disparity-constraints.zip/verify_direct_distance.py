"""Audit frozen pilot and exercise compact checkpoints in fresh processes.

Run: python3 experiments/disparity_constraints/verify_direct_distance.py RUN_DIR
Child inputs are a deployment checkpoint and raw queries, never a teacher table.
"""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time

import torch
from torch.nn import functional as F
import direct_distance as experiment


def vectorized(model, x):
    """Generate all class distances together; trades working memory for latency."""
    n, k = len(x), len(model.anchors)
    left = x[:, None, :].expand(n, k, -1)
    right = model.anchors[None, :, :].expand(n, k, -1)
    return -model.log_scale.exp()*model.distance(left, right)


def child(directory):
    c = json.loads((directory/'config.json').read_text())
    torch.set_num_threads(c['threads'])
    # This directory deliberately contains no teacher, labels, or training data.
    assert {p.name for p in directory.iterdir()} == {'config.json', 'model.pt', 'queries.pt'}
    state = torch.load(directory/'model.pt', weights_only=True)
    x = torch.load(directory/'queries.pt', weights_only=True)
    is_generator = 'anchors' in state
    if is_generator:
        assert set(state) == {'anchors', 'log_scale', 'pair.0.weight', 'pair.0.bias',
                              'pair.2.weight', 'pair.2.bias', 'pair.4.weight', 'pair.4.bias'}
        model = experiment.Generator(c, torch.zeros(c['classes'], c['input_dim']))
    else:
        assert set(state) == {'net.0.weight', 'net.0.bias', 'net.2.weight', 'net.2.bias'}
        model = experiment.Dense(c, sum(v.numel() for v in state.values()))
    model.load_state_dict(state)
    with torch.inference_mode():
        reference = model(x)
        streamed = model.stream(x, c['query_chunk']) if is_generator else reference.argmax(-1)
        batched = vectorized(model, x) if is_generator else reference
        assert torch.equal(streamed, reference.argmax(-1))
        assert torch.equal(streamed, batched.argmax(-1))
        modes = {}
        calls = [('streaming', lambda: model.stream(x[:1], 1)),
                 ('vectorized', lambda: vectorized(model, x[:1]).argmax(-1))] if is_generator else [
                 ('dense', lambda: model(x[:1]).argmax(-1))]
        for mode, call in calls:
            for _ in range(10):
                call()
            durations = []
            for _ in range(c['benchmark_repeats']):
                start = time.perf_counter_ns()
                call()
                durations.append((time.perf_counter_ns()-start)/1000)
            # Export actual allocator events, avoiding double-counting nested ops.
            from torch.profiler import profile, ProfilerActivity
            with profile(activities=[ProfilerActivity.CPU], profile_memory=True) as prof:
                call()
            import tempfile
            with tempfile.TemporaryDirectory() as temp:
                trace = Path(temp)/'trace.json'
                prof.export_chrome_trace(str(trace))
                events = json.loads(trace.read_text())['traceEvents']
            allocations = [e for e in events if e.get('name') == '[memory]' and 'Bytes' in e.get('args', {})]
            live, peak = 0, 0
            for event in sorted(allocations, key=lambda e: e['ts']):
                live += event['args']['Bytes']
                peak = max(peak, live)
            assert allocations, 'Missing allocator events'
            modes[mode] = {'median_single_query_us': statistics.median(durations),
                           'incremental_tensor_peak_bytes': peak,
                           'allocation_event_count': len(allocations)}
        print(json.dumps({'stored_scalars': experiment.scalars(model),
                          'checkpoint_file_bytes': (directory/'model.pt').stat().st_size,
                          'predictions_sha256': hashlib.sha256(streamed.numpy().tobytes()).hexdigest(),
                          'max_vectorized_logit_difference': (batched-reference).abs().max().item(),
                          'modes': modes, 'table_loaded': False,
                          'memory_scope': 'Actual CPU tensor allocation events for one query, excludes model storage, Python/runtime, allocator reserve and RSS.'}))


def main(directory):
    p = json.loads((directory/'PROTOCOL.json').read_text())
    c = p['config']
    torch.set_num_threads(c['threads'])
    assert experiment.sha(directory/'source.py') == p['source_sha256']
    candidates = json.loads((directory/'CANDIDATES.json').read_text())
    rows = json.loads((directory/'RESULT.json').read_text())
    freeze = json.loads((directory/'FREEZE.json').read_text())
    for r in candidates:
        assert experiment.sha(directory/r['checkpoint']) == r['sha256']
    checks = []
    for r, frozen in zip(rows, freeze):
        assert r['sha256'] == frozen['sha256']
        assert r['validation']['ce'] == min(q['validation']['ce'] for q in candidates
                                          if q['seed'] == r['seed'] and q['arm'] == r['arm'])
        (train, valid, test), _ = experiment.datasets(r['seed'], c)
        anchors = torch.zeros(c['classes'], c['input_dim'])
        model = experiment.make(r['arm'], r['seed'], c, anchors)
        state = torch.load(directory/r['checkpoint'], weights_only=True)
        model.load_state_dict(state)
        assert experiment.scalars(model)*4 == r['deployed_tensor_bytes']
        assert experiment.measurements(model, valid) == r['validation']
        assert experiment.measurements(model, test) == r['test']
        deploy = directory/f"deploy-audit2-{r['seed']}-{r['arm']}"
        if deploy.exists():
            assert json.loads((deploy/'config.json').read_text()) == c
            assert experiment.sha(deploy/'model.pt') == r['sha256']
            assert torch.equal(torch.load(deploy/'queries.pt', weights_only=True), test[0])
        else:
            deploy.mkdir(exist_ok=False)
            (deploy/'config.json').write_text(json.dumps(c, indent=2))
            # Keep original checkpoint bytes and hash intact, not reserialized.
            (deploy/'model.pt').write_bytes((directory/r['checkpoint']).read_bytes())
            torch.save(test[0], deploy/'queries.pt')
        completed = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                                    '--child', str(deploy.resolve())], capture_output=True, text=True, check=True)
        result = json.loads(completed.stdout)
        with torch.inference_mode():
            reference = model(test[0]).argmax(-1)
            if isinstance(model, experiment.Generator):
                i, j = torch.triu_indices(len(test[0]), len(test[0]), offset=1)
                same = test[1][i] == test[1][j]
                distances = torch.cat([model.distance(test[0][a], test[0][b])
                    for a, b in zip(i.split(4096), j.split(4096))])
                satisfied = torch.where(same, distances <= c['close_distance']+1e-5,
                                        distances >= c['far_distance']-1e-5)
                result['heldout_relation_audit'] = {
                    'pairs': len(distances), 'satisfied_fraction': satisfied.float().mean().item(),
                    'same_mean_distance': distances[same].mean().item(),
                    'different_mean_distance': distances[~same].mean().item()}
        assert hashlib.sha256(reference.numpy().tobytes()).hexdigest() == result['predictions_sha256']
        checks.append({'seed': r['seed'], 'arm': r['arm'], **result})
    audit = {'checkpoints_verified': len(candidates), 'frozen_winners_reproduced': len(rows),
             'fresh_process_deployments': checks, 'test_tuning': False,
             'verifier_sha256': experiment.sha(Path(__file__)),
             'clarification': 'One distance output per streaming evaluation, not one total live scalar; best-so-far, intermediates and pair-function activations also occupy memory. Allocator traces here supersede the training script leaf-event memory estimate.'}
    (directory/'VERIFICATION-v2.json').write_text(json.dumps(audit, indent=2))
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=Path)
    parser.add_argument('--child', action='store_true')
    args = parser.parse_args()
    (child if args.child else main)(args.directory)
