# Original hierarchy: contiguous-stream geometric-transport ablation

This is a local byte-level WikiText pilot, not a word-level SOTA result or novelty claim. The official test was not read.

## Confirmed result

| Arm | Mean byte CE | Mean BPC |
|---|---:|---:|
| Original hierarchy | 1.655564 | 2.388474 |
| Fixed cross-scale transport | 1.661265 | 2.396698 |
| State/input-conditioned geometric transport | 1.662196 | 2.398041 |
| Transformer | 1.730256 | 2.496231 |

The original hierarchy has 4.32% lower mean CE than this Transformer and wins in all three seeds. The geometric extension loses to fixed transport in every seed and to the original hierarchy in two seeds. It is not promoted as an architectural improvement.

| Seed | Original | Fixed transport | Geometry | Transformer |
|---|---:|---:|---:|---:|
| 2503 | 1.646189 | 1.644296 | 1.644479 | 1.690183 |
| 2551 | 1.659792 | 1.674492 | 1.677024 | 1.740950 |
| 2609 | 1.660711 | 1.665005 | 1.665084 | 1.759634 |

## Contract and limits

Three seeds; two learning rates per arm; 3,000 optimizer updates; batch eight; 64-token BPTT; 1,536,000 target-byte exposures per trial. Parameters: original 52,861; fixed transport 52,987; geometry 53,113; Transformer 52,768. All arms use identical contiguous training targets per seed and equal learning-rate search counts.

The exact original learned gates, nonlinear update, mean-state coupling and learned scales are retained. Hierarchy state is carried between contiguous chunks and detached after each optimizer step. The Transformer scores each new 64-token chunk with up to 64 preceding tokens (128-token maximum window). Both start without prior text.

Parameters, target exposure and tuning counts are matched; effective history and FLOPs are **not** matched. The result therefore supports a local streaming-architecture comparison, not an isolated geometry advantage, general Transformer superiority, or equal-compute claim. Byte CE cannot be compared to published word-level perplexity. Only one task and small parameter scale are covered.

Validation-only checkpoint and learning-rate selection used a separate region. All 24 candidate checkpoint hashes, recorded best steps, selection scores, frozen selections and source hashes were checked before confirmation. Twelve frozen checkpoints were evaluated twice in FP32 on 65,536 reserved validation target bytes starting at byte 524,288. State begins fresh at that region's start and carries across chunks; Transformer prefix remains inside the region. Duplicate drift was zero for every checkpoint.

## Evidence and reproduction

Training: `../original-transport-stream-20261001-v1/PROTOCOL.json`, `CANDIDATES.json`, `FREEZE.json`, checkpoints and `COMPLETION.json`.

Confirmation: `PROTOCOL.json`, `RESULT.json`, `SUMMARY.json`, `COMPLETION.json`. These receipts contain source/checkpoint/data hashes and per-seed metrics.

From the repository root, reproduce training into a fresh output directory:

```sh
python3 experiments/disparity_constraints/run_original_transport_stream.py --config experiments/disparity_constraints/original-transport-stream-20261001-v1.json --output experiments/disparity_constraints/original-transport-stream-reproduction
python3 experiments/disparity_constraints/confirm_original_transport_stream.py --source experiments/disparity_constraints/original-transport-stream-reproduction --output experiments/disparity_constraints/original-transport-stream-reproduction-validation --bytes 65536
```

The configured local WikiText train/validation files and existing PyTorch environment are required. No cloud resources were created. The original word-level validation gates are not crossed by this byte experiment; the official test remains sealed.
