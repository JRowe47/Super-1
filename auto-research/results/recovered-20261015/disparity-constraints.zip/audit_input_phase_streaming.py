"""Incremental adapter audit, separate from accuracy/promotion authority."""
import argparse
import json
import statistics
import time
from pathlib import Path

import torch
import audit_phase_streaming as streaming
import run_input_generated_phase as experiment


def input_phase_step(model, token, state):
    embedded = model.embedding(token)
    drive = torch.tanh(model.drive(embedded))
    retention = torch.sigmoid(model.write(embedded)+model.retention)
    if state is None:
        state = torch.zeros_like(drive)
    for angle, gain, offset in [(model.angle, model.gain, 0), (model.second_angle, model.second_gain, 1)]:
        theta = model.angle_for(state, drive, angle, gain, offset)
        state = experiment.generated.source.rotate(state, theta, offset)
    state = retention*state+(1-retention)*drive
    return model.norm(state)@model.embedding.weight.T, state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--arms', nargs='+', choices=['input_generated_overlapping', 'geometric_overlapping', 'transformer'], required=True)
    parser.add_argument('--all-seeds', action='store_true')
    parser.add_argument('--repeats', type=int, required=True)
    parser.add_argument('--warmups', type=int, required=True)
    parser.add_argument('--parity-atol', type=float, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.repeats > 0 and args.warmups >= 0 and args.parity_atol > 0
    pilot = experiment.runner.pilot
    sha = pilot.shared.prior.sha
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    for path, digest in protocol['checks']['source_hashes'].items():
        assert sha(Path(path)) == digest
    assert sha(Path(pilot.__file__)) == protocol['source_sha256']
    candidate_file = args.source/('FREEZE.json' if (args.source/'FREEZE.json').exists() else 'CANDIDATES.json')
    candidates = json.loads(candidate_file.read_text())
    if args.all_seeds:
        assert candidate_file.name == 'FREEZE.json', 'All-seed audit requires frozen selection'
        chosen = [row for row in candidates if row['arm'] in args.arms]
        assert len(chosen) == len(config_seeds := protocol['config']['seeds'])*len(args.arms)
        assert {(row['seed'], row['arm']) for row in chosen} == {(seed, arm) for seed in config_seeds for arm in args.arms}
    else:
        chosen = [next(row for row in candidates if row['arm']==arm) for arm in args.arms]
    config = protocol['config']
    pilot.C.update(config)
    torch.set_num_threads(config['threads'])
    makes, _, _ = experiment.builders(config)
    torch.manual_seed(config['seeds'][0])
    tokens = torch.randint(256, (1, config['context']))
    rows = []
    with torch.inference_mode():
        for row in chosen:
            path = args.source/Path(row['checkpoint']).name
            assert sha(path) == row['sha256']
            model = makes[row['arm']]().float().eval()
            model.load_state_dict(torch.load(path, weights_only=True))
            step = streaming.transformer_step if row['arm']=='transformer' else input_phase_step
            reference = model(tokens)
            actual, state = streaming.stream(model, tokens, step)
            error = (reference-actual).abs().max().item()
            assert torch.allclose(reference, actual, atol=args.parity_atol, rtol=args.parity_atol), error
            for _ in range(args.warmups):
                streaming.stream(model, tokens, step)
            timings = []
            for _ in range(args.repeats):
                begin = time.perf_counter()
                streaming.stream(model, tokens, step)
                timings.append(time.perf_counter()-begin)
            weights = sum(parameter.numel()*parameter.element_size() for parameter in model.parameters())
            persistent = streaming.bytes_of(state)
            rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                         'streaming_parity_max_error': error, 'weight_tensor_bytes': weights,
                         'persistent_state_bytes': persistent, 'weight_plus_state_bytes': weights+persistent,
                         'context': config['context'], 'batch': 1, 'precision': 'FP32',
                         'cpu_median_microseconds_per_token': statistics.median(timings)*1e6/config['context']})
            assert sha(path) == row['sha256']
    args.output.mkdir()
    result = {'rows': rows, 'candidate_file': candidate_file.name,
              'selection_scope': ('All frozen seeds for requested arms; not new accuracy confirmation.' if args.all_seeds else
                                  'First listed completed checkpoint per requested arm; not canonical sweep ranking or accuracy confirmation.'),
              'timing_scope': 'Batch-one CPU incremental decoding of synthetic tokens, concurrent training contention. No GPU or peak-memory claim.',
              'memory_scope': 'Actual parameter and persistent tensor bytes; excludes temporaries, allocator overhead and runtime. State compression is not equal to total deployment compression.',
              'parity_atol': args.parity_atol, 'repeats': args.repeats, 'warmups': args.warmups,
              'accuracy_evaluated': False, 'validation_read': False, 'official_test_read': False,
              'source_checkpoints_unchanged': True, 'source_sha256': {str(Path(path).resolve()): sha(Path(path))
                  for path in [__file__, streaming.__file__, experiment.__file__, experiment.generated.__file__]}}
    (args.output/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
