"""Reserved-region, duplicate-FP32 confirmation of a completed native run."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

import torch
import run_original_transport_stream as runner


def inspect_selection(source, protocol, completed, frozen):
    """Require the complete declared sweep and reproduce its selection rule."""
    config = protocol['config']
    candidates = json.loads((source/'CANDIDATES.json').read_text())
    expected = {(seed, arm, lr) for seed in config['seeds']
                for arm in protocol['arms'] for lr in config['lrs']}
    assert len(candidates) == len(expected) == completed['candidates']
    assert {(row['seed'], row['arm'], row['lr']) for row in candidates} == expected
    assert len(frozen) == len(config['seeds'])*len(protocol['arms'])
    assert {(row['seed'], row['arm']) for row in frozen} == {(s, a) for s in config['seeds'] for a in protocol['arms']}
    for row in candidates:
        assert runner.shared.shared.prior.sha(source/Path(row['checkpoint']).name) == row['sha256']
        best = min(row['history'], key=lambda score: score['ce'])
        assert row['best_step'] == best['step']
        assert row['validation'] == {key: value for key, value in best.items() if key != 'step'}, 'Selection score drift'
    for row in frozen:
        choices = [trial for trial in candidates if (trial['seed'], trial['arm']) == (row['seed'], row['arm'])]
        assert row == min(choices, key=lambda trial: trial['validation']['ce']), 'Frozen checkpoint selection drift'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bytes', type=int, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and args.bytes > 0
    protocol = json.loads((args.source/'PROTOCOL.json').read_text())
    completed = json.loads((args.source/'COMPLETION.json').read_text())
    frozen = json.loads((args.source/'FREEZE.json').read_text())
    config = protocol['config']
    expected = {(seed, arm) for seed in config['seeds'] for arm in protocol['arms']}
    assert len(frozen) == len(expected)
    assert {(r['seed'], r['arm']) for r in frozen} == expected
    assert completed['candidates'] == len(expected)*len(config['lrs'])
    assert completed['official_test_read'] is False
    inspect_selection(args.source, protocol, completed, frozen)
    sha = runner.shared.shared.prior.sha
    files = {
        'runner_sha256': Path(runner.__file__),
        'transport_sha256': Path(runner.transport.__file__),
        'authoritative_wrapper_sha256': runner.transport.SOURCE,
        'authoritative_core_sha256': runner.transport.authoritative.AUTHORITATIVE_MULTISCALE_PATH,
        'authoritative_transformer_sha256': runner.transport.authoritative.AUTHORITATIVE_TRANSFORMER_PATH,
    }
    for field, path in files.items():
        assert sha(path) == protocol[field], field
    start = config['reserved_confirmation_start']
    assert start > config['selection_start']+config['selection_bytes']
    assert args.bytes % config['context'] == 0
    torch.set_num_threads(config['threads'])
    torch.use_deterministic_algorithms(True)
    raw = (runner.shared.DATA/'valid.txt').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == protocol['data_sha256']['valid']
    assert start+args.bytes < len(raw)
    valid = torch.tensor(list(raw), dtype=torch.long)
    args.output.mkdir()
    runner.shared.shared.write(args.output/'PROTOCOL.json', {
        'source_protocol_sha256': sha(args.source/'PROTOCOL.json'),
        'source_freeze_sha256': sha(args.source/'FREEZE.json'),
        'confirmation_source_sha256': sha(Path(__file__)),
        'validation_start': start, 'scored_bytes': args.bytes, 'precision': 'FP32',
        'duplicates': 2, 'state_contract': 'Fresh state at region start, carry across contiguous chunks; Transformer prefix stays inside this region.',
        'official_test_read': False, 'official_test_eligible': False,
    })
    rows = []
    for row in frozen:
        checkpoint = args.source/Path(row['checkpoint']).name
        assert sha(checkpoint) == row['sha256']
        model = runner.make_model(row['arm'], config).float().eval()
        model.load_state_dict(torch.load(checkpoint, weights_only=True))
        assert runner.shared.count(model) == protocol['parameters'][row['arm']]
        assert all(p.dtype == torch.float32 for p in model.parameters())
        first = runner.evaluate(model, row['arm'], valid, config, start, args.bytes)
        second = runner.evaluate(model, row['arm'], valid, config, start, args.bytes)
        assert first == second, 'Duplicate FP32 drift forbids confirmation'
        rows.append({'seed': row['seed'], 'arm': row['arm'], 'sha256': row['sha256'],
                     'validation': first, 'duplicate_drift': 0})
        runner.shared.shared.write(args.output/'RESULT.json', rows)
        print(json.dumps({'confirmed': len(rows), 'total': len(frozen), **rows[-1]}), flush=True)
    groups = [{'arm': arm, 'ce': statistics.mean(r['validation']['ce'] for r in rows if r['arm']==arm),
               'bpc': statistics.mean(r['validation']['bpc'] for r in rows if r['arm']==arm)} for arm in protocol['arms']]
    pairs = []
    for seed in config['seeds']:
        scores = {r['arm']: r['validation']['ce'] for r in rows if r['seed']==seed}
        pairs.append({'seed': seed,
                      'geometry_minus_original_ce': scores['geometric_transport']-scores['original'],
                      'geometry_minus_fixed_transport_ce': scores['geometric_transport']-scores['fixed_transport'],
                      'geometry_minus_transformer_ce': scores['geometric_transport']-scores['transformer']})
    runner.shared.shared.write(args.output/'SUMMARY.json', {
        'groups': groups, 'pairs': pairs, 'duplicate_drift': 0,
        'geometry_beats_both_hierarchy_controls_all_seeds': all(p['geometry_minus_original_ce']<0 and p['geometry_minus_fixed_transport_ce']<0 for p in pairs),
        'official_test_read': False, 'official_test_eligible': False,
    })
    runner.shared.shared.write(args.output/'COMPLETION.json', {'checkpoints': len(rows), 'duplicate_drift': 0,
                                                            'official_test_read': False, 'cloud_resources_created': 0})


if __name__ == '__main__':
    main()
