"""Render confirmed three-seed benchmark scores, without new evaluation."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--training-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--candidate-arm', choices=['geometric_overlapping', 'relative_phase_key', 'pair_energy'], default='geometric_overlapping')
    args = parser.parse_args()
    assert not args.output.exists()
    completed = json.loads((args.source/'COMPLETION.json').read_text())
    assert completed['checkpoints'] == 12 and completed['duplicate_drift'] == 0
    rows = json.loads((args.source/'RESULT.json').read_text())
    assert len(rows) == 12 and all(row['duplicate_drift'] == 0 for row in rows)
    confirmation = json.loads((args.source/'PROTOCOL.json').read_text())
    training_path = args.training_source/'PROTOCOL.json'
    assert hashlib.sha256(training_path.read_bytes()).hexdigest() == confirmation['source_protocol_sha256']
    training = json.loads(training_path.read_text())
    keyed = args.candidate_arm == 'relative_phase_key'
    energy = args.candidate_arm == 'pair_energy'
    arms = ['pair_energy', 'geometric_overlapping', 'relative_phase_key', 'transformer'] if energy else (([args.candidate_arm, 'geometric_overlapping'] if keyed else
            ['geometric_overlapping', 'input_generated_overlapping']) + ['fixed_overlapping', 'transformer']
            )
    labels = ['Pair-energy\nquery', 'Existing\ngeometry', 'Learned phase\nkeys', 'Transformer'] if energy else ((['Learned phase\nkeys', 'Existing\ngeometry'] if keyed else
              ['State-dependent\ngeometry', 'Input-only\nrotations']) + ['Fixed\nrotations', 'Transformer'])
    seeds = sorted({row['seed'] for row in rows})
    assert len(seeds) == 3
    assert all(sum(row['seed'] == seed and row['arm'] == arm for row in rows) == 1
               for seed in seeds for arm in arms)
    byte_counts = {row['validation']['scored_bytes'] for row in rows}
    assert byte_counts == {confirmation['scored_bytes']}
    scores = np.array([[next(row['validation']['ce'] for row in rows if row['seed']==seed and row['arm']==arm)
                        for arm in arms] for seed in seeds])
    colors = ['#256b62', '#719e97', '#9ba5b2', '#c17353']
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11, 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.titleweight': 'bold'})
    fig, axes = plt.subplots(1, 2, figsize=(12, 6), gridspec_kw={'width_ratios': [1.2, 1]})
    fig.patch.set_facecolor('#f8f6f1')
    for ax in axes:
        ax.set_facecolor('#f8f6f1')
    means = scores.mean(0)
    axes[0].bar(range(4), means, color=colors, width=.65)
    for index in range(4):
        axes[0].scatter(np.arange(3)*.08+index-.08, scores[:, index], s=28,
                        color='#182733', edgecolors='white', linewidths=.7, zorder=3)
        axes[0].text(index, scores[:, index].max()+.04, f'{means[index]:.4f}', ha='center', fontweight='bold')
    axes[0].set_xticks(range(4), labels)
    axes[0].set_ylim(0, scores.max()*1.15)
    axes[0].set_ylabel('Reserved-validation byte CE (lower is better)')
    axes[0].set_title('Mean cross-entropy, with all three seeds', loc='left', pad=18)
    axes[0].grid(axis='y', alpha=.15)
    axes[0].set_axisbelow(True)
    reductions = (means[1:]-means[0])/means[1:]*100
    axes[1].barh(range(3), reductions, color=colors[1:], height=.55)
    axes[1].set_yticks(range(3), ['vs existing geometry', 'vs phase keys', 'vs Transformer'] if energy else ['vs existing geometry' if keyed else 'vs input-only', 'vs fixed', 'vs Transformer'])
    margin = max(float(np.abs(reductions).max())*.22, .2)
    axes[1].set_xlim(min(0, reductions.min())-margin, max(0, reductions.max())+margin)
    axes[1].axvline(0, color='#182733', linewidth=.7)
    for index, value in enumerate(reductions):
        axes[1].text(value+margin*.08, index, f'{value:.2f}%', va='center', fontweight='bold')
    axes[1].set_xlabel('Relative reduction in mean CE (%)')
    axes[1].set_title('Pair-energy advantage' if energy else ('Phase-key advantage' if keyed else 'State-dependent geometry advantage'), loc='left', pad=18)
    axes[1].grid(axis='x', alpha=.15)
    axes[1].set_axisbelow(True)
    all_wins = bool(np.all(scores[:, :1] < scores[:, 1:]))
    fig.suptitle('Geometric function weights: confirmed local comparison', x=.05, ha='left', fontsize=19, fontweight='bold')
    counts = [training['parameters'][arm] for arm in arms]
    fig.text(.05, .885, f'{min(counts):,}–{max(counts):,} parameters | {len(seeds)} seeds | {confirmation["scored_bytes"]:,} reserved bytes | duplicate FP32 drift: zero', fontsize=11)
    outcome = 'Candidate wins every control in every seed.' if all_wins else 'Candidate does not win every control in every seed.'
    fig.text(.05, .07, outcome+' Equal target/LR budgets; parameters closely matched, FLOPs not matched.', fontsize=10)
    fig.text(.05, .035, 'Small byte-level pilot—not SOTA, established novelty, or official-test evidence. No total-memory or GPU-latency claim.', fontsize=10, color='#7b4a35')
    fig.subplots_adjust(left=.08, right=.97, bottom=.25, top=.79, wspace=.48)
    fig.savefig(args.output, dpi=180, facecolor=fig.get_facecolor())
    plt.close(fig)
    receipt = {'source_result_sha256': hashlib.sha256((args.source/'RESULT.json').read_bytes()).hexdigest(),
               'source_protocol_sha256': confirmation['source_protocol_sha256'],
               'candidate_wins_every_control_every_seed': all_wins,
               'chart_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
               'source_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'accuracy_evaluation_performed': False, 'official_test_read': False}
    args.output.with_suffix('.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
