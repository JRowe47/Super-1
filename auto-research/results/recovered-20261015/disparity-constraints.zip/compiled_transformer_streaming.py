"""Exact one-layer projected-KV adapter for the existing TinyTransformer."""
import copy
from typing import Tuple

import torch
from torch import nn
from torch.nn import functional as F


class TransformerStep(nn.Module):
    __constants__ = ['heads']

    def __init__(self, model):
        super().__init__()
        self.embedding = copy.deepcopy(model.embedding)
        self.block = copy.deepcopy(model.block)
        self.norm = copy.deepcopy(model.norm)
        self.position = nn.Parameter(model.position.detach().clone(), requires_grad=False)
        self.heads = model.block.self_attn.num_heads

    def forward(self, token: torch.Tensor, state: Tuple[torch.Tensor, torch.Tensor]) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        embedded = self.embedding(token)+self.position[state[0].shape[-2]]
        normalized = self.block.norm1(embedded)
        q, k, v = F.linear(normalized, self.block.self_attn.in_proj_weight, self.block.self_attn.in_proj_bias).chunk(3, -1)
        q = q.reshape(token.shape[0], self.heads, 1, -1)
        k = k.reshape(token.shape[0], self.heads, 1, -1)
        v = v.reshape(token.shape[0], self.heads, 1, -1)
        k, v = torch.cat((state[0], k), -2), torch.cat((state[1], v), -2)
        attended = F.scaled_dot_product_attention(q, k, v).reshape(token.shape[0], -1)
        hidden = embedded+self.block.self_attn.out_proj(attended)
        hidden = hidden+self.block.linear2(self.block.activation(self.block.linear1(self.block.norm2(hidden))))
        return self.norm(hidden)@self.embedding.weight.T, (k, v)


def stream(step, tokens, width, heads):
    cache = torch.empty((len(tokens), heads, 0, width//heads), dtype=torch.float32)
    state = (cache, cache)
    outputs = []
    for index in range(tokens.shape[1]):
        logits, state = step(tokens[:, index], state)
        outputs.append(logits)
    return torch.stack(outputs, 1), state
