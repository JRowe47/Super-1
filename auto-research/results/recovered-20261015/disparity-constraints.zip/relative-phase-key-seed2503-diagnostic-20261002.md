# Preliminary phase-key diagnostic — seed 2503 only

Read-only checkpoint inspection; no validation or test evaluation, training change, or promotion.

At learning rate 0.003, phase keys improved selection CE through step 2,500 (1.8537979722 versus geometry 1.8587815054), but finished slightly worse at step 3,000 (1.8375011273 versus 1.8373312242). Both arms selected step 3,000. At learning rate 0.001, keyed selection CE was 1.9871725291 versus geometry 1.9913798235. Learning-rate selection must not be replaced by cherry-picking the favorable 0.001 comparison.

All 128 keys in each completed keyed checkpoint are finite and nonzero. For learning rate 0.003, the first/second banks have mean absolute key angles 0.2572658658 / 0.2930567861 radians and maximum absolute angles 0.8816423416 / 0.8374117017. For learning rate 0.001, means are 0.1871868223 / 0.1921472251 and maxima 0.5521393418 / 0.7699526548.

Checkpoint hashes were verified against CANDIDATES.json:

- LR 0.001: `4d06efc5f230c2effdb06e0f694c7dba6b845b18263922ca97a1ab3d6ebe974c`
- LR 0.003: `ac21693889ff7d4dc19a2aa6180db471ca34c658601310915f934574a62aba36`

This rules out keys simply remaining at their zero initialization in these checkpoints. It does not establish causal usefulness, generalization improvement, failure of the mechanism across seeds, or novelty. Complete the sealed sweep, freeze selection, and run the predeclared duplicate FP32 confirmation before deciding.
