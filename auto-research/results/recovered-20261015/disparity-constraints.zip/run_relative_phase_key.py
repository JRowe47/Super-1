"""Controlled phase-key extension; inherited training protocol unchanged."""
from pathlib import Path
import hashlib

import run_overlapping_phase as runner
import relative_phase_key_candidate as keyed

original_builders = runner.builders
original_checks = runner.candidate.checks


def builders(config):
    makes, width, ff = original_builders(config)
    makes['relative_phase_key'] = lambda: keyed.RelativePhaseKeyLM(config['width'])
    return {name: makes[name] for name in config['arms']}, width, ff


def checks():
    return {'overlapping_checks': original_checks(), 'relative_phase_key_checks': keyed.checks(),
            'source_hashes': {str(Path(path).resolve()): hashlib.sha256(Path(path).read_bytes()).hexdigest()
                              for path in [__file__, keyed.__file__]},
            'hypothesis': 'Learned relative-phase keys distinguish alignment from antiparallel alignment and improve on normalized-cross-only queries.',
            'limitation': 'Not the original hierarchy; FLOPs, novelty and SOTA are not established.'}


if __name__ == '__main__':
    runner.builders = builders
    runner.candidate.checks = checks
    runner.main()
