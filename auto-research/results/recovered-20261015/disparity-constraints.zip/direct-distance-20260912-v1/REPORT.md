# Direct-distance compression pilot

Synthetic concept classification, not language modeling or SOTA.

Full results include all candidates, frozen selections, hashes and training-only tables. Deployments contain only compact model tensors and (for distance models) eight raw exemplars. No table is retained in the deployment.

| Arm | Mean held-out CE | Accuracy | Deployed tensor bytes | Median query us (seed mean) |
|---|---:|---:|---:|---:|
| dense | 0.000199 | 100.0000% | 5832 | 7.76 |
| direct | 0.000022 | 100.0000% | 5832 | 252.06 |
| distilled | 0.000012 | 100.0000% | 5832 | 249.31 |

Training uses 256 examples, validation 128 and test 512 per seed with disjoint nuisance-style sets. Selection uses validation only. This is reused synthetic task design, not independent real-world evidence.

The distilled generator additionally sees a large label-trained relational table. The direct generator is the identical deployed architecture trained with classification CE only. Dense matches all deployed FP32 tensor bytes including the exemplars. Training computation and inference latency are not matched.

Distances are generated directly, but the compact generator is still parameterized by ordinary neural-network weights. Compression does not create extra independent bits. Symmetry, positivity and zero self-distance are architectural; triangle inequalities are not guaranteed. Teacher training accuracy is transductive memorization, not generalization.

Latency is CPU single-query Python execution, not an optimized GPU prediction. Tensor-memory profiling excludes runtime/allocator overhead. No language-model or SOTA conclusion follows.

## Verified deployment and inference tradeoff

`VERIFICATION-v2.json` independently checks all 18 checkpoint hashes and reproduces
the nine validation-selected models' scores. Nine fresh child processes load
only compact checkpoints and query fixtures, with no training table or labels.
Three mechanism unit tests pass. Batched-class and streaming predictions agree;
the vectorized implementation also matched the reference logits exactly on
these held-out queries. No retraining or test-based model selection was done.

| Implementation | Deployed FP32 tensor bytes | Incremental query tensor peak bytes | Mean single-query median, microseconds |
|---|---:|---:|---:|
| Dense classifier | 5,832 | 464 | 8.53 |
| Distilled distances, streaming | 5,832 | 405 | 246.54 |
| Distilled distances, vectorized over classes | 5,832 | 3,108 | 45.11 |

These peaks come from actual CPU allocation/free events and supersede the
training script's leaf-event estimate. They exclude model storage, Python,
runtime, allocator reserve and total RSS. One generated distance per streaming
call does **not** mean one total live scalar: activation and best-so-far storage
are included in the allocation audit. Vectorization reduces latency about 5.5x
versus streaming but remains about 5.3x slower than the dense classifier here.
Checkpoint files are 8,345 bytes for dense and 9,497 for distilled due to
serialization overhead; the exact match is deployed tensor storage, not files.

## What survived compression

Each teacher directly learned 32,640 independent off-diagonal distances and
materialized a 256-by-256 FP32 table (262,144 bytes). Deployment stores 1,330
trainable generator scalars and 128 raw-exemplar scalars (5,832 bytes total),
not that table. The three distilled generators reconstruct the training tables
with mean distance RMSE **0.036424**. This is approximate compression of a
structured, label-trained table, not lossless storage of arbitrary distances.

Across all 130,816 unordered held-out pairs per seed, mean close/far constraint
satisfaction is **92.3269%** after distillation versus **75.7759%** for the
identical generator trained without the table. Both already classify every
held-out example correctly. Thus the table improves relational structure on this
task, but does not enforce every unseen relationship. One sampled triangle out
of 4,096 violates the inequality for the distilled seed-89 model; these outputs
are learned dissimilarities, not proven global metrics.

All three designs reach 100% held-out accuracy. The lower CE therefore measures
confidence on already-correct predictions, not an accuracy or capacity gain.
Distilled models also learn larger logit scales (17.67–21.09 versus 14.66–15.25
without distillation), so calibration is a possible contributor to the tiny CE
differences. The strong result is mechanism feasibility and approximate
relational compression; superiority on difficult prediction tasks remains open.

Code and reproduction instructions: `../DIRECT_DISTANCE_README.md`.
