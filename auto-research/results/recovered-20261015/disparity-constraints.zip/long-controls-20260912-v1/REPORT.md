# Longer training and temperature controls

Validation only. Shared nanoGPT encoder, context 32, width 48, two layers; 4,000 updates / 512,000 target bytes per candidate. Three seeds, two peak learning rates, warmup and cosine decay in every arm. Same initialized encoder tensors and windows. Learned temperature adds one trainable scalar; fixed arms also store one scale scalar. FLOPs are not matched. No official test access.

The linear-temperature head calibrates ordinary dot-product logits. Cosine-temperature calibrates normalized distance logits. Constrained cosine-temperature adds the prior byte-label penalty. The temperature-calibrated cosine arms isolate the penalty effect.

| Arm | Mean assessment CE | Mean BPC | Mean selected-run seconds |
|---|---:|---:|---:|
| linear_fixed | 1.876524 | 2.707251 | 6.71 |
| linear_temperature | 1.871395 | 2.699852 | 6.71 |
| cosine_fixed | 1.838822 | 2.652860 | 6.90 |
| cosine_temperature | 1.839542 | 2.653898 | 7.03 |
| constrained_cosine_temperature | 1.868348 | 2.695456 | 12.04 |

| Seed | Arm | Peak LR | Selected step | Assessment CE | Scale |
|---:|---|---:|---:|---:|---:|
| 17 | linear_fixed | 0.003 | 4000 | 1.877204 | 1.000 |
| 17 | linear_temperature | 0.003 | 4000 | 1.875461 | 1.343 |
| 17 | cosine_fixed | 0.003 | 4000 | 1.849842 | 20.000 |
| 17 | cosine_temperature | 0.003 | 4000 | 1.844649 | 13.840 |
| 17 | constrained_cosine_temperature | 0.003 | 4000 | 1.874756 | 15.191 |
| 43 | linear_fixed | 0.003 | 4000 | 1.875693 | 1.000 |
| 43 | linear_temperature | 0.003 | 4000 | 1.872252 | 1.360 |
| 43 | cosine_fixed | 0.003 | 4000 | 1.839600 | 20.000 |
| 43 | cosine_temperature | 0.003 | 4000 | 1.837760 | 13.560 |
| 43 | constrained_cosine_temperature | 0.003 | 4000 | 1.864489 | 15.360 |
| 89 | linear_fixed | 0.003 | 4000 | 1.876673 | 1.000 |
| 89 | linear_temperature | 0.003 | 4000 | 1.866470 | 1.343 |
| 89 | cosine_fixed | 0.003 | 4000 | 1.827025 | 20.000 |
| 89 | cosine_temperature | 0.003 | 4000 | 1.836217 | 14.316 |
| 89 | constrained_cosine_temperature | 0.003 | 4000 | 1.865797 | 15.157 |

Assessment uses a previously unused 32,768-byte middle region of validation, distinct from the prefix used for selection and suffix used in the pilot. It is not a new independent dataset. This evaluates bytes of word-preprocessed WikiText-2, not word-level perplexity. Convergence is not presumed; histories record the last-step trend. Checkpoint hashes, exact selection reproduction and duplicate assessment were checked. No post-assessment tuning.
