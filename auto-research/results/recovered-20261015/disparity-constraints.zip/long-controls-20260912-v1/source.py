"""Longer fixed-budget, validation-only head ablations. No official-test access."""
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time
import argparse
import torch
from torch import nn
from torch.nn import functional as F
import nanogpt_compare as pilot

ARMS=('linear_fixed','linear_temperature','cosine_fixed','cosine_temperature','constrained_cosine_temperature')


class Head(nn.Module):
    def __init__(self,weight,arm):
        super().__init__()
        self.weight=weight
        self.normalized='cosine' in arm
        self.initial_scale=20. if self.normalized else 1.
        self.log_scale=nn.Parameter(torch.tensor(math.log(self.initial_scale)),requires_grad='temperature' in arm)
        self.hidden=None

    def forward(self,x):
        self.hidden=F.normalize(x,dim=-1)
        logits=self.hidden @ F.normalize(self.weight,dim=-1).T if self.normalized else x @ self.weight.T
        return self.log_scale.exp()*logits


def make(module,c,seed,arm):
    model=pilot.make(module,c,seed,'nanogpt')
    model.lm_head=Head(model.lm_head.weight,arm)
    return model


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    c=json.loads(Path(__file__).with_name('nanogpt_config.json').read_text())
    c.update(steps=4000,validation_interval=500,warmup_steps=100,minimum_lr_ratio=.1,
             assessment_start=262144,assessment_bytes=32768)
    torch.set_num_threads(c['threads']);torch.use_deterministic_algorithms(True)
    assert hashlib.sha256(Path(c['nanogpt_source']).read_bytes()).hexdigest()==c['nanogpt_sha256']
    spec=importlib.util.spec_from_file_location('pinned_nanogpt',c['nanogpt_source'])
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    train_bytes=(Path(c['data_root'])/'train.txt').read_bytes()
    valid_bytes=(Path(c['data_root'])/'valid.txt').read_bytes()
    train=torch.tensor(list(train_bytes),dtype=torch.long)
    selection=torch.tensor(list(valid_bytes[:c['selection_bytes']+1]),dtype=torch.long)
    start=c['assessment_start'];end=start+c['assessment_bytes']+1
    assert end<len(valid_bytes)-32769 and start>c['selection_bytes']+1
    assessment=torch.tensor(list(valid_bytes[start:end]),dtype=torch.long)
    out=args.output;out.mkdir(exist_ok=False)
    protocol={'config':c,'arms':ARMS,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'pilot_source_sha256':hashlib.sha256(Path(pilot.__file__).read_bytes()).hexdigest(),
      'train_sha256':hashlib.sha256(train_bytes).hexdigest(),'valid_sha256':hashlib.sha256(valid_bytes).hexdigest(),
      'device':'cpu','torch':torch.__version__,'official_test_opened':False,
      'selection':'lowest prefix validation CE across checkpoint and equal two-LR search',
      'assessment':'previously unused middle validation region; all candidates complete before assessment; developmental evidence, not independent dataset',
      'schedule':'100-step warmup then cosine decay to 0.1 of peak LR; 4000 steps / 512000 targets per candidate',
      'matching':'same encoder initialization, token windows, steps and LR search; 70464 trainable weights plus one head scale (fixed or learned); not FLOP matched',
      'constraints':'same/different next byte, same fixed penalty as pilot; batchwise only; not semantic supervision',
      'convergence':'fixed 10x pilot budget; inspect final validation trend, no convergence guarantee'}
    models=[make(module,c,17,a) for a in ARMS]
    reference=pilot.make(module,c,17,'nanogpt')
    with torch.no_grad():
        x=train[:c['context']].reshape(1,-1)
        base=reference(x,x)[0]
        assert torch.equal(base,models[0](x,x)[0])
        assert torch.equal(base,models[1](x,x)[0])
        assert torch.equal(models[2](x,x)[0],models[3](x,x)[0])
        assert torch.equal(models[3](x,x)[0],models[4](x,x)[0])
    for m in models:
        assert all(torch.equal(v,m.state_dict()[k]) for k,v in reference.state_dict().items())
    protocol['counts']={a:{'stored_scalars':sum(p.numel() for p in m.parameters()),'trainable_scalars':sum(p.numel() for p in m.parameters() if p.requires_grad)} for a,m in zip(ARMS,models)}
    protocol['initial_equivalence_verified']=True
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2));(out/'source.py').write_text(Path(__file__).read_text())
    del models,reference
    records=[]
    for seed in c['seeds']:
      for arm in ARMS:
       for peak in c['learning_rates']:
        model=make(module,c,seed,arm)
        # Scale is calibrated through CE, excluded from weight decay in every arm.
        params=[p for n,p in model.named_parameters() if n!='lm_head.log_scale']
        opt=torch.optim.AdamW([{'params':params,'weight_decay':c['weight_decay']},
                              {'params':[model.lm_head.log_scale],'weight_decay':0.}],lr=peak)
        rng=torch.Generator().manual_seed(seed+10000)
        best_ce=float('inf');best=None;history=[];started=time.perf_counter()
        for step in range(1,c['steps']+1):
            if step<=c['warmup_steps']:factor=step/c['warmup_steps']
            else:
                phase=(step-c['warmup_steps'])/(c['steps']-c['warmup_steps'])
                factor=c['minimum_lr_ratio']+(1-c['minimum_lr_ratio'])*.5*(1+math.cos(math.pi*phase))
            for g in opt.param_groups:g['lr']=peak*factor
            model.train();opt.zero_grad(set_to_none=True)
            indices=torch.randint(len(train)-c['context']-1,(c['batch_size'],),generator=rng)
            positions=indices[:,None]+torch.arange(c['context'])[None,:]
            x,y=train[positions],train[positions+1]
            _,ce=model(x,y);loss=ce
            if arm.startswith('constrained'):
                penalty,geometry=pilot.pairs(model.lm_head.hidden,y,c);loss=loss+c['penalty']*penalty
            assert torch.isfinite(loss)
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),c['clip']);opt.step()
            if step%c['validation_interval']==0:
                score=pilot.evaluation(model,selection,c['context'])['ce']
                row={'step':step,'selection_ce':score,'scale':float(model.lm_head.log_scale.detach().exp()),'elapsed_seconds':time.perf_counter()-started}
                if arm.startswith('constrained'):row['last_batch_geometry']=geometry
                history.append(row)
                if score<best_ce:best_ce=score;best=copy.deepcopy(model.state_dict());best_step=step
        path=out/f'{seed}-{arm}-{peak}.pt';torch.save(best,path)
        r={'seed':seed,'arm':arm,'peak_lr':peak,'selection_ce':best_ce,'best_step':best_step,'history':history,
           'seconds':time.perf_counter()-started,'checkpoint':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        records.append(r);(out/'CANDIDATES.json').write_text(json.dumps(records,indent=2))
        print(json.dumps({k:v for k,v in r.items() if k!='history'}),flush=True)
    winners=[]
    for seed in c['seeds']:
      for arm in ARMS:
        r=min((r for r in records if r['seed']==seed and r['arm']==arm),key=lambda r:r['selection_ce'])
        path=out/r['checkpoint'];assert hashlib.sha256(path.read_bytes()).hexdigest()==r['sha256']
        model=make(module,c,seed,arm);model.load_state_dict(torch.load(path,weights_only=True))
        assert pilot.evaluation(model,selection,c['context'])['ce']==r['selection_ce']
        score=pilot.evaluation(model,assessment,c['context'])
        assert score==pilot.evaluation(model,assessment,c['context'])
        winners.append({**r,'assessment':score})
    (out/'RESULT.json').write_text(json.dumps(winners,indent=2))
    lines=['# Longer training and temperature controls','',
        'Validation only. Shared nanoGPT encoder, context 32, width 48, two layers; 4,000 updates / 512,000 target bytes per candidate. Three seeds, two peak learning rates, warmup and cosine decay in every arm. Same initialized encoder tensors and windows. Learned temperature adds one trainable scalar; fixed arms also store one scale scalar. FLOPs are not matched. No official test access.', '',
        'The linear-temperature head calibrates ordinary dot-product logits. Cosine-temperature calibrates normalized distance logits. Constrained cosine-temperature adds the prior byte-label penalty. The temperature-calibrated cosine arms isolate the penalty effect.', '',
        '| Arm | Mean assessment CE | Mean BPC | Mean selected-run seconds |','|---|---:|---:|---:|']
    for arm in ARMS:
        rows=[r for r in winners if r['arm']==arm]
        lines.append(f"| {arm} | {sum(r['assessment']['ce'] for r in rows)/3:.6f} | {sum(r['assessment']['bpc'] for r in rows)/3:.6f} | {sum(r['seconds'] for r in rows)/3:.2f} |")
    lines+=['','| Seed | Arm | Peak LR | Selected step | Assessment CE | Scale |','|---:|---|---:|---:|---:|---:|']
    for r in winners:
        scale=next(h['scale'] for h in r['history'] if h['step']==r['best_step'])
        lines.append(f"| {r['seed']} | {r['arm']} | {r['peak_lr']} | {r['best_step']} | {r['assessment']['ce']:.6f} | {scale:.3f} |")
    lines+=['','Assessment uses a previously unused 32,768-byte middle region of validation, distinct from the prefix used for selection and suffix used in the pilot. It is not a new independent dataset. This evaluates bytes of word-preprocessed WikiText-2, not word-level perplexity. Convergence is not presumed; histories record the last-step trend. Checkpoint hashes, exact selection reproduction and duplicate assessment were checked. No post-assessment tuning.']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    os.environ.setdefault('MPLCONFIGDIR',str(Path('/private/tmp/disparity-long-mpl')))
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4))
    for arm in ARMS:
        rows=[r for r in winners if r['arm']==arm]
        ys=[sum(r['history'][i]['selection_ce'] for r in rows)/3 for i in range(len(rows[0]['history']))]
        axes[0].plot([h['step'] for h in rows[0]['history']],ys,label=arm)
        axes[1].plot([sum(r['history'][i]['elapsed_seconds'] for r in rows)/3 for i in range(len(ys))],ys,label=arm)
    for ax in axes:ax.set_ylabel('Selection validation CE');ax.grid(alpha=.2)
    axes[0].set_xlabel('Training steps (128 targets each)');axes[1].set_xlabel('CPU elapsed seconds (includes validation)')
    axes[0].legend(fontsize=7);fig.tight_layout();fig.savefig(out/'progress.png',dpi=160)
    (out/'COMPLETION.json').write_text(json.dumps({'candidates':len(records),'winners':len(winners),'official_test_opened':False,'duplicate_assessment_drift':0,'cloud_resources_created':0},indent=2))


if __name__=='__main__':main()
