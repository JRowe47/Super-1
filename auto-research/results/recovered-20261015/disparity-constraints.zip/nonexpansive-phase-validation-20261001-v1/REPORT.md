# Stability-cap ablation: confirmed accuracy tradeoff

This is a local byte-level WikiText experiment, not word-level perplexity, SOTA, a novelty proof or a test of the original hierarchy. The official test remains sealed.

| Arm | Mean byte CE | Mean BPC |
|---|---:|---:|
| Fixed overlapping rotations | 1.954338 | 2.819513 |
| Unconstrained geometric overlapping rotations | 1.909135 | 2.754299 |
| Bounded geometric overlapping rotations | 1.956524 | 2.822668 |
| Transformer | 1.984887 | 2.863587 |

The bounded variant loses to unconstrained geometry in all three seeds and to fixed rotations in two seeds. Its mean CE is worse than the fixed control. It beats this Transformer in all seeds, but that alone does not establish a benefit from its geometric function: the fixed control also beats this Transformer. Do not promote the bounded variant as an accuracy improvement.

The unconstrained geometric control again wins against fixed rotations and the Transformer in every seed on this additional reserved validation region. These are the same control checkpoint hashes as the earlier experiment, so this is an additional-region check, not a new independent training-seed replication.

## Experimental contract

Three seeds (2503, 2551, 2609); two learning rates per arm; 3,000 updates; batch eight; 64-token reset windows; 1,536,000 target-byte exposures per trial. Parameters: fixed 24,960; both geometric variants 25,024; Transformer 25,053. Training windows and target exposure per seed and tuning counts match; FLOPs do not.

All 24 trials completed. All 18 matching control trials reproduced the earlier histories, selected steps, validation scores and checkpoint hashes exactly. Every candidate hash and source hash was checked, and frozen checkpoint selection was reconstructed from validation histories before evaluation.

Twelve frozen checkpoints were evaluated twice in FP32 on 65,536 reserved validation target bytes beginning at byte 786,432, outside the selection region. Every duplicate comparison had zero drift. No cloud resources or official test data were used.

## Interpretation

The gain cap guarantees a conservative fixed-input state-sensitivity bound for this successor model. It does not guarantee accuracy, output/input/parameter sensitivity, or a corresponding bound for the original state-gated hierarchy. The 200-case FP64 sensitivity audit passed, but the training experiment shows that this constraint did not retain the useful accuracy gain here.

The separate gain-budget diagnostic found most gains of the earlier unconstrained checkpoints outside the sufficient bound. That suggested the constraint might be restrictive; it did not itself prove the accuracy outcome or establish that local expansion is necessary for every successful design.

The next active experiment tests input-generated angles at a larger scale without clamping their gain. It is a different hypothesis and is not yet validated.

## Evidence and reproduction

Source training receipts: `../nonexpansive-phase-20261001-v1/PROTOCOL.json`, `CANDIDATES.json`, `FREEZE.json`, checkpoints and `COMPLETION.json`.

Confirmation receipts: `PROTOCOL.json`, `RESULT.json`, `SUMMARY.json`, `COMPLETION.json`.

Control replay: `../nonexpansive-control-replay-audit-20261001-v2/RESULT.json`.

```sh
python3 experiments/disparity_constraints/run_nonexpansive_phase.py --config experiments/disparity_constraints/nonexpansive-phase-20261001-v1.json --output experiments/disparity_constraints/nonexpansive-phase-reproduction
python3 experiments/disparity_constraints/confirm_nonexpansive_phase.py --source experiments/disparity_constraints/nonexpansive-phase-reproduction --output experiments/disparity_constraints/nonexpansive-phase-reproduction-validation --windows 1024
```

Use fresh output paths, the configured local train/validation files and the existing PyTorch environment. Earlier reports and checkpoints are preserved.
