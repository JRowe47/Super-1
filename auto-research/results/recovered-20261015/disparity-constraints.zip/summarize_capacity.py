"""Audit and summarize a completed predeclared sweep without further training."""
import argparse
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import statistics

import numpy as np
from scipy.stats import t as student_t
import torch
import capacity_sweep as sweep


def mean(values):
    return statistics.mean(values)


def interval(values, alpha):
    m = mean(values)
    if len(values) < 2:
        return [m, m]
    radius = float(student_t.ppf(1-alpha/2, len(values)-1))*statistics.stdev(values)/math.sqrt(len(values))
    return [m-radius, m+radius]


def main(out):
    protocol = json.loads((out/'PROTOCOL.json').read_text())
    c = protocol['config']
    assert sweep.prior.sha(out/'source.py') == protocol['source_sha256']
    assert sweep.prior.sha(Path(sweep.prior.__file__)) == protocol['distance_table_source_sha256']
    assert sweep.prior.sha(Path(sweep.__file__)) == protocol['source_sha256']
    completed = json.loads((out/'COMPLETION.json').read_text())
    rows = json.loads((out/'RESULT.json').read_text())
    frozen = json.loads((out/'FREEZE.json').read_text())
    baselines = json.loads((out/'BASELINE_FREEZE.json').read_text())
    expected = len(c['tasks'])*len(c['seeds'])*len(c['scalar_budgets'])*len(c['arms'])
    assert len(rows) == len(frozen) == completed['selected'] == expected
    frozen_hashes = {r['checkpoint']:r['sha256'] for r in frozen}
    candidates = []
    for path in out.glob('*/CANDIDATES.json'):
        candidates.extend(json.loads(path.read_text()))
    assert len(candidates) == expected*len(c['learning_rates'])
    for r in candidates:
        path = Path(r['checkpoint'])
        assert sweep.prior.sha(path) == r['sha256']
        state = torch.load(path, weights_only=True)
        assert sum(v.numel()*v.element_size() for v in state.values()) == r['deployed_tensor_bytes']
        assert r['deployed_tensor_bytes'] <= r['budget_scalars']*4
        assert not any('aux' in k or 'matrix' in k for k in state)
    grouped = collections.defaultdict(list)
    for r in candidates:
        grouped[(r['task'], r['seed'], r['budget_scalars'], r['arm'])].append(r)
    for r in rows:
        assert r['sha256'] == frozen_hashes[r['checkpoint']]
        choices = grouped[(r['task'], r['seed'], r['budget_scalars'], r['arm'])]
        assert r['validation']['ce'] == min(v['validation']['ce'] for v in choices)
    index = {(r['task'],r['seed'],r['budget_scalars'],r['arm']):r for r in rows}
    baseline_index = {}
    for b in baselines:
        choices = [r for r in frozen if r['task'] == b['task'] and r['seed'] == b['seed'] and
                   r['budget_scalars'] == b['budget_scalars'] and
                   r['arm'] in ('dense','dense_teacher','coordinates_teacher')]
        assert b['sha256'] == min(choices,key=lambda r:r['validation']['ce'])['sha256']
        baseline_index[(b['task'], b['seed'], b['budget_scalars'])] = index[(b['task'],b['seed'],b['budget_scalars'],b['arm'])]
    comparisons = []
    pairs = [(a,b) for a in c['scalar_budgets'] for b in c['scalar_budgets'] if a <= b]
    family_n = len(c['tasks'])*len(pairs)
    alpha = (1-c['criteria']['confidence_level'])/family_n
    for task in c['tasks']:
        for student_budget, baseline_budget in pairs:
            dist = [index[(task,s,student_budget,'distilled')] for s in c['seeds']]
            base = [baseline_index[(task,s,baseline_budget)] for s in c['seeds']]
            differences = [d['test']['accuracy']-b['test']['accuracy'] for d,b in zip(dist,base)]
            bounds = interval(differences, alpha)
            weights_ratio = mean(d['deployed_tensor_bytes'] for d in dist)/mean(b['deployed_tensor_bytes'] for b in base)
            modes = []
            for mode in ('inference','streaming'):
                latency_ratio = mean(d[mode]['median_single_query_us'] for d in dist)/mean(b['inference']['median_single_query_us'] for b in base)
                total_ratio = mean(d['deployed_tensor_bytes']+d[mode]['incremental_cpu_tensor_peak_bytes'] for d in dist)/mean(
                    b['deployed_tensor_bytes']+b['inference']['incremental_cpu_tensor_peak_bytes'] for b in base)
                latency_ok = latency_ratio <= c['criteria']['maximum_latency_ratio']
                memory_ok = total_ratio <= c['criteria']['maximum_equal_memory_ratio']
                if student_budget == baseline_budget:
                    accuracy_ok = bounds[0] >= c['criteria']['material_accuracy_gain']
                    storage_ok = weights_ratio <= c['criteria']['maximum_equal_memory_ratio']
                else:
                    accuracy_ok = bounds[0] >= -c['criteria']['comparable_accuracy_tolerance']
                    storage_ok = weights_ratio <= c['criteria']['maximum_memory_ratio_for_savings']
                modes.append({'mode': mode, 'latency_ratio': latency_ratio, 'total_tensor_memory_ratio': total_ratio,
                              'accuracy_ok': accuracy_ok, 'storage_ok': storage_ok, 'memory_ok': memory_ok,
                              'latency_ok': latency_ok, 'passes_screen': bool(accuracy_ok and storage_ok and memory_ok and latency_ok)})
            comparisons.append({'task': task, 'student_budget_scalars': student_budget,
                'baseline_budget_scalars': baseline_budget, 'comparison': 'accuracy_gain' if student_budget==baseline_budget else 'storage_savings',
                'mean_accuracy_difference': mean(differences), 'paired_accuracy_differences': differences,
                'simultaneous_interval': bounds, 'deployed_tensor_ratio': weights_ratio,
                'baseline_arms': [b['arm'] for b in base], 'modes': modes})
    aggregates = []
    for task in c['tasks']:
        for cap in c['scalar_budgets']:
            for arm in c['arms']:
                group = [index[(task,s,cap,arm)] for s in c['seeds']]
                aggregates.append({'task':task,'cap':cap,'arm':arm,
                    'accuracy':mean(r['test']['accuracy'] for r in group),
                    'accuracy_interval':interval([r['test']['accuracy'] for r in group],1-c['criteria']['confidence_level']),
                    'ce':mean(r['test']['ce'] for r in group),
                    'deployed_bytes':mean(r['deployed_tensor_bytes'] for r in group),
                    'latency_us':mean(r['inference']['median_single_query_us'] for r in group),
                    'incremental_tensor_peak_bytes':mean(r['inference']['incremental_cpu_tensor_peak_bytes'] for r in group),
                    'best_step_mean':mean(r['best_step'] for r in group)})
    passes = [(r['task'], r['student_budget_scalars'], r['baseline_budget_scalars'], m['mode']) for r in comparisons for m in r['modes'] if m['passes_screen']]
    same_cap = {(r['task'],r['student_budget_scalars']):r for r in comparisons if r['comparison']=='accuracy_gain'}
    frontier_passes = []
    for r in comparisons:
        same = same_cap[(r['task'],r['student_budget_scalars'])]
        distinguished = r['comparison']=='accuracy_gain' or same['simultaneous_interval'][0] > c['criteria']['comparable_accuracy_tolerance']
        r['frontier_distinguished'] = bool(distinguished)
        for m in r['modes']:
            if m['passes_screen'] and distinguished:
                frontier_passes.append((r['task'],r['student_budget_scalars'],r['baseline_budget_scalars'],m['mode']))
    summary = {'checkpoint_hashes_verified':len(candidates),'selected_models_verified':len(rows),
               'criteria':c['criteria'],'accuracy_comparison_family':family_n,
               'comparisons':comparisons,'aggregates':aggregates,'screen_passes':passes,
               'frontier_qualified_passes':frontier_passes,
               'confidence_caveat':'Paired t intervals over five seeds, Bonferroni across predeclared accuracy comparisons. Digits splits overlap; intervals are exploratory seed/split variation, not an independent population guarantee.',
               'source_sha256':sweep.prior.sha(Path(__file__))}
    sweep.write(out/'SUMMARY.json',summary)
    lines = ['# Direct-distance inference capacity sweep','',
             f"Completed {len(candidates)} training candidates; {len(rows)} validation-selected checkpoints; {len(c['seeds'])} seeds, {len(c['scalar_budgets'])} storage caps and {len(c['tasks'])} task conditions. No cloud resources.",'',
             f"**Predeclared joint accuracy/storage/latency screening passes: {len(passes)} deployment comparisons; distinct frontier-qualified passes: {len(frontier_passes)}.** A screening pass is not a breakthrough claim. See every comparison in SUMMARY.json.",'',
             '## Protocol and controls','',
             'Teacher arms all receive the same label-trained table, class-logit targets and sampled pair-distance targets. Dense-teacher uses a training-only auxiliary relational head discarded before deployment. Coordinates-teacher compresses relationships into embeddings. Direct and distilled share an identical scalar pair-function architecture; distilled gets additional teacher supervision. Dense and dense-teacher share identical deployed architecture and initialization. All dense models also learn logit scale.','',
             'Storage caps are 8, 16 and 32 KiB of deployed FP32 tensors, including exemplars/prototypes and scale. Actual sizes differ slightly because architectures are selected without dummy padding. Every arm uses the same 1,000-update schedule, input batches, two-LR search and validation checkpoints. Training FLOPs differ; this is a fixed-budget comparison, not convergence proof.','',
             'The reference baseline for each task/seed/cap is selected by validation CE among dense, dense-teacher and coordinates-teacher, before test access. No reference selection uses test results. All candidates and baselines are globally frozen before evaluation.','',
             '## Held-out quality and deployment costs','',
             '| Task | Cap KiB | Arm | Accuracy | CE | Actual tensor bytes | Query us | Incremental tensor peak bytes |',
             '|---|---:|---|---:|---:|---:|---:|---:|']
    for a in aggregates:
        lines.append(f"| {a['task']} | {a['cap']*4/1024:.0f} | {a['arm']} | {a['accuracy']:.2%} | {a['ce']:.4f} | {a['deployed_bytes']:.0f} | {a['latency_us']:.2f} | {a['incremental_tensor_peak_bytes']:.0f} |")
    lines += ['', '## Predeclared claim checks','',
              'Comparable accuracy: simultaneous lower bound no worse than -1 percentage point, at most half the actual deployed tensor bytes. Material accuracy gain: simultaneous lower bound at least +3 percentage points at the same storage cap. Both require mean latency at most 2x baseline and total model-plus-query tensor memory at most 1.05x baseline. These are proposed engineering thresholds, not universal scientific definitions.','',
              f"The {family_n} accuracy comparisons use paired t intervals across five seeds, Bonferroni-adjusted for a 95% family confidence level. Timing/working-memory comparisons are engineering measurements, not confidence bounds. Two deployment modes share the same accuracy comparison.",'',
              'A secondary frontier guard avoids calling half-storage matches against oversized baselines distinct advantages when a same-cap baseline already matches accuracy. It requires the existing simultaneous same-cap interval to show the student ahead by more than the one-point equivalence tolerance. Audit correction: ANALYSIS_PROTOCOL.json was created nine seconds after global checkpoint freeze, so this guard is post hoc, not preregistered. It was added before inspecting held-out scores, but assessment had started. The original predeclared screen is reported unchanged.', '',
              '| Task | Student cap KiB | Baseline cap KiB | Mean accuracy difference pp | Adjusted interval pp | Tensor storage ratio | Vectorized latency ratio | Vectorized total tensor ratio | Pass in any mode |',
              '|---|---:|---:|---:|---|---:|---:|---:|---|']
    for r in comparisons:
        mode=r['modes'][0]
        lines.append(f"| {r['task']} | {r['student_budget_scalars']/256:.0f} | {r['baseline_budget_scalars']/256:.0f} | {r['mean_accuracy_difference']*100:+.2f} | [{r['simultaneous_interval'][0]*100:+.2f}, {r['simultaneous_interval'][1]*100:+.2f}] | {r['deployed_tensor_ratio']:.3f} | {mode['latency_ratio']:.2f} | {mode['total_tensor_memory_ratio']:.2f} | {any(m['passes_screen'] for m in r['modes'])} |")
    lines += ['', '## Boundaries','',
              '- Context8 and context32 are related synthetic conditions, not independent task families; context8 extends the earlier pilot. Digits is a small real handwritten-digit task, not MNIST or a language-model benchmark.',
              '- Digits is deduplicated before stratified splitting. Train/validation/test input hashes are checked for overlap. Different seeds reuse the same underlying digits dataset, so uncertainty describes split/seed variation and is exploratory.',
              '- Test inference has no teacher or auxiliary head in the model state. Runtime profiling measures actual CPU tensor allocation/free events; it excludes Python/runtime memory, allocator reserve and total RSS. Checkpoint serialization overhead is reported separately in RESULT.json.',
              '- Current implementations are CPU PyTorch canaries, not optimized deployment kernels. Both throughput and batching can alter latency; these are single-query measurements.',
              '- Direct distances do not imply a globally valid metric. Compression does not add independent information bits. Richer supervision and ordinary distillation are controlled but finite tuning budgets cannot establish optimality.',
              '- All selected validation scores are reproduced, held-out scores duplicate-confirmed, and checkpoint bytes verified. There is no post-test training or hyperparameter adjustment.']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    os.environ.setdefault('MPLCONFIGDIR','/private/tmp/disparity-capacity-mpl')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2,len(c['tasks']),figsize=(14,8))
    colors = dict(zip(c['arms'],plt.get_cmap('tab10').colors))
    for col, task in enumerate(c['tasks']):
        for arm in c['arms']:
            points=[a for a in aggregates if a['task']==task and a['arm']==arm]
            acc=[a['accuracy']*100 for a in points]
            axes[0,col].plot([a['deployed_bytes']/1024 for a in points],acc,'o-',color=colors[arm],label=arm)
            axes[1,col].plot([a['latency_us'] for a in points],acc,'o-',color=colors[arm])
        axes[0,col].set_title(task)
        axes[0,col].set_xlabel('Deployed tensors (KiB)')
        axes[1,col].set_xlabel('Single-query CPU latency (microseconds)')
        axes[1,col].set_xscale('log')
        for ax in axes[:,col]:
            ax.set_ylabel('Held-out accuracy (%)')
            ax.grid(alpha=.25)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=len(c['arms']),fontsize=9)
    fig.suptitle('Direct-distance capacity sweep: five-seed means, fixed training budget')
    fig.tight_layout(rect=(0,.06,1,.95))
    fig.savefig(out/'capacity.png',dpi=160)
    print(json.dumps({'screen_passes':passes,'report':str(out/'REPORT.md'),'chart':str(out/'capacity.png')},indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    main(parser.parse_args().output)
