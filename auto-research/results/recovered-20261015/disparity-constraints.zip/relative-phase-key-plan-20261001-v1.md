# Relative-phase key mechanism test

Hypothesis: learned reference phases permit a relative geometry query to distinguish aligned and antiparallel state/input pairs. The prior normalized-cross query maps both exact cases to zero. This expressive distinction is proven by the canary, but no accuracy advantage follows automatically.

Initialize both reference keys to zero, exactly preserving the prior geometric model's forward function and native gradients. Learn keys jointly with the existing model from fresh initialization. No transfer from a saturated checkpoint. New stored parameters: 128 at width 128.

Run 24 trials: three seeds, two learning rates, and four arms (keyed geometry, existing geometry, fixed overlapping rotations, matched-parameter Transformer). Use the same training-window generator, 3,000 steps, batch four, context 128, 1,536,000 training target-byte exposures and selection region as the completed larger comparison. The unchanged controls should reproduce their earlier checkpoints and selection scores; verify exact replay. Those controls are reused training evidence, not a new independent-seed replication.

Freeze validation-selected steps and learning rates before evaluating the new predeclared reserved region: 65,536 validation bytes starting at 655,360. Evaluate each of twelve frozen checkpoints twice in FP32; forbid promotion on duplicate drift or source/data/checkpoint hash mismatch. Advance the new key mechanism only on consistent improvement over both existing geometry and fixed transport across all three seeds. Winning against Transformer alone cannot establish the contribution of the keys.

Closely matched parameter/token/LR budgets, not matched FLOPs. No official test read, cloud resources, original-hierarchy replacement, global Jacobian-contraction claim, or research-novelty claim. State-dependent rotations preserve state norm for a sampled angle but can still have an expanding state Jacobian. Prior research on phase/orthogonal recurrence prevents claiming generic rotation-based recurrence is new. Novelty review of the specific mechanism remains pending.
