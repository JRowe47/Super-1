# Signed nonlinear geometric-weight pilot

Five seeds; 8 KiB cap; 2,000 updates per candidate. Validation-selected, globally frozen before held-out scoring. Digits is reused development data, not independent confirmation.

| Model | Bytes | CE | Accuracy | Query us | Query tensor bytes |
|---|---:|---:|---:|---:|---:|
| dense | 6880 | 0.07592 | 97.93% | 7.51 | 222 |
| factorized | 8132 | 0.08316 | 97.34% | 8.73 | 336 |
| signed_kernel | 8192 | 0.10619 | 96.74% | 281.56 | 655628 |

All coordinates, kernel parameters and output weights count toward storage. The shared nonlinear kernel can increase matrix rank beyond coordinate dimension; measured ranks are recorded per checkpoint. Blocked inference generates and consumes only 16 rows at a time. Tensor allocations exclude model weights and RSS. Digits is reused development evidence. Equal updates are not convergence proof. Prior kernelized synaptic weight work exists; no novelty or SOTA claim.

Reproduce: python3 experiments/disparity_constraints/signed_kernel_test.py --output NEW_DIRECTORY
