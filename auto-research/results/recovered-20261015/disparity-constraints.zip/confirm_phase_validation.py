"""Frozen phase pilot: duplicate FP32 evaluation on disjoint validation bytes."""
import argparse,json,statistics,math
from pathlib import Path
import torch
import phase_transition_language as pilot

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);assert not args.output.exists()
    pr=json.loads((args.source/'PROTOCOL.json').read_text());assert pilot.shared.prior.sha(Path(pilot.__file__))==pr['source_sha256']
    frozen=json.loads((args.source/'FREEZE.json').read_text())
    pilot.C.update(pr['config']);pilot.C['validation_windows']=1024;pilot.C['validation_start']=16384
    args.output.mkdir()
    pilot.shared.write(args.output/'PROTOCOL.json',{'source_freeze_sha256':pilot.shared.prior.sha(args.source/'FREEZE.json'),'validation_start':pilot.C['validation_start'],'validation_windows':pilot.C['validation_windows'],'bytes':65536,'context':pilot.C['context'],'precision':'FP32','repetitions':2,'selection':'Every original selected model scored; no new model or hyperparameter selection. Disjoint validation continuation, not official test.'})
    raw=(pilot.DATA/'valid.txt').read_bytes()
    import hashlib
    assert hashlib.sha256(raw).hexdigest()==pr['data_sha256']['valid']
    valid=torch.tensor(list(raw),dtype=torch.long);rows=[]
    for r in frozen:
        path=args.source/Path(r['checkpoint']).name;assert pilot.shared.prior.sha(path)==r['sha256']
        if r['arm']=='transformer':m=pilot.TinyTransformer(pr['transformer_width'],pr['transformer_ff_width'])
        else:m=pilot.PhaseLM(pr['config']['width'],r['arm']=='geometric_rotation')
        m.load_state_dict(torch.load(path,weights_only=True));m.eval();a=pilot.evaluate(m,valid);b=pilot.evaluate(m,valid);assert a==b
        rows.append({'seed':r['seed'],'arm':r['arm'],'sha256':r['sha256'],'validation':a,'duplicate_drift':0});pilot.shared.write(args.output/'RESULT.json',rows)
    groups=[{'arm':arm,'ce':statistics.mean(r['validation']['ce'] for r in rows if r['arm']==arm),'bpc':statistics.mean(r['validation']['bpc'] for r in rows if r['arm']==arm)} for arm in pr['config']['arms']]
    pairs=[]
    for seed in pr['config']['seeds']:
        idx={r['arm']:r['validation']['ce'] for r in rows if r['seed']==seed}
        pairs.append({'seed':seed,'geometric_minus_fixed_ce':idx['geometric_rotation']-idx['fixed_rotation'],'geometric_minus_transformer_ce':idx['geometric_rotation']-idx['transformer']})
    pilot.shared.write(args.output/'SUMMARY.json',{'groups':groups,'pairs':pairs,'official_test_read':False,'duplicate_drift':0})
    lines=['# Disjoint WikiText validation confirmation','','Frozen local byte-model pilot, three seeds. Every checkpoint scored twice in FP32 on 65,536 target bytes from a validation region disjoint from selection. No official test read. Models saw only 153,600 training target bytes per trial, so convergence is unproven.','','| Arm | CE | BPC |','|---|---:|---:|']
    for r in groups:lines.append(f"| {r['arm']} | {r['ce']:.6f} | {r['bpc']:.6f} |")
    lines+=['','Per-seed geometry minus fixed-rotation CE (negative favors geometry): '+str([r['geometric_minus_fixed_ce'] for r in pairs]),'','These are byte-level CE/BPC values, not word-level perplexity or evidence of SOTA. The recurrent architecture is an experimental successor, not the original hierarchy. Parameter counts are matched; FLOPs and effective optimization are not.']
    (args.output/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'groups':groups,'pairs':pairs}))

if __name__=='__main__':main()
