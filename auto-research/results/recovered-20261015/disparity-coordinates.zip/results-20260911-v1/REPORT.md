# Learned disparity coordinates: local feasibility test

Synthetic held-out regression; identical data, minibatches, training steps, and shared learning rate. Checkpoints selected using validation only. Frozen controls retain the same stored parameters but train fewer of them.

| Task | Model | Stored / trainable | Mean test MSE | Mean R2 | Mean training seconds |
|---|---|---:|---:|---:|---:|
| smooth_interactions | disparity | 278 / 278 | 0.354854 | 0.6411 | 0.35 |
| smooth_interactions | dense_matched | 281 / 281 | 0.016828 | 0.9830 | 0.16 |
| smooth_interactions | frozen_coordinates | 278 / 107 | 0.414258 | 0.5811 | 0.30 |
| smooth_interactions | frozen_generator | 278 / 196 | 0.413277 | 0.5820 | 0.26 |
| independent_dense_teacher | disparity | 278 / 278 | 0.175846 | 0.8218 | 0.35 |
| independent_dense_teacher | dense_matched | 281 / 281 | 0.048473 | 0.9507 | 0.16 |
| independent_dense_teacher | frozen_coordinates | 278 / 107 | 0.178646 | 0.8188 | 0.29 |
| independent_dense_teacher | frozen_generator | 278 / 196 | 0.309362 | 0.6919 | 0.25 |

The generator evaluates a shared nonlinear function on coordinate differences. Both coordinates and generator coefficients are included in parameter counts. The effective weights are input independent in this first experiment. Pairwise differences are dependent; this does not establish extra independent information capacity. Generating weights adds inference computation; inference timings include this cost. Three seeds are a preliminary comparison, not a broad superiority claim.

Full per-seed results, shift invariance, coordinate changes, ablation errors, timings, and checkpoint hashes are in RESULT.json.

## Interpretation and independent verification

Learning through disparities is feasible in this prototype, but its accuracy is substantially worse than the conventional network: mean test MSE is 0.354854 versus 0.016828 on smooth interactions, and 0.175846 versus 0.048473 on the independent dense teacher. The dense model wins in every seed on both tasks. The full disparity model uses 278 stored/trainable scalars; the parameter-matched dense baseline uses 281 (about 1.1% more). Their widths differ to match parameter counts. This is a matched-step, approximately matched-parameter comparison, not a FLOP-matched or independently tuned comparison.

There is no demonstrated storage compression here: the disparity model generates 216 matrix entries using 278 stored scalars including coordinates, generator coefficients, and biases. Directly storing the same-shaped matrices plus biases would take 241 scalars. The inference implementation regenerates matrices on every call and is about three times slower than the dense baseline in this tiny CPU timing. Because the generated weights are input independent, they could be cached for inference at the cost of storing the expanded matrices.

All 24 primary checkpoint hashes and saved validation/test metrics were independently verified, with exact metric reproduction on CPU. Selection was confirmed to use the minimum recorded validation MSE. See VERIFICATION.json. Every checkpoint was selected before its test evaluation; coordinate shuffling is a subsequent diagnostic, not a selection criterion. Each seed uses a different independent dataset/teacher draw shared by all arms, so variation across seeds includes task-instance variation.

## Additional coordinate-only control

After seeing the primary results, a stricter diagnostic was added without tuning any primary settings: all generator coefficients and every bias were frozen, leaving only the 171 coordinate scalars trainable. The remaining 107 fixed scalars still count toward stored model size. This diagnostic isolates whether coordinate disparities themselves can learn; it is not part of a preregistered model-selection sweep.

| Task | Initial validation MSE | Selected validation MSE | Held-out test MSE | Test MSE after coordinate shuffling |
|---|---:|---:|---:|---:|
| Smooth interactions | 0.905626 | 0.409742 | 0.410681 | 0.989053 |
| Independent dense teacher | 1.096604 | 0.308158 | 0.308693 | 1.018105 |

Values are means over three seeds. Every coordinate-only run improved validation error. The audit verified that all non-coordinate tensors remained bitwise unchanged. Common shifts of all endpoints in a layer changed predictions by at most 4.77e-7 across all disparity arms and controls, consistent with floating-point rounding and dependence on differences. Together these checks support the narrow claim that relative coordinates can be trained and used to generate inference weights. They do not establish extra independent capacity, superior accuracy, or a language-model benefit.

The complete experiment ran locally on CPU; no cloud resources or external datasets were used. Reproduction: run `run.py --output <new-directory>` and then `verify.py --results <new-directory>` from the experiment directory. The source and configuration are adjacent to this results directory. The protocol records their SHA-256 hashes.
