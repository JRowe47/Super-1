"""Local synthetic feasibility experiment; no external data or cloud resources."""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import time

import torch
from torch import nn


class DisparityLayer(nn.Module):
    def __init__(self, inputs, outputs, dimensions, generator_width):
        super().__init__()
        # One shared coordinate space for both endpoint sets in this layer.
        self.coordinates = nn.Parameter(torch.randn(inputs + outputs, dimensions))
        self.inputs = inputs
        self.generator = nn.Sequential(nn.Linear(dimensions, generator_width),
                                       nn.Tanh(), nn.Linear(generator_width, 1))
        self.bias = nn.Parameter(torch.zeros(outputs))

    def weight(self):
        p = self.coordinates
        differences = p[self.inputs:, None, :] - p[None, :self.inputs, :]
        return self.generator(differences).squeeze(-1) / math.sqrt(self.inputs)

    def forward(self, x):
        return nn.functional.linear(x, self.weight(), self.bias)


def make_model(kind, c, dense_width):
    if kind == "dense_matched":
        return nn.Sequential(nn.Linear(c["input_dim"], dense_width), nn.Tanh(),
                             nn.Linear(dense_width, 1))
    model = nn.Sequential(
        DisparityLayer(c["input_dim"], c["hidden_width"], c["coordinate_dim"], c["generator_width"]),
        nn.Tanh(),
        DisparityLayer(c["hidden_width"], 1, c["coordinate_dim"], c["generator_width"]))
    for layer in (model[0], model[2]):
        if kind == "frozen_coordinates":
            layer.coordinates.requires_grad_(False)
        if kind == "frozen_generator":
            for parameter in layer.generator.parameters():
                parameter.requires_grad_(False)
    return model


def count(model, trainable=False):
    return sum(p.numel() for p in model.parameters() if not trainable or p.requires_grad)


def dataset(task, seed, c):
    rng = torch.Generator().manual_seed(seed + 10000)
    total = sum(c[k] for k in ("train_examples", "validation_examples", "test_examples"))
    x = torch.rand(total, c["input_dim"], generator=rng) * 2 - 1
    if task == "smooth_interactions":
        y = (torch.sin(2*x[:, 0] + x[:, 1]) + x[:, 2]*x[:, 3]
             + .5*torch.cos(3*x[:, 4]) + .3*x[:, 5]*x[:, 6]*x[:, 7])[:, None]
    elif task == "independent_dense_teacher":
        # Teacher uses unconstrained random dense weights, never disparity weights.
        a = torch.randn(c["input_dim"], c["teacher_width"], generator=rng)
        b = torch.randn(c["teacher_width"], generator=rng)
        v = torch.randn(c["teacher_width"], 1, generator=rng)
        y = torch.tanh(x @ a + b) @ v
    else:
        raise ValueError(task)
    n, m = c["train_examples"], c["validation_examples"]
    mean, std = y[:n].mean(), y[:n].std()
    y = (y-mean)/std
    return (x[:n], y[:n]), (x[n:n+m], y[n:n+m]), (x[n+m:], y[n+m:])


def evaluate(model, data):
    with torch.no_grad():
        return float((model(data[0])-data[1]).square().mean())


def run_one(kind, task, seed, c, width, out):
    torch.manual_seed(seed)
    model = make_model(kind, c, width)
    train, validation, test = dataset(task, seed, c)
    initial = copy.deepcopy(model.state_dict())
    initial_test = None  # Test is evaluated only after validation checkpoint selection.
    initial_validation = evaluate(model, validation)
    optimizer = torch.optim.Adam(model.parameters(), lr=c["learning_rate"])
    batches = torch.Generator().manual_seed(seed + 20000)
    best_loss, best_step, best = initial_validation, 0, initial
    history = [{"step": 0, "validation_mse": best_loss}]
    started = time.perf_counter()
    for step in range(1, c["steps"]+1):
        indices = torch.randint(len(train[0]), (c["batch_size"],), generator=batches)
        optimizer.zero_grad(set_to_none=True)
        loss = (model(train[0][indices])-train[1][indices]).square().mean()
        if not torch.isfinite(loss):
            raise RuntimeError("Nonfinite training loss")
        loss.backward()
        optimizer.step()
        if step % c["validation_interval"] == 0 or step == c["steps"]:
            value = evaluate(model, validation)
            history.append({"step": step, "validation_mse": value})
            if value < best_loss:
                best_loss, best_step, best = value, step, copy.deepcopy(model.state_dict())
    seconds = time.perf_counter()-started
    model.load_state_dict(best)
    test_mse = evaluate(model, test)
    record = dict(task=task, seed=seed, model=kind, stored_parameters=count(model),
                  trainable_parameters=count(model, True), initial_validation_mse=initial_validation,
                  best_validation_mse=best_loss, best_step=best_step, test_mse=test_mse,
                  test_r2=1-test_mse/float(test[1].var(unbiased=False)),
                  training_seconds=seconds, history=history)
    with torch.no_grad():
        probe = test[0][:c["batch_size"]]
        reference = model(probe)
        start = time.perf_counter()
        for _ in range(c["inference_repetitions"]):
            model(probe)
        record["inference_ms_per_batch"] = (time.perf_counter()-start)*1000/c["inference_repetitions"]
        if kind != "dense_matched":
            record["generated_weights"] = sum(layer.weight().numel() for layer in (model[0], model[2]))
            record["coordinate_change_l2"] = sum(float((model[i].coordinates-initial[f"{i}.coordinates"]).square().sum()) for i in (0,2))**.5
            for layer in (model[0], model[2]):
                layer.coordinates.add_(torch.linspace(-.7, .9, c["coordinate_dim"]))
            record["common_shift_max_error"] = float((model(probe)-reference).abs().max())
            model.load_state_dict(best)
            # Destructive ablation is applied to a copy of the selected model only.
            for layer in (model[0], model[2]):
                permutation = torch.randperm(len(layer.coordinates))
                layer.coordinates.copy_(layer.coordinates[permutation])
            record["shuffled_coordinates_test_mse"] = evaluate(model, test)
            model.load_state_dict(best)
    checkpoint = out / f"{task}-{seed}-{kind}.pt"
    torch.save(best, checkpoint)
    record["checkpoint_sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    print(json.dumps({k:v for k,v in record.items() if k != "history"}), flush=True)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path(__file__).with_name("config.json"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    c = json.loads(args.config.read_text())
    if c["input_dim"] != 8:
        raise ValueError("The analytic task is defined for eight inputs")
    torch.set_num_threads(c["threads"])
    torch.use_deterministic_algorithms(True)
    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    target_count = count(make_model("disparity", c, 1))
    width = min(range(1, target_count+1), key=lambda w: abs((c["input_dim"]+2)*w+1-target_count))
    protocol = dict(config=c, dense_width=width, torch_version=torch.__version__, device="cpu",
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    config_sha256=hashlib.sha256(args.config.read_bytes()).hexdigest(),
                    selection="lowest validation MSE, identical minibatches and step budget",
                    tuning="one preregistered shared learning rate, no post-result tuning",
                    scope="synthetic feasibility only; no language-model or capacity theorem claim")
    (out/"PROTOCOL.json").write_text(json.dumps(protocol, indent=2))
    records = []
    for task in c["tasks"]:
        for seed in c["seeds"]:
            for kind in ("disparity", "dense_matched", "frozen_coordinates", "frozen_generator"):
                records.append(run_one(kind, task, seed, c, width, out))
                (out/"RESULT.json").write_text(json.dumps(records, indent=2, allow_nan=False))
    os.environ.setdefault("MPLCONFIGDIR", str(out/"matplotlib"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, len(c["tasks"]), figsize=(12,4), squeeze=False)
    lines = ["# Learned disparity coordinates: local feasibility test", "",
             "Synthetic held-out regression; identical data, minibatches, training steps, and shared learning rate. Checkpoints selected using validation only. Frozen controls retain the same stored parameters but train fewer of them.", "",
             "| Task | Model | Stored / trainable | Mean test MSE | Mean R2 | Mean training seconds |", "|---|---|---:|---:|---:|---:|"]
    for axis, task in zip(axes[0], c["tasks"]):
        for kind in ("disparity", "dense_matched", "frozen_coordinates", "frozen_generator"):
            rows = [r for r in records if r["task"]==task and r["model"]==kind]
            average = lambda key: sum(r[key] for r in rows)/len(rows)
            curves = torch.tensor([[h["validation_mse"] for h in r["history"]] for r in rows])
            axis.plot([h["step"] for h in rows[0]["history"]], curves.mean(0), label=kind)
            lines.append(f"| {task} | {kind} | {rows[0]['stored_parameters']} / {rows[0]['trainable_parameters']} | {average('test_mse'):.6f} | {average('test_r2'):.4f} | {average('training_seconds'):.2f} |")
        axis.set(title=task.replace('_',' '), xlabel="Optimizer steps", ylabel="Validation MSE (mean of three seeds)", yscale="log")
        axis.legend(fontsize=8)
        axis.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(out/"progress.png", dpi=180)
    lines += ["", "The generator evaluates a shared nonlinear function on coordinate differences. Both coordinates and generator coefficients are included in parameter counts. The effective weights are input independent in this first experiment. Pairwise differences are dependent; this does not establish extra independent information capacity. Generating weights adds inference computation; inference timings include this cost. Three seeds are a preliminary comparison, not a broad superiority claim.", "", "Full per-seed results, shift invariance, coordinate changes, ablation errors, timings, and checkpoint hashes are in RESULT.json."]
    (out/"REPORT.md").write_text('\n'.join(lines)+'\n')


if __name__ == "__main__":
    main()
