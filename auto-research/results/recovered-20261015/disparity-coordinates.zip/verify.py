"""Audit saved results and add a disclosed, post-primary coordinate-only control."""
import argparse
import hashlib
import json
from pathlib import Path

import torch
import run as experiment


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args()
    root = args.results
    protocol = json.loads((root/"PROTOCOL.json").read_text())
    records = json.loads((root/"RESULT.json").read_text())
    c, width = protocol["config"], protocol["dense_width"]
    torch.set_num_threads(c["threads"])
    torch.use_deterministic_algorithms(True)
    assert hashlib.sha256(Path(experiment.__file__).read_bytes()).hexdigest() == protocol["source_sha256"]
    assert len(records) == len(c["tasks"])*len(c["seeds"])*4
    for record in records:
        checkpoint = root/f"{record['task']}-{record['seed']}-{record['model']}.pt"
        assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == record["checkpoint_sha256"]
        model = experiment.make_model(record["model"], c, width)
        model.load_state_dict(torch.load(checkpoint, weights_only=True))
        train, valid, test = experiment.dataset(record["task"], record["seed"], c)
        assert experiment.evaluate(model, test) == record["test_mse"]
        assert experiment.evaluate(model, valid) == record["best_validation_mse"]
        assert record["best_validation_mse"] == min(r["validation_mse"] for r in record["history"])
        assert experiment.count(model) == record["stored_parameters"]
        assert experiment.count(model, True) == record["trainable_parameters"]
    out = root/"coordinate-only-control"
    out.mkdir(exist_ok=False)
    (out/"PROTOCOL.json").write_text(json.dumps({
        "timing": "Added after primary results to isolate coordinate learning; no primary settings tuned",
        "config": c, "fixed": "All generator coefficients and all output biases",
        "trainable": "Only endpoint coordinates", "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    }, indent=2))
    factory = experiment.make_model

    def coordinates_only(kind, config, dense_width):
        model = factory("frozen_generator", config, dense_width)
        for layer in (model[0], model[2]):
            layer.bias.requires_grad_(False)
        return model

    experiment.make_model = coordinates_only
    controls = []
    for task in c["tasks"]:
        for seed in c["seeds"]:
            row = experiment.run_one("coordinates_only", task, seed, c, width, out)
            torch.manual_seed(seed)
            initial = coordinates_only("coordinates_only", c, width)
            saved = torch.load(out/f"{task}-{seed}-coordinates_only.pt", weights_only=True)
            for name, value in initial.state_dict().items():
                if not name.endswith("coordinates"):
                    assert torch.equal(value, saved[name]), name
            assert row["coordinate_change_l2"] > 0
            assert row["common_shift_max_error"] < 1e-5
            controls.append(row)
    (out/"RESULT.json").write_text(json.dumps(controls, indent=2, allow_nan=False))
    summary = {"primary_checkpoints_verified": len(records), "exact_metric_reproduction": True,
               "validation_selection_verified": True, "coordinate_only_fixed_parameters_verified": True,
               "coordinate_only_models": len(controls), "primary_config_changed": False}
    (root/"VERIFICATION.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
