"""Verify package structure, registered artifacts, manifest, and secrets."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "provenance" / "package_spec.json"
SECRET_PATTERNS = {
    "openai_key": re.compile(rb"sk-[A-Za-z0-9_-]{32,}"),
    "google_private_key": re.compile(rb'"private_key"\s*:\s*"-----BEGIN'),
    "aws_access_key": re.compile(rb"AKIA[0-9A-Z]{16}"),
    "github_token": re.compile(rb"gh[pousr]_[A-Za-z0-9]{30,}"),
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file() and path.name != "MANIFEST.sha256")


def main() -> None:
    spec = json.loads(SPEC.read_text())
    required = set(spec["required_files"])
    required.update(spec["registered_artifact_hashes"])
    missing = sorted(name for name in required if not (ROOT / name).is_file())
    if missing:
        raise FileNotFoundError(f"missing required files: {missing}")
    for path in ROOT.rglob("*.json"):
        json.loads(path.read_text())
    pdf = ROOT / "docs" / "hierarchy_vs_transformer_progress_report.pdf"
    if pdf.read_bytes()[:5] != b"%PDF-":
        raise ValueError("report does not have a PDF header")
    for relative, expected in spec["registered_artifact_hashes"].items():
        actual = digest(ROOT / relative)
        if actual != expected:
            raise ValueError(
                f"registered artifact mismatch: {relative}: {actual} != {expected}")
    findings = []
    for path in files():
        data = path.read_bytes()
        for kind, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                findings.append(f"{kind}: {path.relative_to(ROOT)}")
    if findings:
        raise ValueError("possible credentials found: " + "; ".join(findings))
    manifest = ROOT / "MANIFEST.sha256"
    if not manifest.is_file():
        raise FileNotFoundError("MANIFEST.sha256 is missing")
    expected_manifest = {}
    for line in manifest.read_text().splitlines():
        checksum, relative = line.split("  ", 1)
        expected_manifest[relative] = checksum
    actual_manifest = {
        str(path.relative_to(ROOT)): digest(path) for path in files()
    }
    if actual_manifest != expected_manifest:
        added = sorted(set(actual_manifest) - set(expected_manifest))
        removed = sorted(set(expected_manifest) - set(actual_manifest))
        changed = sorted(
            name for name in set(actual_manifest) & set(expected_manifest)
            if actual_manifest[name] != expected_manifest[name])
        raise ValueError(
            f"manifest mismatch: added={added}, removed={removed}, changed={changed}")
    print(json.dumps({
        "status": "PASS",
        "files": len(actual_manifest),
        "registered_artifacts": len(spec["registered_artifact_hashes"]),
    }))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"package verification: FAIL: {error}", file=sys.stderr)
        raise
