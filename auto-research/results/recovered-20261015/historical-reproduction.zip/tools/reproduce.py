"""Single manifest-driven interface for reproducing the completed study."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
EXPERIMENTS = SOURCE / "representation_experiments"
BASE_CONFIG = (
    EXPERIMENTS / "configs" / "qwen06b_matched_hierarchy_function_v1.json")
DATA_IDENTITY = ROOT / "provenance" / "data_identity.json"
EXPECTED = ROOT / "evidence" / "expected_metrics.json"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def environment() -> dict[str, str]:
    result = dict(os.environ)
    result["PYTHONPATH"] = str(SOURCE)
    return result


def verify_data(data_dir: Path) -> dict:
    identity = load_json(DATA_IDENTITY)["original_completed_suite_hashes"]
    report = {"status": "PASS", "files": {}}
    for name in ("train.bin", "val.bin"):
        path = data_dir / name
        expected = identity[name]
        if not path.is_file():
            raise FileNotFoundError(path)
        actual = {"bytes": path.stat().st_size, "sha256": sha256(path)}
        actual["expected_bytes"] = int(expected["bytes"])
        actual["expected_sha256"] = expected["sha256"]
        actual["match"] = (
            actual["bytes"] == actual["expected_bytes"]
            and actual["sha256"] == actual["expected_sha256"])
        report["files"][name] = actual
        if not actual["match"]:
            report["status"] = "FAIL"
    if report["status"] != "PASS":
        raise ValueError(json.dumps(report, indent=2))
    return report


def prepare_data(data_dir: Path) -> None:
    assets = load_json(ROOT / "provenance" / "assets.json")
    data = load_json(DATA_IDENTITY)["builder_contract"]
    command = [
        sys.executable, str(SOURCE / "prepare_pythia_data.py"),
        "--tokenizer", data["tokenizer"],
        "--dataset", data["dataset"],
        "--subset", data["subset"],
        "--split", data["split"],
        "--text_column", data["text_column"],
        "--train_tokens", str(data["train_tokens"]),
        "--val_tokens", str(data["validation_tokens"]),
        "--token_dtype", assets["training_corpus"]["token_dtype"],
        "--out", str(data_dir.resolve()),
    ]
    subprocess.run(command, check=True, env=environment())
    print(json.dumps(verify_data(data_dir.resolve()), indent=2))


def materialized_config(data_dir: Path, run_dir: Path, teacher: str | None) -> Path:
    config = load_json(BASE_CONFIG)
    config["data"] = str(data_dir.resolve())
    if teacher:
        config["teacher"] = teacher
    path = run_dir / "reproduction_config.json"
    encoded = json.dumps(config, indent=2, sort_keys=True) + "\n"
    if path.exists():
        if path.read_text() != encoded:
            raise RuntimeError(
                f"{path} exists with different settings; use a new run directory")
    else:
        run_dir.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(encoded)
        os.replace(temporary, path)
    return path


def run_study(args: argparse.Namespace) -> None:
    data_dir = Path(args.data_dir).expanduser().resolve()
    run_dir = Path(args.run_dir).expanduser().resolve()
    verify_data(data_dir)
    config_path = materialized_config(data_dir, run_dir, args.teacher)
    env = environment()
    if not args.allow_network:
        env["HF_HUB_OFFLINE"] = "1"
        env["TRANSFORMERS_OFFLINE"] = "1"
    if args.arm:
        config = load_json(config_path)
        if args.arm not in config["arms"]:
            raise KeyError(f"unknown arm: {args.arm}")
        arm_dir = run_dir / args.arm
        arm_dir.mkdir(parents=True, exist_ok=True)
        env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        result_path = arm_dir / "result.json"
        if not result_path.exists():
            subprocess.run([
                sys.executable, "-u", str(EXPERIMENTS / "distribution_distillation.py"),
                "--config", str(config_path), "--arm", args.arm,
                "--out", str(arm_dir),
            ], check=True, env=env)
        benchmark_path = arm_dir / "benchmarks.json"
        if not benchmark_path.exists():
            subprocess.run([
                sys.executable, "-u", str(EXPERIMENTS / "distribution_benchmarks.py"),
                "--config", str(config_path), "--arm", args.arm,
                "--checkpoint", str(arm_dir / "student_final.pt"),
                "--limit", str(config["benchmark"]["limit"]),
                "--out", str(benchmark_path),
            ], check=True, env=env)
        return
    subprocess.run([
        sys.executable, "-u", str(EXPERIMENTS / "run_matched_hierarchy_suite.py"),
        "--config", str(config_path), "--out", str(run_dir),
        "--gpus", args.gpus,
    ], check=True, env=env)


def observed_arm(run_dir: Path, arm: str) -> dict:
    result = load_json(run_dir / arm / "result.json")
    benchmark = load_json(run_dir / arm / "benchmarks.json")
    metrics = result["metrics"]
    return {
        "architecture": result["architecture"],
        "width": int(result["width"]),
        "stored_parameters": int(result["stored_parameters"]),
        "steps": int(result["steps"]),
        "tokens": int(result["tokens"]),
        "ce": {
            "512": float(metrics["student_ce"]),
            "1024": float(metrics["long_context"]["1024"]["student_ce"]),
            "2048": float(metrics["long_context"]["2048"]["student_ce"]),
        },
        "benchmark_mean": float(benchmark["mean_score"]),
    }


def verify_results(run_dir: Path, allow_partial: bool) -> dict:
    expected = load_json(EXPECTED)
    common = expected["common"]
    ce_band = float(expected["fresh_run_diagnostics"][
        "fixed_ce_absolute_reference_band"])
    benchmark_band = float(expected["fresh_run_diagnostics"][
        "benchmark_mean_absolute_reference_band"])
    report = {"status": "PASS", "arms": {}, "primary_relation": None}
    observed = {}
    for arm, reference in expected["arms"].items():
        result_path = run_dir / arm / "result.json"
        benchmark_path = run_dir / arm / "benchmarks.json"
        if not result_path.exists() or not benchmark_path.exists():
            if allow_partial:
                report["arms"][arm] = {"status": "MISSING"}
                continue
            raise FileNotFoundError(f"missing completed result/benchmark for {arm}")
        row = observed_arm(run_dir, arm)
        observed[arm] = row
        structural = {
            "architecture": row["architecture"] == reference["architecture"],
            "width": row["width"] == int(reference["width"]),
            "stored_parameters": row["stored_parameters"] == int(
                reference["stored_parameters"]),
            "steps": row["steps"] == int(common["steps"]),
            "tokens": row["tokens"] == int(common["executed_training_tokens"]),
        }
        diagnostics = {
            "ce_absolute_delta": {
                context: row["ce"][context] - float(reference["ce"][context])
                for context in common["contexts"]
                for context in [str(context)]
            },
            "benchmark_mean_delta": (
                row["benchmark_mean"] - float(reference["benchmark"]["mean"])),
        }
        diagnostics["within_reference_band"] = (
            all(abs(value) <= ce_band
                for value in diagnostics["ce_absolute_delta"].values())
            and abs(diagnostics["benchmark_mean_delta"]) <= benchmark_band)
        status = "PASS" if all(structural.values()) else "FAIL"
        report["arms"][arm] = {
            "status": status, "structural": structural,
            "observed": row, "diagnostics": diagnostics,
        }
        if status == "FAIL":
            report["status"] = "FAIL"
    comparison = expected["primary_comparison"]
    reference_name = comparison["reference"]
    candidate_name = comparison["candidate"]
    if reference_name in observed and candidate_name in observed:
        reference = observed[reference_name]
        candidate = observed[candidate_name]
        relation = {
            "lower_ce_at_all_contexts": all(
                candidate["ce"][str(context)] < reference["ce"][str(context)]
                for context in common["contexts"]),
            "benchmark_mean_not_lower": (
                candidate["benchmark_mean"] >= reference["benchmark_mean"]),
        }
        relation["status"] = "PASS" if all(relation.values()) else "FAIL"
        report["primary_relation"] = relation
        if relation["status"] == "FAIL":
            report["status"] = "FAIL"
    elif not allow_partial:
        report["status"] = "FAIL"
        report["primary_relation"] = {"status": "MISSING"}
    return report


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    subparsers = result.add_subparsers(dest="command", required=True)
    prepare = subparsers.add_parser("prepare-data")
    prepare.add_argument("--data-dir", required=True)
    check = subparsers.add_parser("verify-data")
    check.add_argument("--data-dir", required=True)
    subparsers.add_parser("smoke")
    run = subparsers.add_parser("run")
    run.add_argument("--data-dir", required=True)
    run.add_argument("--run-dir", required=True)
    run.add_argument("--gpus", default="0,1,2,3")
    run.add_argument("--gpu", default="0")
    run.add_argument("--arm")
    run.add_argument("--teacher", help="prefetched teacher snapshot path or model ID")
    run.add_argument("--allow-network", action="store_true")
    verify = subparsers.add_parser("verify-results")
    verify.add_argument("--run-dir", required=True)
    verify.add_argument("--allow-partial", action="store_true")
    return result


def main() -> None:
    args = parser().parse_args()
    if args.command == "prepare-data":
        prepare_data(Path(args.data_dir).expanduser())
    elif args.command == "verify-data":
        print(json.dumps(verify_data(Path(args.data_dir).expanduser()), indent=2))
    elif args.command == "smoke":
        subprocess.run([
            sys.executable, str(EXPERIMENTS / "smoke_matched_hierarchy.py"),
            "--config", str(BASE_CONFIG),
        ], check=True, env=environment())
    elif args.command == "run":
        run_study(args)
    elif args.command == "verify-results":
        report = verify_results(
            Path(args.run_dir).expanduser().resolve(), args.allow_partial)
        print(json.dumps(report, indent=2))
        if report["status"] != "PASS":
            raise SystemExit(1)


if __name__ == "__main__":
    main()
