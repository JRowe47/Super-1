"""Prefetch registered model and benchmark snapshots for offline execution."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-dir")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    assets = json.loads((ROOT / "provenance" / "assets.json").read_text())
    try:
        from datasets import load_dataset
        from huggingface_hub import snapshot_download
    except ImportError as error:
        raise RuntimeError("install source/requirements.txt first") from error
    cache_dir = (
        str(Path(args.cache_dir).expanduser().resolve()) if args.cache_dir else None)
    teacher = assets["teacher"]
    teacher_path = snapshot_download(
        repo_id=teacher["repo_id"],
        revision=teacher["observed_cache_revision"],
        cache_dir=cache_dir,
    )
    datasets = {}
    for name, item in assets["benchmark_datasets"].items():
        options = {
            "path": item["repo_id"],
            "split": item["split"],
            "revision": item["observed_cache_revision"],
        }
        if item.get("config"):
            options["name"] = item["config"]
        loaded = load_dataset(**options)
        datasets[name] = {
            "rows": len(loaded),
            "repo_id": item["repo_id"],
            "revision": item["observed_cache_revision"],
        }
    payload = {
        "status": "complete",
        "teacher_snapshot": teacher_path,
        "benchmark_datasets": datasets,
    }
    output = Path(args.out).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, output)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
