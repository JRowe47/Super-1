"""Capture runtime and accelerator provenance without changing the system."""
from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from importlib import metadata
from pathlib import Path


PACKAGES = [
    "torch", "transformers", "datasets", "huggingface-hub",
    "safetensors", "numpy", "accelerate",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    payload = {
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "packages": {},
        "cuda": {},
    }
    for package in PACKAGES:
        try:
            payload["packages"][package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            payload["packages"][package] = None
    try:
        import torch
        payload["cuda"] = {
            "available": torch.cuda.is_available(),
            "torch_cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "devices": [
                {
                    "index": index,
                    "name": torch.cuda.get_device_name(index),
                    "capability": list(torch.cuda.get_device_capability(index)),
                }
                for index in range(torch.cuda.device_count())
            ],
        }
    except Exception as error:
        payload["cuda"] = {"capture_error": repr(error)}
    output = Path(args.out).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(encoded)
    os.replace(temporary, output)
    print(output)


if __name__ == "__main__":
    main()
