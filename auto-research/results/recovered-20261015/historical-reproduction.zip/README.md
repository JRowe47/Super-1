# Hierarchy vs. transformer: completed-result reproduction bundle

This bundle packages the code, immutable experiment manifest, original result
artifacts, provenance, and verification tools for the completed equal-storage
Qwen3-0.6B study behind the accompanying report.

The defensible result is:

- both models trained for exactly 4,883 optimizer steps / 10,000,384 tokens;
- the matched transformer used 119,041,536 stored parameters;
- the pure hierarchy used 119,694,800 stored parameters;
- fixed held-out CE favored hierarchy by 16.35% at 512 tokens, 40.70% at
  1,024 tokens, and 50.30% at 2,048 tokens;
- exact limit-1000 benchmark mean was 0.280206 for hierarchy versus 0.257500
  for the matched transformer;
- recurrent state stayed at 5,504 bytes per sequence, while transformer state
  grew from 7,471,104 bytes at 512 tokens to 29,884,416 bytes at 2,048.

The benchmark statement refers to ARC-Easy, HellaSwag, LAMBADA OpenAI, and
PIQA. It does not refer to the unfinished 1B-token Qwen3-1.7B run.

## Reproduction boundary

This is a lightweight code bundle. It deliberately excludes the 4.008 GB
token corpus, Hugging Face caches, and ~478 MB model checkpoints. Their exact
hashes are recorded under `provenance/` so a local copy can be verified.

Three original result/benchmark pairs are included byte-for-byte. The fourth
function-weight result is represented by a typed transcription from the
completed suite summary because its full remote artifact was not present in
the local workspace.

The original experiment manifest is exact. The included Python source is a
later, backward-compatible research snapshot containing the same architectures
and training path plus additive follow-up features. The hashes of both the
originally deployed core files and the included snapshot are recorded in
`provenance/source_identity.json`. The original byte-identical source remains
on a preserved, terminated cloud boot disk and was not reattached merely to
assemble this archive. Therefore this package supports scientific
reproduction, but it does not claim a bit-for-bit code rerun.

## Quick start

Use Python 3.10+ and an A100-class CUDA worker. From the package root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r source/requirements.txt
python tools/verify_package.py
python tools/reproduce.py smoke
```

Verify an existing exact corpus:

```bash
python tools/reproduce.py verify-data --data-dir /path/to/qwen3-06b-representation
```

Or regenerate it from the registered tokenizer and FineWeb-Edu stream:

```bash
python tools/reproduce.py prepare-data --data-dir /path/to/qwen3-06b-representation
```

Run one arm on one GPU:

```bash
python tools/reproduce.py run \
  --data-dir /path/to/qwen3-06b-representation \
  --run-dir /path/to/runs/qwen06b-matched-hierarchy-function-v1 \
  --gpu 0 \
  --arm hierarchical_qwen_full_kl
```

Run the complete four-arm study on four GPUs:

```bash
python tools/reproduce.py run \
  --data-dir /path/to/qwen3-06b-representation \
  --run-dir /path/to/runs/qwen06b-matched-hierarchy-function-v1 \
  --gpus 0,1,2,3
```

The launcher is resume-safe: completed `result.json` and `benchmarks.json`
artifacts are skipped, while unfinished arms resume from `checkpoint.pt`.
Model and benchmark assets must already be in the selected Hugging Face cache
because the frozen launchers run offline after prefetch.

Validate a completed rerun against the original evidence:

```bash
python tools/reproduce.py verify-results \
  --run-dir /path/to/runs/qwen06b-matched-hierarchy-function-v1
```

The verifier reports exact identity separately from statistical reproduction.
It never converts a smaller improvement into a fabricated failure: the primary
scientific relation is simply lower CE and no worse benchmark mean at matched
tokens/storage. Reference bands are displayed as diagnostics.

## Package map

- `source/`: training, model, evaluation, benchmark, and data-preparation code.
- `source/representation_experiments/configs/`: immutable 10M-token manifest.
- `evidence/original_results/`: original byte-identical JSON artifacts.
- `evidence/expected_metrics.json`: machine-readable completed metrics.
- `provenance/`: data, source, environment, checkpoint, and asset identities.
- `tools/reproduce.py`: data, smoke, run, and result-verification interface.
- `tools/verify_package.py`: package hashes, JSON/PDF, and secret scan.
- `docs/hierarchy_vs_transformer_progress_report.pdf`: charted report.

Read `REPRODUCIBILITY.md` before interpreting a fresh rerun.
