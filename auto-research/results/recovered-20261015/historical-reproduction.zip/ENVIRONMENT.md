# Environment

## Recorded execution environment

The completed study used Linux CUDA workers with NVIDIA A100 GPUs and BF16
teacher/student computation. The actual training environment and the later
benchmark-offload environment were aligned to:

- Python 3.10.12;
- PyTorch 2.11.0+cu130;
- Transformers 5.12.1;
- Datasets 5.0.1;
- Safetensors 0.8.0;
- NumPy 2.2.6;
- Hugging Face Hub 1.26.1;
- NVIDIA driver 580.159.03 and CUDA 13.0.

The `+cu130` build may not be available from public package indexes.
`source/requirements.txt` therefore specifies compatible public lower bounds.
For the closest rerun, create a CUDA image with the recorded versions or use a
single frozen environment for both training and benchmarks, then capture it:

```bash
python tools/capture_environment.py --out /path/to/run/environment.json
```

## Hardware expectation

Each arm was designed for one A100-class GPU. Four GPUs reproduce the four arms
in parallel; one GPU can run them sequentially. The estimated MAC advantage of
the recurrent hierarchy did not translate to prototype wall-clock speed: the
Python recurrent implementation was substantially slower than the optimized
transformer kernel. Preserve both facts when reporting efficiency.

## Offline assets

The launchers set `HF_HUB_OFFLINE=1`. Prefetch the teacher/tokenizer and the four
benchmark datasets before starting training. Registered identifiers and known
cache revisions are in `provenance/assets.json`.
