# Reproducibility contract

## What is matched

The manifest fixes the teacher model ID, vocabulary, token dtype, 120M stored
parameter ceiling, context lengths, data order, 10M nominal-token target,
optimizer, schedule, random seed, CE/KL weights, temperature mixture, fixed
evaluation positions, and benchmark limit.

At batch size 4 and context 512, `ceil(10,000,000 / 2,048)` produces 4,883
steps and 10,000,384 executed tokens. A rerun using a different world size,
batch, context, seed, corpus bytes, or tokenizer snapshot is a new experiment.

## Levels of agreement

1. **Artifact identity:** SHA-256 matches an included original JSON or a
   registered external corpus/checkpoint. This is exact.
2. **Configuration identity:** the immutable manifest and resolved architecture,
   width, parameters, steps, and tokens match exactly.
3. **Statistical reproduction:** a fresh training run preserves the direction
   and scale of the fixed-evaluation comparison. GPU kernel/library differences
   can prevent bitwise-identical weights even with the same seed.

The result verifier reports all three levels instead of treating them as one.

## Primary comparison

The primary paired claim is pure hierarchy versus the matched transformer:

| Context | Transformer CE | Pure hierarchy CE | Relative reduction |
|---:|---:|---:|---:|
| 512 | 6.288168 | 5.260253 | 16.35% |
| 1,024 | 8.550756 | 5.070329 | 40.70% |
| 2,048 | 10.647091 | 5.291337 | 50.30% |

The hierarchy benchmark mean was 0.280206 versus 0.257500. These are four-task,
limit-1000, one-seed results without confidence intervals; they should not be
presented as a universal benchmark estimate.

## Function-weight interpretation

The local-attention function-weight arm beat the matched transformer, but not
the pure hierarchy. The completed suite therefore established the hierarchy
advantage, not an added function-weight advantage. The later no-local-attention
50M study was paused before fixed evaluation, and the Qwen3-1.7B 1B-token run
was interrupted at 43,261,952 tokens. Neither supplies completed benchmark
evidence.

## Source identity limitation

The exact original config is included. Four core files were later extended in
the live research tree. Their original and included hashes are registered in
`provenance/source_identity.json`. No result is labeled bitwise reproducible
unless the original hashes are restored. This package intentionally does not
claim that stronger level of identity.

## Autonomous generation limitation

The historical `rollout_degradation` metric is teacher-forced over validation
tokens. Later true autonomous audits found recurrent repetition collapse in
multiple 5M follow-ups. Do not cite teacher-forced rollout stability as proof
of fluent 2K autonomous generation.
