# License and data notice

This archive contains original experiment code and compact result metadata.
It does not redistribute Qwen weights, Hugging Face dataset contents, model
caches, or token corpora.

Users must obtain and comply with the licenses and terms for:

- `Qwen/Qwen3-0.6B-Base`;
- `HuggingFaceFW/fineweb-edu`, subset `sample-10BT`;
- `EleutherAI/lambada_openai`;
- `Rowan/hellaswag`;
- `allenai/ai2_arc`;
- `lighteval/piqa`;
- PyTorch, Transformers, Datasets, NumPy, Accelerate, and Safetensors.

The included PDF and JSON evidence may be shared with attribution to the study,
but benchmark and model licenses remain independent.
