"""Local production-contract tests."""
