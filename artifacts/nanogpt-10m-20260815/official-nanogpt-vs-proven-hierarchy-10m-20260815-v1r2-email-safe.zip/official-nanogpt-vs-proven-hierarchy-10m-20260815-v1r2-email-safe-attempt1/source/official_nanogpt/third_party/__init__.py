"""Vendored third-party dependencies."""
